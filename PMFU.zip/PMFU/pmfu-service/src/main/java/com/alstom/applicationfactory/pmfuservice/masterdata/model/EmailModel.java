package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type email model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailModel {
    /**
     * The EmailModel Recipients.
     */
    @NotNull(message = Constants.EMPTY_EMAIL_RECIPIENTS)
    @Size(min = Constants.INT_LENGTH_1, message = Constants.EMPTY_EMAIL_RECIPIENTS)
    private List<String> recipients;
    /**
     * The EmailModel Subject.
     */
    @NotNull(message = Constants.EMPTY_EMAIL_SUBJECT)
    @Size(min = Constants.INT_LENGTH_1, max = Constants.INT_LENGTH_500, message = Constants.EMAIL_SUBJECT_MIN_MAX)
    private String subject;
    /**
     * The EmailModel Body.
     */
    @NotNull(message = Constants.EMPTY_EMAIL_BODY)
    @Size(min = Constants.INT_LENGTH_1, max = Constants.INT_LENGTH_5000, message = Constants.EMAIL_BODY_MIN_MAX)
    private String body;
}
