package com.alstom.applicationfactory.pmfuservice.projectsetup.service;

import java.util.List;
import java.util.UUID;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpModel;

public interface ProjectSetUpService {

    /**
     * @param requestModel
     * @return project setup object.
     */
    Object searchProjectSetUp(RequestModel requestModel);

    /**
     * @param id
     * @return ProjectSetUpModel
     */
    ProjectSetUpModel viewProjectSetUp(UUID id);

    /**
     * @param id
     */
    void deleteProjectSetUpById(UUID id);

    /**
     * @param projSetUpId
     * @param mileStoneIdList
     * @param email
     */
    void deleteProjectMileStoneById(UUID projSetUpId, List<UUID> mileStoneIdList, String email);

    /**
     * @param projectSetUpModel
     * @param email
     * @return ProjectSetUpModel
     */
    ProjectSetUpModel saveProjectSetUp(ProjectSetUpModel projectSetUpModel, String email);

    /**
     * @param projSetUpId
     * @param actionId
     * @param email
     */
    void deletePuActionById(UUID projSetUpId, UUID actionId, String email);

    /**
     * @param projSetUpId
     * @param contractId
     * @param email
     */
    void deleteContractById(UUID projSetUpId, UUID contractId, String email);
}
