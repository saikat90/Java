package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.Set;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Profile model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProfileModel {
    /**
     * applicationId field.
     */
    private UUID applicationId;
    /**
     * applicationName field.
     */
    private String applicationName;
    /**
     * applicationCode field.
     */
    private String applicationCode;
    /**
     * userName field.
     */
    private String userName;
    /**
     * userEmail field.
     */
    private String userEmail;
    /**
     * permissions field.
     */
    private Set<String> permissions;
}
