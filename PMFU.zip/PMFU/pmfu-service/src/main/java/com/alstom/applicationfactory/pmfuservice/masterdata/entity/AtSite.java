package com.alstom.applicationfactory.pmfuservice.masterdata.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type ATSite.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "puatsite")
public class AtSite {
    /**
     * primary key - id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * Version of site.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * Region of Site.
     */
    @Column(name = "region", length = Constants.INT_LENGTH_50)
    private String region;

    /**
     * Site country.
     */
    @Column(name = "country", length = Constants.INT_LENGTH_50)
    private String country;

    /**
     * Site Unit.
     */
    @Column(name = "unit", length = Constants.INT_LENGTH_50)
    private String unit;

    /**
     * Site.
     */
    @Column(name = "site", length = Constants.INT_LENGTH_50)
    private String site;

    /**
     * caratCode.
     */
    @Column(name = "carat_code", length = Constants.INT_LENGTH_20, unique = true)
    private String caratCode;

    /**
     * caratName.
     */
    @Column(name = "carat_name", length = Constants.INT_LENGTH_200)
    private String caratName;

    /**
     * Site Unit Acrnym.
     */
    @Column(name = "unit_acronym", length = Constants.INT_LENGTH_100)
    private String unitAcronym;

    /**
     * Site Business.
     */
    @Column(name = "business", length = Constants.INT_LENGTH_100)
    private String business;

    /**
     * site internal margin.
     */
    @Column(name = "internal_margin")
    private Double internalMargin;

    /**
     * Site kp.
     */
    @Column(name = "kp")
    private Double kp;

    /**
     * Site ki.
     */
    @Column(name = "ki")
    private Double ki;

    /**
     * Site knpInternal.
     */
    @Column(name = "knp_internal")
    private Double knpInternal;

    /**
     * Site knpExternal.
     */
    @Column(name = "knp_external")
    private Double knpExternal;

    /**
     * Site street.
     */
    @Column(name = "street", length = Constants.INT_LENGTH_200)
    private String street;

    /**
     * Site postCode.
     */
    @Column(name = "post_code", length = Constants.INT_LENGTH_20)
    private String postCode;

    /**
     * Site town.
     */
    @Column(name = "town", length = Constants.INT_LENGTH_50)
    private String town;

    /**
     * Site state.
     */
    @Column(name = "state", length = Constants.INT_LENGTH_50)
    private String state;

    /**
     * Site segment.
     */
    @Column(name = "segment", length = Constants.INT_LENGTH_20)
    private String segment;

    /**
     * site segment not region.
     */
    @Column(nullable = false, length = Constants.INT_LENGTH_1, name = "obs_uses_segment_not_region")
    private boolean obsUsesSegmentNotRegion;

    /**
     * Site createdDate.
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     * Site modifiedDate.
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     * Site createdBy.
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     * Site mofidiedBy.
     */
    @Column(name = "updated_by")
    private String modifiedBy;
}
