package com.alstom.applicationfactory.pmfuservice.projectsetup.entity;

import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type CommodityActionPlan.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pucommodity_action_plan")
public class CommodityActionPlan {
    /**
     * CommodityActionPlan id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * CommodityActionPlan version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * CommodityActionPlan buyer name.
     */
    @Column(name = "buyer_name", length = Constants.INT_LENGTH_110)
    private String buyerName;

    /**
     * CommodityActionPlan commodity manager name.
     */
    @Column(name = "commodity_manager_name", length = Constants.INT_LENGTH_110)
    private String commodityManagerName;

    /**
     * CommodityActionPlan spqd name.
     */
    @Column(name = "spqd_name", length = Constants.INT_LENGTH_110)
    private String spqdName;

    /**
     * CommodityActionPlan eng name.
     */
    @Column(name = "eng_name", length = Constants.INT_LENGTH_110)
    private String engName;

    /**
     * CommodityActionPlan project market.
     */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pu_project_market_rev_id", referencedColumnName = Constants.COLUMN_REF_ID)
    private ProjectMarket projectMarket;

    /**
     * CommodityActionPlan actions list.
     */
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = Constants.TABLE_COMMODITY_ACTION_PLAN, cascade = CascadeType.ALL)
    private List<PuActions> puActionsList;
}
