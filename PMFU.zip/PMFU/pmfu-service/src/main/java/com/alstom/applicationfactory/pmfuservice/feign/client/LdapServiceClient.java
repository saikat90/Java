package com.alstom.applicationfactory.pmfuservice.feign.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient("ldap-service")
public interface LdapServiceClient {

    /**
     * Find users object.
     *
     * @param request the request
     * @return the object
     */
    @PostMapping("/users/search")
    Object findUsers(@RequestBody(required = false) Map<String, String> request);
}
