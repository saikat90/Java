package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type commodity action plan model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommodityActionPlanModel {

    /**
     * CommodityActionPlanModel id.
     */
    private UUID id;

    /**
     * CommodityActionPlanModel version.
     */
    @NotNull(message = "Version should not be empty")
    private Integer version;

    /**
     * CommodityActionPlanModel buyer name.
     */
    private String buyerName;

    /**
     * CommodityActionPlanModel commodity manager name.
     */
    private String commodityManagerName;

    /**
     * CommodityActionPlanModel spqd name.
     */
    private String spqdName;

    /**
     * CommodityActionPlanModel eng name.
     */
    private String engName;

    /**
     * CommodityActionPlanModel project market.
     */
    @JsonIgnore
    private ProjectMarketModel projectMarket;

    /**
     * CommodityActionPlanModel actions list.
     */
    private List<PuActionsModel> puActionsList;

}
