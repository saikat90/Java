package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alstom.applicationfactory.pmfuservice.feign.client.MasterDataServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.MasterDataService;

import lombok.extern.slf4j.Slf4j;

@Service("masterDataService")
@Slf4j
public class MasterDataServiceImpl implements MasterDataService {

    /**
     * MasterDataServiceClient.
     */
    @Autowired
    private MasterDataServiceClient masterDataServiceClient;

    @Override
    public Object getProjectData(final Map<String, Object> request) {
        log.debug("Entry:MasterDataServiceImpl:getProjectData");
        Object result = this.masterDataServiceClient.getProjectData(request);
        log.debug("Leave:MasterDataServiceImpl:getProjectData");
        return result;
    }
}
