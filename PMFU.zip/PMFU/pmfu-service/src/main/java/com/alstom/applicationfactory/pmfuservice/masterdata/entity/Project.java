package com.alstom.applicationfactory.pmfuservice.masterdata.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Project.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Project {
    /**
     * The Uniq id.
     */
    @Id
    private Long uniqId;
    /**
     * The Ct code.
     */
    @Column(name = "ct_code")
    private String ctCode;
    /**
     * The Proj name.
     */
    @Column(name = "proj_name")
    private String projName;
    /**
     * The Cust company name.
     */
    private String custCompanyName;
    /**
     * The Unit name.
     */
    private String unitName;
    /**
     * The Prj deleted.
     */
    private boolean prjDeleted;
}
