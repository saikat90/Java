package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityStatus;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUp;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.PuActions;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.AllActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractStatusGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQDeliveryGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQEventModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQMilestoneGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.KPIService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "kpiService")
@Transactional
@Slf4j
public class KPIServiceImpl implements KPIService {

    /**
     * ProjectSetUpRepository.
     */
    @Autowired
    private ProjectSetUpRepository projSetUpRepo;

    @Override
    public List<DFQEventModel> getDFQEventData(final UUID id, final String period) {
        log.debug("Entry:KPIServiceImpl:getDFQEventData");
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date today = dateFormat.parse(dateFormat.format(new Date()));
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(today);
            Date firstDate = null;
            Date lastDate = null;
            ProjectSetUp projSetUp = projSetUpRepo.findById(id).orElse(null);

            if (period.equals(Constants.WEEKLY)) {
                calendar.set(Calendar.DAY_OF_WEEK, calendar.getMinimum(Calendar.DAY_OF_WEEK));
                firstDate = calendar.getTime();
                calendar.set(Calendar.DAY_OF_WEEK, calendar.getMaximum(Calendar.DAY_OF_WEEK));
                lastDate = calendar.getTime();

            } else if (period.equals(Constants.MONTHLY)) {
                calendar.set(Calendar.DAY_OF_MONTH,
                        calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
                firstDate = calendar.getTime();
                calendar.set(Calendar.DAY_OF_MONTH,
                        calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
                lastDate = calendar.getTime();
            }

            List<DFQEventModel> dfQEventList = buildKPI(firstDate, lastDate, projSetUp);
            log.debug("Leave:KPIServiceImpl:getDFQEventData");
            return dfQEventList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    private List<DFQEventModel> buildKPI(final Date firstDate, final Date lastDate,
            final ProjectSetUp projSetUp) {
        List<DFQEventModel> dfqEventModelList = new ArrayList<>();
        projSetUp.getProjectMarketList().forEach(projectMarket -> {
            projectMarket.getProjectMilestoneList().forEach(projectMileStone -> {
                CommodityStatus comStatus = projectMileStone.getCommodityStatus();
                // Tech Input
                if (comStatus.getActualDateTechInput() != null
                        && (comStatus.getActualDateTechInput().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateTechInput())) >= 0) {
                    DFQEventModel dfqTechInputModel = new DFQEventModel();
                    dfqTechInputModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqTechInputModel.setMaterial(projectMileStone.getMaterial());
                    dfqTechInputModel.setMileStone(Constants.TECH_INPUT);
                    dfqTechInputModel.setNeedsDate(comStatus.getNeedsTechInput());
                    dfqTechInputModel.setActualDate(comStatus.getActualDateTechInput());
                    int variance = calculateDateDifference(comStatus.getNeedsTechInput(),
                            comStatus.getActualDateTechInput());
                    dfqTechInputModel.setVariance(variance);
                    dfqTechInputModel
                            .setTime(dfqTechInputModel.getVariance() <= 0 ? Constants.ON_TIME
                                    : Constants.LATE);
                    dfqTechInputModel.setStatus(comStatus.getStatusTechInput());
                    dfqEventModelList.add(dfqTechInputModel);
                }

                // Go RFQ
                if (comStatus.getActualDateGoRfq() != null
                        && (comStatus.getActualDateGoRfq().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateGoRfq())) >= 0) {
                    DFQEventModel dfqGoRfqModel = new DFQEventModel();
                    dfqGoRfqModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqGoRfqModel.setMaterial(projectMileStone.getMaterial());
                    dfqGoRfqModel.setMileStone(Constants.GO_RFQ);
                    dfqGoRfqModel.setNeedsDate(comStatus.getNeedsGoRfq());
                    dfqGoRfqModel.setActualDate(comStatus.getActualDateGoRfq());
                    int variance = calculateDateDifference(comStatus.getNeedsGoRfq(),
                            comStatus.getActualDateGoRfq());
                    dfqGoRfqModel.setVariance(variance);
                    dfqGoRfqModel.setTime(
                            dfqGoRfqModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqGoRfqModel.setStatus(comStatus.getStatusGoRfq());
                    dfqEventModelList.add(dfqGoRfqModel);
                }

                // BA
                if (comStatus.getActualDateBa() != null
                        && (comStatus.getActualDateBa().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateBa())) >= 0) {
                    DFQEventModel dfqBAModel = new DFQEventModel();
                    dfqBAModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqBAModel.setMaterial(projectMileStone.getMaterial());
                    dfqBAModel.setMileStone(Constants.BA);
                    dfqBAModel.setNeedsDate(comStatus.getNeedsBa());
                    dfqBAModel.setActualDate(comStatus.getActualDateBa());
                    int variance = calculateDateDifference(comStatus.getNeedsBa(),
                            comStatus.getActualDateBa());
                    dfqBAModel.setVariance(variance);
                    dfqBAModel.setTime(
                            dfqBAModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqBAModel.setStatus(comStatus.getStatusBa());
                    dfqEventModelList.add(dfqBAModel);
                }

                // Go Order
                if (comStatus.getActualDateGoOrder() != null
                        && (comStatus.getActualDateGoOrder().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateGoOrder())) >= 0) {
                    DFQEventModel dfqGoOrderModel = new DFQEventModel();
                    dfqGoOrderModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqGoOrderModel.setMaterial(projectMileStone.getMaterial());
                    dfqGoOrderModel.setMileStone(Constants.GO_ORDER);
                    dfqGoOrderModel.setNeedsDate(comStatus.getNeedsGoOrder());
                    dfqGoOrderModel.setActualDate(comStatus.getActualDateGoOrder());
                    int variance = calculateDateDifference(comStatus.getNeedsGoOrder(),
                            comStatus.getActualDateGoOrder());
                    dfqGoOrderModel.setVariance(variance);
                    dfqGoOrderModel.setTime(dfqGoOrderModel.getVariance() <= 0 ? Constants.ON_TIME
                            : Constants.LATE);
                    dfqGoOrderModel.setStatus(comStatus.getStatusGoOrder());
                    dfqEventModelList.add(dfqGoOrderModel);
                }

                // PGR
                if (comStatus.getActualDatePgr() != null
                        && (comStatus.getActualDatePgr().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDatePgr())) >= 0) {
                    DFQEventModel dfqPgrModel = new DFQEventModel();
                    dfqPgrModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqPgrModel.setMaterial(projectMileStone.getMaterial());
                    dfqPgrModel.setMileStone(Constants.PGR);
                    dfqPgrModel.setNeedsDate(comStatus.getNeedsPgr());
                    dfqPgrModel.setActualDate(comStatus.getActualDatePgr());
                    int variance = calculateDateDifference(comStatus.getNeedsPgr(),
                            comStatus.getActualDatePgr());
                    dfqPgrModel.setVariance(variance);
                    dfqPgrModel.setTime(
                            dfqPgrModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqPgrModel.setStatus(comStatus.getStatusPgr());
                    dfqEventModelList.add(dfqPgrModel);
                }

                // CGR
                if (comStatus.getActualDateCgr() != null
                        && (comStatus.getActualDateCgr().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateCgr())) >= 0) {
                    DFQEventModel dfqCgrModel = new DFQEventModel();
                    dfqCgrModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqCgrModel.setMaterial(projectMileStone.getMaterial());
                    dfqCgrModel.setMileStone(Constants.CGR);
                    dfqCgrModel.setNeedsDate(comStatus.getNeedsCgr());
                    dfqCgrModel.setActualDate(comStatus.getActualDateCgr());
                    int variance = calculateDateDifference(comStatus.getNeedsCgr(),
                            comStatus.getActualDateCgr());
                    dfqCgrModel.setVariance(variance);
                    dfqCgrModel.setTime(
                            dfqCgrModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqCgrModel.setStatus(comStatus.getStatusGgr());
                    dfqEventModelList.add(dfqCgrModel);
                }

                // Go Prod
                if (comStatus.getActualDateGoProd() != null
                        && (comStatus.getActualDateGoProd().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateGoProd())) >= 0) {
                    DFQEventModel dfqGoProdModel = new DFQEventModel();
                    dfqGoProdModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqGoProdModel.setMaterial(projectMileStone.getMaterial());
                    dfqGoProdModel.setMileStone(Constants.GO_PROD);
                    dfqGoProdModel.setNeedsDate(comStatus.getNeedsGoProd());
                    dfqGoProdModel.setActualDate(comStatus.getActualDateGoProd());
                    int variance = calculateDateDifference(comStatus.getNeedsGoProd(),
                            comStatus.getActualDateGoProd());
                    dfqGoProdModel.setVariance(variance);
                    dfqGoProdModel.setTime(
                            dfqGoProdModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqGoProdModel.setStatus(comStatus.getStatusGoProd());
                    dfqEventModelList.add(dfqGoProdModel);
                }

                // FAI
                if (comStatus.getActualDateFai() != null
                        && (comStatus.getActualDateFai().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateFai())) >= 0) {
                    DFQEventModel dfqFaiModel = new DFQEventModel();
                    dfqFaiModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqFaiModel.setMaterial(projectMileStone.getMaterial());
                    dfqFaiModel.setMileStone(Constants.FAI);
                    dfqFaiModel.setNeedsDate(comStatus.getNeedsFai());
                    dfqFaiModel.setActualDate(comStatus.getActualDateFai());
                    int variance = calculateDateDifference(comStatus.getNeedsFai(),
                            comStatus.getActualDateFai());
                    dfqFaiModel.setVariance(variance);
                    dfqFaiModel.setTime(
                            dfqFaiModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqFaiModel.setStatus(comStatus.getStatusFai());
                    dfqEventModelList.add(dfqFaiModel);
                }

                // FAT
                if (comStatus.getActualDateFat() != null
                        && (comStatus.getActualDateFat().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateFat())) >= 0) {
                    DFQEventModel dfqFatModel = new DFQEventModel();
                    dfqFatModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqFatModel.setMaterial(projectMileStone.getMaterial());
                    dfqFatModel.setMileStone(Constants.FAT);
                    dfqFatModel.setNeedsDate(comStatus.getNeedsFat());
                    dfqFatModel.setActualDate(comStatus.getActualDateFat());
                    int variance = calculateDateDifference(comStatus.getNeedsFat(),
                            comStatus.getActualDateFat());
                    dfqFatModel.setVariance(variance);
                    dfqFatModel.setTime(
                            dfqFatModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqFatModel.setStatus(comStatus.getStatusFat());
                    dfqEventModelList.add(dfqFatModel);
                }

                // IQA
                if (comStatus.getActualDateIqa() != null
                        && (comStatus.getActualDateIqa().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateIqa())) >= 0) {
                    DFQEventModel dfqIqaModel = new DFQEventModel();
                    dfqIqaModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqIqaModel.setMaterial(projectMileStone.getMaterial());
                    dfqIqaModel.setMileStone(Constants.IQA);
                    dfqIqaModel.setNeedsDate(comStatus.getNeedsIqa());
                    dfqIqaModel.setActualDate(comStatus.getActualDateIqa());
                    int variance = calculateDateDifference(comStatus.getNeedsIqa(),
                            comStatus.getActualDateIqa());
                    dfqIqaModel.setVariance(variance);
                    dfqIqaModel.setTime(
                            dfqIqaModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqIqaModel.setStatus(comStatus.getStatusIqa());
                    dfqEventModelList.add(dfqIqaModel);
                }

                // FQA
                if (comStatus.getActualDateFqa() != null
                        && (comStatus.getActualDateFqa().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateFqa())) >= 0) {
                    DFQEventModel dfqFqaModel = new DFQEventModel();
                    dfqFqaModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqFqaModel.setMaterial(projectMileStone.getMaterial());
                    dfqFqaModel.setMileStone(Constants.FQA);
                    dfqFqaModel.setNeedsDate(comStatus.getNeedsFqa());
                    dfqFqaModel.setActualDate(comStatus.getActualDateFqa());
                    int variance = calculateDateDifference(comStatus.getNeedsFqa(),
                            comStatus.getActualDateFqa());
                    dfqFqaModel.setVariance(variance);
                    dfqFqaModel.setTime(
                            dfqFqaModel.getVariance() <= 0 ? Constants.ON_TIME : Constants.LATE);
                    dfqFqaModel.setStatus(comStatus.getStatusFqa());
                    dfqEventModelList.add(dfqFqaModel);
                }

                // Delivery
                if (comStatus.getActualDateDelivery() != null
                        && (comStatus.getActualDateDelivery().compareTo(firstDate)
                                * lastDate.compareTo(comStatus.getActualDateDelivery())) >= 0) {
                    DFQEventModel dfqDeliveryModel = new DFQEventModel();
                    dfqDeliveryModel.setMarketCode(projectMileStone.getSupplierMarketCode());
                    dfqDeliveryModel.setMaterial(projectMileStone.getMaterial());
                    dfqDeliveryModel.setMileStone(Constants.DELIVERY);
                    dfqDeliveryModel.setNeedsDate(comStatus.getNeedsFirstNeed());
                    dfqDeliveryModel.setActualDate(comStatus.getActualDateDelivery());
                    int variance = calculateDateDifference(comStatus.getNeedsFirstNeed(),
                            comStatus.getActualDateDelivery());
                    dfqDeliveryModel.setVariance(variance);
                    dfqDeliveryModel.setTime(dfqDeliveryModel.getVariance() <= 0 ? Constants.ON_TIME
                            : Constants.LATE);
                    dfqDeliveryModel.setStatus(comStatus.getStatusDelivery());
                    dfqEventModelList.add(dfqDeliveryModel);
                }
            });
        });
        return dfqEventModelList;
    }

    private int calculateDateDifference(final Date needsDate, final Date actualDate) {
        long diff = actualDate.getTime() - needsDate.getTime();
        int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
        return diffDays;
    }

    @Override
    public List<ProjectMasterDataModel> getProjectMasterData(final UUID id) {
        log.debug("Entry:KPIServiceImpl:getProjectMasterData");
        try {
            List<ProjectMasterDataModel> projMasterDataList = new ArrayList<>();
            ProjectSetUp projSetUp = projSetUpRepo.findById(id).orElse(null);

            projSetUp.getProjectMarketList().forEach(projectMarket -> {
                projectMarket.getProjectMilestoneList().forEach(projectMileStone -> {
                    CommodityStatus comStatus = projectMileStone.getCommodityStatus();

                    if (projSetUp.getProjectId() != null) {
                        // Tech Input
                        ProjectMasterDataModel projTechInputModel = populateProjectDetails(
                                projSetUp);
                        populateMileStoneDetails(projTechInputModel, projectMileStone);
                        projTechInputModel.setMileStone(Constants.TECH_INPUT);
                        projTechInputModel.setNeedsDate(comStatus.getNeedsTechInput());
                        projTechInputModel.setForecastDate(comStatus.getForecastDateTechInput());
                        projTechInputModel.setActualDate(comStatus.getActualDateTechInput());
                        projTechInputModel.setStatus(comStatus.getStatusTechInput());
                        if (projTechInputModel.getNeedsDate() != null
                                && projTechInputModel.getActualDate() != null) {
                            projTechInputModel.setVariance(
                                    calculateDateDifference(projTechInputModel.getNeedsDate(),
                                            projTechInputModel.getActualDate()));
                            projTechInputModel.setTime(
                                    projTechInputModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                        }

                        // GO RFQ
                        ProjectMasterDataModel projGoRfqModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projGoRfqModel, projectMileStone);
                        projGoRfqModel.setMileStone(Constants.GO_RFQ);
                        if (comStatus.getDfqMilestoneGoRfq() != null
                                && comStatus.getDfqMilestoneGoRfq().equals(Constants.X)) {
                            projGoRfqModel.setApplicable(comStatus.getDfqMilestoneGoRfq());
                            projGoRfqModel.setDuration(comStatus.getDurationGoRfq());
                            projGoRfqModel.setNeedsDate(comStatus.getNeedsGoRfq());
                            projGoRfqModel.setForecastDate(comStatus.getForecastDateGoRfq());
                            projGoRfqModel.setActualDate(comStatus.getActualDateGoRfq());
                            projGoRfqModel.setStatus(comStatus.getStatusGoRfq());
                            if (projGoRfqModel.getNeedsDate() != null
                                    && projGoRfqModel.getActualDate() != null) {
                                projGoRfqModel.setVariance(
                                        calculateDateDifference(projGoRfqModel.getNeedsDate(),
                                                projGoRfqModel.getActualDate()));
                                projGoRfqModel.setTime(
                                        projGoRfqModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // BA
                        ProjectMasterDataModel projBAModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projBAModel, projectMileStone);
                        projBAModel.setMileStone(Constants.BA);
                        if (comStatus.getDfqMilestoneBa() != null
                                && comStatus.getDfqMilestoneBa().equals(Constants.X)) {
                            projBAModel.setApplicable(comStatus.getDfqMilestoneBa());
                            projBAModel.setDuration(comStatus.getDurationBa());
                            projBAModel.setNeedsDate(comStatus.getNeedsBa());
                            projBAModel.setForecastDate(comStatus.getForecastDateBa());
                            projBAModel.setActualDate(comStatus.getActualDateBa());
                            projBAModel.setStatus(comStatus.getStatusBa());
                            if (projBAModel.getNeedsDate() != null
                                    && projBAModel.getActualDate() != null) {
                                projBAModel.setVariance(calculateDateDifference(
                                        projBAModel.getNeedsDate(), projBAModel.getActualDate()));
                                projBAModel
                                        .setTime(projBAModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // GO_ORDER
                        ProjectMasterDataModel projGoOrderModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projGoOrderModel, projectMileStone);
                        projGoOrderModel.setMileStone(Constants.GO_ORDER);
                        if (comStatus.getDfqMilestoneGoOrder() != null
                                && comStatus.getDfqMilestoneGoOrder().equals(Constants.X)) {
                            projGoOrderModel.setApplicable(comStatus.getDfqMilestoneGoOrder());
                            projGoOrderModel.setDuration(comStatus.getDurationGoOrder());
                            projGoOrderModel.setNeedsDate(comStatus.getNeedsGoOrder());
                            projGoOrderModel.setForecastDate(comStatus.getForecastDateGoOrder());
                            projGoOrderModel.setActualDate(comStatus.getActualDateGoOrder());
                            projGoOrderModel.setStatus(comStatus.getStatusGoOrder());
                            if (projGoOrderModel.getNeedsDate() != null
                                    && projGoOrderModel.getActualDate() != null) {
                                projGoOrderModel.setVariance(
                                        calculateDateDifference(projGoOrderModel.getNeedsDate(),
                                                projGoOrderModel.getActualDate()));
                                projGoOrderModel.setTime(
                                        projGoOrderModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // PGR
                        ProjectMasterDataModel projPGRModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projPGRModel, projectMileStone);
                        projPGRModel.setMileStone(Constants.PGR);
                        if (comStatus.getDfqMilestonePgr() != null
                                && comStatus.getDfqMilestonePgr().equals(Constants.X)) {
                            projPGRModel.setApplicable(comStatus.getDfqMilestonePgr());
                            projPGRModel.setDuration(comStatus.getDurationPgr());
                            projPGRModel.setNeedsDate(comStatus.getNeedsPgr());
                            projPGRModel.setForecastDate(comStatus.getForecastDatePgr());
                            projPGRModel.setActualDate(comStatus.getActualDatePgr());
                            projPGRModel.setStatus(comStatus.getStatusPgr());
                            if (projPGRModel.getNeedsDate() != null
                                    && projPGRModel.getActualDate() != null) {
                                projPGRModel.setVariance(calculateDateDifference(
                                        projPGRModel.getNeedsDate(), projPGRModel.getActualDate()));
                                projPGRModel
                                        .setTime(projPGRModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // CGR
                        ProjectMasterDataModel projCGRModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projCGRModel, projectMileStone);
                        projCGRModel.setMileStone(Constants.CGR);
                        if (comStatus.getDfqMilestoneGgr() != null
                                && comStatus.getDfqMilestoneGgr().equals(Constants.X)) {
                            projCGRModel.setApplicable(comStatus.getDfqMilestoneGgr());
                            projCGRModel.setDuration(comStatus.getDurationCgr());
                            projCGRModel.setNeedsDate(comStatus.getNeedsCgr());
                            projCGRModel.setForecastDate(comStatus.getForecastDateCgr());
                            projCGRModel.setActualDate(comStatus.getActualDateCgr());
                            projCGRModel.setStatus(comStatus.getStatusGgr());
                            if (projCGRModel.getNeedsDate() != null
                                    && projCGRModel.getActualDate() != null) {
                                projCGRModel.setVariance(calculateDateDifference(
                                        projCGRModel.getNeedsDate(), projCGRModel.getActualDate()));
                                projCGRModel
                                        .setTime(projCGRModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // GO_PROD
                        ProjectMasterDataModel projGoProdModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projGoProdModel, projectMileStone);
                        projGoProdModel.setMileStone(Constants.GO_PROD);
                        if (comStatus.getDfqMilestoneGoProd() != null
                                && comStatus.getDfqMilestoneGoProd().equals(Constants.X)) {
                            projGoProdModel.setApplicable(comStatus.getDfqMilestoneGoProd());
                            projGoProdModel.setDuration(comStatus.getDurationGoProd());
                            projGoProdModel.setNeedsDate(comStatus.getNeedsGoProd());
                            projGoProdModel.setForecastDate(comStatus.getForecastDateGoProd());
                            projGoProdModel.setActualDate(comStatus.getActualDateGoProd());
                            projGoProdModel.setStatus(comStatus.getStatusGoProd());
                            if (projGoProdModel.getNeedsDate() != null
                                    && projGoProdModel.getActualDate() != null) {
                                projGoProdModel.setVariance(
                                        calculateDateDifference(projGoProdModel.getNeedsDate(),
                                                projGoProdModel.getActualDate()));
                                projGoProdModel.setTime(
                                        projGoProdModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // FAI
                        ProjectMasterDataModel projFAIModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projFAIModel, projectMileStone);
                        projFAIModel.setMileStone(Constants.FAI);
                        if (comStatus.getDfqMilestoneFai() != null
                                && comStatus.getDfqMilestoneFai().equals(Constants.X)) {
                            projFAIModel.setApplicable(comStatus.getDfqMilestoneFai());
                            projFAIModel.setDuration(comStatus.getDurationFai());
                            projFAIModel.setNeedsDate(comStatus.getNeedsFai());
                            projFAIModel.setForecastDate(comStatus.getForecastDateFai());
                            projFAIModel.setActualDate(comStatus.getActualDateFai());
                            projFAIModel.setStatus(comStatus.getStatusFai());
                            if (projFAIModel.getNeedsDate() != null
                                    && projFAIModel.getActualDate() != null) {
                                projFAIModel.setVariance(calculateDateDifference(
                                        projFAIModel.getNeedsDate(), projFAIModel.getActualDate()));
                                projFAIModel
                                        .setTime(projFAIModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // FAT
                        ProjectMasterDataModel projFATModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projFATModel, projectMileStone);
                        projFATModel.setMileStone(Constants.FAT);
                        if (comStatus.getDfqMilestoneFat() != null
                                && comStatus.getDfqMilestoneFat().equals(Constants.X)) {
                            projFATModel.setApplicable(comStatus.getDfqMilestoneFat());
                            projFATModel.setDuration(comStatus.getDurationFat());
                            projFATModel.setNeedsDate(comStatus.getNeedsFat());
                            projFATModel.setForecastDate(comStatus.getForecastDateFat());
                            projFATModel.setActualDate(comStatus.getActualDateFat());
                            projFATModel.setStatus(comStatus.getStatusFat());
                            if (projFATModel.getNeedsDate() != null
                                    && projFATModel.getActualDate() != null) {
                                projFATModel.setVariance(calculateDateDifference(
                                        projFATModel.getNeedsDate(), projFATModel.getActualDate()));
                                projFATModel
                                        .setTime(projFATModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // Delivery
                        Calendar calendar = Calendar.getInstance();
                        Date today = calendar.getTime();
                        ProjectMasterDataModel projDeliveryModel = populateProjectDetails(
                                projSetUp);
                        populateMileStoneDetails(projDeliveryModel, projectMileStone);
                        projDeliveryModel.setMileStone(Constants.DELIVERY);
                        projDeliveryModel.setApplicable(comStatus.getDfqMilestoneDelivery());
                        projDeliveryModel.setDuration(comStatus.getDurationDelivery());
                        projDeliveryModel.setNeedsDate(comStatus.getNeedsFirstNeed());
                        projDeliveryModel.setForecastDate(comStatus.getForecastDateDelivery());
                        projDeliveryModel.setActualDate(comStatus.getActualDateDelivery());
                        projDeliveryModel.setStatus(comStatus.getStatusDelivery());
                        if (projDeliveryModel.getNeedsDate() != null
                                && projDeliveryModel.getActualDate() != null) {
                            projDeliveryModel.setVariance(
                                    calculateDateDifference(projDeliveryModel.getNeedsDate(),
                                            projDeliveryModel.getActualDate()));
                            projDeliveryModel.setTime(
                                    projDeliveryModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                        } else if (projDeliveryModel.getNeedsDate() != null) {
                            projDeliveryModel.setVariance(calculateDateDifference(
                                    projDeliveryModel.getNeedsDate(), today));
                            projDeliveryModel.setTime(
                                    projDeliveryModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                        }

                        // IQA
                        ProjectMasterDataModel projIQAModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projIQAModel, projectMileStone);
                        projIQAModel.setMileStone(Constants.IQA);
                        if (comStatus.getDfqMilestoneIqa() != null
                                && comStatus.getDfqMilestoneIqa().equals(Constants.X)) {
                            projIQAModel.setApplicable(comStatus.getDfqMilestoneIqa());
                            projIQAModel.setDuration(comStatus.getDurationIqa());
                            projIQAModel.setNeedsDate(comStatus.getNeedsIqa());
                            projIQAModel.setForecastDate(comStatus.getForecastDateIqa());
                            projIQAModel.setActualDate(comStatus.getActualDateIqa());
                            projIQAModel.setStatus(comStatus.getStatusIqa());
                            if (projIQAModel.getNeedsDate() != null
                                    && projIQAModel.getActualDate() != null) {
                                projIQAModel.setVariance(calculateDateDifference(
                                        projIQAModel.getNeedsDate(), projIQAModel.getActualDate()));
                                projIQAModel
                                        .setTime(projIQAModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }

                        // FQA
                        ProjectMasterDataModel projFQAModel = populateProjectDetails(projSetUp);
                        populateMileStoneDetails(projFQAModel, projectMileStone);
                        projFQAModel.setMileStone(Constants.FQA);
                        if (comStatus.getDfqMilestoneFqa() != null
                                && comStatus.getDfqMilestoneFqa().equals(Constants.X)) {
                            projFQAModel.setApplicable(comStatus.getDfqMilestoneFqa());
                            projFQAModel.setDuration(comStatus.getDurationFqa());
                            projFQAModel.setNeedsDate(comStatus.getNeedsFqa());
                            projFQAModel.setForecastDate(comStatus.getForecastDateFqa());
                            projFQAModel.setActualDate(comStatus.getActualDateFqa());
                            projFQAModel.setStatus(comStatus.getStatusFqa());
                            if (projFQAModel.getNeedsDate() != null
                                    && projFQAModel.getActualDate() != null) {
                                projFQAModel.setVariance(calculateDateDifference(
                                        projFQAModel.getNeedsDate(), projFQAModel.getActualDate()));
                                projFQAModel
                                        .setTime(projFQAModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                        }
                        projMasterDataList.add(projTechInputModel);
                        projMasterDataList.add(projGoRfqModel);
                        projMasterDataList.add(projBAModel);
                        projMasterDataList.add(projGoOrderModel);
                        projMasterDataList.add(projPGRModel);
                        projMasterDataList.add(projCGRModel);
                        projMasterDataList.add(projGoProdModel);
                        projMasterDataList.add(projFAIModel);
                        projMasterDataList.add(projFATModel);
                        projMasterDataList.add(projDeliveryModel);
                        projMasterDataList.add(projIQAModel);
                        projMasterDataList.add(projFQAModel);
                    }
                });
            });

            log.debug("Leave:KPIServiceImpl:getProjectMasterData");
            return projMasterDataList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    private void populateMileStoneDetails(final ProjectMasterDataModel projMasterModel,
            final ProjectMilestone projectMileStone) {
        projMasterModel.setDomainCode(projectMileStone.getDomainCode());
        projMasterModel.setMarketCode(projectMileStone.getSupplierMarketCode());
        projMasterModel.setMaterial(projectMileStone.getMaterial());
    }

    private ProjectMasterDataModel populateProjectDetails(final ProjectSetUp projSetUp) {
        ProjectMasterDataModel projMDModel = new ProjectMasterDataModel();
        projMDModel.setProjectId(projSetUp.getProjectId());
        projMDModel.setProjectName(projSetUp.getProject().getProjName());
        projMDModel.setCdbCode(projSetUp.getProject().getCtCode());
        projMDModel.setRegion(projSetUp.getAtSite().getRegion());
        projMDModel.setSite(projSetUp.getAtSite().getSite());
        projMDModel.setProductLine(projSetUp.getProductLine());
        projMDModel.setPrsm(projSetUp.getPrsm().getFirstName().concat(" ")
                .concat(projSetUp.getPrsm().getLastName()));
        return projMDModel;
    }

    @Override
    public List<ContractStatusGraphModel> getContractStatus(final UUID id) {
        log.debug("Entry:KPIServiceImpl:getContractStatus");

        try {
            int perfBondYes = 0;
            int perfBondNo = 0;
            int warrantyBondYes = 0;
            int warrantyBondNo = 0;
            int poYes = 0;
            int poNo = 0;

            List<ContractStatusGraphModel> contractStatusList = new ArrayList<>();
            ContractStatusGraphModel contractStatusPerfBond = new ContractStatusGraphModel();
            contractStatusPerfBond.setYesCount(perfBondYes);
            contractStatusPerfBond.setNoCount(perfBondNo);
            contractStatusPerfBond.setContractType("Perf Bond");
            ContractStatusGraphModel contractStatusWarrantyBond = new ContractStatusGraphModel();
            contractStatusWarrantyBond.setYesCount(warrantyBondYes);
            contractStatusWarrantyBond.setNoCount(warrantyBondNo);
            contractStatusWarrantyBond.setContractType("Warranty Bond");
            ContractStatusGraphModel contractStatusPoBond = new ContractStatusGraphModel();
            contractStatusPoBond.setYesCount(poYes);
            contractStatusPoBond.setNoCount(poNo);
            contractStatusPoBond.setContractType("PO");

            ProjectSetUp projSetUp = projSetUpRepo.findById(id).orElse(null);

            projSetUp.getProjectMarketList().forEach(projectMarket -> {
                projectMarket.getCommodityContract().getContractsList().forEach(contract -> {
                    if (contract.getPerfBond() != null) {
                        if (contract.getPerfBond().equals("RECEIVED")) {
                            contractStatusPerfBond
                                    .setYesCount(contractStatusPerfBond.getYesCount() + 1);
                        } else if (contract.getPerfBond().equals("NOT_RECEIVED")) {
                            contractStatusPerfBond
                                    .setNoCount(contractStatusPerfBond.getNoCount() + 1);
                        }
                    }
                    if (contract.getWarrantyBond() != null) {
                        if (contract.getWarrantyBond().equals("RECEIVED")) {
                            contractStatusWarrantyBond
                                    .setYesCount(contractStatusWarrantyBond.getYesCount() + 1);
                        } else if (contract.getWarrantyBond().equals("NOT_RECEIVED")) {
                            contractStatusWarrantyBond
                                    .setNoCount(contractStatusWarrantyBond.getNoCount() + 1);
                        }
                    }
                    if (contract.getPo() != null) {
                        if (contract.getPo().equals("SENT")) {
                            contractStatusPoBond
                                    .setYesCount(contractStatusPoBond.getYesCount() + 1);
                        } else if (contract.getPo().equals("NOT_SENT")) {
                            contractStatusPoBond.setNoCount(contractStatusPoBond.getNoCount() + 1);
                        }
                    }
                });
            });

            contractStatusList.add(contractStatusPerfBond);
            contractStatusList.add(contractStatusWarrantyBond);
            contractStatusList.add(contractStatusPoBond);

            log.debug("Leave:KPIServiceImpl:getContractStatus");
            return contractStatusList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }

    }

    @Override
    public List<DFQMilestoneGraphModel> getDFQMileStoneGraph(final UUID id) {

        log.debug("Entry:KPIServiceImpl:getDFQMileStoneGraph");
        int onTimeGo = 0;
        int onTimeNoGo = 0;
        int lateGo = 0;
        int lateNoGo = 0;
        int onTimeNotDone = 0;
        int lateNotDone = 0;
        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime();
        try {
            List<DFQMilestoneGraphModel> dfqMileStoneList = new ArrayList<>();
            ProjectSetUp projSetUp = projSetUpRepo.findById(id).orElse(null);

            DFQMilestoneGraphModel goRfqModel = new DFQMilestoneGraphModel();
            goRfqModel.setMileStoneType(Constants.GO_RFQ);
            goRfqModel.setOnTimeGo(onTimeGo);
            goRfqModel.setLateGo(lateGo);
            goRfqModel.setOnTimeNoGo(onTimeNoGo);
            goRfqModel.setLateNoGo(lateNoGo);
            goRfqModel.setOnTimeNotDone(onTimeNotDone);
            goRfqModel.setLateNotDone(lateNotDone);

            DFQMilestoneGraphModel baModel = new DFQMilestoneGraphModel();
            baModel.setMileStoneType(Constants.BA);
            baModel.setOnTimeGo(onTimeGo);
            baModel.setLateGo(lateGo);
            baModel.setOnTimeNoGo(onTimeNoGo);
            baModel.setLateNoGo(lateNoGo);
            baModel.setOnTimeNotDone(onTimeNotDone);
            baModel.setLateNotDone(lateNotDone);

            DFQMilestoneGraphModel goOrderModel = new DFQMilestoneGraphModel();
            goOrderModel.setMileStoneType(Constants.GO_ORDER);
            goOrderModel.setOnTimeGo(onTimeGo);
            goOrderModel.setLateGo(lateGo);
            goOrderModel.setOnTimeNoGo(onTimeNoGo);
            goOrderModel.setLateNoGo(lateNoGo);
            goOrderModel.setOnTimeNotDone(onTimeNotDone);
            goOrderModel.setLateNotDone(lateNotDone);

            DFQMilestoneGraphModel faiModel = new DFQMilestoneGraphModel();
            faiModel.setMileStoneType(Constants.FAI);
            faiModel.setOnTimeGo(onTimeGo);
            faiModel.setLateGo(lateGo);
            faiModel.setOnTimeNoGo(onTimeNoGo);
            faiModel.setLateNoGo(lateNoGo);
            faiModel.setOnTimeNotDone(onTimeNotDone);
            faiModel.setLateNotDone(lateNotDone);

            DFQMilestoneGraphModel fatModel = new DFQMilestoneGraphModel();
            fatModel.setMileStoneType(Constants.FAT);
            fatModel.setOnTimeGo(onTimeGo);
            fatModel.setLateGo(lateGo);
            fatModel.setOnTimeNoGo(onTimeNoGo);
            fatModel.setLateNoGo(lateNoGo);
            fatModel.setOnTimeNotDone(onTimeNotDone);
            fatModel.setLateNotDone(lateNotDone);

            projSetUp.getProjectMarketList().forEach(projectMarket -> {
                projectMarket.getProjectMilestoneList().forEach(projectMileStone -> {
                    CommodityStatus comStatus = projectMileStone.getCommodityStatus();

                    if (projSetUp.getProjectId() != null) {
                        // GO RFQ
                        if (comStatus.getNeedsGoRfq() != null
                                && comStatus.getActualDateGoRfq() != null) {
                            int variance = calculateDateDifference(comStatus.getNeedsGoRfq(),
                                    comStatus.getActualDateGoRfq());
                            if (comStatus.getStatusGoRfq() != null) {
                                if (comStatus.getStatusGoRfq().equals(Constants.GO)
                                        && variance <= 0) {
                                    goRfqModel.setOnTimeGo(goRfqModel.getOnTimeGo() + 1);
                                } else if (comStatus.getStatusGoRfq().equals(Constants.GO)
                                        && variance > 0) {
                                    goRfqModel.setLateGo(goRfqModel.getLateGo() + 1);
                                } else if (comStatus.getStatusGoRfq().equals(Constants.NOGO)
                                        && variance <= 0) {
                                    goRfqModel.setOnTimeNoGo(goRfqModel.getOnTimeNoGo() + 1);
                                } else if (comStatus.getStatusGoRfq().equals(Constants.NOGO)
                                        && variance > 0) {
                                    goRfqModel.setLateNoGo(goRfqModel.getLateNoGo() + 1);
                                }
                            }
                        }
                        if (comStatus.getDfqMilestoneGoRfq() != null
                                && comStatus.getDfqMilestoneGoRfq().equals(Constants.X)
                                && comStatus.getNeedsGoRfq() != null
                                && comStatus.getActualDateGoRfq() == null) {
                            int variance = calculateDateDifference(comStatus.getNeedsGoRfq(),
                                    today);
                            if (variance <= 0) {
                                goRfqModel.setOnTimeNotDone(goRfqModel.getOnTimeNotDone() + 1);
                            } else if (variance > 0) {
                                goRfqModel.setLateNotDone(goRfqModel.getLateNotDone() + 1);
                            }
                        }

                        // BA
                        if (comStatus.getNeedsBa() != null && comStatus.getActualDateBa() != null) {
                            int variance = calculateDateDifference(comStatus.getNeedsBa(),
                                    comStatus.getActualDateBa());
                            if (comStatus.getStatusBa() != null) {
                                if (comStatus.getStatusBa().equals(Constants.GO) && variance <= 0) {
                                    baModel.setOnTimeGo(baModel.getOnTimeGo() + 1);
                                } else if (comStatus.getStatusBa().equals(Constants.GO)
                                        && variance > 0) {
                                    baModel.setLateGo(baModel.getLateGo() + 1);
                                } else if (comStatus.getStatusBa().equals(Constants.NOGO)
                                        && variance <= 0) {
                                    baModel.setOnTimeNoGo(baModel.getOnTimeNoGo() + 1);
                                } else if (comStatus.getStatusBa().equals(Constants.NOGO)
                                        && variance > 0) {
                                    baModel.setLateNoGo(baModel.getLateNoGo() + 1);
                                }
                            }
                        }
                        if (comStatus.getDfqMilestoneBa() != null
                                && comStatus.getDfqMilestoneBa().equals(Constants.X)
                                && comStatus.getNeedsBa() != null
                                && comStatus.getActualDateBa() == null) {
                            int variance = calculateDateDifference(comStatus.getNeedsBa(), today);
                            if (variance <= 0) {
                                baModel.setOnTimeNotDone(baModel.getOnTimeNotDone() + 1);
                            } else if (variance > 0) {
                                baModel.setLateNotDone(baModel.getLateNotDone() + 1);
                            }
                        }

                        // Go Order
                        if (comStatus.getNeedsGoOrder() != null
                                && comStatus.getActualDateGoOrder() != null) {
                            int variance = calculateDateDifference(comStatus.getNeedsGoOrder(),
                                    comStatus.getActualDateGoOrder());
                            if (comStatus.getNeedsGoOrder() != null) {
                                if (comStatus.getStatusGoOrder().equals(Constants.GO)
                                        && variance <= 0) {
                                    goOrderModel.setOnTimeGo(goOrderModel.getOnTimeGo() + 1);
                                } else if (comStatus.getStatusGoOrder().equals(Constants.GO)
                                        && variance > 0) {
                                    goOrderModel.setLateGo(goOrderModel.getLateGo() + 1);
                                } else if (comStatus.getStatusGoOrder().equals(Constants.NOGO)
                                        && variance <= 0) {
                                    goOrderModel.setOnTimeNoGo(goOrderModel.getOnTimeNoGo() + 1);
                                } else if (comStatus.getStatusGoOrder().equals(Constants.NOGO)
                                        && variance > 0) {
                                    goOrderModel.setLateNoGo(goOrderModel.getLateNoGo() + 1);
                                }
                            }
                        }
                        if (comStatus.getDfqMilestoneGoOrder() != null
                                && comStatus.getDfqMilestoneGoOrder().equals(Constants.X)
                                && comStatus.getNeedsGoOrder() != null
                                && comStatus.getActualDateGoOrder() == null) {
                            int variance = calculateDateDifference(comStatus.getNeedsGoOrder(),
                                    today);
                            if (variance <= 0) {
                                goOrderModel.setOnTimeNotDone(goOrderModel.getOnTimeNotDone() + 1);
                            } else if (variance > 0) {
                                goOrderModel.setLateNotDone(goOrderModel.getLateNotDone() + 1);
                            }
                        }

                        if (comStatus.getNeedsFai() != null
                                && comStatus.getActualDateFai() != null) {
                            int variance = calculateDateDifference(comStatus.getNeedsFai(),
                                    comStatus.getActualDateFai());
                            if (comStatus.getStatusFai() != null) {
                                if (comStatus.getStatusFai().equals(Constants.GO)
                                        && variance <= 0) {
                                    faiModel.setOnTimeGo(faiModel.getOnTimeGo() + 1);
                                } else if (comStatus.getStatusFai().equals(Constants.GO)
                                        && variance > 0) {
                                    faiModel.setLateGo(faiModel.getLateGo() + 1);
                                } else if (comStatus.getStatusFai().equals(Constants.NOGO)
                                        && variance <= 0) {
                                    faiModel.setOnTimeNoGo(faiModel.getOnTimeNoGo() + 1);
                                } else if (comStatus.getStatusFai().equals(Constants.NOGO)
                                        && variance > 0) {
                                    faiModel.setLateNoGo(faiModel.getLateNoGo() + 1);
                                }
                            }
                        }
                        if (comStatus.getDfqMilestoneFai() != null
                                && comStatus.getDfqMilestoneFai().equals(Constants.X)
                                && comStatus.getNeedsFai() != null
                                && comStatus.getActualDateFai() == null) {
                            int variance = calculateDateDifference(comStatus.getNeedsFai(), today);
                            if (variance <= 0) {
                                faiModel.setOnTimeNotDone(faiModel.getOnTimeNotDone() + 1);
                            } else if (variance > 0) {
                                faiModel.setLateNotDone(faiModel.getLateNotDone() + 1);
                            }
                        }

                        // FAT
                        if (comStatus.getNeedsFat() != null
                                && comStatus.getActualDateFat() != null) {
                            int variance = calculateDateDifference(comStatus.getNeedsFat(),
                                    comStatus.getActualDateFat());
                            if (comStatus.getStatusFat() != null) {
                                if (comStatus.getStatusFat().equals(Constants.GO)
                                        && variance <= 0) {
                                    fatModel.setOnTimeGo(fatModel.getOnTimeGo() + 1);
                                } else if (comStatus.getStatusFat().equals(Constants.GO)
                                        && variance > 0) {
                                    fatModel.setLateGo(fatModel.getLateGo() + 1);
                                } else if (comStatus.getStatusFat().equals(Constants.NOGO)
                                        && variance <= 0) {
                                    fatModel.setOnTimeNoGo(fatModel.getOnTimeNoGo() + 1);
                                } else if (comStatus.getStatusFat().equals(Constants.NOGO)
                                        && variance > 0) {
                                    fatModel.setLateNoGo(fatModel.getLateNoGo() + 1);
                                }
                            }
                        }
                        if (comStatus.getDfqMilestoneFat() != null
                                && comStatus.getDfqMilestoneFat().equals(Constants.X)
                                && comStatus.getNeedsFat() != null
                                && comStatus.getActualDateFat() == null) {
                            int variance = calculateDateDifference(comStatus.getNeedsFat(), today);
                            if (variance <= 0) {
                                fatModel.setOnTimeNotDone(fatModel.getOnTimeNotDone() + 1);
                            } else if (variance > 0) {
                                fatModel.setLateNotDone(fatModel.getLateNotDone() + 1);
                            }
                        }
                    }
                });
            });

            dfqMileStoneList.add(goRfqModel);
            dfqMileStoneList.add(baModel);
            dfqMileStoneList.add(goOrderModel);
            dfqMileStoneList.add(faiModel);
            dfqMileStoneList.add(fatModel);
            log.debug("Leave:KPIServiceImpl:getDFQMileStoneGraph");
            return dfqMileStoneList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    @Override
    public List<DFQDeliveryGraphModel> getDFQDeliveryGraph(final UUID id) {
        log.debug("Entry:KPIServiceImpl:getDFQDeliveryGraph");
        int onTimeDelivered = 0;
        int onTimeNotDelivered = 0;
        int lateDelivered = 0;
        int lateNotDelivered = 0;
        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime();
        try {
            List<DFQDeliveryGraphModel> dfqDeliveryList = new ArrayList<>();
            ProjectSetUp projSetUp = projSetUpRepo.findById(id).orElse(null);

            DFQDeliveryGraphModel lateModel = new DFQDeliveryGraphModel();
            lateModel.setTimeType(Constants.LATE_GRAPH);
            lateModel.setOnTimeDelivered(onTimeDelivered);
            lateModel.setOnTimeNotDelivered(onTimeNotDelivered);
            lateModel.setLateDelivered(lateDelivered);
            lateModel.setLateNotDelivered(lateNotDelivered);

            DFQDeliveryGraphModel onTimeModel = new DFQDeliveryGraphModel();
            onTimeModel.setTimeType(Constants.ON_TIME_GRAPH);
            onTimeModel.setOnTimeDelivered(onTimeDelivered);
            onTimeModel.setOnTimeNotDelivered(onTimeNotDelivered);
            onTimeModel.setLateDelivered(lateDelivered);
            onTimeModel.setLateNotDelivered(lateNotDelivered);

            projSetUp.getProjectMarketList().forEach(projectMarket -> {
                projectMarket.getProjectMilestoneList().forEach(projectMileStone -> {
                    CommodityStatus comStatus = projectMileStone.getCommodityStatus();

                    if (projSetUp.getProjectId() != null) {
                        int variance = 0;

                        if (comStatus.getNeedsFirstNeed() != null
                                && comStatus.getActualDateDelivery() != null) {
                            variance = calculateDateDifference(comStatus.getNeedsFirstNeed(),
                                    comStatus.getActualDateDelivery());
                        } else if (comStatus.getNeedsFirstNeed() != null) {
                            variance = calculateDateDifference(comStatus.getNeedsFirstNeed(),
                                    today);
                        }
                        if (comStatus.getStatusDelivery() != null) {
                            if (comStatus.getStatusDelivery().equals(Constants.DELIVERED)
                                    && variance <= 0) {
                                onTimeModel
                                        .setOnTimeDelivered(onTimeModel.getOnTimeDelivered() + 1);
                            } else if (comStatus.getStatusDelivery().equals(Constants.NOT_DELIVERED)
                                    && variance <= 0) {
                                onTimeModel.setOnTimeNotDelivered(
                                        onTimeModel.getOnTimeNotDelivered() + 1);
                            } else if (comStatus.getStatusDelivery().equals(Constants.DELIVERED)
                                    && variance > 0) {
                                lateModel.setLateDelivered(lateModel.getLateDelivered() + 1);
                            } else if (comStatus.getStatusDelivery().equals(Constants.NOT_DELIVERED)
                                    && variance > 0) {
                                lateModel.setLateNotDelivered(lateModel.getLateNotDelivered() + 1);
                            }
                        } else {
                            if (variance <= 0) {
                                onTimeModel.setOnTimeNotDelivered(
                                        onTimeModel.getOnTimeNotDelivered() + 1);
                            } else {
                                lateModel.setLateNotDelivered(lateModel.getLateNotDelivered() + 1);
                            }
                        }

                    }
                });
            });

            dfqDeliveryList.add(lateModel);
            dfqDeliveryList.add(onTimeModel);
            log.debug("Leave:KPIServiceImpl:getDFQDeliveryGraph");
            return dfqDeliveryList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param id
     * @param key
     * @return AllActionsModel
     */
    @Override
    public List<AllActionsModel> getAllActions(final UUID id, final String key) {
        log.debug("Entry:KPIServiceImpl:getAllActions");
        try {
            List<AllActionsModel> allActionsModelList = null;
            ProjectSetUp projSetUp = projSetUpRepo.findById(id).orElse(null);
            allActionsModelList = buildActionsKPI(projSetUp, key);
            log.debug("Leave:KPIServiceImpl:getAllActions");
            return allActionsModelList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Error", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }

    }

    /**
     * @param projSetUp
     * @param key
     * @return AllActionsModel
     */
    private List<AllActionsModel> buildActionsKPI(final ProjectSetUp projSetUp, final String key) {
        List<AllActionsModel> actionsModelList = new ArrayList<>();
        projSetUp.getProjectMarketList().forEach(ProjectMarket -> {
            List<PuActions> actionsList = ProjectMarket.getCommodityActionPlan().getPuActionsList();
            // if (!actionsList.isEmpty()) {
            actionsList.forEach(actions -> {
                if ((key.equals(Constants.OPEN) && actions.getStatus() != null
                        && actions.getStatus().equals(Constants.OPEN_CAPS))
                        || key.equals(Constants.ALL)) {
                    AllActionsModel actionModel = new AllActionsModel();
                    actionModel.setMarketCode(ProjectMarket.getSupplierMarketCode());
                    actionModel.setCreatedDate(actions.getCreatedDate());
                    actionModel.setClosingDate(actions.getClosingDate());
                    actionModel.setPic(actions.getPic());
                    actionModel.setDescription(actions.getDescription());
                    actionModel.setPriority(actions.getPriority());
                    actionModel.setStatus(actions.getStatus());
                    actionModel.setTargetDate(actions.getTargetDate());
                    actionModel.setProjectId(projSetUp.getProjectId());
                    actionModel.setProjectName(
                            projSetUp.getProject() != null ? projSetUp.getProject().getProjName()
                                    : "");
                    actionModel.setDomainCode(ProjectMarket.getDomainCode());
                    actionModel.setMaterial(actions.getMaterial());
                    actionModel.setExportDate(new Date());
                    actionsModelList.add(actionModel);
                }
            });
            // }
        });
        return actionsModelList;
    }
}
