package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type UserSearchQuery model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserSearchQueryModel {

    /**
     * UserSearchQueryModel id.
     */
    private UUID id;

    /**
     * UserSearchQueryModel user.
     */
    private UserModel user;

    /**
     * UserSearchQueryModel name.
     */
    private String name;

    /**
     * UserSearchQueryModel screen name.
     */
    private String screenName;

    /**
     * UserSearchQueryModel criteria.
     */
    private String criteria;

    /**
     * UserSearchQueryModel default query.
     */
    private boolean defaultQuery;

    /**
     * UserSearchQueryModel shared.
     */
    private boolean shared;

    /**
     * UserSearchQueryModel shared by user.
     */
    private UserModel sharedByUser;

    /**
     * UserSearchQueryModel shared to users.
     */
    private List<UserModel> sharedToUsers = Collections.EMPTY_LIST;

    /**
     * UserSearchQueryModel created date.
     */
    private Date createdDate;

    /**
     * UserSearchQueryModel modified date.
     */
    private Date modifiedDate;

    /**
     * UserSearchQueryModel created by.
     */
    private String createdBy;

    /**
     * UserSearchQueryModel modified by.
     */
    private String modifiedBy;

}
