package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type project market model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectMarketModel {

    /**
     * ProjectMarketModel id.
     */
    private UUID id;

    /**
     * ProjectMarketModel version.
     */
    private Integer version;

    /**
     * ProjectMarketModel supplier market code.
     */
    @NotNull(message = Constants.MARKET_CODE_NOTEMPTY)
    private String supplierMarketCode;

    /**
     * ProjectMarketModel domain code.
     */
    private String domainCode;

    /**
     * ProjectMarketModel project set up.
     */
    @JsonIgnore
    private ProjectSetUpModel projectSetUp;

    /**
     * ProjectMarketModel project market seq.
     */
    private Integer listProjectMarketSeq;

    /**
     * ProjectMarketModel project milestone list.
     */
    private List<ProjectMilestoneModel> projectMilestoneList;

    /**
     * ProjectMarketModel commodity contract.
     */
    private CommodityContractModel commodityContract;

    /**
     * ProjectMarketModel commodity action plan.
     */
    private CommodityActionPlanModel commodityActionPlan;
}
