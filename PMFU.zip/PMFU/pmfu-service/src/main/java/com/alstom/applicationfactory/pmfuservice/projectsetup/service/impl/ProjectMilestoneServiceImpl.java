package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityActionPlan;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityContract;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityStatus;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.Contracts;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUp;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityActionPlanRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityContractRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityStatusRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ContractsRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMarketRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMilestoneRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectMilestoneService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author shanmugam.raj
 *
 */
@Service(value = "projectMilestoneService")
@Transactional
@Slf4j
public class ProjectMilestoneServiceImpl implements ProjectMilestoneService {

    /**
     * ProjectSetUpRepository.
     */
    @Autowired
    private ProjectSetUpRepository projectSetUpRepository;

    /**
     * ProjectMarketRepository.
     */
    @Autowired
    private ProjectMarketRepository projectMarketRepository;

    /**
     * CommodityStatusRepository.
     */
    @Autowired
    private CommodityStatusRepository commodityStatusRepository;

    /**
     * ProjectMilestoneRepository.
     */
    @Autowired
    private ProjectMilestoneRepository projectMilestoneRepository;

    /**
     * CommodityActionPlanRepository.
     */
    @Autowired
    private CommodityActionPlanRepository commodityActionPlanRepository;

    /**
     * CommodityContractRepository.
     */
    @Autowired
    private CommodityContractRepository commodityContractRepository;

    /**
     * ContractsRepository.
     */
    @Autowired
    private ContractsRepository contractsRepository;

    @Override
    public boolean isProjectIDAndCdbCodeExists(final Integer projectID, final String cdbCode) {
        log.debug("Entry:ProjectMilestoneServiceImpl:isProjectIDExists");

        ModelMapper mapper = new ModelMapper();
        ProjectSetUp projectSetUp = null;
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            projectSetUp = projectSetUpRepository.findByProjectId(projectID);
            if (null != projectSetUp) {
                if (projectSetUp.getProject().getCtCode().equals(cdbCode)) {
                    return true;
                }
            }
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp",
                    "Unable to search for Project Setup by Project ID / CDB Code ");
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
        log.debug("Leave:ProjectMilestoneServiceImpl:isProjectIDExists");
        return false;
    }

    @Override
    public void saveImportedMilestoneRecords(
            final Map<String, List<ProjectMilestone>> puproject_market_projectMilestoneMap) {
        log.debug("Entry:ProjectMilestoneServiceImpl:saveImportedMilestoneRecords");
        boolean fetchedProjectSetupRecord = false;

        ProjectSetUp projectSetUp = new ProjectSetUp();

        Integer projectMarketSeq = 0;
        Integer projectMilestoneSeq = 0;
        String projectName = null;
        Integer projectId = 0;

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        for (Map.Entry<String, List<ProjectMilestone>> entry : puproject_market_projectMilestoneMap
                .entrySet()) {
            ProjectMarket projectMarket = new ProjectMarket();
            ProjectMarket createdProjectMarket = new ProjectMarket();

            CommodityActionPlan commodityActionPlan = new CommodityActionPlan();
            // CommodityActionPlan createdCommodityActionPlan = new CommodityActionPlan();

            CommodityContract commodityContract = new CommodityContract();
            CommodityContract createdCommodityContract = new CommodityContract();

            String puproject_market_code = entry.getKey();
            List<ProjectMilestone> projectMilestoneList = entry.getValue();

            if (!fetchedProjectSetupRecord) {
                projectSetUp = projectSetUpRepository
                        .findByProjectId(projectMilestoneList.get(0).getProjectId());
                projectName = projectSetUp.getProject().getProjName();
                projectId = projectSetUp.getProjectId();
                fetchedProjectSetupRecord = true;
            }
            try {
                ProjectMarket existingProjectMarket = new ProjectMarket();

                existingProjectMarket = projectMarketRepository
                        .findByProjectSetUpIdAndSupplierMarketCode(projectSetUp.getId(),
                                puproject_market_code);

                if (null != existingProjectMarket) {
                    // assinging existing project market record for its referenced tables.
                    createdProjectMarket = existingProjectMarket;
                } else {
                    projectMarket.setVersion(0);
                    projectMarket.setSupplierMarketCode(puproject_market_code);
                    projectMarket.setDomainCode(projectMilestoneList.get(0).getDomainCode());
                    projectMarket.setProjectSetUp(projectSetUp);

                    projectMarketSeq = projectMarketRepository.findSeqNumber(projectId);
                    projectMarket.setListProjectMarketSeq(projectMarketSeq);

                    // Creating a record in puproject_market table
                    createdProjectMarket = projectMarketRepository.save(projectMarket);
                }
                if (null != createdProjectMarket) {

                    if (null == existingProjectMarket) {

                        commodityActionPlan.setVersion(0);
                        commodityActionPlan.setProjectMarket(createdProjectMarket);

                        // Creating a record in pucommodity_action_plan table
                        commodityActionPlanRepository.save(commodityActionPlan);
                        // createdCommodityActionPlan =
                        // commodityActionPlanRepository.save(commodityActionPlan);

                        commodityContract.setVersion(0);
                        commodityContract.setProjectMarket(createdProjectMarket);

                        // Creating a record in pucommodity_contract table
                        createdCommodityContract = commodityContractRepository
                                .save(commodityContract);
                    } else {
                        CommodityContract existingCommodityContract = new CommodityContract();
                        existingCommodityContract = commodityContractRepository
                                .findByProjectMarketId(createdProjectMarket.getId());

                        // assinging existing commodity contract record for its referenced tables.
                        createdCommodityContract = existingCommodityContract;
                    }

                    for (ProjectMilestone projectMilestoneRecord : projectMilestoneList) {
                        ProjectMilestone projectMilestone = new ProjectMilestone();
                        ProjectMilestone createdProjectMilestone = new ProjectMilestone();

                        CommodityStatus createdCommodityStatusRecord = new CommodityStatus();

                        CommodityStatus existingCommodityStatusRecord = null;
                        Contracts contracts = new Contracts();

                        projectMilestone = mapper.map(projectMilestoneRecord,
                                ProjectMilestone.class);
                        projectMilestone.setProjectName(projectName);
                        projectMilestone.setProjectId(projectId);
                        projectMilestoneSeq = projectMilestoneRepository.findSeqNumber(projectId,
                                puproject_market_code);
                        projectMilestone.setListMarketCodeByProjectSeq(projectMilestoneSeq);
                        projectMilestone.setProjectMarket(createdProjectMarket);

                        ProjectMilestone existingProjectMilestoneRecord = isMarketCodeAndMaterialExists(
                                projectId, puproject_market_code, projectMilestone.getMaterial());
                        if (null != existingProjectMilestoneRecord) {

                            UUID puMarketCodeId = existingProjectMilestoneRecord.getId();
                            existingCommodityStatusRecord = commodityStatusRepository
                                    .findByProjectMilestoneId(puMarketCodeId);
                            // delete & re-create data for global milestone tab
                            projectMilestoneRepository
                                    .deleteById(existingProjectMilestoneRecord.getId());
                            projectMilestone.setListMarketCodeByProjectSeq(
                                    existingProjectMilestoneRecord.getListMarketCodeByProjectSeq());
                        }

                        // For every record in puproject_market table - creating a record in
                        // pumarket_code table
                        createdProjectMilestone = projectMilestoneRepository.save(projectMilestone);

                        if (null != createdProjectMilestone) {
                            // For every record in pumarket_code table - creating a record in
                            // pucommodity_status table
                            createdCommodityStatusRecord = importCommodityStatusRecord(
                                    createdProjectMilestone, existingCommodityStatusRecord);

                            // updating global milestone colour code for existing data - starts
                            if (null != existingProjectMilestoneRecord) {
                                createdProjectMilestone.setTechInputColor(
                                        createdCommodityStatusRecord.getStatusColorTechInput());
                                createdProjectMilestone.setGoRfqColor(
                                        createdCommodityStatusRecord.getStatusColorGoRfq());
                                createdProjectMilestone.setBaColor(
                                        createdCommodityStatusRecord.getStatusColorBa());
                                createdProjectMilestone.setGoOrderColor(
                                        createdCommodityStatusRecord.getStatusColorGoOrder());
                                createdProjectMilestone.setPgrColor(
                                        createdCommodityStatusRecord.getStatusColorPgr());
                                createdProjectMilestone.setCgrColor(
                                        createdCommodityStatusRecord.getStatusColorGgr());
                                createdProjectMilestone.setGoProdColor(
                                        createdCommodityStatusRecord.getStatusColorGoProd());
                                createdProjectMilestone.setFaiColor(
                                        createdCommodityStatusRecord.getStatusColorFai());
                                createdProjectMilestone.setFatColor(
                                        createdCommodityStatusRecord.getStatusColorFat());
                                createdProjectMilestone.setDeliveryColor(
                                        createdCommodityStatusRecord.getStatusColorDelivery());
                                createdProjectMilestone.setIqaColor(
                                        createdCommodityStatusRecord.getStatusColorIqa());
                                createdProjectMilestone.setFqaColor(
                                        createdCommodityStatusRecord.getStatusColorFqa());
                                projectMilestoneRepository.save(createdProjectMilestone);
                            }
                            // updating global milestone colour code for existing data - end
                            if (null != createdCommodityContract) {
                                contracts.setVersion(0);
                                contracts.setMaterialComponent(
                                        createdProjectMilestone.getMaterial());
                                contracts.setCommodityContract(createdCommodityContract);

                                // For every record in pumarket_code table - creating a record in
                                // contracts
                                // table using commodity contract as key
                                if (null == existingProjectMilestoneRecord) {
                                    contractsRepository.save(contracts);
                                }
                            } else {
                                log.error("Error while creating record for Commodity Contract");
                                List<ErrorModel> errors = new ArrayList<>();
                                errors.add(new ErrorModel("Commodity Contract",
                                        "Error while creating record for Commodity Contract"));
                                throw new ApplicationFactoryException(Constants.ERROR_CODE_406,
                                        errors);
                            }
                        } else {
                            log.error("Error while creating record for Project Milestone");
                            List<ErrorModel> errors = new ArrayList<>();
                            errors.add(new ErrorModel("Project Milestone",
                                    "Error while creating record for Project Milestone"));
                            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
                        }
                        // projectMilestoneSeq++;
                    }
                } else {
                    log.error("Error while creating record for ProjectMarket");
                    List<ErrorModel> errors = new ArrayList<>();
                    errors.add(new ErrorModel("ProjectMarket",
                            "Error while creating record for ProjectMarket"));
                    throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
                }
            } catch (Exception e) {
                log.error("Error while processing import");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel("Project Milestone", "Error while processing import"));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            // projectMarketSeq++;
        }
        log.debug("Leave:InstructionAttachmentServiceImpl:createInstructionAttachment");
    }

    public CommodityStatus importCommodityStatusRecord(
            final ProjectMilestone createdProjectMilestone,
            final CommodityStatus existingCommodityStatusRecord) {

        Integer durationGoRfq, durationBa, durationGoOrder, durationPgr, durationCgr,
                durationGoProd, durationFai, durationIqa, durationFqa, durationFat;

        String statusTechInput = null, statusGoRfq = null, statusBa = null, statusGoOrder = null,
                statusPgr = null, statusCgr = null, statusGoProd = null, statusFai = null,
                statusFat = null, statusDelivery = null;

        Date actualFat = null, actualFai = null, actualGoProd = null, actualCgr = null,
                actualPgr = null, actualGoOrder = null, actualBa = null, actualGoRfq = null,
                actualTechInput = null, actualDelivery = null, actualFirsNeed = null,
                actualIqa = null, actualFqa = null;

        CommodityStatus commodityStatus = new CommodityStatus();

        CommodityStatus createdCommodityStatus = new CommodityStatus();

        final String milestone_techinput = createdProjectMilestone.getTechInput();
        final String milestone_gorfq = createdProjectMilestone.getGoRfq();
        final String milestone_ba = createdProjectMilestone.getBa();
        final String milestone_goorder = createdProjectMilestone.getGoOrder();
        final String milestone_pgr = createdProjectMilestone.getPgr();
        final String milestone_cgr = createdProjectMilestone.getCgr();
        final String milestone_goprod = createdProjectMilestone.getGoProd();
        final String milestone_fai = createdProjectMilestone.getFai();
        final String milestone_iqa = createdProjectMilestone.getIqa();
        final String milestone_fqa = createdProjectMilestone.getFqa();
        final String milestone_fat = createdProjectMilestone.getFat();

        if (null != existingCommodityStatusRecord) {
            durationGoRfq = existingCommodityStatusRecord.getDurationGoRfq();
            durationBa = existingCommodityStatusRecord.getDurationBa();
            durationGoOrder = existingCommodityStatusRecord.getDurationGoOrder();
            durationPgr = existingCommodityStatusRecord.getDurationPgr();
            durationCgr = existingCommodityStatusRecord.getDurationCgr();
            durationGoProd = existingCommodityStatusRecord.getDurationGoProd();
            durationFai = existingCommodityStatusRecord.getDurationFai();
            durationIqa = existingCommodityStatusRecord.getDurationIqa();
            durationFqa = existingCommodityStatusRecord.getDurationFqa();
            durationFat = existingCommodityStatusRecord.getDurationFat();

            actualFat = existingCommodityStatusRecord.getActualDateFat();
            actualFai = existingCommodityStatusRecord.getActualDateFai();
            actualGoProd = existingCommodityStatusRecord.getActualDateGoProd();
            actualCgr = existingCommodityStatusRecord.getActualDateCgr();
            actualPgr = existingCommodityStatusRecord.getActualDatePgr();
            actualGoOrder = existingCommodityStatusRecord.getActualDateGoOrder();
            actualBa = existingCommodityStatusRecord.getActualDateBa();
            actualGoRfq = existingCommodityStatusRecord.getActualDateGoRfq();
            actualTechInput = existingCommodityStatusRecord.getActualDateTechInput();
            actualDelivery = existingCommodityStatusRecord.getActualDateDelivery();
            actualFirsNeed = existingCommodityStatusRecord.getActualDateFirstNeed();
            actualFqa = existingCommodityStatusRecord.getActualDateFqa();
            actualIqa = existingCommodityStatusRecord.getActualDateIqa();

            commodityStatus.setActualDateBa(actualBa);
            commodityStatus.setActualDatePgr(actualPgr);
            commodityStatus.setActualDateCgr(actualCgr);
            commodityStatus.setActualDateDelivery(actualDelivery);
            commodityStatus.setActualDateFai(actualFai);
            commodityStatus.setActualDateFat(actualFat);
            commodityStatus.setActualDateFirstNeed(actualFirsNeed);
            commodityStatus.setActualDateFqa(actualFqa);
            commodityStatus.setActualDateGoOrder(actualGoOrder);
            commodityStatus.setActualDateGoProd(actualGoProd);
            commodityStatus.setActualDateGoRfq(actualGoRfq);
            commodityStatus.setActualDateIqa(actualIqa);
            commodityStatus.setActualDateTechInput(actualTechInput);
            commodityStatus.setActualDateTitle(existingCommodityStatusRecord.getActualDateTitle());

            commodityStatus.setForecastDateBa(existingCommodityStatusRecord.getForecastDateBa());
            commodityStatus.setForecastDateCgr(existingCommodityStatusRecord.getForecastDateCgr());
            commodityStatus.setForecastDateDelivery(
                    existingCommodityStatusRecord.getForecastDateDelivery());
            commodityStatus.setForecastDateFai(existingCommodityStatusRecord.getForecastDateFai());
            commodityStatus.setForecastDateFat(existingCommodityStatusRecord.getForecastDateFat());
            commodityStatus.setForecastDateFirstNeed(
                    existingCommodityStatusRecord.getForecastDateFirstNeed());
            commodityStatus.setForecastDateFqa(existingCommodityStatusRecord.getForecastDateFqa());
            commodityStatus
                    .setForecastDateGoOrder(existingCommodityStatusRecord.getForecastDateGoOrder());
            commodityStatus
                    .setForecastDateGoProd(existingCommodityStatusRecord.getForecastDateGoProd());
            commodityStatus
                    .setForecastDateGoRfq(existingCommodityStatusRecord.getForecastDateGoRfq());
            commodityStatus.setForecastDateIqa(existingCommodityStatusRecord.getForecastDateIqa());
            commodityStatus.setForecastDatePgr(existingCommodityStatusRecord.getForecastDatePgr());
            commodityStatus.setForecastDateTechInput(
                    existingCommodityStatusRecord.getForecastDateTechInput());
            commodityStatus.setForecastDateTitle("Forecast Date");

            statusTechInput = existingCommodityStatusRecord.getStatusTechInput();
            statusGoRfq = existingCommodityStatusRecord.getStatusGoRfq();
            statusBa = existingCommodityStatusRecord.getStatusBa();
            statusGoOrder = existingCommodityStatusRecord.getStatusGoOrder();
            statusPgr = existingCommodityStatusRecord.getStatusPgr();
            statusCgr = existingCommodityStatusRecord.getStatusGgr();
            statusGoProd = existingCommodityStatusRecord.getStatusGoProd();
            statusFai = existingCommodityStatusRecord.getStatusFai();
            statusFat = existingCommodityStatusRecord.getStatusFat();
            statusDelivery = existingCommodityStatusRecord.getStatusDelivery();

            commodityStatus.setStatusTechInput(statusTechInput);
            commodityStatus.setStatusBa(statusBa);
            commodityStatus.setStatusGoRfq(statusGoRfq);
            commodityStatus.setStatusGoOrder(statusGoOrder);
            commodityStatus.setStatusPgr(statusPgr);
            commodityStatus.setStatusGgr(statusCgr);
            commodityStatus.setStatusGoProd(statusGoProd);
            commodityStatus.setStatusFai(statusFai);
            commodityStatus.setStatusFat(statusFat);
            commodityStatus.setStatusDelivery(statusDelivery);

        } else {
            durationGoRfq = createdProjectMilestone.getMcGoRfq();
            durationBa = createdProjectMilestone.getMcBa();
            durationGoOrder = createdProjectMilestone.getMcGoOrder();
            durationPgr = createdProjectMilestone.getMcPgr();
            durationCgr = createdProjectMilestone.getMcCgr();
            durationGoProd = createdProjectMilestone.getMcGoProd();
            durationFai = createdProjectMilestone.getMcFai();
            durationIqa = createdProjectMilestone.getMcIqa();
            durationFqa = createdProjectMilestone.getMcFqa();
            durationFat = createdProjectMilestone.getMcFat();
        }
        Date needsFat = null;
        Date needsFai = null;
        Date needsGoProd = null;
        Date needsCgr = null;
        Date needsPgr = null;
        Date needsGoOrder = null;
        Date needsBa = null;
        Date needsGoRfq = null;
        Date needsTechInput = null;
        Date needsFirstNeed = createdProjectMilestone.getFirstNeed();
        if (needsFirstNeed != null) {
            needsFat = subtractDays(needsFirstNeed, 0);
            needsFai = subtractDays(needsFat, durationFat);
            needsGoProd = subtractDays(needsFai, durationFai);
            needsCgr = subtractDays(needsGoProd, durationGoProd);
            needsPgr = subtractDays(needsCgr, durationCgr);
            needsGoOrder = subtractDays(needsPgr, durationPgr);
            needsBa = subtractDays(needsGoOrder, durationGoOrder);
            needsGoRfq = subtractDays(needsBa, durationBa);
            needsTechInput = subtractDays(needsGoRfq, durationGoRfq);
        }

        commodityStatus.setVersion(0);
        commodityStatus.setDfqMilestoneTitle(createdProjectMilestone.getMaterial());
        commodityStatus.setDfqMilestoneTechInput(milestone_techinput);
        commodityStatus.setDfqMilestoneGoRfq(milestone_gorfq);
        commodityStatus.setDfqMilestoneBa(milestone_ba);
        commodityStatus.setDfqMilestoneGoOrder(milestone_goorder);
        commodityStatus.setDfqMilestonePgr(milestone_pgr);
        commodityStatus.setDfqMilestoneGgr(milestone_cgr);
        commodityStatus.setDfqMilestoneGoProd(milestone_goprod);
        commodityStatus.setDfqMilestoneFai(milestone_fai);
        commodityStatus.setDfqMilestoneIqa(milestone_iqa);
        commodityStatus.setDfqMilestoneFqa(milestone_fqa);
        commodityStatus.setDfqMilestoneFat(milestone_fat);
        // commodityStatus.setDfqMilestoneFirstNeed(dfqMilestoneFirstNeed);
        // commodityStatus.setDfqMilestoneDelivery(dfqMilestoneDelivery);
        commodityStatus.setDurationTile("Duration");
        // commodityStatus.setDurationTechInput(durationTechInput);
        commodityStatus.setDurationGoRfq(durationGoRfq);
        commodityStatus.setDurationBa(durationBa);
        commodityStatus.setDurationGoOrder(durationGoOrder);
        commodityStatus.setDurationPgr(durationPgr);
        commodityStatus.setDurationCgr(durationCgr);
        commodityStatus.setDurationGoProd(durationGoProd);
        commodityStatus.setDurationFai(durationFai);
        commodityStatus.setDurationIqa(durationIqa);
        commodityStatus.setDurationFqa(durationFqa);
        commodityStatus.setDurationFat(durationFat);
        // commodityStatus.setDurationFirstNeed(durationFirstNeed);
        // commodityStatus.setDurationDelivery(durationDelivery);
        commodityStatus.setNeedsTitle("Needs");
        commodityStatus.setNeedsTechInput(needsTechInput);
        if (milestone_gorfq != null && (milestone_gorfq.equals("X")) && (needsGoRfq != null)) {
            commodityStatus.setNeedsGoRfq(needsGoRfq);
            commodityStatus.setStatusColorGoRfq(getColorCode(needsGoRfq, actualGoRfq, statusGoRfq));
        }

        if (milestone_ba != null && (milestone_ba.equals("X")) && (needsBa != null)) {
            commodityStatus.setNeedsBa(needsBa);
            commodityStatus.setStatusColorBa(getColorCode(needsBa, actualBa, statusBa));
        }

        if (milestone_goorder != null && (milestone_goorder.equals("X"))
                && (needsGoOrder != null)) {
            commodityStatus.setNeedsGoOrder(needsGoOrder);
            commodityStatus.setStatusColorGoOrder(
                    getColorCode(needsGoOrder, actualGoOrder, statusGoOrder));
        }

        if (milestone_pgr != null && (milestone_pgr.equals("X")) && (needsPgr != null)) {
            commodityStatus.setNeedsPgr(needsPgr);
            commodityStatus.setStatusColorPgr(getColorCode(needsPgr, actualPgr, statusPgr));
        }

        if (milestone_cgr != null && (milestone_cgr.equals("X")) && (needsCgr != null)) {
            commodityStatus.setNeedsCgr(needsCgr);
            commodityStatus.setStatusColorGgr(getColorCode(needsCgr, actualCgr, statusCgr));
        }

        if (milestone_goprod != null && (milestone_goprod.equals("X")) && (needsGoProd != null)) {
            commodityStatus.setNeedsGoProd(needsGoProd);
            commodityStatus
                    .setStatusColorGoProd(getColorCode(needsGoProd, actualGoProd, statusGoProd));
        }

        if (milestone_fai != null && (milestone_fai.equals("X")) && (needsFai != null)) {
            commodityStatus.setNeedsFai(needsFai);
            commodityStatus.setStatusColorFai(getColorCode(needsFai, actualFai, statusFai));
        }

        // if (milestone_gorfq != null && milestone_gorfq == "X")
        // commodityStatus.setNeedsIqa(needsIqa);
        // if (milestone_gorfq != null && milestone_gorfq == "X")
        // commodityStatus.setNeedsFqa(needsFqa);

        if (milestone_fat != null && (milestone_fat.equals("X")) && (needsFat != null)) {
            commodityStatus.setNeedsFat(needsFat);
            commodityStatus.setStatusColorFat(getColorCode(needsFat, actualFat, statusFat));
        }

        commodityStatus.setNeedsFirstNeed(needsFirstNeed);
        // commodityStatus.setNeedsDelivery(needsDelivery);

        commodityStatus.setActualDateTitle("Actual Date");
        commodityStatus.setStatusTitle("Status");
        commodityStatus.setForecastDateTitle("Forecast Date");
        commodityStatus.setStatusColorTitle("Status Color");
        if (needsTechInput != null) {
            commodityStatus.setStatusColorTechInput(
                    getColorCode(needsTechInput, actualTechInput, statusTechInput));
        }

        // commodityStatus.setStatusColorIqa(statusColorIqa);
        // commodityStatus.setStatusColorFqa(statusColorFqa);

        if (needsFirstNeed != null) {
            commodityStatus.setStatusColorDelivery(
                    getColorCode(needsFirstNeed, actualDelivery, statusDelivery));
        }

        commodityStatus.setProjectMilestone(createdProjectMilestone);
        commodityStatus.setListCommodityStatusSeq(0);

        createdCommodityStatus = commodityStatusRepository.save(commodityStatus);

        return createdCommodityStatus;

    }

    private Date subtractDays(final Date date, final int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, -days);

        return cal.getTime();
    }

    private String getColorCode(final Date needDate, final Date actualDate, final String status) {
        Calendar cal = Calendar.getInstance();
        Date currentDate = cal.getTime();

        int needsDateCompare = needDate.compareTo(currentDate);
        if (actualDate == null) {
            if (needsDateCompare < 0) {
                return Constants.COLOR_RED;
            } else {
                return null;
            }
        } else {

            int actualDateCompare = actualDate.compareTo(needDate);
            if (actualDateCompare <= 0 && needsDateCompare <= 0) {
                if (status.equals(Constants.NOGO) || status.equals(Constants.NOT_DELIVERED)
                        || status.equals(Constants.NOT_RECEIVED)) {
                    return Constants.COLOR_ORANGE;
                } else if (status.equals(Constants.GO) || status.equals(Constants.DELIVERED)
                        || status.equals(Constants.RECEIVED)) {
                    return Constants.COLOR_STRONG_GREEN;
                } else {
                    return null;
                }
            } else if (actualDateCompare <= 0 && needsDateCompare > 0) {
                if (status.equals(Constants.NOGO) || status.equals(Constants.NOT_DELIVERED)
                        || status.equals(Constants.NOT_RECEIVED)) {
                    return Constants.COLOR_LIGHT_GREEN;
                } else if (status.equals(Constants.GO) || status.equals(Constants.DELIVERED)
                        || status.equals(Constants.RECEIVED)) {
                    return Constants.COLOR_STRONG_GREEN;
                } else {
                    return null;
                }
            } else {
                if (status.equals(Constants.NOGO) || status.equals(Constants.NOT_DELIVERED)
                        || status.equals(Constants.NOT_RECEIVED)) {
                    return Constants.COLOR_ORANGE;
                } else if (status.equals(Constants.GO) || status.equals(Constants.DELIVERED)
                        || status.equals(Constants.RECEIVED)) {
                    return Constants.COLOR_YELLOW;
                } else {
                    return null;
                }
            }
        }
    }

    @Override
    public ProjectMilestone isMarketCodeAndMaterialExists(final Integer projectID,
            final String supplierMarketCode, final String materialName) {
        log.debug("Entry:ProjectMilestoneServiceImpl:isCdbCodeAndMaterialExists");

        ProjectMilestone projectMilestone = null;
        try {
            projectMilestone = projectMilestoneRepository.findByMarketCodeAndMaterial(projectID,
                    supplierMarketCode, materialName);
            if (null != projectMilestone) {
                return projectMilestone;
            }
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project Milestone Import",
                    "Error occurred while searching for CDB Code & Material ");
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
        log.debug("Leave:ProjectMilestoneServiceImpl:isCdbCodeAndMaterialExists");
        return projectMilestone;
    }

}
