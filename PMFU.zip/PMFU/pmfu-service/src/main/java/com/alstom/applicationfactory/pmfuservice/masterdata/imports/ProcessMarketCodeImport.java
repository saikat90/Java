package com.alstom.applicationfactory.pmfuservice.masterdata.imports;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.MarketCodeMasterDataService;
import com.alstom.applicationfactory.pmfuservice.util.ImportUtility;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProcessMarketCodeImport {

    /**
     * ImportUtility.
     */
    @Autowired
    private ImportUtility importsUtility;
    /**
     * MarketCodeMasterDataService.
     */
    @Autowired
    private MarketCodeMasterDataService marketCodeMDService;

    /**
     * @param marketCodeSheet
     * @param marketCodeList
     * @param errorList
     */
    public final void processMarketCodeData(final XSSFSheet marketCodeSheet,
            final List<MarketCodeMasterData> marketCodeList, final List<String> errorList) {
        log.debug("Entry:PmfuProcessMarketCodeImport:processMarketCodeData");
        if (Objects.nonNull(marketCodeSheet)) {
            Iterator<Row> rowItr = marketCodeSheet.iterator();
            rowItr.next();
            while (rowItr.hasNext()) {
                MarketCodeMasterData marketCodeRec = new MarketCodeMasterData();
                Row row = rowItr.next();
                if (row.getRowNum() >= 2) {
                    if (importsUtility.isEmptyRow(row)) {
                        break;
                    }
                    String marketCode = row.getCell(0) == null ? ""
                            : row.getCell(0).getStringCellValue();
                    if (marketCode.isEmpty()) {
                        errorList.add("Market Code is empty in Row " + row.getRowNum());
                    } else if (marketCodeMDService.isMarketCodeExists(marketCode)) {
                        errorList.add("Market Code " + marketCode + " already exists.");
                    } else {
                        marketCodeRec.setMarketCode(marketCode);
                        marketCodeRec.setVersion(0);
                        marketCodeRec.setMarketName(
                                row.getCell(1) == null ? "" : row.getCell(1).getStringCellValue());
                        marketCodeRec.setDomainCode(
                                row.getCell(2) == null ? "" : row.getCell(2).getStringCellValue());
                        marketCodeRec.setDomainName(row.getCell(Constants.THREE) == null ? ""
                                : row.getCell(Constants.THREE).getStringCellValue());
                        marketCodeRec.setGlobalLocal(row.getCell(Constants.FOUR) == null ? ""
                                : row.getCell(Constants.FOUR).getStringCellValue());
                        marketCodeRec.setTrain(row.getCell(Constants.FIVE) == null ? ""
                                : row.getCell(Constants.FIVE).getStringCellValue());
                        marketCodeRec.setRailControl(row.getCell(Constants.SIX) == null ? ""
                                : row.getCell(Constants.SIX).getStringCellValue());
                        marketCodeRec.setSystemInfra(row.getCell(Constants.SEVEN) == null ? ""
                                : row.getCell(Constants.SEVEN).getStringCellValue());
                        marketCodeRec.setGoRFQ(row.getCell(Constants.EIGHT) == null ? 0
                                : (int) row.getCell(Constants.EIGHT).getNumericCellValue());
                        marketCodeRec.setBa(row.getCell(Constants.NINE) == null ? 0
                                : (int) row.getCell(Constants.NINE).getNumericCellValue());
                        marketCodeRec.setGoOrder(row.getCell(Constants.TEN) == null ? 0
                                : (int) row.getCell(Constants.TEN).getNumericCellValue());
                        marketCodeRec.setPgr(row.getCell(Constants.ELEVEN) == null ? 0
                                : (int) row.getCell(Constants.ELEVEN).getNumericCellValue());
                        marketCodeRec.setCgr(row.getCell(Constants.TWELVE) == null ? 0
                                : (int) row.getCell(Constants.TWELVE).getNumericCellValue());
                        marketCodeRec.setGoProd(row.getCell(Constants.THIRTEEN) == null ? 0
                                : (int) row.getCell(Constants.THIRTEEN).getNumericCellValue());
                        marketCodeRec.setFai(row.getCell(Constants.FOURTEEN) == null ? 0
                                : (int) row.getCell(Constants.FOURTEEN).getNumericCellValue());
                        marketCodeRec.setIqa(row.getCell(Constants.FIFTEEN) == null ? 0
                                : (int) row.getCell(Constants.FIFTEEN).getNumericCellValue());
                        marketCodeRec.setFqa(row.getCell(Constants.SIXTEEN) == null ? 0
                                : (int) row.getCell(Constants.SIXTEEN).getNumericCellValue());
                        marketCodeRec.setFat(row.getCell(Constants.SEVENTEEN) == null ? 0
                                : (int) row.getCell(Constants.SEVENTEEN).getNumericCellValue());
                        marketCodeList.add(marketCodeRec);
                    }
                }
            }
            log.debug("Leave:PmfuProcessMarketCodeImport:processMarketCodeData");
        } else {
            log.error("Error while fetching the Excel Sheet");
            List<ErrorModel> errorModel = new ArrayList<>();
            errorModel.add(new ErrorModel("Error", "Error while fetching the Excel Sheet"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorModel);
        }

    }

    /**
     * @param marketCode
     * @param dataRow
     * @return Row value.
     */
    public final Row populateExcelRowValue(final MarketCodeMasterData marketCode,
            final Row dataRow) {
        dataRow.createCell(0).setCellValue(marketCode.getMarketCode());
        dataRow.createCell(1).setCellValue(marketCode.getMarketName());
        dataRow.createCell(2).setCellValue(marketCode.getDomainCode());
        dataRow.createCell(Constants.THREE).setCellValue(marketCode.getDomainName());
        dataRow.createCell(Constants.FOUR).setCellValue(marketCode.getGlobalLocal());
        dataRow.createCell(Constants.FIVE).setCellValue(marketCode.getTrain());
        dataRow.createCell(Constants.SIX).setCellValue(marketCode.getRailControl());
        dataRow.createCell(Constants.SEVEN).setCellValue(marketCode.getSystemInfra());
        dataRow.createCell(Constants.EIGHT).setCellValue(marketCode.getGoRFQ());
        dataRow.createCell(Constants.NINE).setCellValue(marketCode.getBa());
        dataRow.createCell(Constants.TEN).setCellValue(marketCode.getGoOrder());
        dataRow.createCell(Constants.ELEVEN).setCellValue(marketCode.getPgr());
        dataRow.createCell(Constants.TWELVE).setCellValue(marketCode.getCgr());
        dataRow.createCell(Constants.THIRTEEN).setCellValue(marketCode.getGoProd());
        dataRow.createCell(Constants.FOURTEEN).setCellValue(marketCode.getFai());
        dataRow.createCell(Constants.FIFTEEN).setCellValue(marketCode.getIqa());
        dataRow.createCell(Constants.SIXTEEN).setCellValue(marketCode.getFqa());
        dataRow.createCell(Constants.SEVENTEEN).setCellValue(marketCode.getFat());
        return dataRow;
    }

}
