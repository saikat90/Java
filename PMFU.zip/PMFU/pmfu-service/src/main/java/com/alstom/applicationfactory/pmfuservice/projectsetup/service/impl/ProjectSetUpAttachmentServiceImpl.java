package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUpAttachment;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpAttachmentModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpAttachmentRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectSetUpAttachmentService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "projectSetUpAttachmentService")
@Transactional
@Slf4j
@RefreshScope
public class ProjectSetUpAttachmentServiceImpl implements ProjectSetUpAttachmentService {

    /**
     * ProjectSetUpAttachmentRepository.
     */
    @Autowired
    private ProjectSetUpAttachmentRepository projectSetUpAttachmentRepository;
    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;
    /**
     * upload path for the attached file.
     */
    @Value("${projectsetup.attachment.upload.path}")
    private String basePath;

    @Override
    public ProjectSetUpAttachmentModel uploadAttachment(final MultipartFile file,
            final String userEmail) {
        log.debug("Entry:ProjectSetUpAttachmentServiceImpl:uploadAttachment");
        if (file.isEmpty()) {
            log.error("Attached file is empty");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Error", "Attached file is empty"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        try {
            String attachedFileName = file.getOriginalFilename();
            ProjectSetUpAttachment projSetUpAttachment = new ProjectSetUpAttachment();
            ProjectSetUpAttachmentModel projSetUpAttachmentCreatedModel = new ProjectSetUpAttachmentModel();
            User userEntity = null;
            projSetUpAttachment.setAttachedFileName(attachedFileName);
            try {
                userEntity = userRepository.findByEmail(userEmail).get(0);
            } catch (NullPointerException ex) {
                log.debug("User not present in the system for the email: " + userEmail);
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel("Error",
                        "User not present in the system for the email: " + userEmail));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            if (null != userEntity) {
                projSetUpAttachment.setCreatedBy(userEntity.getEmployeeId());
            }
            projSetUpAttachment.setCreatedDate(new Timestamp(new Date().getTime()));
            projSetUpAttachment.setVersion(0);
            projSetUpAttachment.setUploadSuccesfull(true);

            projSetUpAttachmentCreatedModel = createAttachment(projSetUpAttachment);

            if (null != projSetUpAttachmentCreatedModel) {

                String uuidString = projSetUpAttachmentCreatedModel.getId().toString();
                String uuidPath = getFilePath(uuidString);
                byte[] bytes = file.getBytes();
                // path to create directories based on UUID
                Path directoryPath = Paths.get(basePath + uuidPath);
                // Getting absolute path for storing images
                Path uploadPath = Paths.get(basePath + uuidPath + file.getOriginalFilename());
                // Creating directories from above path (directoryPath)
                Files.createDirectories(directoryPath);
                // Writing content
                Files.write(uploadPath, bytes);
            }
            log.debug("Leave:ProjectSetUpAttachmentServiceImpl:uploadAttachment");
            return projSetUpAttachmentCreatedModel;
        } catch (IOException e) {
            log.error("Error while performing upload");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Error", "Error while performing upload"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
    }

    private String getFilePath(final String uuidString) {
        String uuidPath = "/";
        Pattern pattern = Pattern.compile(Constants.UUID_PATTERN);
        Matcher matcher = pattern.matcher(uuidString);

        if (matcher.find()) {
            for (int i = 1; i <= matcher.groupCount(); i++) {
                uuidPath = uuidPath + matcher.group(i) + "/";
            }
        }
        return uuidPath;
    }

    private ProjectSetUpAttachmentModel createAttachment(
            final ProjectSetUpAttachment projSetUpAttachment) {
        log.debug("Entry:ProjectSetUpAttachmentServiceImpl:createAttachment");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        ProjectSetUpAttachmentModel projectSetUpAttachmentModel = null;
        try {
            ProjectSetUpAttachment createdProjectSetUpAttachment = new ProjectSetUpAttachment();
            createdProjectSetUpAttachment = projectSetUpAttachmentRepository
                    .save(projSetUpAttachment);
            projectSetUpAttachmentModel = mapper.map(createdProjectSetUpAttachment,
                    ProjectSetUpAttachmentModel.class);
        } catch (Exception e) {
            log.error("Error while creating Attachment");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Error", "Error while creating Attachment"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:ProjectSetUpAttachmentServiceImpl:createAttachment");
        return projectSetUpAttachmentModel;
    }

    @Override
    public File downloadAttachment(final UUID projSetUpAttachmentId) {
        log.debug("Entry:ProjectSetUpAttachmentServiceImpl:downloadAttachment");
        ProjectSetUpAttachment projSetUpAttachment = projectSetUpAttachmentRepository
                .findById(projSetUpAttachmentId).orElse(null);
        File file;
        if (null != projSetUpAttachment) {
            String uuidPath = getFilePath(projSetUpAttachment.getId().toString());
            Path downloadPath = Paths
                    .get(basePath + uuidPath + projSetUpAttachment.getAttachedFileName());
            file = new File(downloadPath.toUri());
        } else {
            log.error("Error occurred while fetching attachment");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Error", "Error occurred while fetching attachment"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:ProjectSetUpAttachmentServiceImpl:downloadAttachment");
        return file;
    }

    @Override
    public byte[] readFileToByteArray(final File file) {
        log.debug("Entry:ProjectSetUpAttachmentServiceImpl:readFileToByteArray");
        FileInputStream fis = null;
        byte[] bArray = new byte[(int) file.length()];
        try {
            fis = new FileInputStream(file);
            int count = fis.read(bArray);
        } catch (IOException e) {
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("File ", "Error in reading attachments"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    log.error("Error while reading file");
                }
            }
        }
        log.debug("Leave:ProjectSetUpAttachmentServiceImpl:readFileToByteArray");
        return bArray;
    }

    @Override
    public void deleteAttachmentById(final UUID id) {
        log.debug("Entry:ProjectSetUpAttachmentServiceImpl:deleteAttachmentById");
        try {
            projectSetUpAttachmentRepository.deleteById(id);
            log.debug("Leave:ProjectSetUpAttachmentServiceImpl:deleteAttachmentById");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Error", e.getMessage());
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }

    }

}
