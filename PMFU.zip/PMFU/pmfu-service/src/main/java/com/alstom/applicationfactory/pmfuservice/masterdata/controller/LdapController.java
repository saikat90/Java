package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.pmfuservice.masterdata.service.LdapService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class LdapController {

    /**
     * LdapService.
     */
    @Autowired
    private LdapService ldapService;

    /**
     * @param request
     * @return user Object
     */
    @PostMapping("/users/search")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public Object findUsers(@RequestBody(required = false) final Map<String, String> request) {
        log.debug("Entry:LdapController:findUsers");
        Object userModelList = this.ldapService.findUsers(request);
        log.debug("Leave:LdapController:findUsers");
        return userModelList;
    }
}
