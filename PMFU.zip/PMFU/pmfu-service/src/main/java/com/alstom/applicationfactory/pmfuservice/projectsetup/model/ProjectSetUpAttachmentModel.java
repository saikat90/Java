package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type project setup attachment model.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectSetUpAttachmentModel {

    /**
     * ProjectSetUpAttachmentModel id.
     */
    private UUID id;

    /**
     * ProjectSetUpAttachmentModel version.
     */
    private Integer version;

    /**
     * ProjectSetUpAttachmentModel file name.
     */
    private String attachedFileName;

    /**
     * ProjectSetUpAttachmentModel upload successful.
     */
    private Boolean uploadSuccesfull;

    /**
     * ProjectSetUpAttachmentModel created date.
     */
    private Date createdDate;

    /**
     * ProjectSetUpAttachmentModel modified date.
     */
    private Date modifiedDate;

    /**
     * ProjectSetUpAttachmentModel created by.
     */
    private String createdBy;

    /**
     * ProjectSetUpAttachmentModel modified by.
     */
    private String modifiedBy;

    /**
     * ProjectSetUpAttachmentModel project set up.
     */
    @JsonIgnore
    private ProjectSetUpModel projectSetUp;
}
