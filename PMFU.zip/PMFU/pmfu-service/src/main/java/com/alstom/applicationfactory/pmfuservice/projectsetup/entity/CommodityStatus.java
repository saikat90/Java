package com.alstom.applicationfactory.pmfuservice.projectsetup.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type CommodityStatus.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pucommodity_status")
public class CommodityStatus {

    /**
     * CommodityStatus id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * CommodityStatus version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * CommodityStatus dfq milestone title.
     */
    @Column(name = "dfq_milestone_title", length = Constants.INT_LENGTH_100)
    private String dfqMilestoneTitle;

    /**
     * CommodityStatus dfq milestone tech input.
     */
    @Column(name = "dfq_milestone_tech_input", length = Constants.INT_LENGTH_20)
    private String dfqMilestoneTechInput;

    /**
     * CommodityStatus dfq milestone goRfq.
     */
    @Column(name = "dfq_milestone_go_rfq", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneGoRfq;

    /**
     * CommodityStatus dfq milestone ba.
     */
    @Column(name = "dfq_milestone_ba", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneBa;

    /**
     * CommodityStatus dfq milestone goOrder.
     */
    @Column(name = "dfq_milestone_go_order", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneGoOrder;

    /**
     * CommodityStatus dfq milestone pgr.
     */
    @Column(name = "dfq_milestone_pgr", length = Constants.INT_LENGTH_2)
    private String dfqMilestonePgr;

    /**
     * CommodityStatus dfq milestone cgr.
     */
    @Column(name = "dfq_milestone_cgr", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneGgr;

    /**
     * CommodityStatus dfq milestone goProd.
     */
    @Column(name = "dfq_milestone_go_prod", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneGoProd;

    /**
     * CommodityStatus dfq milestone fai.
     */
    @Column(name = "dfq_milestone_fai", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneFai;

    /**
     * CommodityStatus dfq milestone iqa.
     */
    @Column(name = "dfq_milestone_iqa", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneIqa;

    /**
     * CommodityStatus dfq milestone fqa.
     */
    @Column(name = "dfq_milestone_fqa", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneFqa;

    /**
     * CommodityStatus dfq milestone fat.
     */
    @Column(name = "dfq_milestone_fat", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneFat;

    /**
     * CommodityStatus dfq milestone first need.
     */
    @Column(name = "dfq_milestone_first_need", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date dfqMilestoneFirstNeed;

    /**
     * CommodityStatus dfq milestone delivery.
     */
    @Column(name = "dfq_milestone_delivery", length = Constants.INT_LENGTH_2)
    private String dfqMilestoneDelivery;

    /**
     * CommodityStatus duration title.
     */
    @Column(name = "duration_title", length = Constants.INT_LENGTH_100)
    private String durationTile;

    /**
     * CommodityStatus duration tech input.
     */
    @Column(name = "duration_tech_input", length = Constants.INT_LENGTH_20)
    private String durationTechInput;

    /**
     * CommodityStatus duration goRfq.
     */
    @Column(name = "duration_go_rfq")
    private Integer durationGoRfq;

    /**
     * CommodityStatus duration ba.
     */
    @Column(name = "duration_ba")
    private Integer durationBa;

    /**
     * CommodityStatus duration goORder.
     */
    @Column(name = "duration_go_order")
    private Integer durationGoOrder;

    /**
     * CommodityStatus duration pgr.
     */
    @Column(name = "duration_pgr")
    private Integer durationPgr;

    /**
     * CommodityStatus duration cgr.
     */
    @Column(name = "duration_cgr")
    private Integer durationCgr;

    /**
     * CommodityStatus duration goProd.
     */
    @Column(name = "duration_go_prod")
    private Integer durationGoProd;

    /**
     * CommodityStatus duration fai.
     */
    @Column(name = "duration_fai")
    private Integer durationFai;

    /**
     * CommodityStatus duration iqa.
     */
    @Column(name = "duration_iqa")
    private Integer durationIqa;

    /**
     * CommodityStatus duration fqa.
     */
    @Column(name = "duration_fqa")
    private Integer durationFqa;

    /**
     * CommodityStatus duration fat.
     */
    @Column(name = "duration_fat")
    private Integer durationFat;

    /**
     * CommodityStatus duration first need.
     */
    @Column(name = "duration_first_need", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date durationFirstNeed;

    /**
     * CommodityStatus duration delivery.
     */
    @Column(name = "duration_delivery")
    private Integer durationDelivery;

    /**
     * CommodityStatus needs title.
     */
    @Column(name = "needs_title", length = Constants.INT_LENGTH_100)
    private String needsTitle;

    /**
     * CommodityStatus needs tech input.
     */
    @Column(name = "needs_tech_input", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsTechInput;

    /**
     * CommodityStatus needs goRfq.
     */
    @Column(name = "needs_go_rfq", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsGoRfq;

    /**
     * CommodityStatus needs ba.
     */
    @Column(name = "needs_ba", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsBa;

    /**
     * CommodityStatus needs goOrder.
     */
    @Column(name = "needs_go_order", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsGoOrder;

    /**
     * CommodityStatus needs pgr.
     */
    @Column(name = "needs_pgr", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsPgr;

    /**
     * CommodityStatus needs cgr.
     */
    @Column(name = "needs_cgr", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsCgr;

    /**
     * CommodityStatus needs goPRod.
     */
    @Column(name = "needs_go_prod", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsGoProd;

    /**
     * CommodityStatus needs fai.
     */
    @Column(name = "needs_fai", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsFai;

    /**
     * CommodityStatus needs iqa.
     */
    @Column(name = "needs_iqa", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsIqa;

    /**
     * CommodityStatus needs fqa.
     */
    @Column(name = "needs_fqa", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsFqa;

    /**
     * CommodityStatus needs fat.
     */
    @Column(name = "needs_fat", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsFat;

    /**
     * CommodityStatus needs first need.
     */
    @Column(name = "needs_first_need", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsFirstNeed;

    /**
     * CommodityStatus needs delivery.
     */
    @Column(name = "needs_delivery", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date needsDelivery;

    /**
     * CommodityStatus actual date title.
     */
    @Column(name = "actual_date_title", length = Constants.INT_LENGTH_100)
    private String actualDateTitle;

    /**
     * CommodityStatus actual date tech input.
     */
    @Column(name = "actual_date_tech_input", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateTechInput;

    /**
     * CommodityStatus actual date goRfq.
     */
    @Column(name = "actual_date_go_rfq", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateGoRfq;

    /**
     * CommodityStatus actual date ba.
     */
    @Column(name = "actual_date_ba", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateBa;

    /**
     * CommodityStatus actual date goORder.
     */
    @Column(name = "actual_date_go_order", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateGoOrder;

    /**
     * CommodityStatus actual date pgr.
     */
    @Column(name = "actual_date_pgr", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDatePgr;

    /**
     * CommodityStatus actual date cgr.
     */
    @Column(name = "actual_date_cgr", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateCgr;

    /**
     * CommodityStatus actual date go prod.
     */
    @Column(name = "actual_date_go_prod", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateGoProd;

    /**
     * CommodityStatus actual date fai.
     */
    @Column(name = "actual_date_fai", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateFai;

    /**
     * CommodityStatus actual date iqa.
     */
    @Column(name = "actual_date_iqa", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateIqa;

    /**
     * CommodityStatus actual date fqa.
     */
    @Column(name = "actual_date_fqa", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateFqa;

    /**
     * CommodityStatus actual date fat.
     */
    @Column(name = "actual_date_fat", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateFat;

    /**
     * CommodityStatus actual date first need.
     */
    @Column(name = "actual_date_first_need", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateFirstNeed;

    /**
     * CommodityStatus actual date delivery.
     */
    @Column(name = "actual_date_delivery", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date actualDateDelivery;

    /**
     * CommodityStatus status title.
     */
    @Column(name = "status_title", length = Constants.INT_LENGTH_100)
    private String statusTitle;

    /**
     * CommodityStatus status tech input.
     */
    @Column(name = "status_tech_input", length = Constants.INT_LENGTH_12)
    private String statusTechInput;

    /**
     * CommodityStatus status goRfq.
     */
    @Column(name = "status_go_rfq", length = Constants.INT_LENGTH_5)
    private String statusGoRfq;

    /**
     * CommodityStatus status ba.
     */
    @Column(name = "status_ba", length = Constants.INT_LENGTH_5)
    private String statusBa;

    /**
     * CommodityStatus status goORder.
     */
    @Column(name = "status_go_order", length = Constants.INT_LENGTH_5)
    private String statusGoOrder;

    /**
     * CommodityStatus status pgr.
     */
    @Column(name = "status_pgr", length = Constants.INT_LENGTH_5)
    private String statusPgr;

    /**
     * CommodityStatus status cgr.
     */
    @Column(name = "status_cgr", length = Constants.INT_LENGTH_5)
    private String statusGgr;

    /**
     * CommodityStatus status goProd.
     */
    @Column(name = "status_go_prod", length = Constants.INT_LENGTH_5)
    private String statusGoProd;

    /**
     * CommodityStatus status fai.
     */
    @Column(name = "status_fai", length = Constants.INT_LENGTH_5)
    private String statusFai;

    /**
     * CommodityStatus status iqa.
     */
    @Column(name = "status_iqa", length = Constants.INT_LENGTH_5)
    private String statusIqa;

    /**
     * CommodityStatus status fqa.
     */
    @Column(name = "status_fqa", length = Constants.INT_LENGTH_5)
    private String statusFqa;

    /**
     * CommodityStatus status fat.
     */
    @Column(name = "status_fat", length = Constants.INT_LENGTH_5)
    private String statusFat;

    /**
     * CommodityStatus status first need.
     */
    @Column(name = "status_first_need", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date statusFirstNeed;

    /**
     * CommodityStatus status delivery.
     */
    @Column(name = "status_delivery", length = Constants.INT_LENGTH_5)
    private String statusDelivery;

    /**
     * CommodityStatus status color title.
     */
    @Column(name = "status_color_title", length = Constants.INT_LENGTH_100)
    private String statusColorTitle;

    /**
     * CommodityStatus status color tech input.
     */
    @Column(name = "status_color_tech_input", length = Constants.INT_LENGTH_10)
    private String statusColorTechInput;

    /**
     * CommodityStatus status color goRfq.
     */
    @Column(name = "status_color_go_rfq", length = Constants.INT_LENGTH_10)
    private String statusColorGoRfq;

    /**
     * CommodityStatus status color ba.
     */
    @Column(name = "status_color_ba", length = Constants.INT_LENGTH_10)
    private String statusColorBa;

    /**
     * CommodityStatus status color goOrder.
     */
    @Column(name = "status_color_go_order", length = Constants.INT_LENGTH_10)
    private String statusColorGoOrder;

    /**
     * CommodityStatus status color pgr.
     */
    @Column(name = "status_color_pgr", length = Constants.INT_LENGTH_10)
    private String statusColorPgr;

    /**
     * CommodityStatus status color cgr.
     */
    @Column(name = "status_color_cgr", length = Constants.INT_LENGTH_10)
    private String statusColorGgr;

    /**
     * CommodityStatus status color goPRod.
     */
    @Column(name = "status_color_go_prod", length = Constants.INT_LENGTH_10)
    private String statusColorGoProd;

    /**
     * CommodityStatus status color fai.
     */
    @Column(name = "status_color_fai", length = Constants.INT_LENGTH_10)
    private String statusColorFai;

    /**
     * CommodityStatus status color iqa.
     */
    @Column(name = "status_color_iqa", length = Constants.INT_LENGTH_10)
    private String statusColorIqa;

    /**
     * CommodityStatus status color fqa.
     */
    @Column(name = "status_color_fqa", length = Constants.INT_LENGTH_10)
    private String statusColorFqa;

    /**
     * CommodityStatus status color fat.
     */
    @Column(name = "status_color_fat", length = Constants.INT_LENGTH_10)
    private String statusColorFat;

    /**
     * CommodityStatus status color firstneed.
     */
    @Column(name = "status_color_first_need", length = Constants.INT_LENGTH_10)
    private String statusColorFirstNeed;

    /**
     * CommodityStatus status color delivery.
     */
    @Column(name = "status_color_delivery", length = Constants.INT_LENGTH_10)
    private String statusColorDelivery;

    /**
     * CommodityStatus project milestone.
     */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pu_market_code_rev_id ", referencedColumnName = Constants.COLUMN_REF_ID)
    private ProjectMilestone projectMilestone;

    /**
     * CommodityStatus sequence.
     */
    @Column(name = "pumarket_code_list_of_commodity_status_seq")
    private Integer listCommodityStatusSeq;

    /**
     * CommodityStatus forecast date title.
     */
    @Column(name = "forecast_date_title", length = Constants.INT_LENGTH_100)
    private String forecastDateTitle;

    /**
     * CommodityStatus forecast date techInput.
     */
    @Column(name = "forecast_date_tech_input", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateTechInput;

    /**
     * CommodityStatus forecast date goRfq.
     */
    @Column(name = "forecast_date_go_rfq", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateGoRfq;

    /**
     * CommodityStatus forecast date ba.
     */
    @Column(name = "forecast_date_ba", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateBa;

    /**
     * CommodityStatus forecast date goOrder.
     */
    @Column(name = "forecast_date_go_order", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateGoOrder;

    /**
     * CommodityStatus forecast date pgr.
     */
    @Column(name = "forecast_date_pgr", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDatePgr;

    /**
     * CommodityStatus forecast date cgr.
     */
    @Column(name = "forecast_date_cgr", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateCgr;

    /**
     * CommodityStatus forecast date goProd.
     */
    @Column(name = "forecast_date_go_prod", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateGoProd;

    /**
     * CommodityStatus forecast date fai.
     */
    @Column(name = "forecast_date_fai", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateFai;

    /**
     * CommodityStatus forecast iqa.
     */
    @Column(name = "forecast_date_iqa", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateIqa;

    /**
     * CommodityStatus forecast fqa date.
     */
    @Column(name = "forecast_date_fqa", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateFqa;

    /**
     * CommodityStatus forecast fat date.
     */
    @Column(name = "forecast_date_fat", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateFat;

    /**
     * CommodityStatus forecast first need date.
     */
    @Column(name = "forecast_date_first_need", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateFirstNeed;

    /**
     * CommodityStatus forecast delivery date.
     */
    @Column(name = "forecast_date_delivery", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date forecastDateDelivery;
}
