package com.alstom.applicationfactory.pmfuservice.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.google.common.collect.ImmutableMap;

public final class RequestModifier {

    private RequestModifier() {
    }

    /**
     * Updates request map with AND condition.
     *
     * @param requestMap       Request map
     * @param filterConditions Filter conditions
     * @return Request map
     */
    public static Map<String, Object> updateRequestMapWithAnd(final Map<String, Object> requestMap,
            final List<Map<String, Object>> filterConditions) {
        return updateRequestMapWithAndOrOr(requestMap, filterConditions, Constants.STR_AND);
    }

    /**
     * Updates request map with OR condition.
     *
     * @param requestMap       Request map
     * @param filterConditions Filter conditions
     * @return Request map
     */
    public static Map<String, Object> updateRequestMapWithOr(final Map<String, Object> requestMap,
            final List<Map<String, Object>> filterConditions) {
        return updateRequestMapWithAndOrOr(requestMap, filterConditions, Constants.STR_OR);
    }

    private static Map<String, Object> updateRequestMapWithAndOrOr(
            final Map<String, Object> requestMap, final List<Map<String, Object>> filterConditions,
            final String condition) {
        Map<String, Object> filter = (Map) ((Map) requestMap.get(Constants.STR_FILTER_JOINS))
                .get(Constants.STR_FILTER);
        if (Objects.nonNull(filter.get(Constants.STR_CONDITION))
                && Objects.nonNull(filter.get(Constants.STR_FILTER_CONDITIONS))) {
            if (filter.get(Constants.STR_CONDITION).toString().equalsIgnoreCase(condition)) {
                List<Map<String, Object>> existingFilterConditions = (List) filter
                        .get(Constants.STR_FILTER_CONDITIONS);
                existingFilterConditions.addAll(filterConditions);
                filter.put(Constants.STR_FILTER_CONDITIONS, existingFilterConditions);
            } else {
                Map<String, Object> filterConditionsBackup = new HashMap<>();
                filterConditionsBackup.put(Constants.STR_CONDITION,
                        filter.get(Constants.STR_CONDITION));
                filterConditionsBackup.put(Constants.STR_FILTER_CONDITIONS,
                        filter.get(Constants.STR_FILTER_CONDITIONS));
                Map<String, Object> filterBackup = new HashMap<>();
                filterBackup.put(Constants.STR_FILTER, filterConditionsBackup);
                filterConditions.add(filterBackup);
                filter.put(Constants.STR_CONDITION, condition);
                filter.put(Constants.STR_FILTER_CONDITIONS, filterConditions);
            }
        } else {
            filter.put(Constants.STR_CONDITION, condition);
            filter.put(Constants.STR_FILTER_CONDITIONS, filterConditions);
        }
        return requestMap;
    }

    /**
     * Returns default map of filter conditions if request map passed is empty.
     *
     * @param requestMap Request map
     * @return Request map
     */
    public static Map<String, Object> defaultRequestMapIfEmpty(
            final Map<String, Object> requestMap) {
        Map<String, Object> returnMap = requestMap;
        if (Objects.isNull(returnMap)) {
            returnMap = new HashMap<>();
        }
        if (Objects.isNull(returnMap.get(Constants.STR_FILTER_JOINS))) {
            returnMap.put(Constants.STR_FILTER_JOINS, new HashMap<>());
        }
        Map<String, Object> filterMap = (Map) returnMap.get(Constants.STR_FILTER_JOINS);
        if (Objects.isNull(filterMap.get(Constants.STR_FILTER))) {
            filterMap.put(Constants.STR_FILTER, new HashMap<>());
        }
        return returnMap;
    }

    /**
     * Returns map of filter conditions.
     *
     * @param type     Type of filter condition
     * @param field    Filter condition field
     * @param data     Filter data
     * @param operator Operator to be used for filtering
     * @return Filter condition map
     */
    public static Map<String, Object> getFilterCondition(final String type, final String field,
            final Object data, final String operator) {
        return ImmutableMap.of(Constants.STR_TYPE, type, Constants.STR_FIELD, field,
                Constants.STR_DATA, data, Constants.STR_OPERATOR, operator);
    }

    /**
     * Returns map of filter conditions.
     *
     * @param type  Type of filter condition
     * @param field Filter condition field
     * @param data  Filter data
     * @return Filter condition map
     */
    public static Map<String, Object> getFilterCondition(final String type, final String field,
            final Object data) {
        return ImmutableMap.of(Constants.STR_TYPE, type, Constants.STR_FIELD, field,
                Constants.STR_DATA, data);
    }
}
