package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.AtSiteRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.AtSiteService;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/atSite")
@Slf4j
public class AtSiteController {

    /**
     * AtSiteService.
     */
    @Autowired
    private AtSiteService atSiteService;
    /**
     * AtSiteRepository.
     */
    @Autowired
    private AtSiteRepository atSiteRepository;

    /**
     * @return Object.
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public Object findAll() {
        log.debug("Entry:PmfuAtSiteController:findAll");
        Object result = this.atSiteRepository.findAll();
        log.debug("Leave:PmfuAtSiteController:findAll");
        return result;
    }

    /**
     * @param request
     * @return Object.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public Object searchAtSite(@RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:PmfuAtSiteController:SearchAtSite");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = atSiteService.searchAtSite(requestModel);
        log.debug("Leave:PmfuAtSiteController:SearchAtSite");
        return res;
    }

    /**
     * @param id
     * @return AtSiteModel
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public AtSiteModel viewAtSite(@PathVariable("id") final UUID id) {
        log.debug("Entry:PmfuAtSiteController:ViewAtSite");
        AtSiteModel atSiteModel = atSiteService.viewAtSite(id);
        log.debug("Leave:PmfuAtSiteController:ViewAtSite");
        return atSiteModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasRole('ADM')")
    public void deleteAtSiteById(@PathVariable("id") final UUID id) {
        log.debug("Entry:PmfuAtSiteController:DeleteAtSite");
        this.atSiteService.deleteAtSiteById(id);
        log.debug("Leave:PmfuAtSiteController:DeleteAtSite");
    }

    /**
     * @param atSite
     * @return AtSiteModel
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_PMFU') and hasRole('ADM')")
    public AtSiteModel createAtSite(@RequestBody @Valid final AtSiteModel atSite) {
        log.debug("Entry:PmfuAtSiteController:CreateAtSite");
        AtSiteModel atSiteModel = atSiteService.createAtSite(atSite);
        log.debug("Leave:PmfuAtSiteController:CreateAtSite");
        return atSiteModel;
    }

    /**
     * @param atSite
     * @return AtSiteModel
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_PMFU') and hasRole('ADM')")
    public AtSiteModel updateAtSite(@RequestBody @Valid final AtSiteModel atSite) {
        log.debug("Entry:PmfuAtSiteController:UpdateAtSite");
        AtSiteModel atSiteModel = atSiteService.updateAtSite(atSite);
        log.debug("Leave:PmfuAtSiteController:UpdateAtSite");
        return atSiteModel;
    }

    /**
     * @param request
     * @return Object
     */
    @PostMapping("/searchlist")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public Object findAtSiteforSearch(
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:PmfuAtSiteController:findAtSiteforSearch");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = atSiteService.findAtSiteforSearch(requestModel);
        log.debug("Leave:PmfuAtSiteController:findAtSiteforSearch");
        return res;
    }

}
