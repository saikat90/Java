package com.alstom.applicationfactory.pmfuservice.listener;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

import com.alstom.applicationfactory.pmfuservice.masterdata.entity.Project;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.UserRepository;

@Configuration
public class KafkaTopicListener {

    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;

    /**
     * ProjectRepository.
     */
    @Autowired
    private ProjectRepository projectRepository;

    /**
     * Synchronize user list from Admin to PMFU.
     * 
     * @param records
     */
    @KafkaListener(topics = "user-list", groupId = "pmfu-service")
    public void refreshUsers(List<Map> records) {
        this.userRepository.saveAll(records.stream()
                .map(record -> new User(UUID.fromString((String) record.get("id")),
                        (String) record.get("employeeId"), (String) record.get("firstName"),
                        (String) record.get("lastName"), (String) record.get("email"),
                        (String) record.get("department")))
                .collect(Collectors.toList()));
    }

    /**
     * Synchronize project data from MDM to PMFU.
     * 
     * @param records
     */
    @KafkaListener(topics = "project-list", groupId = "pmfu-service")
    public void refreshProjects(List<Map> records) {
        this.projectRepository.saveAll(records.stream()
                .map(record -> new Project(
                        Objects.nonNull(record.get("uniqId")) ? Long.valueOf(record.get("uniqId").toString())
                                : null,
                        (String) record.get("ctCode"), (String) record.get("projName"),
                        (String) record.get("custCompanyName"), (String) record.get("unitName"),
                        (Boolean) record.get("prjDeleted")))
                .collect(Collectors.toList()));
    }

}
