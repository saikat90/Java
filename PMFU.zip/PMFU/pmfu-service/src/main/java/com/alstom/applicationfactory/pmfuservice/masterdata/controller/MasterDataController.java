package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.pmfuservice.masterdata.service.MasterDataService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class MasterDataController {

    /**
     * MasterDataService.
     */
    @Autowired
    private MasterDataService masterDataService;

    /**
     * @param request
     * @return project object
     */
    @PostMapping("/projectMasterData/list")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public Object getProjectData(@RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:MasterDataController:getProjectData");
        Object result = this.masterDataService.getProjectData(request);
        log.debug("Leave:MasterDataController:getProjectData");
        return result;
    }
}
