package com.alstom.applicationfactory.pmfuservice.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilterConditionModel {
    /**
     * Filter Condition Type.
     */
    private String type;
    /**
     * Filter Condtion Field.
     */
    private String field;
    /**
     * Filter Condtion Operator.
     */
    private String operator;
    /**
     * Filter Condtion date.
     */
    private Object data;
    /**
     * Filter Condtion filter.
     */
    private FilterModel filter;

}
