package com.alstom.applicationfactory.pmfuservice.exception;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.EmailModel;

import lombok.extern.slf4j.Slf4j;

/**
 * RestResponseEntityExceptionHandler.
 */
@RefreshScope
@RestControllerAdvice
@Slf4j
public class RestResponseEntityExceptionHandler {

    /**
     * List of users to be notified on error.
     */
    @Value("${application.factory.error.reporting.users}")
    private String[] users;
    /**
     */
    private static final String FAILED = "Failed";
    /**
     * Email service feign client.
     */
    @Autowired
    private EmailServiceClient emailServiceClient;

    /**
     * Handles the exception happening in the the application.
     * 
     * @param ex       : Exception
     * @param response : ExceptionModel
     * @return :
     */

    @ExceptionHandler(value = { Exception.class })
    protected ExceptionModel exceptionHandle(final Exception ex,
            final HttpServletResponse response) {
        log.debug("Entry:pmfu-Service:RestResponseEntityExceptionHandler:exceptionHandle.");
        String className = ex.getClass().getSimpleName();
        ExceptionModel exceptionModel = null;
        List<ErrorModel> errors = new ArrayList<>();
        switch (className) {
        case "MethodArgumentNotValidException":
            List<ErrorModel> errorsList = validationMsgMethod((MethodArgumentNotValidException) ex);
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            exceptionModel = new ExceptionModel(HttpStatus.BAD_REQUEST.value(), FAILED, errorsList);
            break;
        case "AccessDeniedException":
            errors.add(new ErrorModel(Constants.UNAUTHORIZED, Constants.UNAUTHORIZED_MSG));
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            exceptionModel = new ExceptionModel(HttpStatus.UNAUTHORIZED.value(), FAILED, errors);
            break;
        case "NoHandlerFoundException":
            errors.add(new ErrorModel(Constants.RESOURCE, Constants.RESOURCE_MSG));
            response.setStatus(HttpStatus.NOT_FOUND.value());
            exceptionModel = new ExceptionModel(HttpStatus.NOT_FOUND.value(), FAILED, errors);
            break;
        case "ApplicationFactoryException":
            ApplicationFactoryException cEx = (ApplicationFactoryException) ex;
            response.setStatus(cEx.getErrorCode());
            errors = (cEx.getErrorModelList());
            exceptionModel = new ExceptionModel(cEx.getErrorCode(), FAILED, errors);
            break;
        case "SoapFaultClientException":
            errors.add(new ErrorModel(Constants.REQUEST, Constants.REQUEST_MSG));
            response.setStatus(HttpStatus.NO_CONTENT.value());
            exceptionModel = new ExceptionModel(HttpStatus.NO_CONTENT.value(), FAILED, errors);
            break;
        case "HttpMediaTypeException":
            errors.add(new ErrorModel(Constants.MEDIA_TYPE, Constants.MEDIA_TYPE_MSG));
            response.setStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value());
            exceptionModel = new ExceptionModel(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value(), FAILED,
                    errors);
            break;
        case "HystrixRuntimeException":
            errors.add(new ErrorModel(Constants.SERVER_ERROR, Constants.HYSTRIX_ERROR));
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            exceptionModel = new ExceptionModel(HttpStatus.BAD_REQUEST.value(), FAILED, errors);
            break;
        case "InvalidDataAccessApiUsageException":
            errors.add(new ErrorModel(Constants.SERVER_ERROR, Constants.DATA_ACCESS_ISSUE));
            response.setStatus(HttpStatus.NOT_FOUND.value());
            exceptionModel = new ExceptionModel(HttpStatus.NOT_FOUND.value(), FAILED, errors);
            break;
        case "NumberFormatException":
            errors.add(new ErrorModel(Constants.DATA_ERROR, Constants.DATA_ERROR_MSG));
            response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
            exceptionModel = new ExceptionModel(HttpStatus.NOT_ACCEPTABLE.value(), FAILED, errors);
            break;
        case "MappingException":
            errors.add(new ErrorModel(Constants.MAPPING_ERROR, Constants.MAPPING_ERROR_MSG));
            response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
            exceptionModel = new ExceptionModel(HttpStatus.NOT_ACCEPTABLE.value(), FAILED, errors);
            break;
        case "NullPointerException":
            errors.add(new ErrorModel(Constants.FIELD_NULL, Constants.FIELD_NULL_MSG));
            response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
            exceptionModel = new ExceptionModel(HttpStatus.NOT_ACCEPTABLE.value(), FAILED, errors);
            break;
        case "DataIntegrityViolationException":
            errors.add(new ErrorModel(Constants.MAPPING_ERROR, Constants.DATA_EXITS));
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            exceptionModel = new ExceptionModel(HttpStatus.BAD_REQUEST.value(), FAILED, errors);
            break;
        case "MismatchedInputException":
            errors.add(new ErrorModel(Constants.MAPPING_ERROR, Constants.DATA_CONVERT_ERROR));
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            exceptionModel = new ExceptionModel(HttpStatus.BAD_REQUEST.value(), FAILED, errors);
            break;
        case "ConstraintViolationException":
            errors.add(new ErrorModel(Constants.MAPPING_ERROR, Constants.DATA_VIOLATION));
            response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
            exceptionModel = new ExceptionModel(HttpStatus.NOT_ACCEPTABLE.value(), FAILED, errors);
            break;
        default:
            errors.add(new ErrorModel(Constants.SERVER_ERROR, Constants.FACTORY_ADMIN_MSG));
            log.debug("Internal server error.");
            response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
            exceptionModel = new ExceptionModel(HttpStatus.NOT_ACCEPTABLE.value(), FAILED, errors);
            EmailModel email = new EmailModel();
            String errorReport = ExceptionUtils.getFullStackTrace(ex);
            email.setBody(errorReport);
            email.setRecipients(Arrays.asList(users));
            email.setSubject("Application Factory Error Report");
            emailServiceClient.sendMail(email);
            log.error("RestResponseEntityExceptionHandler actual error:: " + ex);
            break;
        }
        log.debug("Leave:pmfu-Service:RestResponseEntityExceptionHandler:exceptionHandle.");
        return exceptionModel;
    }

    /**
     * validationMsgMethod.
     * 
     * @param ex : MethodArgumentNotValidException
     * @return : List<ErrorModel>
     */
    private List<ErrorModel> validationMsgMethod(MethodArgumentNotValidException ex) {
        return ex.getBindingResult().getFieldErrors().stream()
                .map(x -> new ErrorModel(x.getField(), x.getDefaultMessage()))
                .collect(Collectors.toList());
    }

}
