package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Project model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectModel {
    /**
     * The Uniq id.
     */
    private Long uniqId;
    /**
     * The Ct code.
     */
    private String ctCode;
    /**
     * The Proj name.
     */
    private String projName;
    /**
     * The Cust company name.
     */
    private String custCompanyName;
    /**
     * The Unit name.
     */
    private String unitName;
    /**
     * The Prj deleted.
     */
    private boolean prjDeleted;
}
