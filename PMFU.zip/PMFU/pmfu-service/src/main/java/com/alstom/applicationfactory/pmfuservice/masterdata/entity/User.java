package com.alstom.applicationfactory.pmfuservice.masterdata.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type User.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "af_user")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class User implements Serializable {
    /**
     * User id.
     */
    @Id
    private UUID id;
    /**
     * User employeeId.
     */
    @Column(nullable = false, length = Constants.INT_LENGTH_30)
    private String employeeId;
    /**
     * User firstName.
     */
    @Column(nullable = false, length = Constants.INT_LENGTH_50)
    private String firstName;
    /**
     * User lastName.
     */
    @Column(nullable = false, length = Constants.INT_LENGTH_50)
    private String lastName;
    /**
     * User email.
     */
    @Column(nullable = false, length = Constants.INT_LENGTH_100)
    private String email;
    /**
     * User department.
     */
    @Column(nullable = false, length = Constants.INT_LENGTH_50)
    private String department;
}
