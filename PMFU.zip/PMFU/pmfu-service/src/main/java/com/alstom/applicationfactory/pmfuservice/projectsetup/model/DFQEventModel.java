package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type dfq event model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DFQEventModel {

    /**
     * DFQEventModel market code.
     */
    private String marketCode;

    /**
     * DFQEventModel material.
     */
    private String material;

    /**
     * DFQEventModel milestone.
     */
    private String mileStone;

    /**
     * DFQEventModel needs date.
     */
    private Date needsDate;

    /**
     * DFQEventModel actual date.
     */
    private Date actualDate;

    /**
     * DFQEventModel time.
     */
    private String time;

    /**
     * DFQEventModel variance.
     */
    private Integer variance;

    /**
     * DFQEventModel status.
     */
    private String status;
}
