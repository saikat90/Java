package com.alstom.applicationfactory.pmfuservice.config;

import com.alstom.applicationfactory.pmfuservice.feign.Interceptor;
import feign.RequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignConfig {
    /**
     * Request interceptor bean for feign client.
     *
     * @return Request interceptor for feign client
     */
    @Bean
    public RequestInterceptor getFeignClientInterceptor() {
        return new Interceptor();
    }
}
