package com.alstom.applicationfactory.pmfuservice.masterdata.imports;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.MarketCodeMasterDataRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.MarketCodeMasterDataService;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectMilestoneService;
import com.alstom.applicationfactory.pmfuservice.util.ImportUtility;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProcessProjectMilestoneImport {

    /**
     * ImportUtility.
     */
    @Autowired
    private ImportUtility importsUtility;
    /**
     * ProjectMilestoneService.
     */
    @Autowired
    private ProjectMilestoneService projectMilestoneService;

    /**
     * MarketCodeMasterDataRepository.
     */
    @Autowired
    private MarketCodeMasterDataRepository marketCodeMasterDataRepository;

    /**
     * MarketCodeMasterDataService.
     */
    @Autowired
    private MarketCodeMasterDataService marketCodeMasterDataService;

    /**
     * Tech Input values.
     */
    private static final List<String> techInputValues = Collections.unmodifiableList(Arrays
            .asList("Plan", "Specification", "plan", "specification", "PLAN", "SPECIFICATION"));

    /**
     * Milestone values.
     */
    private static final List<String> mileStoneValues = Collections
            .unmodifiableList(Arrays.asList("X", "NA", "x", "na", "Na"));

    /**
     * @param projectMilestoneSheet
     * @param puproject_market_projectMilestoneMap
     * @param errorList
     * @param projectSetupId
     */
    public final void processProjectMilestoneData(final XSSFSheet projectMilestoneSheet,
            final Map<String, List<ProjectMilestone>> puproject_market_projectMilestoneMap,
            final List<String> errorList, final Integer projectSetupId) {
        log.debug("Entry:PmfuProcessProjectMilestoneImport:processProjectMilestoneData");

        MarketCodeMasterData marketCodeMasterData = new MarketCodeMasterData();
        if (Objects.nonNull(projectMilestoneSheet)) {
            Iterator<Row> rowItr = projectMilestoneSheet.iterator();
            rowItr.next(); // Need to optimize the logic in case of blank sheet
            while (rowItr.hasNext()) {
                ProjectMilestone projectMilestoneRec = new ProjectMilestone();
                Row row = rowItr.next();
                Boolean processRecord = true;
                if (row.getRowNum() >= 2) {
                    if (importsUtility.isEmptyRow(row)) {
                        processRecord = false;
                        break;
                    }
                    StringBuffer errorAppender = new StringBuffer();
                    String cdbCode = row.getCell(Constants.FIFTEEN) == null ? ""
                            : row.getCell(Constants.FIFTEEN).getStringCellValue();
                    Integer excelProjectSetupId = row.getCell(Constants.FOURTEEN) == null ? 0
                            : (int) row.getCell(Constants.FOURTEEN).getNumericCellValue();
                    String material = row.getCell(0) == null ? ""
                            : row.getCell(0).getStringCellValue();
                    String supplierMarketCode = row.getCell(1) == null ? ""
                            : row.getCell(1).getStringCellValue();
                    errorAppender.append("\nIn Row Number " + (row.getRowNum() + 1) + "- ");
                    if (material.isEmpty()) {
                        errorAppender.append(" Material Name is empty. ");
                        processRecord = false;
                    }
                    if (supplierMarketCode.isEmpty()) {
                        errorAppender.append(" Market Code is empty. ");
                        processRecord = false;
                    } else if (!marketCodeMasterDataService
                            .isMarketCodeExists(supplierMarketCode)) {
                        errorAppender.append(" Supplier Market Code " + supplierMarketCode
                                + " does not exist. ");
                        processRecord = false;
                    }
                    if (excelProjectSetupId == 0) {
                        errorAppender.append(" Project ID is empty. ");
                        processRecord = false;
                    } else if (!excelProjectSetupId.equals(projectSetupId)) {
                        errorAppender.append(" Project ID does not belong to this Project Setup. ");
                        processRecord = false;
                    }
                    if (cdbCode.isEmpty()) {
                        errorAppender.append(" CDB Code is empty. ");
                        processRecord = false;
                    } else if (!projectMilestoneService
                            .isProjectIDAndCdbCodeExists(excelProjectSetupId, cdbCode)) {
                        errorAppender.append(" Project ID " + excelProjectSetupId + " or CDB Code "
                                + cdbCode + " does not exist for this Project Setup. ");
                        processRecord = false;
                    }
                    if (!validateOtherCellData(row)) {
                        errorAppender.append(" Error in Column C to K. ");
                        processRecord = false;
                    }
                    if (processRecord) {
                        projectMilestoneRec.setVersion(0);
                        projectMilestoneRec.setCdbCode(cdbCode);
                        projectMilestoneRec.setProjectId(excelProjectSetupId);
                        projectMilestoneRec.setMaterial(material);
                        projectMilestoneRec.setTechInput(row.getCell(2) == null ? ""
                                : row.getCell(2).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setGoRfq(row.getCell(Constants.THREE) == null ? ""
                                : row.getCell(Constants.THREE).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setBa(row.getCell(Constants.FOUR) == null ? ""
                                : row.getCell(Constants.FOUR).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setGoOrder(row.getCell(Constants.FIVE) == null ? ""
                                : row.getCell(Constants.FIVE).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setPgr(row.getCell(Constants.SIX) == null ? ""
                                : row.getCell(Constants.SIX).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setCgr(row.getCell(Constants.SEVEN) == null ? ""
                                : row.getCell(Constants.SEVEN).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setGoProd(row.getCell(Constants.EIGHT) == null ? ""
                                : row.getCell(Constants.EIGHT).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setFai(row.getCell(Constants.NINE) == null ? ""
                                : row.getCell(Constants.NINE).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setFat(row.getCell(Constants.TEN) == null ? ""
                                : row.getCell(Constants.TEN).getStringCellValue().toUpperCase());
                        if (row.getCell(Constants.ELEVEN) != null) {
                            try {
                                //row.getCell(Constants.ELEVEN).setCellType(CellType.STRING);
                                //projectMilestoneRec.setFirstNeed(new SimpleDateFormat("dd/MM/yyyy")
                                        //.parse(row.getCell(Constants.ELEVEN).getStringCellValue()));
                                Date firstNeedDate = row.getCell(Constants.ELEVEN).getDateCellValue();
                                
                                SimpleDateFormat formatter  = new SimpleDateFormat("dd/MM/yyyy"); 
                                projectMilestoneRec.setFirstNeed(formatter.parse(formatter.format(firstNeedDate)));
                            } catch (Exception e) {
                                log.error(
                                        " Error while parsing first Need Date. Date should be of format DD/MM/YYYY. ");
                                List<ErrorModel> errorModel = new ArrayList<>();
                                errorModel.add(new ErrorModel("Error",
                                        " Error while parsing first Need Date. Date should be of format DD/MM/YYYY. "));
                                throw new ApplicationFactoryException(Constants.ERROR_CODE_406,
                                        errorModel);
                            }
                        } else {
                            projectMilestoneRec.setFirstNeed(null);
                        }

                        projectMilestoneRec.setIqa(row.getCell(Constants.TWELVE) == null ? ""
                                : row.getCell(Constants.TWELVE).getStringCellValue().toUpperCase());
                        projectMilestoneRec.setFqa(row.getCell(Constants.THIRTEEN) == null ? ""
                                : row.getCell(Constants.THIRTEEN).getStringCellValue()
                                        .toUpperCase());

                        projectMilestoneRec.setSupplierMarketCode(supplierMarketCode);

                        marketCodeMasterData = marketCodeMasterDataRepository
                                .findByMarketCode(supplierMarketCode);

                        if (Objects.nonNull(marketCodeMasterData)) {
                            projectMilestoneRec
                                    .setSupplierMarketName(marketCodeMasterData.getMarketName());
                            projectMilestoneRec.setDomainCode(marketCodeMasterData.getDomainCode());
                            projectMilestoneRec.setDomainName(marketCodeMasterData.getDomainName());
                            projectMilestoneRec
                                    .setGlobalLocal(marketCodeMasterData.getGlobalLocal());
                            projectMilestoneRec.setTrain(marketCodeMasterData.getTrain());
                            projectMilestoneRec
                                    .setRailControl(marketCodeMasterData.getRailControl());
                            projectMilestoneRec
                                    .setSystemInfra(marketCodeMasterData.getSystemInfra());

                            projectMilestoneRec.setMcGoRfq(marketCodeMasterData.getGoRFQ());
                            projectMilestoneRec.setMcBa(marketCodeMasterData.getBa());
                            projectMilestoneRec.setMcGoOrder(marketCodeMasterData.getGoOrder());
                            projectMilestoneRec.setMcPgr(marketCodeMasterData.getPgr());
                            projectMilestoneRec.setMcCgr(marketCodeMasterData.getCgr());
                            projectMilestoneRec.setMcGoProd(marketCodeMasterData.getGoProd());
                            projectMilestoneRec.setMcFai(marketCodeMasterData.getFai());
                            projectMilestoneRec.setMcIqa(marketCodeMasterData.getIqa());
                            projectMilestoneRec.setMcFqa(marketCodeMasterData.getFqa());
                            projectMilestoneRec.setMcFat(marketCodeMasterData.getFat());
                        }
                        if (puproject_market_projectMilestoneMap.containsKey(supplierMarketCode)) {
                            List<ProjectMilestone> projectMilestoneList = new ArrayList<>();
                            projectMilestoneList = puproject_market_projectMilestoneMap
                                    .get(supplierMarketCode);
                            projectMilestoneList.add(projectMilestoneRec);
                            puproject_market_projectMilestoneMap.replace(supplierMarketCode,
                                    projectMilestoneList);
                        } else {
                            List<ProjectMilestone> projectMilestoneList = new ArrayList<>();
                            projectMilestoneList.add(projectMilestoneRec);
                            puproject_market_projectMilestoneMap.put(supplierMarketCode,
                                    projectMilestoneList);
                        }
                    } else {
                        errorList.add(errorAppender.toString());
                    } // end of if else processRecord
                } // end of if row.getRowNum()
            } // end of while loop
            log.debug("Leave:PmfuProcessProjectMilestoneImport:processProjectMilestoneData");
        } else {
            log.error(" Proccessed excel sheet is in wrong fromat, check & correct the format. ");
            List<ErrorModel> errorModel = new ArrayList<>();
            errorModel.add(new ErrorModel("Error",
                    " Proccessed excel sheet is in wrong fromat, check & correct the format. "));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorModel);
        }

    }

    /**
     * @param row
     * @return BOOLEAN
     */
    private boolean validateOtherCellData(final Row row) {
        String techInput = row.getCell(2) == null ? "" : row.getCell(2).getStringCellValue();

        // List<Integer> columnToBeChecked = Arrays.asList(3, 4, 5, 6, 7, 8, 9, 10, 12,
        // 13);
        List<Integer> columnToBeChecked = Arrays.asList(Constants.THREE, Constants.FOUR,
                Constants.FIVE, Constants.SIX, Constants.SEVEN, Constants.EIGHT, Constants.NINE,
                Constants.TEN, Constants.TWELVE, Constants.THIRTEEN);
        if ((!techInput.equals("")) && !techInputValues.contains(techInput)) {
            return false;
        }
        for (int i = 0; i < columnToBeChecked.size(); i++) {
            String mileStone = row.getCell(columnToBeChecked.get(i)) == null ? ""
                    : row.getCell(columnToBeChecked.get(i)).getStringCellValue();
            if ((!mileStone.equals("")) && !mileStoneValues.contains(mileStone)) {
                return false;
            }
        }
        return true;
    }

}
