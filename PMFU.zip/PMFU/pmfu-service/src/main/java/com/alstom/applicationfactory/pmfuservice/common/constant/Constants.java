package com.alstom.applicationfactory.pmfuservice.common.constant;

/**
 * The type Constants.
 */
public final class Constants {
    private Constants() {
    }

    /**
     * The constant FIELD_PROJECT.
     */
    public static final String FIELD_PROJECT = "Project";
    /**
     * The constant FIELD_EMAIL.
     */
    public static final String FIELD_EMAIL = "Email";
    /**
     * The constant FIELD_ERROR.
     */
    public static final String FIELD_ERROR = "Error";

    /**
     * The constant INTERNAL_ERROR.
     */
    public static final String MSG_EMAIL_RECIPIENT_ARE_NOT_ADDED = "Email recipients are not added.";
    /**
     * The constant MSG_MASTER_DATA_SERVICE_DOWN.
     */
    public static final String MSG_MASTER_DATA_SERVICE_DOWN = "Master data service down.";
    /**
     * The constant ERROR_CODE_406.
     */
    public static final int ERROR_CODE_406 = 406;
    /**
     * The constant ERROR_CODE_405.
     */
    public static final int ERROR_CODE_405 = 405;
    /**
     * The constant INTERNAL_ERROR_MSG.
     */
    public static final String INTERNAL_ERROR_MSG = "not able to perform this operation.";
    /**
     * The constant INTERNAL_ERROR.
     */
    public static final Integer INTERNAL_ERROR = 500;

    /**
     * The constant IMPORTS_FILE_NAME.
     */
    public static final String IMPORTS_FILE_NAME = "";
    /**
     * The constant TOTAL_EXCEL_SHEET.
     */
    public static final Integer TOTAL_EXCEL_SHEET = 1;
    /**
     * The constant MARKETCODE_SHEET_NAME.
     */
    public static final String MARKETCODE_SHEET_NAME = "PUMarketCodeMasterData";
    /**
     * The constant ATSITE_SHEET_NAME.
     */
    public static final String ATSITE_SHEET_NAME = "PUATSite";
    /**
     * The constant PROJECT_SHEET_NAME.
     */
    public static final String PROJECT_SHEET_NAME = "PUProject";
    /**
     * The constant MILESTONE_SHEET_NAME.
     */
    public static final String MILESTONE_SHEET_NAME = "SPL Model";
    /**
     * The constant COLOR_WHITE.
     */
    public static final String COLOR_WHITE = "0xFFFFFFFF";
    /**
     * The constant COLOR_GREY.
     */
    public static final String COLOR_GREY = "0xFFD3D3D3";
    /**
     * The constant COLOR_STRONG_GREEN.
     */
    public static final String COLOR_STRONG_GREEN = "0xFF33CC33";
    /**
     * The constant COLOR_YELLOW.
     */
    public static final String COLOR_YELLOW = "0xFFFFFF00";
    /**
     * The constant COLOR_RED.
     */
    public static final String COLOR_RED = "0xFFFF0000";
    /**
     * The constant COLOR_ORANGE.
     */
    public static final String COLOR_ORANGE = "0xFFFFA500";
    /**
     * The constant COLOR_LIGHT_GREEN.
     */
    public static final String COLOR_LIGHT_GREEN = "0xFF90EA90";

    /**
     * The constant UUID_PATTERN.
     */
    public static final String UUID_PATTERN = "([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})-([0-9A-Fa-f]{4})-([0-9A-Fa-f]{4})-([0-9A-Fa-f]{4})-([0-9A-Fa-f]{12})";

    /**
     * The constant ALLACTIONS_SHEET_NAME.
     */
    public static final String ALLACTIONS_SHEET_NAME = "AllActions";
    /**
     * The constant PROJECT_MASTERDATA_SHEET_NAME.
     */
    public static final String PROJECT_MASTERDATA_SHEET_NAME = "ProjectMasterData";
    /**
     * The constant USER_NOT_EXIST.
     */
    public static final String USER_NOT_EXIST = "User does not exist in the application: ";
    /**
     * The constant RECORD_ALREADY_EXIST.
     */
    public static final String RECORD_ALREADY_EXIST = "Record already exists with the same name. Please update existing record.";
    /**
     * The constant RECORD_DOES_NOT_EXIST.
     */
    public static final String RECORD_DOES_NOT_EXIST = "Record does not exists.";
    /**
     * The constant SAVED_QUERY_SHARED.
     */
    public static final String SAVED_QUERY_SHARED = "_shared";
    /**
     * The constant INT_LENGTH_11.
     */
    public static final int INT_LENGTH_11 = 11;
    /**
     * The constant INT_LENGTH_100.
     */
    public static final int INT_LENGTH_100 = 100;
    /**
     * The constant INT_LENGTH_110.
     */
    public static final int INT_LENGTH_110 = 110;
    /**
     * The constant INT_LENGTH_50.
     */
    public static final int INT_LENGTH_50 = 50;
    /**
     * The constant INT_LENGTH_30.
     */
    public static final int INT_LENGTH_30 = 30;
    /**
     * The constant INT_LENGTH_20.
     */
    public static final int INT_LENGTH_20 = 20;
    /**
     * The constant INT_LENGTH_200.
     */
    public static final int INT_LENGTH_200 = 200;
    /**
     * The constant INT_LENGTH_16.
     */
    public static final int INT_LENGTH_16 = 16;
    /**
     * The constant INT_LENGTH_1.
     */
    public static final int INT_LENGTH_1 = 1;
    /**
     * The constant INT_LENGTH_300.
     */
    public static final int INT_LENGTH_300 = 300;
    /**
     * The constant INT_LENGTH_500.
     */
    public static final int INT_LENGTH_500 = 500;
    /**
     * The constant INT_LENGTH_5000.
     */
    public static final int INT_LENGTH_5000 = 5000;
    /**
     * The constant INT_LENGTH_10.
     */
    public static final int INT_LENGTH_10 = 10;
    /**
     * The constant INT_LENGTH_4096.
     */
    public static final int INT_LENGTH_4096 = 4096;
    /**
     * The constant INT_LENGTH_2.
     */
    public static final int INT_LENGTH_2 = 2;
    /**
     * The constant INT_LENGTH_12.
     */
    public static final int INT_LENGTH_12 = 12;
    /**
     * The constant INT_LENGTH_13.
     */
    public static final int INT_LENGTH_13 = 13;
    /**
     * The constant INT_LENGTH_5.
     */
    public static final int INT_LENGTH_5 = 5;
    /**
     * The constant INT_LENGTH_14.
     */
    public static final int INT_LENGTH_14 = 14;
    /**
     * The constant INT_LENGTH_3.
     */
    public static final int INT_LENGTH_3 = 3;
    /**
     * The constant INT_LENGTH_8.
     */
    public static final int INT_LENGTH_8 = 8;
    /**
     * The constant COLUMN_REF_ID.
     */
    public static final String COLUMN_REF_ID = "id";
    /**
     * The constant COLUMN_CARAT_CODE_NOTEMPTY.
     */
    public static final String CARAT_CODE_NOTEMPTY = "Carat Code should not be empty.";
    /**
     * Empty email recipients message.
     */
    public static final String EMPTY_EMAIL_RECIPIENTS = "Email recipients should not be empty.";
    /**
     * Empty email subject message.
     */
    public static final String EMPTY_EMAIL_SUBJECT = "Email subject should not be empty.";
    /**
     * Email subject min max message.
     */
    public static final String EMAIL_SUBJECT_MIN_MAX = "Subject should be 1-500 characters.";
    /**
     * Empty email body message.
     */
    public static final String EMPTY_EMAIL_BODY = "Email body should not be empty.";
    /**
     * Email body min max message.
     */
    public static final String EMAIL_BODY_MIN_MAX = "Body should be 1-5000 characters.";
    /**
     * The constant COLUMN_MARKET_CODE_NOTEMPTY.
     */
    public static final String MARKET_CODE_NOTEMPTY = "Market Code should not be empty.";
    /**
     * The constant MARKET_NAME_NOTEMPTY.
     */
    public static final String MARKET_NAME_NOTEMPTY = "Market Name should not be empty.";
    /**
     * The constant DOMAIN_CODE_NOTEMPTY.
     */
    public static final String DOMAIN_CODE_NOTEMPTY = "Domain Code should not be empty.";
    /**
     * The constant GORFQ_NOTEMPTY.
     */
    public static final String GORFQ_NOTEMPTY = "GO RFQ should not be empty.";
    /**
     * The constant BA_NOTEMPTY.
     */
    public static final String BA_NOTEMPTY = "BA should not be empty.";
    /**
     * The constant GOORDER_NOTEMPTY.
     */
    public static final String GOORDER_NOTEMPTY = "GO ORDER should not be empty.";
    /**
     * The constant PGR_NOTEMPTY.
     */
    public static final String PGR_NOTEMPTY = "PGR should not be empty.";
    /**
     * The constant CGR_NOTEMPTY.
     */
    public static final String CGR_NOTEMPTY = "CGR should not be empty.";
    /**
     * The constant GOPROD_NOTEMPTY.
     */
    public static final String GOPROD_NOTEMPTY = "GO PROD should not be empty.";
    /**
     * The constant FAI_NOTEMPTY.
     */
    public static final String FAI_NOTEMPTY = "FAI should not be empty.";
    /**
     * The constant IQA_NOTEMPTY.
     */
    public static final String IQA_NOTEMPTY = "IQA should not be empty.";
    /**
     * The constant FQA_NOTEMPTY.
     */
    public static final String FQA_NOTEMPTY = "FQA should not be empty.";
    /**
     * The constant FAT_NOTEMPTY.
     */
    public static final String FAT_NOTEMPTY = "FAT should not be empty.";
    /**
     * Employee id max length message.
     */
    public static final String EMPLOYEE_ID_MAX_MESSAGE = "Employee ID should be 1-30 characters.";
    /**
     * Employee id not empty message.
     */
    public static final String EMPLOYEE_ID_NOT_EMPTY_MESSAGE = "Employee ID should not be empty.";
    /**
     * First name max length message.
     */
    public static final String FIRST_NAME_MAX_MESSAGE = "First Name should be 1-50 characters.";
    /**
     * First name not empty message.
     */
    public static final String FIRST_NAME_NOT_EMPTY_MESSAGE = "First Name should not be empty.";
    /**
     * Last name max length message.
     */
    public static final String LAST_NAME_MAX_MESSAGE = "Last Name should be 1-50 characters.";
    /**
     * Last name not empty message.
     */
    public static final String LAST_NAME_NOT_EMPTY_MESSAGE = "Last Name should not be empty.";
    /**
     * Email id max length message.
     */
    public static final String EMAIL_ID_MAX_MESSAGE = "Email id should be 1-100 characters.";
    /**
     * Email id not empty message.
     */
    public static final String EMAIL_ID_NOT_EMPTY_MESSAGE = "Email id should not be empty.";
    /**
     * Department max length message.
     */
    public static final String DEPARTMENT_MAX_MESSAGE = "Department should be 1-50 characters.";
    /**
     * Department id not empty message.
     */
    public static final String DEPARTMENT_NOT_EMPTY_MESSAGE = "Department should not be empty.";
    /**
     * Column definition date.
     */
    public static final String COLUMN_DEF_DATE = "DATE";
    /**
     * Column mapping TABLE_PROJECT_MARKET.
     */
    public static final String TABLE_PROJECT_MARKET = "projectMarket";
    /**
     * Column mapping TABLE_COMMODITY_ACTION_PLAN.
     */
    public static final String TABLE_COMMODITY_ACTION_PLAN = "commodityActionPlan";
    /**
     * Column mapping TABLE_COMMODITY_CONTRACT.
     */
    public static final String TABLE_COMMODITY_CONTRACT = "commodityContract";
    /**
     * Column mapping TABLE_PROJECT_MILESTONE.
     */
    public static final String TABLE_PROJECT_MILESTONE = "projectMilestone";
    /**
     * Column mapping TABLE_PROJECT_SETUP.
     */
    public static final String TABLE_PROJECT_SETUP = "projectSetUp";
    /**
     * The constant PRSM_NOTEMPTY.
     */
    public static final String PRSM_NOTEMPTY = "PRSM should not be empty.";
    /**
     * The constant PRODUCTLINE_NOTEMPTY.
     */
    public static final String PRODUCTLINE_NOTEMPTY = "Product Line should not be empty.";
    /**
     * The constant SITE_NOTEMPTY.
     */
    public static final String SITE_NOTEMPTY = "Site should not be empty.";
    /**
     * The constant PROJECT_NOTEMPTY.
     */
    public static final String PROJECT_NOTEMPTY = "Project should not be empty.";
    /**
     * The constant PROJECT_ID_NOTEMPTY.
     */
    public static final String PROJECT_ID_NOTEMPTY = "Project Id should not be empty.";
    /**
     * The constant VERSION_NOTEMPTY.
     */
    public static final String VERSION_NOTEMPTY = "Version should not be empty";
    /**
     * The constant PIC_MAX_MSG.
     */
    public static final String PIC_MAX_MSG = "Pic should not be more than 200 characters";
    /**
     * The constant DESC_MAX_MSG.
     */
    public static final String DESC_MAX_MSG = "Description should not be more than 500 characters";
    /**
     * The constant PRIORITY_MAX_MSG.
     */
    public static final String PRIORITY_MAX_MSG = "Priority should not be more than 1 character";
    /**
     * The constant STATUS_MAX_MSG.
     */
    public static final String STATUS_MAX_MSG = "Status should not be more than 5 characters";
    /**
     * The constant MATERIAL_MAX_MSG.
     */
    public static final String MATERIAL_MAX_MSG = "Material should not be more than 500 characters";
    /**
     * The constant ON_TIME.
     */
    public static final String ON_TIME = "ON_TIME";
    /**
     * The constant LATE.
     */
    public static final String LATE = "LATE";
    /**
     * The constant ON_TIME_GRAPH.
     */
    public static final String ON_TIME_GRAPH = "On Time";
    /**
     * The constant LATE_GRAPH.
     */
    public static final String LATE_GRAPH = "Late";
    /**
     * The constant DELIVERED.
     */
    public static final String DELIVERED = "DELIVERED";
    /**
     * The constant NOT_DELIVERED.
     */
    public static final String NOT_DELIVERED = "NOT_DELIVERED";
    /**
     * The constant GO.
     */
    public static final String GO = "GO";
    /**
     * The constant NOGO.
     */
    public static final String NOGO = "NO_GO";
    /**
     * The constant TECH_INPUT.
     */
    public static final String TECH_INPUT = "Tech Input";
    /**
     * The constant GO_RFQ.
     */
    public static final String GO_RFQ = "Go RFQ";
    /**
     * The constant BA.
     */
    public static final String BA = "BA";
    /**
     * The constant PGR.
     */
    public static final String PGR = "PGR";
    /**
     * The constant CGR.
     */
    public static final String CGR = "CGR";
    /**
     * The constant GO_PROD.
     */
    public static final String GO_PROD = "Go Prod";
    /**
     * The constant GO_ORDER.
     */
    public static final String GO_ORDER = "Go Order";
    /**
     * The constant FAI.
     */
    public static final String FAI = "FAI";
    /**
     * The constant FAT.
     */
    public static final String FAT = "FAT";
    /**
     * The constant DELIVERY.
     */
    public static final String DELIVERY = "Delivery";
    /**
     * The constant IQA.
     */
    public static final String IQA = "IQA";
    /**
     * The constant FQA.
     */
    public static final String FQA = "FQA";
    /**
     * The constant X.
     */
    public static final String X = "X";
    /**
     * The constant WEEKLY.
     */
    public static final String WEEKLY = "Weekly";
    /**
     * The constant MONTHLY.
     */
    public static final String MONTHLY = "Monthly";
    /**
     * The constant OPEN.
     */
    public static final String OPEN = "open";
    /**
     * The constant OPEN_CAPS.
     */
    public static final String OPEN_CAPS = "OPEN";
    /**
     * The constant ALL.
     */
    public static final String ALL = "all";
    /**
     * The constant RECEIVED.
     */
    public static final String RECEIVED = "RECEIVED";
    /**
     * The constant NOT_RECEIVED.
     */
    public static final String NOT_RECEIVED = "NOT_RECEIVED";
    /**
     * Actuator security config order.
     */
    public static final int ACTUATOR_ORDER = 1;
    /**
     * QlikSense security config order.
     */
    public static final int QLIK_SENSE_ORDER = 2;
    /**
     * API security config order.
     */
    public static final int API_ORDER = 3;
    /**
     * Content security policy used for http security configuration.
     */
    public static final String CONTENT_SECURITY_POLICY = "script-src 'self'";
    /**
     * actuator endpoints constant.
     */
    public static final String ACTUATOR_ENPOINTS = "/actuator/**";
    /**
     * qliksense endpoints constant.
     */
    public static final String QLIK_SENSE_ENPOINTS = "/qliksense/**";
    /**
     * invalid token constant.
     */
    public static final String INVALID_TOKEN = "invalid_token";
    /**
     * invalid user constant.
     */
    public static final String INVALID_USER = "invalid_user";
    /**
     * app role empty constant.
     */
    public static final String APP_ROLE_EMPTY = "App Roles property is empty in the authentication token";
    /**
     * email empty in token constant.
     */
    public static final String TOKEN_EMAIL_EMPTY = "Preferred username (Email) property is empty in the authentication token";
    /**
     * space delimiter constant.
     */
    public static final String SPACE_DELIMITER = " ";
    /**
     * user not registered in app constant.
     */
    public static final String USER_NOT_REGISTERED = "User (%s) is not registered for the application. Please contact application admin";
    /**
     * Constant - Unauthorized.
     */
    public static final String UNAUTHORIZED = "Unauthorized";
    /**
     * Constant - Unauthorized Msg.
     */
    public static final String UNAUTHORIZED_MSG = "Unauthorized to access this!";
    /**
     * Constant - Resource.
     */
    public static final String RESOURCE = "Resource";
    /**
     * Constant - Resource Msg.
     */
    public static final String RESOURCE_MSG = "Resource not found!";
    /**
     * Constant - Request.
     */
    public static final String REQUEST = "Request";
    /**
     * Constant - Bad Request.
     */
    public static final String REQUEST_MSG = "Bad Request!";
    /**
     * Constant - Media Type.
     */
    public static final String MEDIA_TYPE = "Media Type";
    /**
     * Constant - Media Type Msg.
     */
    public static final String MEDIA_TYPE_MSG = "Unsupported Media Type!";
    /**
     * Constant - Server Error.
     */
    public static final String SERVER_ERROR = "Server Error";
    /**
     * Constant - Hystrix error.
     */
    public static final String HYSTRIX_ERROR = "Hystrix error. Please contact application factory admin";
    /**
     * Constant - Data Access Issue.
     */
    public static final String DATA_ACCESS_ISSUE = "Data access issue. Please contact application factory admin";
    /**
     * Constant.
     */
    public static final String DATA_ERROR = "Data error";
    /**
     * Constant.
     */
    public static final String DATA_ERROR_MSG = "Input data format is wrong";
    /**
     * Constant.
     */
    public static final String MAPPING_ERROR = "Mapping error";
    /**
     * Constant.
     */
    public static final String MAPPING_ERROR_MSG = "Data mapping error";
    /**
     * Constant.
     */
    public static final String FIELD_NULL = "Field Null";
    /**
     * Constant.
     */
    public static final String FIELD_NULL_MSG = "Data field is empty";
    /**
     * Constant.
     */
    public static final String DATA_EXITS = "Data already exist error";
    /**
     * Constant.
     */
    public static final String DATA_CONVERT_ERROR = "Data not able to convert error";
    /**
     * Constant.
     */
    public static final String DATA_VIOLATION = "Data constraint violation error";
    /**
     * Constant.
     */
    public static final String FACTORY_ADMIN_MSG = "Please contact application factory admin";
    /**
     * Percent symbol constant.
     */
    public static final String STR_PERCENT_SYMBOL = "%";
    /**
     * Star symbol constant.
     */
    public static final String STR_STAR_SYMBOL = "*";
    /**
     * Cors config path constant.
     */
    public static final String CORS_CONFIG_PATH = "/**";
    /**
     * Constant for access control allow origin.
     */
    public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
    /**
     * Constant for access control allow methods.
     */
    public static final String ACCESS_CONTROL_ALLOW_METHODS = "Access-Control-Allow-Methods";
    /**
     * Constant for access control allow headers.
     */
    public static final String ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";
    /**
     * Constant for access control max age.
     */
    public static final String ACCESS_CONTROL_MAX_AGE = "Access-Control-Max-Age";
    /**
     * Constant for access control request headers.
     */
    public static final String ACCESS_CONTROL_REQUEST_HEADERS = "Access-Control-Request-Headers";
    /**
     * Constant for access control method.
     */
    public static final String ACCESS_CONTROL_REQUEST_METHOD = "Access-Control-Request-Method";
    /**
     * Constant for WWW-Authenticate.
     */
    public static final String WWW_AUTHENTICATE = "WWW-Authenticate";
    /**
     * Constant for STRING.
     */
    public static final String STR_STRING = "String";
    /**
     * Constant for Integer.
     */
    public static final String STR_INTEGER = "Integer";
    /**
     * Constant for long.
     */
    public static final String STR_LONG = "Long";
    /**
     * Constant for float.
     */
    public static final String STR_FLOAT = "Float";
    /**
     * Constant for double.
     */
    public static final String STR_DOUBLE = "Double";
    /**
     * Constant for uuid.
     */
    public static final String STR_UUID = "UUID";
    /**
     * Constant for date.
     */
    public static final String STR_DATE = "Date";
    /**
     * Constant for boolean.
     */
    public static final String STR_BOOLEAN = "Boolean";
    /**
     * Constant for enum.
     */
    public static final String STR_ENUM = "Enum";
    /**
     * Constant for set.
     */
    public static final String STR_SET = "set";
    /**
     * Constant for list.
     */
    public static final String STR_LIST = "list";
    /**
     * Constant for condition.
     */
    public static final String STR_CONDITION = "condition";
    /**
     * Constant for filter condition.
     */
    public static final String STR_FILTER_CONDITIONS = "filterConditions";
    /**
     * Constant for filter condition.
     */
    public static final String STR_FILTER = "filter";
    /**
     * Constant for filter condition.
     */
    public static final String STR_FILTER_JOINS = "filterJoins";
    /**
     * Constant for filter type.
     */
    public static final String STR_TYPE = "type";
    /**
     * Constant for filter field.
     */
    public static final String STR_FIELD = "field";
    /**
     * Constant for filter data.
     */
    public static final String STR_DATA = "data";
    /**
     * Constant for filter operator.
     */
    public static final String STR_OPERATOR = "operator";
    /**
     * Constant for filter OR.
     */
    public static final String STR_OR = "or";
    /**
     * Constant for filter AND.
     */
    public static final String STR_AND = "and";
    /**
     * Constant for filter PAGE NUMBER.
     */
    public static final String STR_PAGE_NUMBER = "pageNumber";
    /**
     * Constant for filter PAGE SIZE.
     */
    public static final String STR_PAGE_SIZE = "pageSize";
    /**
     * Constant for filter IS PAGED.
     */
    public static final String STR_IS_PAGED = "isPaged";
    /**
     * Constant for filter JOINS.
     */
    public static final String STR_JOINS = "joins";
    /**
     * Constant for filter OBJECT.
     */
    public static final String STR_OBJECT = "object";
    /**
     * Constant for filter SORT.
     */
    public static final String STR_SORT = "sort";
    /**
     * Constant for filter ORDERS.
     */
    public static final String STR_ORDERS = "orders";
    /**
     * Constant for filter DIRECTION.
     */
    public static final String STR_DIRECTION = "direction";
    /**
     * Constant for filter PROPERTY.
     */
    public static final String STR_PROPERTY = "property";
    /**
     * Constant for filter nullHandling.
     */
    public static final String STR_NULL_HANDLING = "nullHandling";
    /**
     * Equals constant.
     */
    public static final String STR_EQ = "eq";
    /**
     * Not equals constant.
     */
    public static final String STR_NOT_EQ = "not-eq";
    /**
     * In constant.
     */
    public static final String STR_IN = "in";
    /**
     * Like constant.
     */
    public static final String STR_LIKE = "like";
    /**
     * Null constant.
     */
    public static final String STR_NULL = "null";
    /**
     * Not null constant.
     */
    public static final String STR_NOT_NULL = "not-null";
    /**
     * less than constant.
     */
    public static final String STR_LESS_THAN = "le";
    /**
     * The constant STR_GREATER_THAN_EQUAL.
     */
    public static final String STR_GREATER_THAN_EQUAL = "ge";
    /**
     * dot regex constant.
     */
    public static final String STR_DOT_REGEX = "\\.";
    /**
     * Deleted constant.
     */
    public static final String STR_DELETED = "deleted";
    /**
     * Deleted constant.
     */
    public static final String STR_NAME = "name";
    /**
     * id constant.
     */
    public static final String STR_ID = "ID";
    /**
     * Failed error message.
     */
    public static final String FAILED = "Failed";
    /**
     * Project deleted constant.
     */
    public static final String STR_PROJECT_DELETED = "prjDeleted";
    /**
     * Constant for records.
     */
    public static final String MASTER_DATA_SYNC_MESSAGE = "Successfully updated %s master data. Inserted: %d and Updated: %d records.";
    /**
     * Number Constant 200.
     */
    public static final int TWO_HUNDRED = 200;

    public static final int THREE = 3;
    /**
     * Number Constant 0.
     */
    public static final int FOUR = 4;
    /**
     * Number Constant 0.
     */
    public static final int FIVE = 5;
    /**
     * Number Constant 0.
     */
    public static final int SIX = 6;
    /**
     * Number Constant 0.
     */
    public static final int SEVEN = 7;
    /**
     * Number Constant 0.
     */
    public static final int EIGHT = 8;
    /**
     * Number Constant 0.
     */
    public static final int NINE = 9;
    /**
     * Number Constant 10.
     */
    public static final int TEN = 10;
    /**
     * Number Constant 10.
     */
    public static final int ELEVEN = 11;
    /**
     * Number Constant 0.
     */
    public static final int TWELVE = 12;
    /**
     * Number Constant 0.
     */
    public static final int THIRTEEN = 13;
    /**
     * Number Constant 0.
     */
    public static final int FOURTEEN = 14;
    /**
     * Number Constant 0.
     */
    public static final int FIFTEEN = 15;
    /**
     * Number Constant 0.
     */
    public static final int SIXTEEN = 16;
    /**
     * Number Constant 0.
     */
    public static final int SEVENTEEN = 17;

    /**
     * Number Constant 18.
     */
    public static final int EIGHTEEN = 18;
    /**
     * Number Constant 19.
     */
    public static final int NINTEEN = 19;
    /**
     * Number Constant 20.
     */
    public static final int TWENTY = 20;
    /**
     * Number Constant 25.
     */
    public static final int TWENTY_FIVE = 25;
    /**
     * Message Constant - Error.
     */
    public static final String ERROR_LABEL = "ERROR";
    /**
     * Constant.
     */
    public static final String ATTACHMENT_READ_ERROR = "Error in reading attachment file.";
    /**
     * Constant - Excel Error 404.
     */
    public static final int ERROR_CODE_404 = 404;
}
