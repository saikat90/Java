package com.alstom.applicationfactory.pmfuservice.masterdata.service;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public interface FileImportService {

    /**
     * @param multipartFile
     * @param projectId
     * @param emailId
     * @return Object
     */
    Map<String, Object> importMasterDataContents(MultipartFile multipartFile, Integer projectId,
            String emailId);
}
