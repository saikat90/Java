package com.alstom.applicationfactory.pmfuservice.projectsetup.service;

import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityContractModel;

public interface CommodityContractService {

    /**
     * @param commodityContractModel
     * @return CommodityContractModel
     */
    CommodityContractModel createCommodityContract(CommodityContractModel commodityContractModel);

}
