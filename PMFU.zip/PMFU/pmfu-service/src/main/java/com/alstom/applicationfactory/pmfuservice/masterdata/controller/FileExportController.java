package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.imports.ProcessAtSiteImport;
import com.alstom.applicationfactory.pmfuservice.masterdata.imports.ProcessKPIData;
import com.alstom.applicationfactory.pmfuservice.masterdata.imports.ProcessMarketCodeImport;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.AtSiteRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.MarketCodeMasterDataRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.AllActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.KPIService;
import com.alstom.applicationfactory.pmfuservice.util.ExportUtility;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = "/export")
@Slf4j
public class FileExportController {

    /**
     * ExportUtility.
     */
    @Autowired
    private ExportUtility exportUtil;
    /**
     * MarketCodeMasterDataRepository.
     */
    @Autowired
    private MarketCodeMasterDataRepository marketCodeRepository;
    /**
     * ProcessMarketCodeImport.
     */
    @Autowired
    private ProcessMarketCodeImport processMarketCodeImp;
    /**
     * AtSiteRepository.
     */
    @Autowired
    private AtSiteRepository atSiteRepository;
    /**
     * ProcessAtSiteImport.
     */
    @Autowired
    private ProcessAtSiteImport processAtSiteImp;
    /**
     * ProcessKPIData.
     */
    @Autowired
    private ProcessKPIData processKPIData;
    /**
     * KPIService.
     */
    @Autowired
    private KPIService kpiService;

    /**
     * @param response
     * @param name
     * @param request
     */
    @PostMapping("/{name}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public void exportExcel(final HttpServletResponse response,
            @PathVariable("name") final String name,
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:FileExportController:exportExcel");
        response.setContentType("application/octet-stream");
        ByteArrayOutputStream outputStream = null;
        ByteArrayInputStream stream = null;
        RequestModel requestModel = RequestMapper.map(request);
        try {
            if (name.equals(Constants.MARKETCODE_SHEET_NAME)) {
                Workbook workbook = exportUtil.getMarketCodeWorkBookWithHeader();
                Sheet sheet = workbook.getSheet("Market Code");
                List<MarketCodeMasterData> marketCodeList = marketCodeRepository
                        .findAll(requestModel.getFilterSpecification());
                if (Objects.nonNull(marketCodeList) && !marketCodeList.isEmpty()) {
                    int i = 0;
                    for (MarketCodeMasterData marketCode : marketCodeList) {
                        Row dataRow = sheet.createRow(i + 1);
                        dataRow = processMarketCodeImp.populateExcelRowValue(marketCode, dataRow);
                        i++;
                    }
                }
                outputStream = new ByteArrayOutputStream();
                workbook.write(outputStream);
                stream = new ByteArrayInputStream(outputStream.toByteArray());
            } else if (name.equals(Constants.ATSITE_SHEET_NAME)) {
                Workbook workbook = exportUtil.getAtSiteWorkBookWithHeader();
                Sheet sheet = workbook.getSheet("AT Site");
                List<AtSite> atSiteList = atSiteRepository
                        .findAll(requestModel.getFilterSpecification());
                if (Objects.nonNull(atSiteList) && !atSiteList.isEmpty()) {
                    int i = 0;
                    for (AtSite site : atSiteList) {
                        Row dataRow = sheet.createRow(i + 1);
                        dataRow = processAtSiteImp.populateExcelRowValue(site, dataRow);
                        i++;
                    }
                }
                outputStream = new ByteArrayOutputStream();
                workbook.write(outputStream);
                stream = new ByteArrayInputStream(outputStream.toByteArray());
            } else {
                List<ErrorModel> errorModel = new ArrayList<>();
                errorModel.add(new ErrorModel("Error", Constants.INTERNAL_ERROR_MSG));
                throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModel);
            }
            IOUtils.copy(stream, response.getOutputStream());
        } catch (Exception exception) {
            List<ErrorModel> errorModel = new ArrayList<>();
            errorModel.add(new ErrorModel("Error", Constants.INTERNAL_ERROR_MSG));
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModel);
        }
        log.debug("Leave:FileExportController:exportExcel");
    }

    /**
     * @param response
     * @param name
     * @param id
     */
    @GetMapping("/{id}/{name}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM','VISITOR','KEYUSER')")
    public void exportKPIExcel(final HttpServletResponse response,
            @PathVariable("name") final String name, @PathVariable("id") final UUID id) {
        log.debug("Entry:FileExportController:exportExcel");
        response.setContentType("application/octet-stream");
        ByteArrayOutputStream outputStream = null;
        ByteArrayInputStream stream = null;
        try {
            if (name.equals(Constants.ALLACTIONS_SHEET_NAME)) {
                Workbook workbook = exportUtil.getAllActionsWorkBookWithHeader();
                Sheet sheet = workbook.getSheet("All Actions");
                List<AllActionsModel> allActionsList = kpiService.getAllActions(id, "all");
                if (Objects.nonNull(allActionsList) && !allActionsList.isEmpty()) {
                    int i = 0;
                    for (AllActionsModel allAction : allActionsList) {
                        Row dataRow = sheet.createRow(i + 1);
                        dataRow = processKPIData.populateExcelRowValue(allAction, dataRow);
                        i++;
                    }
                }
                outputStream = new ByteArrayOutputStream();
                workbook.write(outputStream);
                stream = new ByteArrayInputStream(outputStream.toByteArray());
            } else if (name.equals(Constants.PROJECT_MASTERDATA_SHEET_NAME)) {
                Workbook workbook = exportUtil.getProjectMasterDataWorkBookWithHeader();
                Sheet sheet = workbook.getSheet("Project MasterData");
                List<ProjectMasterDataModel> projectMDList = kpiService.getProjectMasterData(id);
                if (Objects.nonNull(projectMDList) && !projectMDList.isEmpty()) {
                    int i = 0;
                    for (ProjectMasterDataModel prjMDModel : projectMDList) {
                        Row dataRow = sheet.createRow(i + 1);
                        dataRow = processKPIData.populateProjectMDExcelRowValue(prjMDModel,
                                dataRow);
                        i++;
                    }
                }
                outputStream = new ByteArrayOutputStream();
                workbook.write(outputStream);
                stream = new ByteArrayInputStream(outputStream.toByteArray());
            } else {
                List<ErrorModel> errorModel = new ArrayList<>();
                errorModel.add(new ErrorModel("Error", Constants.INTERNAL_ERROR_MSG));
                throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModel);
            }

            IOUtils.copy(stream, response.getOutputStream());
        } catch (Exception exception) {
            List<ErrorModel> errorModel = new ArrayList<>();
            errorModel.add(new ErrorModel("Error", Constants.INTERNAL_ERROR_MSG));
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModel);
        }
        log.debug("Leave:FileExportController:exportExcel");
    }

}
