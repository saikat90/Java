package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type User model.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserModel {
    /**
     * UserModel id.
     */
    private UUID id;
    /**
     * UserModel employeeId.
     */
    @Size(min = Constants.INT_LENGTH_1, max = Constants.INT_LENGTH_30, message = Constants.EMPLOYEE_ID_MAX_MESSAGE)
    @NotNull(message = Constants.EMPLOYEE_ID_NOT_EMPTY_MESSAGE)
    private String employeeId;
    /**
     * UserModel firstName.
     */
    @Size(min = Constants.INT_LENGTH_1, max = Constants.INT_LENGTH_50, message = Constants.FIRST_NAME_MAX_MESSAGE)
    @NotNull(message = Constants.FIRST_NAME_NOT_EMPTY_MESSAGE)
    private String firstName;
    /**
     * UserModel lastName.
     */
    @Size(min = Constants.INT_LENGTH_1, max = Constants.INT_LENGTH_50, message = Constants.LAST_NAME_MAX_MESSAGE)
    @NotNull(message = Constants.LAST_NAME_NOT_EMPTY_MESSAGE)
    private String lastName;
    /**
     * UserModel email.
     */
    @Size(min = Constants.INT_LENGTH_1, max = Constants.INT_LENGTH_100, message = Constants.EMAIL_ID_MAX_MESSAGE)
    @NotNull(message = Constants.EMAIL_ID_NOT_EMPTY_MESSAGE)
    private String email;
    /**
     * UserModel department.
     */
    @Size(min = Constants.INT_LENGTH_1, max = Constants.INT_LENGTH_50, message = Constants.DEPARTMENT_MAX_MESSAGE)
    @NotNull(message = Constants.DEPARTMENT_NOT_EMPTY_MESSAGE)
    private String department;

}
