package com.alstom.applicationfactory.pmfuservice.masterdata.service;

import java.util.Map;

public interface MasterDataService {

    /**
     * @param request
     * @return project object
     */
    Object getProjectData(Map<String, Object> request);

}
