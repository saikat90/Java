package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type QliksenseCommodityContractModel model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QliksenseCommodityContractModel {

    /**
     * QliksenseCommodityContractModel project id.
     */
    private Integer projectId;

    /**
     * QliksenseCommodityContractModel project name.
     */
    private String projectName;

    /**
     * QliksenseCommodityContractModel cdb code.
     */
    private String cdbCode;

    /**
     * QliksenseCommodityContractModel region.
     */
    private String region;

    /**
     * QliksenseCommodityContractModel site.
     */
    private String site;

    /**
     * QliksenseCommodityContractModel product line.
     */
    private String productLine;

    /**
     * QliksenseCommodityContractModel last update.
     */
    private Date lastUpdate;

    /**
     * QliksenseCommodityContractModel description.
     */
    private String description;

    /**
     * QliksenseCommodityContractModel prsm.
     */
    private String prSm;

    /**
     * QliksenseCommodityContractModel prsm deputy.
     */
    private String prSmDeputy;

    /**
     * QliksenseCommodityContractModel pm.
     */
    private String pm;

    /**
     * QliksenseCommodityContractModel prpm.
     */
    private String prPm;

    /**
     * QliksenseCommodityContractModel wpc.
     */
    private String wpc;

    /**
     * QliksenseCommodityContractModel prscl.
     */
    private String prScl;

    /**
     * QliksenseCommodityContractModel prqsm.
     */
    private String prQsm;

    /**
     * QliksenseCommodityContractModel prem.
     */
    private String prEm;

    /**
     * QliksenseCommodityContractModel prscm.
     */
    private String prScm;

    /**
     * QliksenseCommodityContractModel tsm.
     */
    private String tsm;

    /**
     * QliksenseCommodityContractModel pridm.
     */
    private String prIdm;

    /**
     * QliksenseCommodityContractModel prom.
     */
    private String prOm;

    /**
     * QliksenseCommodityContractModel prism.
     */
    private String prIsm;

    /**
     * QliksenseCommodityContractModel domain.
     */
    private String domain;

    /**
     * QliksenseCommodityContractModel domain name.
     */
    private String domainName;

    /**
     * QliksenseCommodityContractModel market code.
     */
    private String marketCode;

    /**
     * QliksenseCommodityContractModel market name.
     */
    private String marketName;

    /**
     * QliksenseCommodityContractModel global local.
     */
    private String globalLocal;

    /**
     * QliksenseCommodityContractModel material.
     */
    private String material;

    /**
     * QliksenseCommodityContractModel contract type.
     */
    private String contractType;

    /**
     * QliksenseCommodityContractModel particular conditions.
     */
    private String particularConditions;

    /**
     * QliksenseCommodityContractModel status contract.
     */
    private String statusContract;

    /**
     * QliksenseCommodityContractModel porc.
     */
    private String poRc;

    /**
     * QliksenseCommodityContractModel perf bond.
     */
    private String perfBond;

    /**
     * QliksenseCommodityContractModel warranty bond.
     */
    private String warrantyBond;

    /**
     * QliksenseCommodityContractModel ar.
     */
    private String ar;

    /**
     * QliksenseCommodityContractModel ponrc.
     */
    private String poNrc;

}
