package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.imports.ProcessAtSiteImport;
import com.alstom.applicationfactory.pmfuservice.masterdata.imports.ProcessMarketCodeImport;
import com.alstom.applicationfactory.pmfuservice.masterdata.imports.ProcessProjectMilestoneImport;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.AtSiteRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.MarketCodeMasterDataRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.FileImportService;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectMilestoneService;
import com.alstom.applicationfactory.pmfuservice.util.ImportUtility;

import lombok.extern.slf4j.Slf4j;

@Service(value = "fileImportService")
@Transactional
@Slf4j
public class FileImportServiceImpl implements FileImportService {

    /**
     * ImportUtility.
     */
    @Autowired
    private ImportUtility importUtility;
    /**
     * ProcessMarketCodeImport.
     */
    @Autowired
    private ProcessMarketCodeImport processMarketCodeImp;
    /**
     * MarketCodeMasterDataRepository.
     */
    @Autowired
    private MarketCodeMasterDataRepository mdMarketCodeRepository;
    /**
     * ProcessAtSiteImport.
     */
    @Autowired
    private ProcessAtSiteImport processAtSiteImp;
    /**
     * AtSiteRepository.
     */
    @Autowired
    private AtSiteRepository atSiteRepository;

    /**
     * ProcessProjectMilestoneImport.
     */
    @Autowired
    private ProcessProjectMilestoneImport processProjectMilestoneImport;

    /**
     * ProjectMilestoneService.
     */
    @Autowired
    private ProjectMilestoneService projectMilestoneService;

    /**
     * totalRecords.
     */
    private int totalRecords = 0;

    /**
     * List of ErrorModel.
     */
    private List<ErrorModel> errorModel = new ArrayList<>();

    @Override
    public Map<String, Object> importMasterDataContents(final MultipartFile multipartFile,
            final Integer projectSetupId, final String emailId) {
        log.debug("Entry:PmfuFileImportServiceImpl:importMasterDataContents");
        Map<String, Object> result = new HashMap<>();
        List<String> errorList = new ArrayList<String>();
        List<MarketCodeMasterData> marketCodeList = new ArrayList<>();
        List<AtSite> atSiteList = new ArrayList<>();
        Map<String, List<ProjectMilestone>> puproject_market_projectMilestoneMap = new HashMap<String, List<ProjectMilestone>>();
        List<ProjectMilestone> projectMilestoneList = new ArrayList<>();
        XSSFWorkbook excelWorkbook = null;
        try {
            excelWorkbook = new XSSFWorkbook(multipartFile.getInputStream());
            if (importUtility.validateExcelFile(excelWorkbook)) {
                XSSFSheet importSheet = excelWorkbook.getSheetAt(0);
                String sheetName = importSheet.getSheetName();
                if (sheetName.equalsIgnoreCase(Constants.MARKETCODE_SHEET_NAME)) {
                    processMarketCodeImp.processMarketCodeData(importSheet, marketCodeList,
                            errorList);
                    if (Objects.nonNull(marketCodeList) && !marketCodeList.isEmpty()) {
                        log.debug(
                                "PmfuFileImportServiceImpl:importMasterDataContents:SaveAllMarketCodes");
                        mdMarketCodeRepository.saveAll(marketCodeList);
                    }
                    result.put("SuccessCount", String.valueOf(marketCodeList.size()));
                    result.put("ErrorList", errorList);
                } else if (sheetName.equalsIgnoreCase(Constants.ATSITE_SHEET_NAME)) {
                    processAtSiteImp.processAtSiteData(importSheet, atSiteList, errorList);
                    if (Objects.nonNull(atSiteList) && !atSiteList.isEmpty()) {
                        log.debug(
                                "PmfuFileImportServiceImpl:importMasterDataContents:SaveAllAtSites");
                        atSiteRepository.saveAll(atSiteList);
                    }
                    result.put("SuccessCount", String.valueOf(atSiteList.size()));
                    result.put("ErrorList", errorList);
                } else if (sheetName.equalsIgnoreCase(Constants.MILESTONE_SHEET_NAME)) {
                    processProjectMilestoneImport.processProjectMilestoneData(importSheet,
                            puproject_market_projectMilestoneMap, errorList, projectSetupId);
                    if (Objects.nonNull(projectMilestoneList)
                            && !puproject_market_projectMilestoneMap.isEmpty()) {
                        if (errorList.isEmpty()) {
                            projectMilestoneService.saveImportedMilestoneRecords(
                                    puproject_market_projectMilestoneMap);
                            puproject_market_projectMilestoneMap.entrySet().stream()
                                    .forEach(mapKey -> {
                                        totalRecords = totalRecords + mapKey.getValue().size();
                                    });
                        } else {
                            totalRecords = 0;
                        }
                    } else {
                        totalRecords = 0;
                    }
                    result.put("SuccessCount", String.valueOf(totalRecords));
                    result.put("ErrorList", errorList);
                } else {
                    log.error("Import Excel Sheet Name is Incorrect");
                    // List<ErrorModel> errorModel = new ArrayList<>();
                    errorModel.add(new ErrorModel("Import Excel format",
                            "Import Excel Sheet Name is Incorrect"));
                    throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorModel);
                }

            } else {
                log.error("Import Excel format is wrong");
                // List<ErrorModel> errorModel = new ArrayList<>();
                errorModel
                        .add(new ErrorModel("Import Excel format", "Import Excel format is wrong"));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorModel);
            }
        } catch (Exception exception) {
            log.error("Failed to process the Excel file", exception.getMessage());
            ApplicationFactoryException cEx = (ApplicationFactoryException) exception;
            errorModel = (cEx.getErrorModelList());
            if (errorModel.isEmpty()) {
                errorModel.add(new ErrorModel("Excel Process",
                        "Error occurred while processing the Excel file"));
            }
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorModel);
        } finally {
            try {
                if (Objects.nonNull(excelWorkbook)) {
                    excelWorkbook.close();
                }
            } catch (IOException e) {
                log.error("Failed to close the excel file");
            }
        }
        log.debug("Leave:PmfuFileImportServiceImpl:importMasterDataContents");
        return result;
    }

}
