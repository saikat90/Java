package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type project setup list model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectSetUpListModel {

    /**
     * ProjectSetUpListModel id.
     */
    private UUID id;

    /**
     * ProjectSetUpListModel version.
     */
    private Integer version;

    /**
     * ProjectSetUpListModel project id.
     */
    @NotNull(message = Constants.PROJECT_ID_NOTEMPTY)
    private Integer projectId;

    /**
     * ProjectSetUpListModel project.
     */
    @NotNull(message = Constants.PROJECT_NOTEMPTY)
    private ProjectModel project;

    /**
     * ProjectSetUpListModel project name temp.
     */
    private String prjectNameTemp;

    /**
     * ProjectSetUpListModel site.
     */
    @NotNull(message = Constants.SITE_NOTEMPTY)
    private AtSiteModel atSite;

    /**
     * ProjectSetUpListModel product line.
     */
    @NotNull(message = Constants.PRODUCTLINE_NOTEMPTY)
    private String productLine;

    /**
     * ProjectSetUpListModel prsm.
     */
    @NotNull(message = Constants.PRSM_NOTEMPTY)
    private UserModel prsm;

    /**
     * ProjectSetUpListModel modified date.
     */
    private Date modifiedDate;

    /**
     * ProjectSetUpListModel prsm deputy.
     */
    private UserModel prsmDeputy;

}
