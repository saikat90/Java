package com.alstom.applicationfactory.pmfuservice.projectsetup.service;

import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMarketModel;

public interface ProjectMarketService {

    /**
     * @param projectMarketModel
     * @return ProjectMarketModel.
     */
    ProjectMarketModel createProjectMarket(ProjectMarketModel projectMarketModel);
}
