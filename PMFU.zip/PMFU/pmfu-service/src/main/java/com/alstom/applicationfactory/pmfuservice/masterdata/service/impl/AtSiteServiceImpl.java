package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.common.model.ResponseModel;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteSearchModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.AtSiteRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.AtSiteService;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;
import com.alstom.applicationfactory.pmfuservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "atSiteService")
@Transactional
@Slf4j
public class AtSiteServiceImpl implements AtSiteService {

    /**
     * AtSiteRepository.
     */
    @Autowired
    private AtSiteRepository atSiteRepository;

    /**
     * @param request
     * @return ATSite Object.
     */
    @Override
    public Object searchAtSite(final RequestModel request) {
        log.debug("Entry:PmfuAtSiteServiceImpl:SearchAtSite");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.atSiteRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(atSite -> mapper.map(atSite, AtSiteModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.atSiteRepository.findAll(request.getFilterSpecification()).stream()
                    .map(atSite -> mapper.map(atSite, AtSiteModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:PmfuAtSiteServiceImpl:SearchAtSite");
        return result;
    }

    @Override
    public AtSiteModel viewAtSite(final UUID atSiteId) {
        log.debug("Entry:PmfuAtSiteServiceImpl:ViewAtSite");
        AtSite atSite;
        AtSiteModel atSiteBean = new AtSiteModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            atSite = atSiteRepository.findById(atSiteId).orElse(null);
            if (null != atSite) {
                atSiteBean = mapper.map(atSite, AtSiteModel.class);
                log.debug("Leave:PmfuAtSiteServiceImpl:ViewAtSite");
            }
            return atSiteBean;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("AT Site", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    @Override
    public void deleteAtSiteById(final UUID atSiteId) {
        log.debug("Entry:PmfuAtSiteServiceImpl:DeleteAtSite");
        try {
            atSiteRepository.deleteById(atSiteId);
            log.debug("Leave:PmfuAtSiteServiceImpl:DeleteAtSite");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Error", e.getMessage());
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    @Override
    public AtSiteModel createAtSite(@Valid final AtSiteModel atSiteBean) {
        log.debug("Entry:PmfuAtSiteServiceImpl:createAtSite");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        AtSiteModel atSiteCreatedBean = new AtSiteModel();
        AtSite atSite = mapper.map(atSiteBean, AtSite.class);

        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();

        filterConditions.add(RequestModifier.getFilterCondition(Constants.STR_STRING, "caratCode",
                atSiteBean.getCaratCode(), Constants.STR_EQ));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        long count = this.atSiteRepository.count(requestModel.getFilterSpecification());

        if (count == 0) {
            atSite = atSiteRepository.save(atSite);
            atSiteCreatedBean = mapper.map(atSite, AtSiteModel.class);
        } else {
            log.error("Record already exists for AtSite. Please update existing value");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("AtSite",
                    "AtSite already exists with the same Carat Code. Please update existing value"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:PmfuAtSiteServiceImpl:createAtSite");
        return atSiteCreatedBean;
    }

    @Override
    public AtSiteModel updateAtSite(@Valid final AtSiteModel atSiteModel) {
        log.debug("Entry:PmfuAtSiteServiceImpl:UpdateAtSite");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        AtSiteModel atSiteBean = new AtSiteModel();
        try {
            AtSite atSite = mapper.map(atSiteModel, AtSite.class);
            AtSite atSiteRecord = atSiteRepository.findById(atSiteModel.getId()).orElse(null);
            if (null != atSiteRecord) {
                AtSite atSiteResult = atSiteRepository.save(atSite);
                atSiteBean = mapper.map(atSiteResult, AtSiteModel.class);
                log.debug("Leave:PmfuAtSiteServiceImpl:UpdateAtSite");
            } else {
                log.error("Record does not exists for the AtSite.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel("AtSite", "Record does not exists for the AtSite."));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return atSiteBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("AtSite", "Unable to update AtSite");
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    @Override
    public boolean isCaratCodeExists(final String caratCode) {
        log.debug("Entry:PmfuMarketCodeMasterDataServiceImpl:isCaratCodeExists");
        AtSite atSiteRecord = null;
        try {
            atSiteRecord = atSiteRepository.findByCaratCode(caratCode);
            if (Objects.nonNull(atSiteRecord)) {
                return true;
            }
            log.debug("Leave:PmfuMarketCodeMasterDataServiceImpl:isCaratCodeExists");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Carat Code",
                    "Unable to search for Carat Code Existance");
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
        return false;
    }

    @Override
    public Object findAtSiteforSearch(final RequestModel requestModel) {
        log.debug("Entry:PmfuAtSiteServiceImpl:findAtSiteforSearch");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        result = this.atSiteRepository.findAll().stream()
                .map(atSite -> mapper.map(atSite, AtSiteSearchModel.class))
                .collect(Collectors.toList());
        log.debug("Leave:PmfuAtSiteServiceImpl:findAtSiteforSearch");
        return result;

    }

}
