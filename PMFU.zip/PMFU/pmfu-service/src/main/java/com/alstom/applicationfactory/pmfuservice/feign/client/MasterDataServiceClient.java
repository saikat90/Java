package com.alstom.applicationfactory.pmfuservice.feign.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient("master-data-service")
public interface MasterDataServiceClient {

    /**
     * Gets project data.
     *
     * @param request the request
     * @return the project data
     */
    @PostMapping("/masterdata/project/list")
    Object getProjectData(@RequestBody(required = false) Map<String, Object> request);
}
