/**
 * Package info.
 */
package com.alstom.applicationfactory.pmfuservice.common.model;
