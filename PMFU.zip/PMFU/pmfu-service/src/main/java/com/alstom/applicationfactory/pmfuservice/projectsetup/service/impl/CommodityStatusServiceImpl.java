package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityStatus;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityStatusModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityStatusRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.CommodityStatusService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author shanmugam.raj
 *
 */
@Service(value = "commodityStatusService")
@Transactional
@Slf4j
public class CommodityStatusServiceImpl implements CommodityStatusService {

    /**
     * CommodityStatusRepository.
     */
    @Autowired
    private CommodityStatusRepository commodityStatusRepository;

    @Override
    public CommodityStatusModel createCommodityStatus(
            final CommodityStatusModel commodityStatusModel) {
        log.debug("Entry:CommodityStatusServiceImpl:createCommodityStatus");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        CommodityStatus createdCommodityStatus = new CommodityStatus();

        CommodityStatusModel createdCommodityStatusModel = new CommodityStatusModel();

        CommodityStatus commodityStatus = mapper.map(commodityStatusModel, CommodityStatus.class);

        try {
            createdCommodityStatus = commodityStatusRepository.save(commodityStatus);
            createdCommodityStatusModel = mapper.map(createdCommodityStatus,
                    CommodityStatusModel.class);
        } catch (Exception e) {
            log.error("Error while creating record for CommodityStatus");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("CommodityStatus",
                    "Error while creating record for CommodityStatus"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:CommodityStatusServiceImpl:createCommodityStatus");
        return createdCommodityStatusModel;
    }
}
