package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type contracts status graph model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ContractStatusGraphModel {

    /**
     * ContractStatusGraphModel yes count.
     */
    private Integer yesCount;

    /**
     * ContractStatusGraphModel no count.
     */
    private Integer noCount;

    /**
     * ContractStatusGraphModel contract type.
     */
    private String contractType;

}
