package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type commodity contract model.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommodityContractModel {

    /**
     * CommodityContractModel id.
     */
    private UUID id;

    /**
     * CommodityContractModel version.
     */
    private Integer version;

    /**
     * CommodityContractModel comments.
     */
    private String comments;

    /**
     * CommodityContractModel project market.
     */
    @JsonIgnore
    private ProjectMarketModel projectMarket;

    /**
     * CommodityContractModel contract list.
     */
    private List<ContractsModel> contractsList;
}
