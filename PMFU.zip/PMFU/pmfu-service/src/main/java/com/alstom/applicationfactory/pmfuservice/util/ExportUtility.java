package com.alstom.applicationfactory.pmfuservice.util;

import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ExportUtility {

    /**
     * ImportUtility.
     */
    @Autowired
    private ImportUtility importUtility;

    /**
     * Get Workbook for Market Code.
     * 
     * @return the Workbook.
     */
    public Workbook getMarketCodeWorkBookWithHeader() {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Market Code");

        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 11);
        font.setFontName(HSSFFont.FONT_ARIAL);

        Row row = sheet.createRow(0);
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
        headerCellStyle.setFont(font);

        List<String> marketCodeHeaders = importUtility.marketCodeHeadersDefault();
        Object[] marketCodeHeaderArr = marketCodeHeaders.toArray();
        BuildHeaderRow(row, marketCodeHeaders.size(), marketCodeHeaderArr, headerCellStyle);

        return workbook;
    }

    /**
     * Get Workbook for ATSite.
     * 
     * @return the Workbook.
     */
    public Workbook getAtSiteWorkBookWithHeader() {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("AT Site");

        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 11);
        font.setFontName(HSSFFont.FONT_ARIAL);

        Row row = sheet.createRow(0);
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
        headerCellStyle.setFont(font);

        List<String> atSiteHeaders = importUtility.atSiteHeadersDefault();
        Object[] atSiteHeaderArr = atSiteHeaders.toArray();
        BuildHeaderRow(row, atSiteHeaders.size(), atSiteHeaderArr, headerCellStyle);

        return workbook;
    }

    /**
     * Get Workbook for All Actions.
     * 
     * @return the Workbook.
     */
    public Workbook getAllActionsWorkBookWithHeader() {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("All Actions");

        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 11);
        font.setFontName(HSSFFont.FONT_ARIAL);

        Row row = sheet.createRow(0);
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
        headerCellStyle.setFont(font);

        List<String> allActionsHeaders = importUtility.allActionsHeadersDefault();
        Object[] allActionsHeaderArr = allActionsHeaders.toArray();
        BuildHeaderRow(row, allActionsHeaders.size(), allActionsHeaderArr, headerCellStyle);

        return workbook;
    }

    /**
     * Build Header for row.
     * 
     * @param row
     * @param size
     * @param headerArr
     * @param headerCellStyle
     */
    private void BuildHeaderRow(Row row, int size, Object[] headerArr, CellStyle headerCellStyle) {

        for (int i = 0; i < size; i++) {
            Cell cell = row.createCell(i);
            cell.setCellValue((String) headerArr[i]);
            cell.setCellStyle(headerCellStyle);
        }
    }

    /**
     * Get Workbook for Project Master Data.
     * 
     * @return the Workbook.
     */
    public Workbook getProjectMasterDataWorkBookWithHeader() {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Project MasterData");

        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 11);
        font.setFontName(HSSFFont.FONT_ARIAL);

        Row row = sheet.createRow(0);

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
        headerCellStyle.setFont(font);

        List<String> projectMDHeaders = importUtility.projectMasterDataHeadersDefault();
        Object[] projectMDHeaderArr = projectMDHeaders.toArray();
        BuildHeaderRow(row, projectMDHeaders.size(), projectMDHeaderArr, headerCellStyle);

        return workbook;
    }
}
