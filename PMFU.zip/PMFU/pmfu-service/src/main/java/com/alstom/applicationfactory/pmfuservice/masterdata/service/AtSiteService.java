package com.alstom.applicationfactory.pmfuservice.masterdata.service;

import java.util.UUID;

import javax.validation.Valid;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;

public interface AtSiteService {

    /**
     * @param requestModel
     * @return ATSite object
     */
    Object searchAtSite(RequestModel requestModel);

    /**
     * @param id
     * @return AtSiteModel
     */
    AtSiteModel viewAtSite(UUID id);

    /**
     * @param id
     */
    void deleteAtSiteById(UUID id);

    /**
     * @param atSite
     * @return created AtSiteModel
     */
    AtSiteModel createAtSite(@Valid AtSiteModel atSite);

    /**
     * @param atSite
     * @return updated AtSiteModel
     */
    AtSiteModel updateAtSite(@Valid AtSiteModel atSite);

    /**
     * @param caratCode
     * @return true or false based on condition.
     */
    boolean isCaratCodeExists(String caratCode);

    /**
     * @param requestModel
     * @return searched ATSite object.
     */
    Object findAtSiteforSearch(RequestModel requestModel);
}
