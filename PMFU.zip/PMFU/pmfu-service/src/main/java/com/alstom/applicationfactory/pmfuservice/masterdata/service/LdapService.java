package com.alstom.applicationfactory.pmfuservice.masterdata.service;

import java.util.Map;

public interface LdapService {
    /**
     * @param request
     * @return user object
     */
    Object findUsers(Map<String, String> request);
}
