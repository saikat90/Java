package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectMilestoneModel {

    /**
     * ProjectMilestoneModel id.
     */
    private UUID id;

    /**
     * ProjectMilestoneModel version.
     */
    private Integer version;

    /**
     * ProjectMilestoneModel material.
     */
    private String material;

    /**
     * ProjectMilestoneModel tech input.
     */
    private String techInput;

    /**
     * ProjectMilestoneModel tech input color.
     */
    private String techInputColor;

    /**
     * ProjectMilestoneModel goRfq.
     */
    private String goRfq;

    /**
     * ProjectMilestoneModel ba.
     */
    private String ba;

    /**
     * ProjectMilestoneModel goORder.
     */
    private String goOrder;

    /**
     * ProjectMilestoneModel pgr.
     */
    private String pgr;

    /**
     * ProjectMilestoneModel cgr.
     */
    private String cgr;

    /**
     * ProjectMilestoneModel goPRod.
     */
    private String goProd;

    /**
     * ProjectMilestoneModel fai.
     */
    private String fai;

    /**
     * ProjectMilestoneModel iqa.
     */
    private String iqa;

    /**
     * ProjectMilestoneModel fqa.
     */
    private String fqa;

    /**
     * ProjectMilestoneModel fat.
     */
    private String fat;

    /**
     * ProjectMilestoneModel goRfq color.
     */
    private String goRfqColor;

    /**
     * ProjectMilestoneModel ba color.
     */
    private String baColor;

    /**
     * ProjectMilestoneModel goOrder color.
     */
    private String goOrderColor;

    /**
     * ProjectMilestoneModel pgr color.
     */
    private String pgrColor;

    /**
     * ProjectMilestoneModel cgr color.
     */
    private String cgrColor;

    /**
     * ProjectMilestoneModel goProd color.
     */
    private String goProdColor;

    /**
     * ProjectMilestoneModel fai color.
     */
    private String faiColor;

    /**
     * ProjectMilestoneModel iqa color.
     */
    private String iqaColor;

    /**
     * ProjectMilestoneModel fqa color.
     */
    private String fqaColor;

    /**
     * ProjectMilestoneModel fat color.
     */
    private String fatColor;

    /**
     * ProjectMilestoneModel delivery color.
     */
    private String deliveryColor;

    /**
     * ProjectMilestoneModel first need.
     */
    private Date firstNeed;

    /**
     * ProjectMilestoneModel supplier market code.
     */
    private String supplierMarketCode;

    /**
     * ProjectMilestoneModel supplier market name.
     */
    private String supplierMarketName;

    /**
     * ProjectMilestoneModel domain code.
     */
    private String domainCode;

    /**
     * ProjectMilestoneModel domain name.
     */
    private String domainName;

    /**
     * ProjectMilestoneModel global local.
     */
    private String globalLocal;

    /**
     * ProjectMilestoneModel train.
     */
    private String train;

    /**
     * ProjectMilestoneModel rail control.
     */
    private String railControl;

    /**
     * ProjectMilestoneModel system infra.
     */
    private String systemInfra;

    /**
     * ProjectMilestoneModel goRfq.
     */
    private Integer mcGoRfq;

    /**
     * ProjectMilestoneModel ba.
     */
    private Integer mcBa;

    /**
     * ProjectMilestoneModel goOrder.
     */
    private Integer mcGoOrder;

    /**
     * ProjectMilestoneModel pgr.
     */
    private Integer mcPgr;

    /**
     * ProjectMilestoneModel cgr.
     */
    private Integer mcCgr;

    /**
     * ProjectMilestoneModel goPRod.
     */
    private Integer mcGoProd;

    /**
     * ProjectMilestoneModel fai.
     */
    private Integer mcFai;

    /**
     * ProjectMilestoneModel iqa.
     */
    private Integer mcIqa;

    /**
     * ProjectMilestoneModel fqa.
     */
    private Integer mcFqa;

    /**
     * ProjectMilestoneModel fat.
     */
    private Integer mcFat;

    /**
     * ProjectMilestoneModel project name.
     */
    private String projectName;

    /**
     * ProjectMilestoneModel project market.
     */
    @JsonIgnore
    private ProjectMarketModel projectMarket;

    /**
     * ProjectMilestoneModel market code seq.
     */
    private Integer listMarketCodeByProjectSeq;

    /**
     * ProjectMilestoneModel cdb code.
     */
    private String cdbCode;

    /**
     * ProjectMilestoneModel project id.
     */
    private Integer projectId;

    /**
     * ProjectMilestoneModel commodity status.
     */
    private CommodityStatusModel commodityStatus;
}
