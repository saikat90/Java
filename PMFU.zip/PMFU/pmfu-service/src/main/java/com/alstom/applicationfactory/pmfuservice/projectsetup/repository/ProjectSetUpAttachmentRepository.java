package com.alstom.applicationfactory.pmfuservice.projectsetup.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUpAttachment;

public interface ProjectSetUpAttachmentRepository
        extends JpaRepository<ProjectSetUpAttachment, UUID>, JpaSpecificationExecutor<ProjectSetUpAttachment> {

}
