package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alstom.applicationfactory.pmfuservice.feign.client.LdapServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.LdapService;

import lombok.extern.slf4j.Slf4j;

@Service("ldapService")
@Slf4j
public class LdapServiceImpl implements LdapService {

    /**
     * LdapServiceClient.
     */
    @Autowired
    private LdapServiceClient ldapServiceClient;

    @Override
    public Object findUsers(final Map<String, String> request) {
        log.debug("Entry:LdapServiceImpl:findUsers");
        Object users = this.ldapServiceClient.findUsers(request);
        log.debug("Entry:LdapServiceImpl:findUsers");
        return users;
    }
}
