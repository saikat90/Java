package com.alstom.applicationfactory.pmfuservice.projectsetup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.pmfuservice.projectsetup.service.QlikSenseService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/qliksense")
@Slf4j
public class QlikSenseController {

    /**
     * QlikSenseService.
     */
    @Autowired
    private QlikSenseService qlikSenseService;

    /**
     * @return CommodityStatus
     */
    @GetMapping("/commodityStatus/kpi")
    public Object findAllCommodityStatusData() {
        log.debug("Entry:qliksenseController:findAllCommodityStatusData");
        Object result = qlikSenseService.findAllCommodityStatusData();
        log.debug("Leave:qliksenseController:findAllCommodityStatusData");
        return result;
    }

    /**
     * @return CommodityContract
     */
    @GetMapping("/commodityContract/kpi")
    public Object findAllCommodityContractData() {
        log.debug("Entry:qliksenseController:findAllCommodityContractData");
        Object result = qlikSenseService.findAllCommodityContractData();
        log.debug("Leave:qliksenseController:findAllCommodityContractData");
        return result;
    }

    /**
     * @return CommodityActionPlan
     */
    @GetMapping("/commodityActionPlan/kpi")
    public Object findAllCommodityActionPlanData() {
        log.debug("Entry:qliksenseController:findAllCommodityActionPlanData");
        Object result = qlikSenseService.findAllCommodityActionPlanData();
        log.debug("Leave:qliksenseController:findAllCommodityActionPlanData");
        return result;
    }

}
