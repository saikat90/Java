package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type commodity status model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommodityStatusModel {

    /**
     * CommodityStatusModel id.
     */
    private UUID id;

    /**
     * CommodityStatusModel version.
     */
    private Integer version;

    /**
     * CommodityStatusModel dfqMilestone title.
     */
    private String dfqMilestoneTitle;

    /**
     * CommodityStatusModel dfqMilestone tech input.
     */
    private String dfqMilestoneTechInput;

    /**
     * CommodityStatusModel dfqMilestone goRfq.
     */
    private String dfqMilestoneGoRfq;

    /**
     * CommodityStatusModel dfqMilestone ba.
     */
    private String dfqMilestoneBa;

    /**
     * CommodityStatusModel dfqMilestone goOrder.
     */
    private String dfqMilestoneGoOrder;

    /**
     * CommodityStatusModel dfqMilestone pgr.
     */
    private String dfqMilestonePgr;

    /**
     * CommodityStatusModel dfqMilestone cgr.
     */
    private String dfqMilestoneGgr;

    /**
     * CommodityStatusModel dfqMilestone goProd.
     */
    private String dfqMilestoneGoProd;

    /**
     * CommodityStatusModel dfqMilestone fai.
     */
    private String dfqMilestoneFai;

    /**
     * CommodityStatusModel dfqMilestone iqa.
     */
    private String dfqMilestoneIqa;

    /**
     * CommodityStatusModel dfqMilestone fqa.
     */
    private String dfqMilestoneFqa;

    /**
     * CommodityStatusModel dfqMilestone fat.
     */
    private String dfqMilestoneFat;

    /**
     * CommodityStatusModel dfqMilestone first need.
     */
    private Date dfqMilestoneFirstNeed;

    /**
     * CommodityStatusModel dfqMilestone delivery.
     */
    private String dfqMilestoneDelivery;

    /**
     * CommodityStatusModel duration title.
     */
    private String durationTile;

    /**
     * CommodityStatusModel duration tech input.
     */
    private String durationTechInput;

    /**
     * CommodityStatusModel duration goRfq.
     */
    private Integer durationGoRfq;

    /**
     * CommodityStatusModel duration ba.
     */
    private Integer durationBa;

    /**
     * CommodityStatusModel duration goOrder.
     */
    private Integer durationGoOrder;

    /**
     * CommodityStatusModel duration pgr.
     */
    private Integer durationPgr;

    /**
     * CommodityStatusModel duration cgr.
     */
    private Integer durationCgr;

    /**
     * CommodityStatusModel duration goProd.
     */
    private Integer durationGoProd;

    /**
     * CommodityStatusModel duration fai.
     */
    private Integer durationFai;

    /**
     * CommodityStatusModel duration iqa.
     */
    private Integer durationIqa;

    /**
     * CommodityStatusModel duration fqa.
     */
    private Integer durationFqa;

    /**
     * CommodityStatusModel duration fat.
     */
    private Integer durationFat;

    /**
     * CommodityStatusModel duration first need.
     */
    private Date durationFirstNeed;

    /**
     * CommodityStatusModel duration delivery.
     */
    private Integer durationDelivery;

    /**
     * CommodityStatusModel needs title.
     */
    private String needsTitle;

    /**
     * CommodityStatusModel needs tech input.
     */
    private Date needsTechInput;

    /**
     * CommodityStatusModel needs goRfq.
     */
    private Date needsGoRfq;

    /**
     * CommodityStatusModel needs ba.
     */
    private Date needsBa;

    /**
     * CommodityStatusModel needs goOrder.
     */
    private Date needsGoOrder;

    /**
     * CommodityStatusModel needs pgr.
     */
    private Date needsPgr;

    /**
     * CommodityStatusModel needs cgr.
     */
    private Date needsCgr;

    /**
     * CommodityStatusModel needs goProd.
     */
    private Date needsGoProd;

    /**
     * CommodityStatusModel needs fai.
     */
    private Date needsFai;

    /**
     * CommodityStatusModel needs iqa.
     */
    private Date needsIqa;

    /**
     * CommodityStatusModel needs fqa.
     */
    private Date needsFqa;

    /**
     * CommodityStatusModel needs fat.
     */
    private Date needsFat;

    /**
     * CommodityStatusModel needs first need.
     */
    private Date needsFirstNeed;

    /**
     * CommodityStatusModel needs delivery.
     */
    private Date needsDelivery;

    /**
     * CommodityStatusModel actual date title.
     */
    private String actualDateTitle;

    /**
     * CommodityStatusModel actual date tech input.
     */
    private Date actualDateTechInput;

    /**
     * CommodityStatusModel actual date goRfq.
     */
    private Date actualDateGoRfq;

    /**
     * CommodityStatusModel actual date ba.
     */
    private Date actualDateBa;

    /**
     * CommodityStatusModel actual date goOrder.
     */
    private Date actualDateGoOrder;

    /**
     * CommodityStatusModel actual date pgr.
     */
    private Date actualDatePgr;

    /**
     * CommodityStatusModel actual date cgr.
     */
    private Date actualDateCgr;

    /**
     * CommodityStatusModel actual date goProd.
     */
    private Date actualDateGoProd;

    /**
     * CommodityStatusModel actual date fai.
     */
    private Date actualDateFai;

    /**
     * CommodityStatusModel actual date iqa.
     */
    private Date actualDateIqa;

    /**
     * CommodityStatusModel actual date fqa.
     */
    private Date actualDateFqa;

    /**
     * CommodityStatusModel actual date fat.
     */
    private Date actualDateFat;

    /**
     * CommodityStatusModel actual date firstneed.
     */
    private Date actualDateFirstNeed;

    /**
     * CommodityStatusModel actual date delivery.
     */
    private Date actualDateDelivery;

    /**
     * CommodityStatusModel status title.
     */
    private String statusTitle;

    /**
     * CommodityStatusModel status tech input.
     */
    private String statusTechInput;

    /**
     * CommodityStatusModel status goRfq.
     */
    private String statusGoRfq;

    /**
     * CommodityStatusModel status ba.
     */
    private String statusBa;

    /**
     * CommodityStatusModel status goOrder.
     */
    private String statusGoOrder;

    /**
     * CommodityStatusModel status pgr.
     */
    private String statusPgr;

    /**
     * CommodityStatusModel status cgr.
     */
    private String statusGgr;

    /**
     * CommodityStatusModel status goProd.
     */
    private String statusGoProd;

    /**
     * CommodityStatusModel status fai.
     */
    private String statusFai;

    /**
     * CommodityStatusModel status iqa.
     */
    private String statusIqa;

    /**
     * CommodityStatusModel status fqa.
     */
    private String statusFqa;

    /**
     * CommodityStatusModel status fat.
     */
    private String statusFat;

    /**
     * CommodityStatusModel status first need.
     */
    private Date statusFirstNeed;

    /**
     * CommodityStatusModel status delivery.
     */
    private String statusDelivery;

    /**
     * CommodityStatusModel status color title.
     */
    private String statusColorTitle;

    /**
     * CommodityStatusModel status color tech input.
     */
    private String statusColorTechInput;

    /**
     * CommodityStatusModel status color goRfq.
     */
    private String statusColorGoRfq;

    /**
     * CommodityStatusModel status color ba.
     */
    private String statusColorBa;

    /**
     * CommodityStatusModel status color goORder.
     */
    private String statusColorGoOrder;

    /**
     * CommodityStatusModel status color pgr.
     */
    private String statusColorPgr;

    /**
     * CommodityStatusModel status color cgr.
     */
    private String statusColorGgr;

    /**
     * CommodityStatusModel status color goProd.
     */
    private String statusColorGoProd;

    /**
     * CommodityStatusModel status color fai.
     */
    private String statusColorFai;

    /**
     * CommodityStatusModel status color iqa.
     */
    private String statusColorIqa;

    /**
     * CommodityStatusModel status color fqa.
     */
    private String statusColorFqa;

    /**
     * CommodityStatusModel status color fat.
     */
    private String statusColorFat;

    /**
     * CommodityStatusModel status color first need.
     */
    private Date statusColorFirstNeed;

    /**
     * CommodityStatusModel status color delivery.
     */
    private String statusColorDelivery;

    /**
     * CommodityStatusModel project milestone.
     */
    @JsonIgnore
    private ProjectMilestoneModel projectMilestone;

    /**
     * CommodityStatusModel seq.
     */
    private Integer listCommodityStatusSeq;

    /**
     * CommodityStatusModel date title.
     */
    private String forecastDateTitle;

    /**
     * CommodityStatusModel date techinput.
     */
    private Date forecastDateTechInput;

    /**
     * CommodityStatusModel date goRfq.
     */
    private Date forecastDateGoRfq;

    /**
     * CommodityStatusModel date ba.
     */
    private Date forecastDateBa;

    /**
     * CommodityStatusModel date goOrder.
     */
    private Date forecastDateGoOrder;

    /**
     * CommodityStatusModel date pgr.
     */
    private Date forecastDatePgr;

    /**
     * CommodityStatusModel date cgr.
     */
    private Date forecastDateCgr;

    /**
     * CommodityStatusModel date goProd.
     */
    private Date forecastDateGoProd;

    /**
     * CommodityStatusModel date fai.
     */
    private Date forecastDateFai;

    /**
     * CommodityStatusModel date iqa.
     */
    private Date forecastDateIqa;

    /**
     * CommodityStatusModel date fqa.
     */
    private Date forecastDateFqa;

    /**
     * CommodityStatusModel date fat.
     */
    private Date forecastDateFat;

    /**
     * CommodityStatusModel date first need.
     */
    private Date forecastDateFirstNeed;

    /**
     * CommodityStatusModel date forecast.
     */
    private Date forecastDateDelivery;
}
