package com.alstom.applicationfactory.pmfuservice.projectsetup.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectSetUpService;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;
import com.alstom.applicationfactory.pmfuservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/projectSetUp")
@Slf4j
@RefreshScope
public class ProjectSetUpController {

    /**
     * ProjectSetUpService.
     */
    @Autowired
    private ProjectSetUpService projectSetUpService;

    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;
    /**
     * email address.
     */
    @Value("${application.factory.jwt.emailProp}")
    private String emailProp;

    /**
     * @param request
     * @return project object.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public Object searchProjectSetUp(
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:PmfuProjectSetUpController:searchProjectSetUp");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = projectSetUpService.searchProjectSetUp(requestModel);
        log.debug("Leave:PmfuProjectSetUpController:searchProjectSetUp");
        return res;
    }

    /**
     * @param id
     * @return ProjectSetUpModel
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public ProjectSetUpModel viewProjectSetUp(@PathVariable("id") final UUID id) {
        log.debug("Entry:PmfuProjectSetUpController:viewProjectSetUp");
        ProjectSetUpModel projectSetUpModel = projectSetUpService.viewProjectSetUp(id);
        log.debug("Leave:PmfuProjectSetUpController:viewProjectSetUp");
        return projectSetUpModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public void deleteProjectSetUpById(@PathVariable("id") final UUID id) {
        log.debug("Entry:PmfuProjectSetUpController:deleteProjectSetUpById");
        this.projectSetUpService.deleteProjectSetUpById(id);
        log.debug("Leave:PmfuProjectSetUpController:deleteProjectSetUpById");
    }

    /**
     * @param request
     * @param authentication
     * @return list of Project Setup
     */
    @PostMapping("/listMyProjects")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public Object listMyProjectSetUp(@RequestBody(required = false) Map<String, Object> request,
            final Authentication authentication) {
        log.debug("Entry:PmfuProjectSetUpController:listMyProjectSetUp");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        User prsmUser = userRepository.findByEmail(email).get(0);
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getFilterCondition(Constants.STR_UUID, "prsm.id",
                prsmUser.getId(), Constants.STR_EQ));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object res = projectSetUpService.searchProjectSetUp(requestModel);
        log.debug("Leave:PmfuProjectSetUpController:listMyProjectSetUp");
        return res;
    }

    /**
     * @param projSetUpId
     * @param mileStoneIdList
     * @param authentication
     */
    @PostMapping("/{id}/mileStone")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public void deleteProjectMileStone(@PathVariable("id") final UUID projSetUpId,
            @RequestBody final List<UUID> mileStoneIdList, final Authentication authentication) {
        log.debug("Entry:PmfuProjectSetUpController:deleteProjectMileStone");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        projectSetUpService.deleteProjectMileStoneById(projSetUpId, mileStoneIdList, email);
        log.debug("Entry:PmfuProjectSetUpController:deleteProjectMileStone");
    }

    /**
     * @param projectSetUpModel
     * @param authentication
     * @return ProjectSetUpModel
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public ProjectSetUpModel saveProjectSetUp(
            @RequestBody final ProjectSetUpModel projectSetUpModel,
            final Authentication authentication) {
        log.debug("Entry:PmfuProjectSetUpController:saveProjectSetUp");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        ProjectSetUpModel createdProjectSetUpModel = new ProjectSetUpModel();
        String email = claims.get(emailProp).toString();
        createdProjectSetUpModel = projectSetUpService.saveProjectSetUp(projectSetUpModel, email);
        log.debug("Leave:PmfuProjectSetUpController:saveProjectSetUp");
        return createdProjectSetUpModel;
    }

    /**
     * @param projSetUpId
     * @param actionId
     * @param authentication
     */
    @DeleteMapping("/{id}/puactions/{actionId}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public void deletePuActionById(@PathVariable("id") final UUID projSetUpId,
            @PathVariable("actionId") final UUID actionId, final Authentication authentication) {
        log.debug("Entry:PmfuProjectSetUpController:deletePuActionById");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        projectSetUpService.deletePuActionById(projSetUpId, actionId, email);
        log.debug("Entry:PmfuProjectSetUpController:deletePuActionById");
    }

    /**
     * @param projSetUpId
     * @param contractId
     * @param authentication
     */
    @DeleteMapping("/{id}/contracts/{contractId}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public void deleteContractById(@PathVariable("id") final UUID projSetUpId,
            @PathVariable("contractId") final UUID contractId,
            final Authentication authentication) {
        log.debug("Entry:PmfuProjectSetUpController:deleteContractById");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        projectSetUpService.deleteContractById(projSetUpId, contractId, email);
        log.debug("Entry:PmfuProjectSetUpController:deleteContractById");
    }
}
