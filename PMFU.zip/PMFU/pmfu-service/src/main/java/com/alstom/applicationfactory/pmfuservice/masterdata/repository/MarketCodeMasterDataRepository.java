package com.alstom.applicationfactory.pmfuservice.masterdata.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;

@Repository
public interface MarketCodeMasterDataRepository extends JpaRepository<MarketCodeMasterData, UUID>,
        JpaSpecificationExecutor<MarketCodeMasterData> {

    /**
     * @param marketCode
     * @return MarketCodeMasterData
     */
    MarketCodeMasterData findByMarketCode(String marketCode);
}
