package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.pmfuservice.masterdata.service.FileImportService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = "/import")
@Slf4j
public class FileImportController {

    /**
     * FileImportService.
     */
    @Autowired
    private FileImportService importService;

    /**
     * @param multipartFile
     * @param projectId
     * @param authentication
     * @return Object.
     */
    @PostMapping("/{projectId}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public Map<String, Object> importMasterDataContents(
            @RequestParam final MultipartFile multipartFile,
            @PathVariable("projectId") final Integer projectId,
            final Authentication authentication) {
        log.debug("Entry:FileImportController:importMasterDataContents");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String emailId = claims.get("preferred_username").toString();
        Map<String, Object> response = importService.importMasterDataContents(multipartFile,
                projectId, emailId);
        log.debug("Leave:FileImportController:importMasterDataContents");
        return response;
    }
}
