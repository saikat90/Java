package com.alstom.applicationfactory.pmfuservice.projectsetup.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpAttachmentModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectSetUpAttachmentService;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/projectSetUpAttachment")
@Slf4j
public class ProjectSetUpAttachmentController {

    /**
     * ProjectSetUpAttachmentService.
     */
    @Autowired
    private ProjectSetUpAttachmentService projectSetUpAttachmentService;

    /**
     * @param file
     * @param userEmail
     * @return ProjectSetUpAttachmentModel
     */
    @PostMapping("/upload")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public ProjectSetUpAttachmentModel uploadAttachment(
            @RequestParam("file") final MultipartFile file,
            @RequestParam("userEmail") final String userEmail) {
        log.debug("Entry:ProjectSetUpAttachmentController:uploadAttachment");
        ProjectSetUpAttachmentModel projSetUpAttachmentModel = projectSetUpAttachmentService
                .uploadAttachment(file, userEmail);
        log.debug("Leave:ProjectSetUpAttachmentController:uploadAttachment");
        return projSetUpAttachmentModel;
    }

    /**
     * @param projSetUpAttachmentId
     * @param response
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM','VISITOR','KEYUSER')")
    public void downloadAttachment(@PathVariable("id") final UUID projSetUpAttachmentId,
            final HttpServletResponse response) {
        log.debug("Entry:ProjectSetUpAttachmentController:downloadAttachment");
        try {
            File file = projectSetUpAttachmentService.downloadAttachment(projSetUpAttachmentId);
            Path path = Paths.get(file.toURI());
            String mimeType = Files.probeContentType(path);
            response.setContentType(mimeType);
            response.setHeader("Content-Disposition",
                    "attachment;filename=\"" + file.getName() + "\"");
            response.getOutputStream()
                    .write(projectSetUpAttachmentService.readFileToByteArray(file));
            response.getOutputStream().close();
        } catch (IOException e) {
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("File ", "Error in reading attachments"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:ProjectSetUpAttachmentController:downloadAttachment");
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM')")
    public void deleteAttachmentById(@PathVariable("id") final UUID id) {
        log.debug("Entry:ProjectSetUpAttachmentController:deleteAttachment");
        this.projectSetUpAttachmentService.deleteAttachmentById(id);
        log.debug("Leave:ProjectSetUpAttachmentController:deleteAttachment");
    }

}
