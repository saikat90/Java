package com.alstom.applicationfactory.pmfuservice.projectsetup.service;

import java.util.List;
import java.util.Map;

import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;

public interface ProjectMilestoneService {

    /**
     * @param projectID
     * @param cdbCode
     * @return true or false based on condition.
     */
    boolean isProjectIDAndCdbCodeExists(Integer projectID, String cdbCode);

    /**
     * @param puproject_market_projectMilestoneMap
     */
    void saveImportedMilestoneRecords(
            Map<String, List<ProjectMilestone>> puproject_market_projectMilestoneMap);

    /**
     * @param projectID
     * @param supplierMarketCode
     * @param materialName
     * @return ProjectMilestone
     */
    ProjectMilestone isMarketCodeAndMaterialExists(Integer projectID, String supplierMarketCode,
            String materialName);
}
