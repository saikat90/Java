package com.alstom.applicationfactory.pmfuservice.masterdata.entity;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type UserSearchQuery.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_search_query")
public class UserSearchQuery {

    /**
     * SavedSearch - id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * SavedSearch - user.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(nullable = false, referencedColumnName = Constants.COLUMN_REF_ID, name = "user_id")
    private User user;

    /**
     * SavedSearch name.
     */
    @Column(nullable = false)
    private String name;

    /**
     * SavedSearch screenName.
     */
    @Column(nullable = false)
    private String screenName;

    /**
     * SavedSearch criteria.
     */
    @Column(length = Constants.INT_LENGTH_4096, nullable = false)
    private String criteria;

    /**
     * SavedSearch defaultQuery.
     */
    @Column(name = "default_query")
    private boolean defaultQuery;

    /**
     * SavedSearch shared.
     */
    @Column(name = "shared")
    private boolean shared;

    /**
     * SavedSearch sharedByUser.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(nullable = false, referencedColumnName = Constants.COLUMN_REF_ID, name = "shared_by_user_id")
    private User sharedByUser;

    /**
     * SavedSearch sharedToUsers.
     */
    @ManyToMany
    @CollectionTable(name = "user_search_query_shared_users")
    private List<User> sharedToUsers = Collections.EMPTY_LIST;

    /**
     * SavedSearch createdDate.
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     * SavedSearch modified date.
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     * SavedSearch created by.
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     * SavedSearch modified by.
     */
    @Column(name = "updated_by")
    private String modifiedBy;
}
