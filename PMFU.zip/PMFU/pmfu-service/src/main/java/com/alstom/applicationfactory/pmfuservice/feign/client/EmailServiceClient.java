package com.alstom.applicationfactory.pmfuservice.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.alstom.applicationfactory.pmfuservice.masterdata.model.EmailModel;

@FeignClient("mail-service")
public interface EmailServiceClient {
    /**
     * Send mail.
     * 
     * @param email
     */
    @PostMapping("/email/send")
    void sendMail(@RequestBody EmailModel email);
}
