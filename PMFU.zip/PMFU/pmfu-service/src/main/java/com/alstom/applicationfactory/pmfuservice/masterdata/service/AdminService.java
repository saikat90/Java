package com.alstom.applicationfactory.pmfuservice.masterdata.service;

import java.util.List;
import java.util.Map;

import org.springframework.security.core.Authentication;

import com.alstom.applicationfactory.pmfuservice.masterdata.model.ApplicationModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProfileModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;

public interface AdminService {
    /**
     * @param code
     * @param authentication
     * @return ProfileModel
     */
    ProfileModel getProfile(String code, Authentication authentication);

    /**
     * @param id
     * @param request
     * @return email address.
     */
    Object findEmailByApplicationId(String id, Map<String, Object> request);

    /**
     * @param id
     * @param request
     * @return user role object.
     */
    Object findRolesByApplicationId(String id, Map<String, Object> request);

    /**
     * @param email
     * @return updated user email object.
     */
    Object updateEmail(Object email);

    /**
     * @param request
     * @return list of all users.
     */
    Object findAllUsers(Map<String, Object> request);

    /**
     * @param users
     * @return list of UserModel
     */
    List<UserModel> saveAllUsers(List<UserModel> users);

    /**
     * @param applicationId
     * @param roleCode
     * @param request
     * @return list of user object for a role.
     */
    Object findRoleUsers(String applicationId, String roleCode, Map<String, Object> request);

    /**
     * @param id
     * @param request
     * @return list of user object that is not mapped to a role.
     */
    Object findUnmappedApplicationRoleUsers(String id, Map<String, Object> request);

    /**
     * @param appRoleId
     * @param request
     * @return list of user object by application role.
     */
    Object findUsersByApplicationRole(String appRoleId, Map<String, Object> request);

    /**
     * @param applicationRoleUsers
     * @return saved user object for a role.
     */
    Object saveUsersForRole(Object applicationRoleUsers);

    /**
     * @param applicationRoleUsers
     * @return updated user object for a role.
     */
    Object updateUsersForRole(Object applicationRoleUsers);

    /**
     * @param id
     * @return ApplicationModel.
     */
    ApplicationModel findById(String id);

    /**
     * @param appId
     * @param applicationRoleUserId
     * @param request
     * @return Object.
     */
    Object getUnmappedRightsForApplicationRoleUser(String appId, String applicationRoleUserId,
            Map<String, Object> request);

    /**
     * @param appRoleUserId
     * @param request
     * @return user rights object for applcation role.
     */
    Object listApplicationRoleUserRights(String appRoleUserId, Map<String, Object> request);

    /**
     * @param applicationRoleUserRightsModels
     * @return saved application role object.
     */
    Object saveApplicationRoleRights(Object applicationRoleUserRightsModels);

    /**
     * @param applicationRoleUserRightsModels
     * @return updated application role object.
     */
    Object updateApplicationRoleRights(Object applicationRoleUserRightsModels);
}
