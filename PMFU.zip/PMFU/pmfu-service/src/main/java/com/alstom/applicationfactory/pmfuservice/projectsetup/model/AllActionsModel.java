package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type AllActions model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AllActionsModel {

    /**
     * AllActionsModel market code.
     */
    private String marketCode;

    /**
     * AllActionsModel created date.
     */
    private Date createdDate;

    /**
     * AllActionsModel closing date.
     */
    private Date closingDate;

    /**
     * AllActionsModel pic.
     */
    private String pic;

    /**
     * AllActionsModel description.
     */
    private String description;

    /**
     * AllActionsModel priority.
     */
    private String priority;

    /**
     * AllActionsModel status.
     */
    private String status;

    /**
     * AllActionsModel target date.
     */
    private Date targetDate;

    /**
     * AllActionsModel project id.
     */
    private Integer projectId;

    /**
     * AllActionsModel project name.
     */
    private String projectName;

    /**
     * AllActionsModel domain code.
     */
    private String domainCode;

    /**
     * AllActionsModel material.
     */
    private String material;

    /**
     * AllActionsModel export date.
     */
    private Date exportDate;

}
