package com.alstom.applicationfactory.pmfuservice.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JoinModel {
    /**
     * Join Model - Object.
     */
    private String object;
    /**
     * Join Model - Type.
     */
    private String type;
    /**
     * Join Model - filter.
     */
    private FilterModel filter;
}
