package com.alstom.applicationfactory.pmfuservice.common.model;

import org.springframework.data.domain.Sort;

import com.alstom.applicationfactory.pmfuservice.util.FilterSpecification;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestModel {
    /**
     * RequestModel - page number.
     */
    private int pageNumber;
    /**
     * RequestModel - page size.
     */
    private int pageSize;
    /**
     * RequestModel - condition to display all records or to list only defined.
     * records
     */
    private boolean isPaged;
    /**
     * RequestModel - filterSpecification.
     */
    private FilterSpecification filterSpecification;

    /**
     * used for sorting of records.
     */
    private Sort sort;
}
