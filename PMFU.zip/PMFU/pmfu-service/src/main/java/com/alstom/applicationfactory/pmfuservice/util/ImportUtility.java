package com.alstom.applicationfactory.pmfuservice.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ImportUtility {

    /**
     * @param excelWorkbook
     * @return boolean.
     */
    public final Boolean validateExcelFile(final XSSFWorkbook excelWorkbook) {
        Boolean result = false;
        int totalSheet = excelWorkbook.getNumberOfSheets();
        if (Constants.TOTAL_EXCEL_SHEET == totalSheet) {
            log.debug("Total sheet:", totalSheet);
            XSSFSheet importSheet = excelWorkbook.getSheetAt(0);
            String sheetName = importSheet.getSheetName();
            if (sheetName.equalsIgnoreCase(Constants.MARKETCODE_SHEET_NAME)) {
                XSSFSheet marketCodeSheet = importSheet;
                if (isValidMarketCodeFormat(marketCodeSheet)) {
                    log.debug("Market Code Import Sheet format is correct");
                    result = true;
                } else {
                    log.error("Market Code Import Sheet format is wrong");
                    List<ErrorModel> errorList = new ArrayList<>();
                    errorList.add(new ErrorModel("Market Code Import",
                            "Market Code Import Sheet format is wrong"));
                    throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
                }
            } else if (sheetName.equalsIgnoreCase(Constants.ATSITE_SHEET_NAME)) {
                XSSFSheet atSiteSheet = importSheet;
                if (isValidAtSiteFormat(atSiteSheet)) {
                    log.debug("AT Site Import Sheet format is correct");
                    result = true;
                } else {
                    log.error("At Site Import Sheet format is wrong");
                    List<ErrorModel> errorList = new ArrayList<>();
                    errorList.add(new ErrorModel("AT Site Import",
                            "AT Site Import Sheet format is wrong"));
                    throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
                }
            } else if (sheetName.equalsIgnoreCase(Constants.MILESTONE_SHEET_NAME)) {
                XSSFSheet projectMilestoneSheet = importSheet;
                if (isValidProjectMilestoneFormat(projectMilestoneSheet)) {
                    log.debug("Milestone Import Sheet format is correct");
                    result = true;
                } else {
                    log.error("Milestone Import Sheet format is wrong");
                    List<ErrorModel> errorList = new ArrayList<>();
                    errorList.add(new ErrorModel("Project Milestone",
                            "Milestone Import Sheet format is wrong"));
                    throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
                }
            } else {
                log.error("Import Excel Sheet Name is Incorrect");
                List<ErrorModel> errorList = new ArrayList<>();
                errorList.add(new ErrorModel("Import Excel Format",
                        "Import Excel Sheet Name is Incorrect"));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
            }
        } else {
            log.error("Import Excel has more number of sheets");
            List<ErrorModel> errorList = new ArrayList<>();
            errorList.add(
                    new ErrorModel("Import Excel Format", "Import Excel has more than 1 Sheet"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }

        return result;
    }

    /**
     * @param sheet
     * @return boolean.
     */
    private Boolean isValidMarketCodeFormat(final XSSFSheet sheet) {
        Boolean result = false;
        Row row = sheet.getRow(1);
        Iterator<Cell> cellItr = row.cellIterator();
        List<String> marketCodeFileHeaders = new ArrayList<>();
        while (cellItr.hasNext()) {
            marketCodeFileHeaders.add(cellItr.next().getStringCellValue());
        }
        List<String> marketCodeHeaders = marketCodeHeadersDefault();

        if (marketCodeFileHeaders.equals(marketCodeHeaders)) {
            result = true;
        }
        return result;
    }

    /**
     * @param sheet
     * @return boolean.
     */
    private Boolean isValidAtSiteFormat(final XSSFSheet sheet) {
        Boolean result = false;
        Row row = sheet.getRow(1);
        Iterator<Cell> cellItr = row.cellIterator();
        List<String> atSiteFileHeaders = new ArrayList<>();
        while (cellItr.hasNext()) {
            atSiteFileHeaders.add(cellItr.next().getStringCellValue());
        }
        List<String> atSiteHeaders = atSiteHeadersDefault();
        if (atSiteFileHeaders.equals(atSiteHeaders)) {
            result = true;
        }
        return result;
    }

    private Boolean isValidProjectMilestoneFormat(final XSSFSheet sheet) {
        Boolean result = false;
        Row row = sheet.getRow(1);
        Iterator<Cell> cellItr = row.cellIterator();
        List<String> projectMilestoneFileHeaders = new ArrayList<>();
        while (cellItr.hasNext()) {
            projectMilestoneFileHeaders.add(cellItr.next().getStringCellValue());
        }
        List<String> projectMilestoneHeaders = projectMilestoneHeadersDefault();

        if (projectMilestoneFileHeaders.equals(projectMilestoneHeaders)) {
            result = true;
        }
        return result;
    }

    /**
     * @param row
     * @return boolean.
     */
    public final Boolean isEmptyRow(final Row row) {
        if (row == null) {
            return true;
        }
        if (row.getLastCellNum() <= 0) {
            return true;
        }
        for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
            Cell cell = row.getCell(cellNum);
            if (cell != null && cell.getCellTypeEnum() != CellType.BLANK
                    && StringUtils.isNotBlank(cell.toString())) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return market code header.
     */
    public final List<String> marketCodeHeadersDefault() {
        List<String> marketCodeHeaders = new ArrayList<>();
        marketCodeHeaders.add("Supplier Market Code");
        marketCodeHeaders.add("Supplier Market Name");
        marketCodeHeaders.add("Domain Code");
        marketCodeHeaders.add("Domain Name");
        marketCodeHeaders.add("Global / Local");
        marketCodeHeaders.add("Train");
        marketCodeHeaders.add("Rail Control");
        marketCodeHeaders.add("Systems & Infra");
        marketCodeHeaders.add("Go RFQ");
        marketCodeHeaders.add("BA");
        marketCodeHeaders.add("Go Order");
        marketCodeHeaders.add("PGR");
        marketCodeHeaders.add("CGR");
        marketCodeHeaders.add("Go Prod");
        marketCodeHeaders.add("FAI");
        marketCodeHeaders.add("IQA");
        marketCodeHeaders.add("FQA");
        marketCodeHeaders.add("FAT");
        return marketCodeHeaders;
    }

    /**
     * @return AT site header.
     */
    public final List<String> atSiteHeadersDefault() {
        List<String> atSiteHeaders = new ArrayList<>();
        atSiteHeaders.add("Region");
        atSiteHeaders.add("Country");
        atSiteHeaders.add("Unit Name");
        atSiteHeaders.add("Site");
        atSiteHeaders.add("Carat Code");
        atSiteHeaders.add("Carat Unit Short Name");
        atSiteHeaders.add("Unit Acronym");
        atSiteHeaders.add("Business");
        atSiteHeaders.add("Internal Margin");
        atSiteHeaders.add("KP");
        atSiteHeaders.add("KI");
        atSiteHeaders.add("KNP Internal");
        atSiteHeaders.add("KNP External");
        atSiteHeaders.add("Street");
        atSiteHeaders.add("Post Code");
        atSiteHeaders.add("Town");
        atSiteHeaders.add("State");
        atSiteHeaders.add("Segment");
        atSiteHeaders.add("OBS uses segment, not region");
        atSiteHeaders.add("Created Timestamp");
        atSiteHeaders.add("Created by");
        return atSiteHeaders;
    }

    /**
     * @return project milestone header.
     */
    private List<String> projectMilestoneHeadersDefault() {
        List<String> projectMilestoneHeaders = new ArrayList<>();
        projectMilestoneHeaders.add("Material");
        projectMilestoneHeaders.add("Supplier Market Code");
        projectMilestoneHeaders.add("Tech Input");
        projectMilestoneHeaders.add("Go RFQ");
        projectMilestoneHeaders.add("BA");
        projectMilestoneHeaders.add("Go Order");
        projectMilestoneHeaders.add("PGR");
        projectMilestoneHeaders.add("CGR");
        projectMilestoneHeaders.add("Go Prod");
        projectMilestoneHeaders.add("FAI");
        projectMilestoneHeaders.add("FAT");
        projectMilestoneHeaders.add("1st NEED");
        projectMilestoneHeaders.add("IQA");
        projectMilestoneHeaders.add("FQA");
        projectMilestoneHeaders.add("Project ID");
        projectMilestoneHeaders.add("CDB Code");
        return projectMilestoneHeaders;
    }

    /**
     * @return all actions header.
     */
    public final List<String> allActionsHeadersDefault() {
        List<String> allActionsHeaders = new ArrayList<>();
        allActionsHeaders.add("Market Code");
        allActionsHeaders.add("Created Date");
        allActionsHeaders.add("Closing Date");
        allActionsHeaders.add("PIC");
        allActionsHeaders.add("Description");
        allActionsHeaders.add("Priority");
        allActionsHeaders.add("Status");
        allActionsHeaders.add("Target");
        allActionsHeaders.add("Project Id");
        allActionsHeaders.add("Project Name");
        allActionsHeaders.add("Domain");
        allActionsHeaders.add("Material");
        allActionsHeaders.add("Export Date");
        return allActionsHeaders;
    }

    /**
     * @return project maseter header.
     */
    public final List<String> projectMasterDataHeadersDefault() {
        List<String> projectMasterDataHeaders = new ArrayList<>();
        projectMasterDataHeaders.add("Project ID");
        projectMasterDataHeaders.add("Project Name");
        projectMasterDataHeaders.add("CDB Code");
        projectMasterDataHeaders.add("Region");
        projectMasterDataHeaders.add("Site");
        projectMasterDataHeaders.add("Product Line");
        projectMasterDataHeaders.add("PrSM");
        projectMasterDataHeaders.add("Domain Code");
        projectMasterDataHeaders.add("Supplier Market Code");
        projectMasterDataHeaders.add("Material");
        projectMasterDataHeaders.add("Milestone");
        projectMasterDataHeaders.add("Applicable");
        projectMasterDataHeaders.add("Duration");
        projectMasterDataHeaders.add("Needs");
        projectMasterDataHeaders.add("Forecast");
        projectMasterDataHeaders.add("Actual");
        projectMasterDataHeaders.add("Status");
        projectMasterDataHeaders.add("Time");
        projectMasterDataHeaders.add("Variance");
        return projectMasterDataHeaders;
    }

}
