package com.alstom.applicationfactory.pmfuservice.projectsetup.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type PuActions.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "puactions")
public class PuActions {
    /**
     * PuActions id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * PuActions version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * PuActions created date.
     */
    @Column(name = "created_date", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date createdDate;

    /**
     * PuActions pic.
     */
    @Column(name = "pic", length = Constants.INT_LENGTH_200)
    private String pic;

    /**
     * PuActions description.
     */
    @Column(name = "description", length = Constants.INT_LENGTH_500)
    private String description;

    /**
     * PuActions priority.
     */
    @Column(name = "priority", length = Constants.INT_LENGTH_1)
    private String priority;

    /**
     * PuActions target date.
     */
    @Column(name = "target_date", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date targetDate;

    /**
     * PuActions status.
     */
    @Column(name = "status", length = Constants.INT_LENGTH_5)
    private String status;

    /**
     * PuActions commodity action plan.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pu_commodity_action_plan_rev_id", referencedColumnName = Constants.COLUMN_REF_ID)
    private CommodityActionPlan commodityActionPlan;

    /**
     * PuActions material.
     */
    @Column(name = "material", length = Constants.INT_LENGTH_5)
    private String material;

    /**
     * PuActions closing date.
     */
    @Column(name = "closing_date", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date closingDate;
}
