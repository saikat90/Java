package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type dfq delivery graph model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DFQDeliveryGraphModel {

    /**
     * DFQDeliveryGraphModel on time delivered.
     */
    private Integer onTimeDelivered;

    /**
     * DFQDeliveryGraphModel on time not delivered.
     */
    private Integer onTimeNotDelivered;

    /**
     * DFQDeliveryGraphModel late delivered.
     */
    private Integer lateDelivered;

    /**
     * DFQDeliveryGraphModel late not delivered.
     */
    private Integer lateNotDelivered;

    /**
     * DFQDeliveryGraphModel time type.
     */
    private String timeType;

}
