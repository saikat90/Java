package com.alstom.applicationfactory.pmfuservice.projectsetup.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.Contracts;

public interface ContractsRepository extends JpaRepository<Contracts, UUID>, JpaSpecificationExecutor<Contracts> {

}
