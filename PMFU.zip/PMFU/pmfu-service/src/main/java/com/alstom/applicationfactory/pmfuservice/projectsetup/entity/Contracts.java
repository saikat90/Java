package com.alstom.applicationfactory.pmfuservice.projectsetup.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Contracts.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pucontracts")
public class Contracts {
    /**
     * Contracts id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * Contracts version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * Contracts material component.
     */
    @Column(name = "material_component", length = Constants.INT_LENGTH_100)
    private String materialComponent;

    /**
     * Contracts contract type.
     */
    @Column(name = "contract_type", length = Constants.INT_LENGTH_3)
    private String contractType;

    /**
     * Contracts part conditions.
     */
    @Column(name = "part_conditions", length = Constants.INT_LENGTH_3)
    private String partConditions;

    /**
     * Contracts status.
     */
    @Column(name = "status", length = Constants.INT_LENGTH_10)
    private String status;

    /**
     * Contracts po.
     */
    @Column(name = "po", length = Constants.INT_LENGTH_8)
    private String po;

    /**
     * Contracts perf bond.
     */
    @Column(name = "perf_bond", length = Constants.INT_LENGTH_12)
    private String perfBond;

    /**
     * Contracts warranty bond.
     */
    @Column(name = "warranty_bond", length = Constants.INT_LENGTH_12)
    private String warrantyBond;

    /**
     * Contracts ar.
     */
    @Column(name = "ar", length = Constants.INT_LENGTH_12)
    private String ar;

    /**
     * Contracts poNrc.
     */
    @Column(name = "po_nrc", length = Constants.INT_LENGTH_14)
    private String poNrc;

    /**
     * Contracts comments.
     */
    @Column(name = "comments", length = Constants.INT_LENGTH_500)
    private String comments;

    /**
     * Contracts commodity contract.
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pu_commodity_contract_rev_id ", referencedColumnName = Constants.COLUMN_REF_ID)
    private CommodityContract commodityContract;
}
