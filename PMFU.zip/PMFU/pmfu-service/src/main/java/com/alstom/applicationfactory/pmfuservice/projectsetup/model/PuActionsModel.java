package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type actions model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PuActionsModel {

    /**
     * PuActionsModel id.
     */
    private UUID id;

    /**
     * PuActionsModel version.
     */
    @NotNull(message = Constants.VERSION_NOTEMPTY)
    private Integer version;

    /**
     * PuActionsModel created date.
     */
    private Date createdDate;

    /**
     * PuActionsModel pic.
     */
    @Size(max = Constants.INT_LENGTH_200, message = Constants.PIC_MAX_MSG)
    private String pic;

    /**
     * PuActionsModel description.
     */
    @Size(max = Constants.INT_LENGTH_500, message = Constants.DESC_MAX_MSG)
    private String description;

    /**
     * PuActionsModel priority.
     */
    @Size(max = Constants.INT_LENGTH_1, message = Constants.PRIORITY_MAX_MSG)
    private String priority;

    /**
     * PuActionsModel target date.
     */
    private Date targetDate;

    /**
     * PuActionsModel status.
     */
    @Size(max = Constants.INT_LENGTH_5, message = Constants.STATUS_MAX_MSG)
    private String status;

    /**
     * PuActionsModel commodity action plan.
     */
    @JsonIgnore
    private CommodityActionPlanModel commodityActionPlan;

    /**
     * PuActionsModel material.
     */
    @Size(max = Constants.INT_LENGTH_500, message = Constants.MATERIAL_MAX_MSG)
    private String material;

    /**
     * PuActionsModel closing date.
     */
    private Date closingDate;
}
