package com.alstom.applicationfactory.pmfuservice.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BasicSecurityUser implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * BasicSecurityUser primary key.
     */
    private UUID id;
    /**
     * Username of the user.
     */
    private String username;
    /**
     * Password of the user.
     */
    private String password;
    /**
     * whether the user is deleted or not.
     */
    private boolean deleted;
}
