package com.alstom.applicationfactory.pmfuservice.masterdata.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type MarketCode MasterData.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pumarket_code_master_data")
public class MarketCodeMasterData {
    /**
     * MarketCode primary key id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * marketCode version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * marketCode.
     */
    @Column(name = "supplier_market_code", length = Constants.INT_LENGTH_20, unique = true)
    private String marketCode;

    /**
     * marketCode name.
     */
    @Column(name = "supplier_market_name", length = Constants.INT_LENGTH_300)
    private String marketName;

    /**
     * domainCode.
     */
    @Column(name = "domain_code", length = Constants.INT_LENGTH_10)
    private String domainCode;

    /**
     * domainName.
     */
    @Column(name = "domain_name", length = Constants.INT_LENGTH_100)
    private String domainName;

    /**
     * marketCode globalLocal.
     */
    @Column(name = "global_local", length = Constants.INT_LENGTH_30)
    private String globalLocal;

    /**
     * marketCode train.
     */
    @Column(name = "train", length = Constants.INT_LENGTH_100)
    private String train;

    /**
     * marketCode railControl.
     */
    @Column(name = "rail_control", length = Constants.INT_LENGTH_100)
    private String railControl;

    /**
     * marketCode systemInfra.
     */
    @Column(name = "system_infra", length = Constants.INT_LENGTH_100)
    private String systemInfra;

    /**
     * marketCode goRfq.
     */
    @Column(name = "mc_gorfq")
    private Integer goRFQ;

    /**
     * marketCode ba.
     */
    @Column(name = "mc_ba")
    private Integer ba;

    /**
     * marketCode goOrder.
     */
    @Column(name = "mc_goorder")
    private Integer goOrder;

    /**
     * marketCode pgr.
     */
    @Column(name = "mc_pgr")
    private Integer pgr;

    /**
     * marketCode cgr.
     */
    @Column(name = "mc_cgr")
    private Integer cgr;

    /**
     * marketCode goProd.
     */
    @Column(name = "mc_goprod")
    private Integer goProd;

    /**
     * marketCode fai.
     */
    @Column(name = "mc_fai")
    private Integer fai;

    /**
     * marketCode iqa.
     */
    @Column(name = "mc_iqa")
    private Integer iqa;

    /**
     * marketCode fqa.
     */
    @Column(name = "mc_fqa")
    private Integer fqa;

    /**
     * marketCode fat.
     */
    @Column(name = "mc_fat")
    private Integer fat;
}
