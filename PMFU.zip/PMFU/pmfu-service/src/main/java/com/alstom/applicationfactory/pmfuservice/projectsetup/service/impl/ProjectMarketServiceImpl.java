package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMarketModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMarketRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectMarketService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "projectMarketService")
@Transactional
@Slf4j
public class ProjectMarketServiceImpl implements ProjectMarketService {

    /**
     * ProjectMarketRepository.
     */
    @Autowired
    private ProjectMarketRepository projectMarketRepository;

    @Override
    public ProjectMarketModel createProjectMarket(final ProjectMarketModel projectMarketModel) {
        log.debug("Entry:ProjectMarketServiceImpl:createProjectMarket");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        ProjectMarket createdProjectMarket = new ProjectMarket();

        ProjectMarketModel createdProjectMarketModel = new ProjectMarketModel();

        ProjectMarket projectMarket = mapper.map(projectMarketModel, ProjectMarket.class);

        try {
            createdProjectMarket = projectMarketRepository.save(projectMarket);
            createdProjectMarketModel = mapper.map(createdProjectMarket, ProjectMarketModel.class);
        } catch (Exception e) {
            log.error("Error while creating record for ProjectMarket");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("ProjectMarket",
                    "Error while creating record for ProjectMarket"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:ProjectMarketServiceImpl:createProjectMarket");
        return createdProjectMarketModel;
    }

}
