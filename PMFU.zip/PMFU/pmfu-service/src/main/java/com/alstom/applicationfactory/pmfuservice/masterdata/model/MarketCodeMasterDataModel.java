package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type MarketCode MasterData model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MarketCodeMasterDataModel {
    /**
     * MarketCodeModel id.
     */
    private UUID id;

    /**
     * MarketCodeModel version.
     */
    private Integer version;
    /**
     * MarketCodeModel market code.
     */
    @NotNull(message = Constants.MARKET_CODE_NOTEMPTY)
    private String marketCode;
    /**
     * MarketCodeModel market name.
     */
    @NotNull(message = Constants.MARKET_NAME_NOTEMPTY)
    private String marketName;
    /**
     * MarketCodeModel domain code.
     */
    @NotNull(message = Constants.DOMAIN_CODE_NOTEMPTY)
    private String domainCode;

    /**
     * MarketCodeModel domain name.
     */
    private String domainName;

    /**
     * MarketCodeModel global local.
     */
    private String globalLocal;

    /**
     * MarketCodeModel train.
     */
    private String train;

    /**
     * MarketCodeModel rail control.
     */
    private String railControl;

    /**
     * MarketCodeModel system infra.
     */
    private String systemInfra;
    /**
     * MarketCodeModel goRfq.
     */
    @NotNull(message = Constants.GORFQ_NOTEMPTY)
    private Integer goRFQ;
    /**
     * MarketCodeModel ba.
     */
    @NotNull(message = Constants.BA_NOTEMPTY)
    private Integer ba;
    /**
     * MarketCodeModel goOrder.
     */
    @NotNull(message = Constants.GOORDER_NOTEMPTY)
    private Integer goOrder;
    /**
     * MarketCodeModel pgr.
     */
    @NotNull(message = Constants.PGR_NOTEMPTY)
    private Integer pgr;
    /**
     * MarketCodeModel cgr.
     */
    @NotNull(message = Constants.CGR_NOTEMPTY)
    private Integer cgr;
    /**
     * MarketCodeModel goProd.
     */
    @NotNull(message = Constants.GOPROD_NOTEMPTY)
    private Integer goProd;
    /**
     * MarketCodeModel fai.
     */
    @NotNull(message = Constants.FAI_NOTEMPTY)
    private Integer fai;
    /**
     * MarketCodeModel iqa.
     */
    @NotNull(message = Constants.IQA_NOTEMPTY)
    private Integer iqa;
    /**
     * MarketCodeModel fqa.
     */
    @NotNull(message = Constants.FQA_NOTEMPTY)
    private Integer fqa;
    /**
     * MarketCodeModel fat.
     */
    @NotNull(message = Constants.FAT_NOTEMPTY)
    private Integer fat;
}
