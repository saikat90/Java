package com.alstom.applicationfactory.pmfuservice.projectsetup.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;

public interface ProjectMilestoneRepository
        extends JpaRepository<ProjectMilestone, UUID>, JpaSpecificationExecutor<ProjectMilestone> {

    /**
     * @param projectMarketId
     * @param marketCode
     * @return ProjectMilestone List
     */
    List<ProjectMilestone> findByProjectMarketIdAndSupplierMarketCode(UUID projectMarketId,
            String marketCode);

    /**
     * @param projectID
     * @param supplierMarketCode
     * @param materialName
     * @return ProjectMilestone
     */
    @Query(value = "select * from pumarket_code pc where "
            + "	pc.project_market_rev_id in (select pm.id from puproject_market pm "
            + "		where pm.pu_set_up_rev_id in (select pu.id from puset_up pu "
            + "				where pu.project_id = ?1) and pm.supplier_market_code =?2) and "
            + " pc.material =?3", nativeQuery = true)
    ProjectMilestone findByMarketCodeAndMaterial(Integer projectID, String supplierMarketCode,
            String materialName);

    /**
     * @param projectId
     * @param supplierMarketCode
     * @return Seq Number
     */
    @Query(value = "select count(pc.puproject_market_list_of_market_code_per_market_seq) from pumarket_code pc "
            + " where pc.project_market_rev_id in (select pm.id from puproject_market pm where pm.pu_set_up_rev_id in (select pu.id from puset_up pu "
            + " where pu.project_id = ?1) and pm.supplier_market_code =?2) ", nativeQuery = true)
    Integer findSeqNumber(Integer projectId, String supplierMarketCode);

    /**
     * @param newMC
     * @param domainCode
     * @param oldMC
     */
    @Modifying
    @Query(value = "update pumarket_code "
            + "set supplier_market_code = ?1 , domain_code = ?2 where supplier_market_code = ?3", nativeQuery = true)
    void updateMarketCodeAndDomainCode(String newMC, String domainCode, String oldMC);

    /**
     * @param projectMarketId
     * @param sequenceNo
     */
    @Modifying
    @Query(value = " update pumarket_code set puproject_market_list_of_market_code_per_market_seq = puproject_market_list_of_market_code_per_market_seq -1 "
            + " where " + " project_market_rev_id = ?1 and "
            + " puproject_market_list_of_market_code_per_market_seq > ?2", nativeQuery = true)
    void updateRearrangeMileStoneSequence(UUID projectMarketId, int sequenceNo);
}
