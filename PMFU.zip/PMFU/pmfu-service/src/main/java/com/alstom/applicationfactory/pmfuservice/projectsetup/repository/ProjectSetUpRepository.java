package com.alstom.applicationfactory.pmfuservice.projectsetup.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUp;

@Repository
public interface ProjectSetUpRepository
        extends JpaRepository<ProjectSetUp, UUID>, JpaSpecificationExecutor<ProjectSetUp> {

    /**
     * @return maximum project id.
     */
    @Query(value = "select max(project_id) from puset_up", nativeQuery = true)
    Integer findMaxProjectId();

    /**
     * @param projectId
     * @return ProjectSetUp
     */
    ProjectSetUp findByProjectId(Integer projectId);
}
