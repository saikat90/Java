package com.alstom.applicationfactory.pmfuservice.projectsetup.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.PuActions;

public interface PuActionsRepository extends JpaRepository<PuActions, UUID>, JpaSpecificationExecutor<PuActions> {

}
