package com.alstom.applicationfactory.pmfuservice.projectsetup.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type ProjectMilestone.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pumarket_code")
public class ProjectMilestone {
    /**
     * ProjectMilestone id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * ProjectMilestone version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * ProjectMilestone material.
     */
    @Column(name = "material", length = Constants.INT_LENGTH_100)
    private String material;

    /**
     * ProjectMilestone color tech input.
     */
    @Column(name = "tech_input_color", length = Constants.INT_LENGTH_10)
    private String techInputColor;

    /**
     * ProjectMilestone tech input.
     */
    @Column(name = "tech_input", length = Constants.INT_LENGTH_20)
    private String techInput;

    /**
     * ProjectMilestone color goRfq.
     */
    @Column(name = "go_rfq", length = Constants.INT_LENGTH_2)
    private String goRfq;

    /**
     * ProjectMilestone ba.
     */
    @Column(name = "ba", length = Constants.INT_LENGTH_2)
    private String ba;

    /**
     * ProjectMilestone goORder.
     */
    @Column(name = "go_order", length = Constants.INT_LENGTH_2)
    private String goOrder;

    /**
     * ProjectMilestone pgr.
     */
    @Column(name = "pgr", length = Constants.INT_LENGTH_2)
    private String pgr;

    /**
     * ProjectMilestone cgr.
     */
    @Column(name = "cgr", length = Constants.INT_LENGTH_2)
    private String cgr;

    /**
     * ProjectMilestone goProd.
     */
    @Column(name = "go_prod", length = Constants.INT_LENGTH_2)
    private String goProd;

    /**
     * ProjectMilestone fai.
     */
    @Column(name = "fai", length = Constants.INT_LENGTH_2)
    private String fai;

    /**
     * ProjectMilestone iqa.
     */
    @Column(name = "iqa", length = Constants.INT_LENGTH_2)
    private String iqa;

    /**
     * ProjectMilestone fqa.
     */
    @Column(name = "fqa", length = Constants.INT_LENGTH_2)
    private String fqa;

    /**
     * ProjectMilestone fat.
     */
    @Column(name = "fat", length = Constants.INT_LENGTH_2)
    private String fat;

    /**
     * ProjectMilestone color goRfq.
     */
    @Column(name = "go_rfqcolor", length = Constants.INT_LENGTH_10)
    private String goRfqColor;

    /**
     * ProjectMilestone color ba.
     */
    @Column(name = "ba_color", length = Constants.INT_LENGTH_10)
    private String baColor;

    /**
     * ProjectMilestone color goOrder.
     */
    @Column(name = "go_order_color", length = Constants.INT_LENGTH_10)
    private String goOrderColor;

    /**
     * ProjectMilestone color pgr.
     */
    @Column(name = "pgr_color", length = Constants.INT_LENGTH_10)
    private String pgrColor;

    /**
     * ProjectMilestone color cgr.
     */
    @Column(name = "cgr_color", length = Constants.INT_LENGTH_10)
    private String cgrColor;

    /**
     * ProjectMilestone color goProd.
     */
    @Column(name = "go_prod_color", length = Constants.INT_LENGTH_10)
    private String goProdColor;

    /**
     * ProjectMilestone color fai.
     */
    @Column(name = "fai_color", length = Constants.INT_LENGTH_10)
    private String faiColor;

    /**
     * ProjectMilestone color iqa.
     */
    @Column(name = "iqa_color", length = Constants.INT_LENGTH_10)
    private String iqaColor;

    /**
     * ProjectMilestone color fqa.
     */
    @Column(name = "fqa_color", length = Constants.INT_LENGTH_10)
    private String fqaColor;

    /**
     * ProjectMilestone color fat.
     */
    @Column(name = "fat_color", length = Constants.INT_LENGTH_10)
    private String fatColor;

    /**
     * ProjectMilestone delivery color.
     */
    @Column(name = "delivery_color", length = Constants.INT_LENGTH_10)
    private String deliveryColor;

    /**
     * ProjectMilestone first need date.
     */
    @Column(name = "first_need", columnDefinition = Constants.COLUMN_DEF_DATE)
    private Date firstNeed;

    /**
     * ProjectMilestone supplier market code.
     */
    @Column(name = "supplier_market_code", length = Constants.INT_LENGTH_20)
    private String supplierMarketCode;

    /**
     * ProjectMilestone supplier market name.
     */
    @Column(name = "supplier_market_name", length = Constants.INT_LENGTH_300)
    private String supplierMarketName;

    /**
     * ProjectMilestone domain code.
     */
    @Column(name = "domain_code", length = Constants.INT_LENGTH_10)
    private String domainCode;

    /**
     * ProjectMilestone domain name.
     */
    @Column(name = "domain_name", length = Constants.INT_LENGTH_100)
    private String domainName;

    /**
     * ProjectMilestone globallocal.
     */
    @Column(name = "global_local", length = Constants.INT_LENGTH_30)
    private String globalLocal;

    /**
     * ProjectMilestone train.
     */
    @Column(name = "train", length = Constants.INT_LENGTH_100)
    private String train;

    /**
     * ProjectMilestone rail control.
     */
    @Column(name = "rail_control", length = Constants.INT_LENGTH_100)
    private String railControl;

    /**
     * ProjectMilestone systemInfra.
     */
    @Column(name = "system_infra", length = Constants.INT_LENGTH_100)
    private String systemInfra;

    /**
     * ProjectMilestone goRfq.
     */
    @Column(name = "mc_gorfq")
    private Integer mcGoRfq;

    /**
     * ProjectMilestone ba.
     */
    @Column(name = "mc_ba")
    private Integer mcBa;

    /**
     * ProjectMilestone goOrder.
     */
    @Column(name = "mc_goorder")
    private Integer mcGoOrder;

    /**
     * ProjectMilestone pgr.
     */
    @Column(name = "mc_pgr")
    private Integer mcPgr;

    /**
     * ProjectMilestone cgr.
     */
    @Column(name = "mc_cgr")
    private Integer mcCgr;

    /**
     * ProjectMilestone goProd.
     */
    @Column(name = "mc_goprod")
    private Integer mcGoProd;

    /**
     * ProjectMilestone fai.
     */
    @Column(name = "mc_fai")
    private Integer mcFai;

    /**
     * ProjectMilestone iqa.
     */
    @Column(name = "mc_iqa")
    private Integer mcIqa;

    /**
     * ProjectMilestone fqa.
     */
    @Column(name = "mc_fqa")
    private Integer mcFqa;

    /**
     * ProjectMilestone fat.
     */
    @Column(name = "mc_fat")
    private Integer mcFat;

    /**
     * ProjectMilestone project name.
     */
    @Column(name = "project_name", length = Constants.INT_LENGTH_200)
    private String projectName;

    /**
     * ProjectMilestone project market.
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "project_market_rev_id ", referencedColumnName = Constants.COLUMN_REF_ID)
    private ProjectMarket projectMarket;

    /**
     * ProjectMilestone market code seq.
     */
    @Column(name = "puproject_market_list_of_market_code_per_market_seq")
    private Integer listMarketCodeByProjectSeq;

    /**
     * ProjectMilestone cdb code.
     */
    @Column(name = "cdb_code", length = Constants.INT_LENGTH_20)
    private String cdbCode;

    /**
     * ProjectMilestone project id.
     */
    @Column(name = "project_id")
    private Integer projectId;

    /**
     * ProjectMilestone commodity status.
     */
    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY, mappedBy = Constants.TABLE_PROJECT_MILESTONE, cascade = CascadeType.ALL)
    private CommodityStatus commodityStatus;
}
