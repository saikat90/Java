package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type project setup model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectSetUpModel {

    /**
     * ProjectSetUpModel id.
     */
    private UUID id;

    /**
     * ProjectSetUpModel version.
     */
    private Integer version;

    /**
     * ProjectSetUpModel project id.
     */
    @NotNull(message = Constants.PROJECT_ID_NOTEMPTY)
    private Integer projectId;

    /**
     * ProjectSetUpModel project.
     */
    @NotNull(message = Constants.PROJECT_NOTEMPTY)
    private ProjectModel project;

    /**
     * ProjectSetUpModel project name temp.
     */
    private String prjectNameTemp;

    /**
     * ProjectSetUpModel site.
     */
    @NotNull(message = Constants.SITE_NOTEMPTY)
    private AtSiteModel atSite;

    /**
     * ProjectSetUpModel product line.
     */
    @NotNull(message = Constants.PRODUCTLINE_NOTEMPTY)
    private String productLine;

    /**
     * ProjectSetUpModel description.
     */
    private String description;

    /**
     * ProjectSetUpModel prsm.
     */
    @NotNull(message = Constants.PRSM_NOTEMPTY)
    private UserModel prsm;

    /**
     * ProjectSetUpModel pm name.
     */
    private String prpmName;

    /**
     * ProjectSetUpModel scl name.
     */
    private String prsclName;

    /**
     * ProjectSetUpModel prem name.
     */
    private String premName;

    /**
     * ProjectSetUpModel tsm name.
     */
    private String tsmName;

    /**
     * ProjectSetUpModel pm name.
     */
    private String pmName;

    /**
     * ProjectSetUpModel wpc name.
     */
    private String wpcName;

    /**
     * ProjectSetUpModel qsm name.
     */
    private String prqsmName;

    /**
     * ProjectSetUpModel scm name.
     */
    private String prscmName;

    /**
     * ProjectSetUpModel prsm depty.
     */
    private UserModel prsmDeputy;

    /**
     * ProjectSetUpModel pridm name.
     */
    private String pridmName;

    /**
     * ProjectSetUpModel prom name.
     */
    private String promName;

    /**
     * ProjectSetUpModel prism name.
     */
    private String prismName;

    /**
     * ProjectSetUpModel created date.
     */
    private Date createdDate;

    /**
     * ProjectSetUpModel modified date.
     */
    private Date modifiedDate;

    /**
     * ProjectSetUpModel created by.
     */
    private String createdBy;

    /**
     * ProjectSetUpModel modified by.
     */
    private String modifiedBy;

    /**
     * ProjectSetUpModel project market list.
     */
    private List<ProjectMarketModel> projectMarketList;

    /**
     * ProjectSetUpModel attachment list.
     */
    private List<ProjectSetUpAttachmentModel> projectSetUpAttachmentList;

}
