package com.alstom.applicationfactory.pmfuservice.projectsetup.service;

import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityStatusModel;

public interface CommodityStatusService {

    /**
     * @param commodityStatusModel
     * @return CommodityStatusModel
     */
    CommodityStatusModel createCommodityStatus(CommodityStatusModel commodityStatusModel);

}
