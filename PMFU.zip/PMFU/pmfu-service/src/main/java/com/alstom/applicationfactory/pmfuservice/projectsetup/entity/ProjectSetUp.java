package com.alstom.applicationfactory.pmfuservice.projectsetup.entity;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.Project;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type ProjectSetUp.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "puset_up")
public class ProjectSetUp {
    /**
     * ProjectSetUp id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * ProjectSetUp version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * ProjectSetUp project id.
     */
    @Column(nullable = false, name = "project_id")
    private Integer projectId;

    /**
     * ProjectSetUp project.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(nullable = false, name = "project_uniq_id ", referencedColumnName = "uniqId")
    private Project project;

    /**
     * ProjectSetUp project name temp.
     */
    @Column(name = "project_name_temp", length = Constants.INT_LENGTH_200)
    private String prjectNameTemp;

    /**
     * ProjectSetUp site.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(nullable = false, name = "site_id ", referencedColumnName = Constants.COLUMN_REF_ID)
    private AtSite atSite;

    /**
     * ProjectSetUp product line.
     */
    @Column(name = "product_line", length = Constants.INT_LENGTH_16, nullable = false)
    private String productLine;

    /**
     * ProjectSetUp description.
     */
    @Column(name = "description", length = Constants.INT_LENGTH_500)
    private String description;

    /**
     * ProjectSetUp prsm.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(nullable = false, name = "pr_sm_id ", referencedColumnName = Constants.COLUMN_REF_ID)
    private User prsm;

    /**
     * ProjectSetUp pm name.
     */
    @Column(name = "pr_pm_name", length = Constants.INT_LENGTH_110)
    private String prpmName;

    /**
     * ProjectSetUp scl name.
     */
    @Column(name = "pr_scl_name", length = Constants.INT_LENGTH_110)
    private String prsclName;

    /**
     * ProjectSetUp em name.
     */
    @Column(name = "pr_em_name", length = Constants.INT_LENGTH_110)
    private String premName;

    /**
     * ProjectSetUp tsm name.
     */
    @Column(name = "tsm_name", length = Constants.INT_LENGTH_110)
    private String tsmName;

    /**
     * ProjectSetUp pm name.
     */
    @Column(name = "pm_name", length = Constants.INT_LENGTH_110)
    private String pmName;

    /**
     * ProjectSetUp wpc name.
     */
    @Column(name = "wpc_name", length = Constants.INT_LENGTH_110)
    private String wpcName;

    /**
     * ProjectSetUp qsm name.
     */
    @Column(name = "pr_qsm_name", length = Constants.INT_LENGTH_110)
    private String prqsmName;

    /**
     * ProjectSetUp scm name.
     */
    @Column(name = "cm_scm_name", length = Constants.INT_LENGTH_110)
    private String prscmName;

    /**
     * ProjectSetUp prsm deputy.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pr_smdeputy_id ", referencedColumnName = Constants.COLUMN_REF_ID)
    private User prsmDeputy;

    /**
     * ProjectSetUp idm name.
     */
    @Column(name = "pr_idm_name", length = Constants.INT_LENGTH_110)
    private String pridmName;

    /**
     * ProjectSetUp om name.
     */
    @Column(name = "pr_om_name", length = Constants.INT_LENGTH_110)
    private String promName;

    /**
     * ProjectSetUp ism name.
     */
    @Column(name = "pr_ism_name", length = Constants.INT_LENGTH_110)
    private String prismName;

    /**
     * ProjectSetUp created date.
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     * ProjectSetUp modified date.
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     * ProjectSetUp created by.
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     * ProjectSetUp modified by.
     */
    @Column(name = "updated_by")
    private String modifiedBy;

    /**
     * ProjectSetUp project market list.
     */
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = Constants.TABLE_PROJECT_SETUP, cascade = CascadeType.ALL)
    private List<ProjectMarket> projectMarketList;

    /**
     * ProjectSetUp attachment list.
     */
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = Constants.TABLE_PROJECT_SETUP, cascade = CascadeType.ALL)
    private List<ProjectSetUpAttachment> projectSetUpAttachmentList;
}
