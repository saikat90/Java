package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ApplicationModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProfileModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.AdminService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "adminService")
@Slf4j
public class AdminServiceImpl implements AdminService {

    /**
     * AdminServiceClient.
     */
    @Autowired
    private AdminServiceClient adminServiceClient;

    /**
     * @param id
     * @return ApplicationModel
     */
    @Override
    public ApplicationModel findById(final String id) {
        log.debug("Entry:AdminServiceImpl:findById");
        ApplicationModel applicationModel = this.adminServiceClient.findById(id);
        log.debug("Leave:AdminServiceImpl:findById");
        return applicationModel;
    }

    /**
     * @param code
     * @param authentication
     * @return ProfileModel
     */
    @Override
    public ProfileModel getProfile(final String code, final Authentication authentication) {
        log.debug("Entry:AdminServiceImpl:getProfile");
        ProfileModel profileModel = this.adminServiceClient.getProfile(code);
        log.debug("Leave:AdminServiceImpl:getProfile");
        return profileModel;
    }

    /**
     * @param id
     * @param request
     * @return email address.
     */
    @Override
    public Object findEmailByApplicationId(final String id, final Map<String, Object> request) {
        log.debug("Entry:AdminServiceImpl:findEmailByApplicationId");
        Object emails = this.adminServiceClient.findEmailByApplicationId(id, request);
        log.debug("Leave:AdminServiceImpl:findEmailByApplicationId");
        return emails;
    }

    /**
     * @param id
     * @param request
     * @return list of roles for an application.
     */
    @Override
    public Object findRolesByApplicationId(final String id, final Map<String, Object> request) {
        log.debug("Entry:AdminServiceImpl:findRolesByApplicationId");
        Object roles = this.adminServiceClient.findRolesByApplicationId(id, request);
        log.debug("Leave:AdminServiceImpl:findRolesByApplicationId");
        return roles;
    }

    /**
     * @param email
     * @return updated user email object.
     */
    @Override
    public Object updateEmail(final Object email) {
        log.debug("Entry:AdminServiceImpl:updateEmail");
        Object roles = this.adminServiceClient.updateEmail(email);
        log.debug("Leave:AdminServiceImpl:updateEmail");
        return roles;
    }

    /**
     * @param request
     * @return list of all users.
     */
    @Override
    public Object findAllUsers(final Map<String, Object> request) {
        log.debug("Entry:AdminServiceImpl:findAllUsers");
        Object users = this.adminServiceClient.findAllUsers(request);
        log.debug("Leave:AdminServiceImpl:findAllUsers");
        return users;
    }

    /**
     * @param users
     * @return
     */
    @Override
    public List<UserModel> saveAllUsers(final List<UserModel> users) {
        log.debug("Entry:AdminServiceImpl:saveAllUsers");
        List<UserModel> userModelList = new ArrayList<>();
        userModelList = this.adminServiceClient.saveAllUsers(users);
        log.debug("Leave:AdminServiceImpl:saveAllUsers");
        return userModelList;
    }

    /**
     * @param applicationId
     * @param roleCode
     * @param request
     * @return list of user object for a role.
     */
    @Override
    public Object findRoleUsers(final String applicationId, final String roleCode,
            final Map<String, Object> request) {
        log.debug("Entry:AdminServiceImpl:findRoleUsers");
        Object roleUsers = this.adminServiceClient.findRoleUsers(applicationId, roleCode, request);
        log.debug("Leave:AdminServiceImpl:findRoleUsers");
        return roleUsers;
    }

    /**
     * @param id
     * @param request
     * @return list of user object that is not mapped to a role.
     */
    @Override
    public Object findUnmappedApplicationRoleUsers(final String id,
            final Map<String, Object> request) {
        log.debug("Entry:AdminServiceImpl:findUnmappedApplicationRoleUsers");
        Object roleUsers = this.adminServiceClient.findUnmappedApplicationRoleUsers(id, request);
        log.debug("Leave:AdminServiceImpl:findUnmappedApplicationRoleUsers");
        return roleUsers;
    }

    /**
     * @param appRoleId
     * @param request
     * @return list of user object by application role.
     */
    @Override
    public Object findUsersByApplicationRole(final String appRoleId,
            final Map<String, Object> request) {
        log.debug("Entry:AdminServiceImpl:findUsersByApplicationRole");
        Object roleUsers = this.adminServiceClient.findUsersByApplicationRole(appRoleId, request);
        log.debug("Leave:AdminServiceImpl:findUsersByApplicationRole");
        return roleUsers;
    }

    /**
     * @param applicationRoleUsers
     * @return saved user object for a role.
     */
    @Override
    public Object saveUsersForRole(final Object applicationRoleUsers) {
        log.debug("Entry:AdminServiceImpl:saveUsersForRole");
        Object roleUsers = this.adminServiceClient.saveUsersForRole(applicationRoleUsers);
        log.debug("Leave:AdminServiceImpl:saveUsersForRole");
        return roleUsers;
    }

    /**
     * @param applicationRoleUsers
     * @return updated user object for a role.
     */
    @Override
    public Object updateUsersForRole(final Object applicationRoleUsers) {
        log.debug("Entry:AdminServiceImpl:updateUsersForRole");
        Object roleUsers = this.adminServiceClient.updateUsersForRole(applicationRoleUsers);
        log.debug("Leave:AdminServiceImpl:updateUsersForRole");
        return roleUsers;
    }

    /**
     * @param appId
     * @param applicationRoleUserId
     * @param request
     * @return Object
     */
    @Override
    public Object getUnmappedRightsForApplicationRoleUser(final String appId,
            final String applicationRoleUserId, final Map<String, Object> request) {
        log.debug("Entry:AdminServiceImpl:getUnmappedRightsForApplicationRoleUser");
        Object rights = this.adminServiceClient.getUnmappedRightsForApplicationRoleUser(appId,
                applicationRoleUserId, request);
        log.debug("Leave:AdminServiceImpl:getUnmappedRightsForApplicationRoleUser");
        return rights;
    }

    /**
     * @param appRoleUserId
     * @param request
     * @return user rights object for applcation role.
     */
    @Override
    public Object listApplicationRoleUserRights(final String appRoleUserId,
            final Map<String, Object> request) {
        log.debug("Entry:AdminServiceImpl:listApplicationRoleUserRights");
        Object rights = this.adminServiceClient.listApplicationRoleUserRights(appRoleUserId,
                request);
        log.debug("Leave:AdminServiceImpl:listApplicationRoleUserRights");
        return rights;
    }

    /**
     * @param applicationRoleUserRightsModels
     * @return saved application role object.
     */
    @Override
    public Object saveApplicationRoleRights(final Object applicationRoleUserRightsModels) {
        log.debug("Entry:AdminServiceImpl:saveApplicationRoleRights");
        Object rights = this.adminServiceClient
                .saveApplicationRoleRights(applicationRoleUserRightsModels);
        log.debug("Leave:AdminServiceImpl:saveApplicationRoleRights");
        return rights;
    }

    /**
     * @param applicationRoleUserRightsModels
     * @return updated application role object.
     */
    @Override
    public Object updateApplicationRoleRights(final Object applicationRoleUserRightsModels) {
        log.debug("Entry:AdminServiceImpl:updateApplicationRoleRights");
        Object rights = this.adminServiceClient
                .updateApplicationRoleRights(applicationRoleUserRightsModels);
        log.debug("Leave:AdminServiceImpl:updateApplicationRoleRights");
        return rights;
    }
}
