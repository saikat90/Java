package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.common.model.ResponseModel;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.MarketCodeMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.MarketCodeMasterDataRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.MarketCodeMasterDataService;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMarketRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMilestoneRepository;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;
import com.alstom.applicationfactory.pmfuservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "marketCodeMasterDataService")
@Transactional
@Slf4j
public class MarketCodeMasterDataServiceImpl implements MarketCodeMasterDataService {

    /**
     * MarketCodeMasterDataRepository.
     */
    @Autowired
    private MarketCodeMasterDataRepository mdMarketCodeRepository;
    /**
     * ProjectMarketRepository.
     */
    @Autowired
    private ProjectMarketRepository projMarketRepo;
    /**
     * ProjectMilestoneRepository.
     */
    @Autowired
    private ProjectMilestoneRepository projectMileStoneRepo;

    /**
     * @param request
     * @return MarketCode object.
     */
    @Override
    public Object searchMDMarketCode(final RequestModel request) {
        log.debug("Entry:PmfuMarketCodeMasterDataServiceImpl:SearchMDMarketCode");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.mdMarketCodeRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(mcMasterData -> mapper.map(mcMasterData, MarketCodeMasterDataModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.mdMarketCodeRepository.findAll(request.getFilterSpecification()).stream()
                    .map(mcMasterData -> mapper.map(mcMasterData, MarketCodeMasterDataModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:PmfuMarketCodeMasterDataServiceImpl:SearchMDMarketCode");
        return result;
    }

    @Override
    public MarketCodeMasterDataModel viewMDMarketCode(final UUID marketCodeId) {
        log.debug("Entry:PmfuMarketCodeMasterDataServiceImpl:ViewMDMarketCode");
        MarketCodeMasterData marketCode;
        MarketCodeMasterDataModel mcBean = new MarketCodeMasterDataModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            marketCode = mdMarketCodeRepository.findById(marketCodeId).orElse(null);
            if (null != marketCode) {
                mcBean = mapper.map(marketCode, MarketCodeMasterDataModel.class);
                log.debug("Leave:PmfuMarketCodeMasterDataServiceImpl:ViewMDMarketCode");
            }
            return mcBean;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Marekt Code", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    @Override
    public void deleteMDMarketCodeById(final UUID marketCodeId) {
        log.debug("Entry:PmfuMarketCodeMasterDataServiceImpl:DeleteMDMarketCode");
        try {
            mdMarketCodeRepository.deleteById(marketCodeId);
            log.debug("Leave:PmfuMarketCodeMasterDataServiceImpl:DeleteMDMarketCode");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Error", e.getMessage());
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    @Override
    public MarketCodeMasterDataModel createMDMarketCode(
            @Valid final MarketCodeMasterDataModel marketCodeBean) {
        log.debug("Entry:PmfuMarketCodeMasterDataServiceImpl:createMDMarketCode");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        MarketCodeMasterDataModel mcBean = new MarketCodeMasterDataModel();
        MarketCodeMasterData marketCode = mapper.map(marketCodeBean, MarketCodeMasterData.class);

        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();

        filterConditions.add(RequestModifier.getFilterCondition(Constants.STR_STRING, "marketCode",
                marketCodeBean.getMarketCode(), Constants.STR_EQ));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        long count = this.mdMarketCodeRepository.count(requestModel.getFilterSpecification());

        if (count == 0) {
            marketCode = mdMarketCodeRepository.save(marketCode);
            mcBean = mapper.map(marketCode, MarketCodeMasterDataModel.class);
        } else {
            log.error("Record already exists for the MarketCode. Please update existing value");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Market Code",
                    "Record already exists for the Marekt Code. Please update existing value"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:PmfuMarketCodeMasterDataServiceImpl:createMDMarketCode");
        return mcBean;
    }

    @Override
    public MarketCodeMasterDataModel updateMDMarketCode(
            @Valid final MarketCodeMasterDataModel marketCodeModel) {
        log.debug("Entry:PmfuMarketCodeMasterDataServiceImpl:UpdateMDMarketCode");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        MarketCodeMasterDataModel mcBean = new MarketCodeMasterDataModel();
        try {
            MarketCodeMasterData marketCode = mapper.map(marketCodeModel,
                    MarketCodeMasterData.class);
            MarketCodeMasterData marketCodeRecord = mdMarketCodeRepository
                    .findById(marketCodeModel.getId()).orElse(null);
            if (null != marketCodeRecord) {
                MarketCodeMasterData marketCodeResult = mdMarketCodeRepository.save(marketCode);
                mcBean = mapper.map(marketCodeResult, MarketCodeMasterDataModel.class);
                log.debug("Leave:PmfuMarketCodeMasterDataServiceImpl:UpdateMDMarketCode");
            } else {
                log.error("Record does not exists for the MarketCode.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(
                        new ErrorModel("Market Code", "Record does not exists for Market Code."));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return mcBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Market Code", "Unable to update Market Code");
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    @Override
    public boolean isMarketCodeExists(final String marketCode) {
        log.debug("Entry:PmfuMarketCodeMasterDataServiceImpl:isMarketCodeExists");
        MarketCodeMasterData marketCodeRecord = null;
        try {
            marketCodeRecord = mdMarketCodeRepository.findByMarketCode(marketCode);
            if (Objects.nonNull(marketCodeRecord)) {
                return true;
            }
            log.debug("Leave:PmfuMarketCodeMasterDataServiceImpl:isMarketCodeExists");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Market Code",
                    "Unable to search for Market Code Existance");
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
        return false;
    }

    @Override
    public MarketCodeMasterDataModel replaceMDMarketCode(final String oldMC, final String newMC) {
        MarketCodeMasterData marketCode;
        log.debug("Entry:PmfuMarketCodeMasterDataServiceImpl:replaceMDMarketCode");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            marketCode = mdMarketCodeRepository.findByMarketCode(newMC);
            String domainCode = marketCode.getDomainCode();
            log.debug("Updating Project Market");
            projMarketRepo.updateMarketCode(newMC, domainCode, oldMC);
            log.debug("Updating Market Code MileStone");
            projectMileStoneRepo.updateMarketCodeAndDomainCode(newMC, domainCode, oldMC);
            log.debug("Leave:PmfuMarketCodeMasterDataServiceImpl:replaceMDMarketCode");
            MarketCodeMasterDataModel marketCodeModel = mapper.map(marketCode,
                    MarketCodeMasterDataModel.class);
            return marketCodeModel;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Market Code", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }
}
