package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type ATSite search model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AtSiteSearchModel {
    /**
     * SiteSearchModel id.
     */
    private UUID id;

    /**
     * SiteSearchModel region.
     */
    private String region;
    /**
     * SiteSearchModel site.
     */
    private String site;
}
