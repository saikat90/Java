package com.alstom.applicationfactory.pmfuservice.util;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.lang.NonNull;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.FilterConditionModel;
import com.alstom.applicationfactory.pmfuservice.common.model.FilterJoinsModel;
import com.alstom.applicationfactory.pmfuservice.common.model.FilterModel;
import com.alstom.applicationfactory.pmfuservice.common.model.JoinModel;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FilterSpecification<T> implements Specification<T> {
    private static final long serialVersionUID = 1L;
    /**
     * Filter and joins.
     */
    private final transient FilterJoinsModel filterJoins;

    /**
     * Map to keep track of joins.
     */
    private transient Map<String, Join<Object, Object>> joinMap;

    /**
     * Constructor.
     *
     * @param filterJoinsParam Filters and joins
     */
    public FilterSpecification(final FilterJoinsModel filterJoinsParam) {
        super();
        this.filterJoins = filterJoinsParam;
    }

    /**
     * Converts to predicate.
     *
     * @param root          Root of criteria query
     * @param criteriaQuery Criteria query
     * @param builder       Query builder
     * @return predicate
     */
    @Override
    public Predicate toPredicate(@NonNull final Root<T> root,
            @NonNull final CriteriaQuery<?> criteriaQuery, @NonNull final CriteriaBuilder builder) {
        List<JoinModel> joins = this.filterJoins.getJoins();
        joinMap = new HashMap<>();
        if (Objects.nonNull(joins)) {
            for (JoinModel join : joins) {
                Join<Object, Object> tableJoin = root.join(join.getObject(),
                        JoinType.valueOf(join.getType()));
                if (Objects.nonNull(join.getFilter())) {
                    Predicate joinPredicate = this.getPredicates(join.getFilter(), tableJoin,
                            builder);
                    tableJoin.on(joinPredicate);
                }
                joinMap.put(join.getObject(), tableJoin);
            }
        }
        return Objects.nonNull(this.filterJoins.getFilter())
                ? this.getPredicates(this.filterJoins.getFilter(), root, builder)
                : null;
    }

    /**
     * Get Predicate.
     * 
     * @param filterModel
     * @param root
     * @param builder
     * @return the Predicate.
     */
    private Predicate getPredicates(final FilterModel filterModel, final Path<?> root,
            final CriteriaBuilder builder) {
        List<Predicate> predicates = filterModel.getFilterConditions().stream().map(filter -> {
            if (Objects.nonNull(filter.getFilter())) {
                return getPredicates(filter.getFilter(), root, builder);
            } else {
                return resolvePredicate(root, filter, builder);
            }
        }).collect(Collectors.toList());
        return getCombinedPredicates(predicates, filterModel, builder);
    }

    /**
     * Get Predicate.
     * 
     * @param root
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate resolvePredicate(final Path<?> root, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Class<?> propJavaType = null;
        Path<?> path = null;
        String[] props = filter.getField().split(Constants.STR_DOT_REGEX);
        Class<?> rootJavaType = null;
        Path<?> rootPath = null;
        try {
            for (String prop : props) {
                if (Objects.isNull(rootJavaType)) {
                    if (root.get(prop).getJavaType().getSimpleName()
                            .equalsIgnoreCase(Constants.STR_SET)
                            || root.get(prop).getJavaType().getSimpleName()
                                    .equalsIgnoreCase(Constants.STR_LIST)) {
                        rootPath = setRootPath(root, prop);
                        rootJavaType = rootPath.getJavaType();
                        continue;
                    } else {
                        rootPath = root;
                        rootJavaType = rootPath.getJavaType();
                    }
                }
                propJavaType = Objects.isNull(propJavaType)
                        ? rootJavaType.getDeclaredField(prop).getType()
                        : propJavaType.getDeclaredField(prop).getType();
                path = Objects.isNull(path) ? rootPath.get(prop) : path.get(prop);
            }
        } catch (NoSuchFieldException ex) {
            log.error(ex.getLocalizedMessage(), ex);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(ex.getLocalizedMessage(), ex.getLocalizedMessage()));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        return getPredicate(path, filter, builder, propJavaType);
    }

    /**
     * Get Root Path.
     * 
     * @param root
     * @param prop
     * @return Path
     */
    private Path<?> setRootPath(final Path<?> root, final String prop) {
        Path<?> rootPath = joinMap.get(prop);
        if (Objects.isNull(rootPath)) {
            Join<Object, Object> tableJoin = ((Root) root).join(prop, JoinType.INNER);
            joinMap.put(prop, tableJoin);
            return tableJoin;
        } else {
            return rootPath;
        }
    }

    /**
     * Get Predicate.
     * 
     * @param predicates
     * @param filterModel
     * @param builder
     * @return Predicate
     */
    private Predicate getCombinedPredicates(final List<Predicate> predicates,
            final FilterModel filterModel, final CriteriaBuilder builder) {
        if (Objects.nonNull(filterModel.getCondition())
                && filterModel.getCondition().equalsIgnoreCase(Constants.STR_OR)) {
            return builder.or(predicates.toArray(Predicate[]::new));
        } else {
            return builder.and(predicates.toArray(Predicate[]::new));
        }
    }

    /**
     * Get Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @param propJavaType
     * @return Predicate
     */
    private Predicate getPredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder, final Class<?> propJavaType) {
        Predicate predicate;
        switch (filter.getType()) {
        case Constants.STR_STRING:
            predicate = getStringPredicate(path, filter, builder);
            break;
        case Constants.STR_INTEGER:
            predicate = getIntegerPredicate(path, filter, builder);
            break;
        case Constants.STR_LONG:
            predicate = getLongPredicate(path, filter, builder);
            break;
        case Constants.STR_FLOAT:
            predicate = getFloatPredicate(path, filter, builder);
            break;
        case Constants.STR_DOUBLE:
            predicate = getDoublePredicate(path, filter, builder);
            break;
        case Constants.STR_UUID:
            predicate = getUUIDPredicate(path, filter, builder);
            break;
        case Constants.STR_DATE:
            predicate = getDatePredicate(path, filter, builder);
            break;
        case Constants.STR_BOOLEAN:
            predicate = getBooleanPredicate(path, filter, builder);
            break;
        case Constants.STR_ENUM:
            predicate = getEnumPredicate(path, filter, builder, propJavaType);
            break;
        default:
            predicate = null;
        }
        return predicate;
    }

    /**
     * Get String Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate getStringPredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Predicate predicate;
        Path<String> pathString = (Path<String>) path;
        if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_EQ)) {
            predicate = builder.equal(builder.lower(pathString),
                    filter.getData().toString().toLowerCase(Locale.ENGLISH));
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_EQ)) {
            predicate = builder.notEqual(builder.lower(pathString),
                    filter.getData().toString().toLowerCase(Locale.ENGLISH));
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_IN)) {
            assert path != null;
            predicate = path.in(filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_LIKE)) {
            predicate = builder.like(builder.lower(pathString),
                    Constants.STR_PERCENT_SYMBOL
                            + filter.getData().toString().toLowerCase(Locale.ENGLISH)
                            + Constants.STR_PERCENT_SYMBOL);
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NULL)) {
            predicate = builder.isNull(path);
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_NULL)) {
            predicate = builder.isNotNull(path);
        } else {
            predicate = builder.like(builder.lower(pathString),
                    Constants.STR_PERCENT_SYMBOL
                            + filter.getData().toString().toLowerCase(Locale.ENGLISH)
                            + Constants.STR_PERCENT_SYMBOL);
        }
        return predicate;
    }

    /**
     * Get Integer Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate getIntegerPredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Predicate predicate;
        Path<Integer> pathInteger = (Path<Integer>) path;
        if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_EQ)) {
            predicate = builder.equal(pathInteger, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_EQ)) {
            predicate = builder.notEqual(pathInteger, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_IN)) {
            assert path != null;
            predicate = path.in(filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NULL)) {
            predicate = builder.isNull(path);
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_NULL)) {
            predicate = builder.isNotNull(path);
        } else {
            predicate = builder.equal(pathInteger, filter.getData());
        }
        return predicate;
    }

    /**
     * Get Long Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate getLongPredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Predicate predicate;
        Path<Long> pathLong = (Path<Long>) path;
        if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_EQ)) {
            predicate = builder.equal(pathLong, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_EQ)) {
            predicate = builder.notEqual(pathLong, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_IN)) {
            assert path != null;
            predicate = path.in(filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NULL)) {
            predicate = builder.isNull(path);
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_NULL)) {
            predicate = builder.isNotNull(path);
        } else {
            predicate = builder.equal(pathLong, filter.getData());
        }
        return predicate;
    }

    /**
     * Get Float Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate getFloatPredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Predicate predicate;
        Path<Float> pathFloat = (Path<Float>) path;
        if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_EQ)) {
            predicate = builder.equal(pathFloat, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_EQ)) {
            predicate = builder.notEqual(pathFloat, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_IN)) {
            assert path != null;
            predicate = path.in(filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NULL)) {
            predicate = builder.isNull(path);
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_NULL)) {
            predicate = builder.isNotNull(path);
        } else {
            predicate = builder.equal(pathFloat, filter.getData());
        }
        return predicate;
    }

    /**
     * Get Double Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate getDoublePredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Predicate predicate;
        Path<Double> pathDouble = (Path<Double>) path;
        if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_EQ)) {
            predicate = builder.equal(pathDouble, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_EQ)) {
            predicate = builder.notEqual(pathDouble, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_IN)) {
            assert path != null;
            predicate = path.in(filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NULL)) {
            predicate = builder.isNull(path);
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_NULL)) {
            predicate = builder.isNotNull(path);
        } else {
            predicate = builder.equal(pathDouble, filter.getData());
        }
        return predicate;
    }

    /**
     * Get UUID Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate getUUIDPredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Predicate predicate;
        Path<UUID> pathUUID = (Path<UUID>) path;
        if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_EQ)) {
            predicate = builder.equal(pathUUID, UUID.fromString(filter.getData().toString()));
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_EQ)) {
            predicate = builder.notEqual(pathUUID, UUID.fromString(filter.getData().toString()));
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_IN)) {
            assert path != null;
            predicate = path.in(filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NULL)) {
            predicate = builder.isNull(path);
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_NULL)) {
            predicate = builder.isNotNull(path);
        } else {
            predicate = builder.equal(pathUUID, UUID.fromString(filter.getData().toString()));
        }
        return predicate;
    }

    /**
     * Get Date Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate getDatePredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Predicate predicate;
        Path<Date> pathDate = (Path<Date>) path;
        if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_EQ)) {
            predicate = builder.equal(pathDate, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_EQ)) {
            predicate = builder.notEqual(pathDate, filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_LESS_THAN)) {
            predicate = builder.lessThanOrEqualTo(pathDate, (Date) filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_IN)) {
            assert path != null;
            predicate = path.in(filter.getData());
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NULL)) {
            predicate = builder.isNull(path);
        } else if (Objects.nonNull(filter.getOperator())
                && filter.getOperator().equalsIgnoreCase(Constants.STR_NOT_NULL)) {
            predicate = builder.isNotNull(path);
        } else {
            predicate = builder.equal(pathDate, filter.getData());
        }
        return predicate;
    }

    /**
     * Get Boolean Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @return Predicate
     */
    private Predicate getBooleanPredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder) {
        Path<Boolean> pathBoolean = (Path<Boolean>) path;
        return builder.equal(pathBoolean, filter.getData());
    }

    /**
     * Get ENUM Predicate.
     * 
     * @param path
     * @param filter
     * @param builder
     * @param propJavaType
     * @return Predicate
     */
    private Predicate getEnumPredicate(final Path<?> path, final FilterConditionModel filter,
            final CriteriaBuilder builder, final Class<?> propJavaType) {
        Predicate predicate = null;
        if (Objects.nonNull(filter.getOperator())) {
            switch (filter.getOperator()) {
            case Constants.STR_EQ:
                assert propJavaType != null;
                predicate = builder.equal(path,
                        getEnumValue(propJavaType, filter.getData().toString()));
                break;
            case Constants.STR_NOT_EQ:
                assert propJavaType != null;
                predicate = builder.notEqual(path,
                        getEnumValue(propJavaType, filter.getData().toString()));
                break;
            case Constants.STR_IN:
                List<Object> enumInValue = new ArrayList<>();
                ((List) filter.getData()).stream().forEach(
                        data -> enumInValue.add(getEnumValue(propJavaType, data.toString())));
                assert path != null;
                predicate = path.in(enumInValue);
                break;
            case Constants.STR_NULL:
                predicate = builder.isNull(path);
                break;
            case Constants.STR_NOT_NULL:
                predicate = builder.isNotNull(path);
                break;
            default:
                break;
            }
        } else {
            assert propJavaType != null;
            predicate = builder.equal(path,
                    getEnumValue(propJavaType, filter.getData().toString()));
        }
        return predicate;
    }

    /**
     * Read Object.
     * 
     * @param in
     * @throws IOException
     * @throws ClassNotFoundException
     */
    private void readObject(final ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
    }

    /**
     * Get ENUM value.
     * 
     * @param propJavaType
     * @param data
     * @return Object
     */
    private Object getEnumValue(final Class<?> propJavaType, final String data) {
        Object enumValue = null;
        for (Object value : propJavaType.getEnumConstants()) {
            if (value.toString().equalsIgnoreCase(data)) {
                enumValue = value;
                break;
            }
        }
        return enumValue;
    }
}
