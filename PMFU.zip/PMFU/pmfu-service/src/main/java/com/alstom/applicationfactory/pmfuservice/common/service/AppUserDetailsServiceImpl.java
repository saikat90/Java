package com.alstom.applicationfactory.pmfuservice.common.service;

import com.alstom.applicationfactory.pmfuservice.common.model.AppUserDetails;
import com.alstom.applicationfactory.pmfuservice.common.model.BasicSecurityUser;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import java.util.Objects;
import javax.servlet.http.HttpServletRequest;

@NoArgsConstructor
public class AppUserDetailsServiceImpl implements UserDetailsService {

    /**
     * Admin service feign client.
     */
    @Autowired
    private AdminServiceClient adminServiceClient;

    /**
     * Http servlet request.
     */
    @Autowired
    private HttpServletRequest request;

    /**
     * Application code.
     */
    private String applicationCode;

    /**
     * External application code. eg: actuator, qlikSense etc
     */
    private String externalApplicationCode;

    /**
     * Parameterized constructor.
     *
     * @param appCode Application code
     * @param extAppCode External application code. eg: actuator, qlikSense etc
     */
    public AppUserDetailsServiceImpl(final String appCode, final String extAppCode) {
        this.applicationCode = appCode;
        this.externalApplicationCode = extAppCode;
    }

    /**
     * Fetches the user details of the user.
     *
     * @param username username of user
     * @return user details object
     */
    @Override
    public UserDetails loadUserByUsername(final String username) {
        BasicSecurityUser user = this.adminServiceClient.getAuthorizedUser(request.getHeader("Authorization"),
                this.applicationCode, this.externalApplicationCode, username);
        if (Objects.isNull(user)) {
            throw new UsernameNotFoundException("User not found");
        } else {
            return new AppUserDetails(user);
        }
    }
}
