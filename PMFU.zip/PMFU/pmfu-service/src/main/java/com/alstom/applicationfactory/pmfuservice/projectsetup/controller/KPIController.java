package com.alstom.applicationfactory.pmfuservice.projectsetup.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.pmfuservice.projectsetup.model.AllActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractStatusGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQDeliveryGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQEventModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQMilestoneGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.KPIService;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/KPI")
@Slf4j
public class KPIController {

    /**
     * KPIService.
     */
    @Autowired
    private KPIService kpiService;

    /**
     * @param id
     * @param period
     * @return List<DFQEventModel>
     */
    @GetMapping("/DFQEvent/{id}/{period}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM','KEYUSER','VISITOR')")
    public List<DFQEventModel> getDFQEventData(@PathVariable("id") final UUID id,
            @PathVariable("period") final String period) {
        log.debug("Entry:KPIController:getDFQEventData");
        List<DFQEventModel> dfqEventModelList = kpiService.getDFQEventData(id, period);
        log.debug("Leave:KPIController:getDFQEventData");
        return dfqEventModelList;
    }

    /**
     * @param id
     * @return List<ProjectMasterDataModel>
     */
    @GetMapping("/project/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM','VISITOR','KEYUSER')")
    public List<ProjectMasterDataModel> getProjectMasterData(@PathVariable("id") final UUID id) {
        log.debug("Entry:KPIController:getProjectMasterData");
        List<ProjectMasterDataModel> projectMasterDataList = kpiService.getProjectMasterData(id);
        log.debug("Leave:KPIController:getProjectMasterData");
        return projectMasterDataList;
    }

    /**
     * @param id
     * @return List<ContractStatusGraphModel>
     */
    @GetMapping("/contractStatus/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM','VISITOR','KEYUSER')")
    public List<ContractStatusGraphModel> getContractStatus(@PathVariable("id") final UUID id) {
        log.debug("Entry:KPIController:getContractStatus");
        List<ContractStatusGraphModel> contractStatusList = kpiService.getContractStatus(id);
        log.debug("Leave:KPIController:getContractStatus");
        return contractStatusList;
    }

    /**
     * @param id
     * @return List<DFQMilestoneGraphModel>
     */
    @GetMapping("/dfqMileStoneGraph/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM','VISITOR','KEYUSER')")
    public List<DFQMilestoneGraphModel> getDFQMileStoneGraph(@PathVariable("id") final UUID id) {
        log.debug("Entry:KPIController:getDFQMileStoneGraph");
        List<DFQMilestoneGraphModel> dfqMileStoneList = kpiService.getDFQMileStoneGraph(id);
        log.debug("Leave:KPIController:getDFQMileStoneGraph");
        return dfqMileStoneList;
    }

    /**
     * @param id
     * @return List<DFQDeliveryGraphModel>
     */
    @GetMapping("/dfqDeliveryGraph/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM','VISITOR','KEYUSER')")
    public List<DFQDeliveryGraphModel> getDFQDeliveryGraph(@PathVariable("id") final UUID id) {
        log.debug("Entry:KPIController:getDFQDeliveryGraph");
        List<DFQDeliveryGraphModel> dfqDeliveryList = kpiService.getDFQDeliveryGraph(id);
        log.debug("Leave:KPIController:getDFQDeliveryGraph");
        return dfqDeliveryList;
    }

    /**
     * @param id
     * @param key
     * @return List<AllActionsModel>
     */
    @GetMapping("/{id}/allActions/{key}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasAnyRole('ADM','PRSM','KEYUSER','VISITOR')")
    public List<AllActionsModel> getAllActions(@PathVariable("id") final UUID id,
            @PathVariable("key") final String key) {
        log.debug("Entry:KPIController:getAllActions");
        List<AllActionsModel> allActionModelList = kpiService.getAllActions(id, key);
        log.debug("Leave:KPIController:getAllActions");
        return allActionModelList;
    }

}
