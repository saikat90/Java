package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Application Model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationModel {
    /**
     * ApplicationModel id.
     */
    private UUID id;
    /**
     * ApplicationModel name.
     */
    private String name;
    /**
     * ApplicationModel code.
     */
    private String code;
    /**
     * ApplicationModel verified.
     */
    private boolean verified;
    /**
     * ApplicationModel deleted.
     */
    private boolean deleted;
    /**
     * ApplicationModel allow all users.
     */
    private boolean allowAllUsers;

}
