package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type contracts model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ContractsModel {
    /**
     * ContractsModel id.
     */
    private UUID id;

    /**
     * ContractsModel version.
     */
    private Integer version;

    /**
     * ContractsModel material component.
     */
    private String materialComponent;

    /**
     * ContractsModel contract type.
     */
    private String contractType;

    /**
     * ContractsModel part conditions.
     */
    private String partConditions;

    /**
     * ContractsModel status.
     */
    private String status;

    /**
     * ContractsModel po.
     */
    private String po;

    /**
     * ContractsModel perf bond.
     */
    private String perfBond;

    /**
     * ContractsModel warranty bond.
     */
    private String warrantyBond;

    /**
     * ContractsModel ar.
     */
    private String ar;

    /**
     * ContractsModel poNrc.
     */
    private String poNrc;

    /**
     * ContractsModel comments.
     */
    private String comments;

    /**
     * ContractsModel commodity contract.
     */
    @JsonIgnore
    private CommodityContractModel commodityContract;

}
