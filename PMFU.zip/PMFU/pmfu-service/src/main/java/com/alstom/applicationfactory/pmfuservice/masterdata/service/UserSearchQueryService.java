package com.alstom.applicationfactory.pmfuservice.masterdata.service;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserSearchQueryModel;

public interface UserSearchQueryService {

    /**
     * @param email
     * @param screenName
     * @return List of UserSearchQueryModel
     */
    List<UserSearchQueryModel> listSavedQuery(String email, String screenName);

    /**
     * @param id
     */
    void deleteUserQueryById(UUID id);

    /**
     * @param savedSearchId
     * @return UserSearchQueryModel
     */
    UserSearchQueryModel viewSavedQuery(UUID savedSearchId);

    /**
     * @param email
     * @param userSearchQueryModel
     * @return created UserSearchQueryModel
     */
    UserSearchQueryModel createSavedSearchQuery(String email,
            @Valid UserSearchQueryModel userSearchQueryModel);

    /**
     * @param email
     * @param userSearchQueryModel
     * @return updated UserSearchQueryModel
     */
    UserSearchQueryModel updateSavedSearchQuery(String email,
            @Valid UserSearchQueryModel userSearchQueryModel);
}
