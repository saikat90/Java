package com.alstom.applicationfactory.pmfuservice.masterdata.service;

import java.util.UUID;

import javax.validation.Valid;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.MarketCodeMasterDataModel;

public interface MarketCodeMasterDataService {

    /**
     * @param requestModel
     * @return MarketCode
     */
    Object searchMDMarketCode(RequestModel requestModel);

    /**
     * @param id
     * @return MarketCodeMasterDataModel
     */
    MarketCodeMasterDataModel viewMDMarketCode(UUID id);

    /**
     * @param id
     */
    void deleteMDMarketCodeById(UUID id);

    /**
     * @param marketCode
     * @return MarketCodeMasterDataModel
     */
    MarketCodeMasterDataModel createMDMarketCode(@Valid MarketCodeMasterDataModel marketCode);

    /**
     * @param marketCode
     * @return MarketCodeMasterDataModel
     */
    MarketCodeMasterDataModel updateMDMarketCode(@Valid MarketCodeMasterDataModel marketCode);

    /**
     * @param marketCode
     * @return true or false based on condition.
     */
    boolean isMarketCodeExists(String marketCode);

    /**
     * @param oldMC
     * @param newMC
     * @return MarketCodeMasterDataModel
     */
    MarketCodeMasterDataModel replaceMDMarketCode(String oldMC, String newMC);

}
