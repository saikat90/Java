package com.alstom.applicationfactory.pmfuservice.common.model;

import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collection;
import java.util.Collections;

@Data
public class AppUserDetails implements UserDetails {
    private static final long serialVersionUID = 1L;
    /**
     * User for basic security.
     */
    private BasicSecurityUser user;

    /**
     * Default constructor.
     */
    public AppUserDetails() {
    }

    /**
     * Constructor with BasicSecurityUser.
     *
     * @param basicUser user
     */
    public AppUserDetails(final BasicSecurityUser basicUser) {
        this.user = basicUser;
    }

    /**
     * Lists granted authorities.
     *
     * @return list of granted authorities
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.emptyList();
    }

    /**
     * Returns password.
     *
     * @return password
     */
    @Override
    public String getPassword() {
        return this.user.getPassword();
    }

    /**
     * Returns username.
     *
     * @return username
     */
    @Override
    public String getUsername() {
        return this.user.getUsername();
    }

    /**
     * Returns if account non-expired or not.
     *
     * @return isAccountNonExpired
     */
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    /**
     * Returns if account non-locked or not.
     *
     * @return isAccountNonLocked
     */
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    /**
     * Returns if credentials is non-expired or not.
     *
     * @return isCredentialsNonExpired
     */
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    /**
     * Returns if account is enabled or not.
     *
     * @return isEnabled
     */
    @Override
    public boolean isEnabled() {
        return true;
    }
}
