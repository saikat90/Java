/**
 * Package info.
 */
package com.alstom.applicationfactory.pmfuservice.masterdata.model;
