package com.alstom.applicationfactory.pmfuservice.projectsetup.service;

import java.util.List;
import java.util.UUID;

import com.alstom.applicationfactory.pmfuservice.projectsetup.model.AllActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractStatusGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQDeliveryGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQEventModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQMilestoneGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMasterDataModel;

public interface KPIService {

    /**
     * @param id
     * @param period
     * @return DFQEventModel List
     */
    List<DFQEventModel> getDFQEventData(UUID id, String period);

    /**
     * @param id
     * @return ProjectMasterDataModel List
     */
    List<ProjectMasterDataModel> getProjectMasterData(UUID id);

    /**
     * @param id
     * @return ContractStatusGraphModel List
     */
    List<ContractStatusGraphModel> getContractStatus(UUID id);

    /**
     * @param id
     * @return DFQMilestoneGraphModel
     */
    List<DFQMilestoneGraphModel> getDFQMileStoneGraph(UUID id);

    /**
     * @param id
     * @return DFQDeliveryGraphModel.
     */
    List<DFQDeliveryGraphModel> getDFQDeliveryGraph(UUID id);

    /**
     * @param id
     * @param key
     * @return AllActionsModel.
     */
    List<AllActionsModel> getAllActions(UUID id, String key);

}
