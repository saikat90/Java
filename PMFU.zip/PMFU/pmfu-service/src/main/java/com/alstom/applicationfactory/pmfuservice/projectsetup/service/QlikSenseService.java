package com.alstom.applicationfactory.pmfuservice.projectsetup.service;

public interface QlikSenseService {

    /**
     * @return Commodity Status
     */
    Object findAllCommodityStatusData();

    /**
     * @return Commodity Contract
     */
    Object findAllCommodityContractData();

    /**
     * @return Commodity ActionPlan
     */
    Object findAllCommodityActionPlanData();

}
