package com.alstom.applicationfactory.pmfuservice.util;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.data.domain.Sort;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.FilterConditionModel;
import com.alstom.applicationfactory.pmfuservice.common.model.FilterJoinsModel;
import com.alstom.applicationfactory.pmfuservice.common.model.FilterModel;
import com.alstom.applicationfactory.pmfuservice.common.model.JoinModel;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;

public final class RequestMapper {

    private RequestMapper() {
    }

    /**
     * Converts request map to request model.
     *
     * @param request Request map
     * @return Request model
     */
    public static RequestModel map(final Map<String, Object> request) {
        if (Objects.nonNull(request)) {
            int pageNumber = Objects.isNull(request.get(Constants.STR_PAGE_NUMBER)) ? 0
                    : (int) request.get(Constants.STR_PAGE_NUMBER);
            int pageSize = Objects.isNull(request.get(Constants.STR_PAGE_SIZE)) ? 0
                    : (int) request.get(Constants.STR_PAGE_SIZE);
            boolean isPaged = Objects.nonNull(request.get(Constants.STR_IS_PAGED))
                    && (boolean) request.get(Constants.STR_IS_PAGED);
            FilterSpecification<?> filterSpecification = getFilterDetails(request);
            Sort sort = getSortDetails(request);
            return new RequestModel(pageNumber, pageSize, isPaged, filterSpecification, sort);
        } else {
            RequestModel requestModel = new RequestModel();
            requestModel.setPaged(false);
            return requestModel;
        }
    }

    /**
     * getFilterDetails.
     * 
     * @param request
     * @return FilterSpecification
     */
    private static FilterSpecification<?> getFilterDetails(final Map<String, Object> request) {
        FilterSpecification<?> filterSpecification;
        if (Objects.nonNull(request.get(Constants.STR_FILTER_JOINS))) {
            FilterModel filter = null;
            List<JoinModel> joins = null;
            Map<String, Object> filterJoinsMap = (Map<String, Object>) request
                    .get(Constants.STR_FILTER_JOINS);
            if (Objects.nonNull(filterJoinsMap.get(Constants.STR_FILTER))) {
                Map<String, Object> filterMap = (Map<String, Object>) filterJoinsMap
                        .get(Constants.STR_FILTER);
                filter = convertToFilterModel(filterMap);
            }
            if (Objects.nonNull(filterJoinsMap.get(Constants.STR_JOINS))) {
                joins = ((List<Map<String, Object>>) filterJoinsMap.get(Constants.STR_JOINS))
                        .stream().map(item -> {
                            Map<String, Object> filterMap = Objects
                                    .nonNull(item.get(Constants.STR_FILTER))
                                            ? (Map<String, Object>) item.get(Constants.STR_FILTER)
                                            : null;
                            return new JoinModel((String) item.get(Constants.STR_OBJECT),
                                    (String) item.get(Constants.STR_TYPE),
                                    Objects.nonNull(filterMap) ? convertToFilterModel(filterMap)
                                            : null);
                        }).collect(Collectors.toList());
            }
            FilterJoinsModel filterJoinModel = new FilterJoinsModel(filter, joins);
            filterSpecification = new FilterSpecification<>(filterJoinModel);
        } else {
            filterSpecification = null;
        }
        return filterSpecification;
    }

    /**
     * Get SortDetails.
     * 
     * @param request
     * @return Sorted Details.
     */
    private static Sort getSortDetails(final Map<String, Object> request) {
        Sort sort;
        if (Objects.nonNull(request.get(Constants.STR_SORT))) {
            List<Sort.Order> orders = ((List<Map<String, Object>>) ((Map) request
                    .get(Constants.STR_SORT)).get(Constants.STR_ORDERS))
                            .stream()
                            .map(order -> new Sort.Order(
                                    Sort.Direction
                                            .values()[(int) order.get(Constants.STR_DIRECTION)],
                                    order.get(Constants.STR_PROPERTY).toString(),
                                    Sort.NullHandling.values()[(int) order
                                            .get(Constants.STR_NULL_HANDLING)]))
                            .collect(Collectors.toList());
            sort = Sort.by(orders);
        } else {
            sort = Sort.unsorted();
        }
        return sort;
    }

    /**
     * Convert to Filter Model.
     * 
     * @param filterMap
     * @return FilterModel
     */
    private static FilterModel convertToFilterModel(final Map<String, Object> filterMap) {
        FilterModel filter = null;
        if (Objects.nonNull(filterMap.get(Constants.STR_FILTER_CONDITIONS))
                && Objects.nonNull(filterMap.get(Constants.STR_CONDITION))) {
            List<Map<String, Object>> filterConditionsMaps = (List) filterMap
                    .get(Constants.STR_FILTER_CONDITIONS);
            List<FilterConditionModel> filterConditions = filterConditionsMaps.stream()
                    .map(item -> {
                        if (Objects.nonNull(item.get(Constants.STR_FILTER))) {
                            FilterModel filterModel = convertToFilterModel(
                                    (Map) item.get(Constants.STR_FILTER));
                            return new FilterConditionModel(null, null, null, null, filterModel);
                        } else {
                            return new FilterConditionModel(item.get(Constants.STR_TYPE).toString(),
                                    item.get(Constants.STR_FIELD).toString(),
                                    Objects.nonNull(item.get(Constants.STR_OPERATOR))
                                            ? item.get(Constants.STR_OPERATOR).toString()
                                            : null,
                                    item.get(Constants.STR_DATA), null);
                        }
                    }).collect(Collectors.toList());
            String condition = (String) filterMap.get(Constants.STR_CONDITION);
            filter = new FilterModel(condition, filterConditions);
        }
        return filter;
    }
}
