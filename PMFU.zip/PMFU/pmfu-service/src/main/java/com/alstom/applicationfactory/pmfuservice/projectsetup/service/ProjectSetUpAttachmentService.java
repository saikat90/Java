package com.alstom.applicationfactory.pmfuservice.projectsetup.service;

import java.io.File;
import java.util.UUID;

import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpAttachmentModel;

public interface ProjectSetUpAttachmentService {

    /**
     * @param file
     * @param userEmail
     * @return ProjectSetUpAttachmentModel
     */
    ProjectSetUpAttachmentModel uploadAttachment(MultipartFile file, String userEmail);

    /**
     * @param projSetUpAttachmentId
     * @return File
     */
    File downloadAttachment(UUID projSetUpAttachmentId);

    /**
     * @param file
     * @return byte array.
     */
    byte[] readFileToByteArray(File file);

    /**
     * @param id
     */
    void deleteAttachmentById(UUID id);

}
