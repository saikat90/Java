package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.common.model.ResponseModel;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityActionPlan;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityContract;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.Contracts;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUp;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.PuActions;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpListModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityContractRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ContractsRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMarketRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMilestoneRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.PuActionsRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectSetUpService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "projectSetUpService")
@Transactional
@Slf4j
public class ProjectSetUpServiceImpl implements ProjectSetUpService {

    /**
     * ProjectSetUpRepository.
     */
    @Autowired
    private ProjectSetUpRepository projectSetUpRepository;
    /**
     * ProjectMilestoneRepository.
     */
    @Autowired
    private ProjectMilestoneRepository projectMileStoneRepo;
    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepo;
    /**
     * ProjectMarketRepository.
     */
    @Autowired
    private ProjectMarketRepository projMarketRepo;
    /**
     * PuActionsRepository.
     */
    @Autowired
    private PuActionsRepository puActionsRepo;
    /**
     * ContractsRepository.
     */
    @Autowired
    private ContractsRepository contractsRepo;
    /**
     * CommodityContractRepository.
     */
    @Autowired
    private CommodityContractRepository commodityContractRepo;

    @Override
    public Object searchProjectSetUp(final RequestModel request) {
        log.debug("Entry:PmfuProjectSetUpServiceImpl:searchProjectSetUp");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.projectSetUpRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(projectSetUp -> mapper.map(projectSetUp, ProjectSetUpListModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.projectSetUpRepository.findAll(request.getFilterSpecification()).stream()
                    .map(projectSetUp -> mapper.map(projectSetUp, ProjectSetUpListModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:PmfuProjectSetUpServiceImpl:searchProjectSetUp");
        return result;
    }

    @Override
    public ProjectSetUpModel viewProjectSetUp(final UUID projectSetUpId) {
        log.debug("Entry:PmfuProjectSetUpServiceImpl:viewProjectSetUp");
        ProjectSetUp projectSetUp;
        ProjectSetUpModel projSetUpModel = null;
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            projectSetUp = projectSetUpRepository.findById(projectSetUpId).orElse(null);
            if (Objects.nonNull(projectSetUp)) {
                projSetUpModel = mapper.map(projectSetUp, ProjectSetUpModel.class);
            }
            log.debug("Leave:PmfuProjectSetUpServiceImpl:viewProjectSetUp");
            return projSetUpModel;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Error", e.getMessage());
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    @Override
    public void deleteProjectSetUpById(final UUID projectSetUpId) {
        log.debug("Entry:PmfuProjectSetUpServiceImpl:deleteProjectSetUpById");
        try {
            this.projectSetUpRepository.deleteById(projectSetUpId);
            log.debug("Leave:PmfuProjectSetUpServiceImpl:deleteProjectSetUpById");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    @Override
    public void deleteProjectMileStoneById(final UUID projSetUpId, final List<UUID> mileStoneIdList,
            final String email) {
        log.debug("Entry:PmfuProjectSetUpServiceImpl:deleteProjectMileStoneById");
        User updateUser = null;
        try {
            updateUser = userRepo.findByEmail(email).get(0);
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Author",
                    "User not present in the system for the email: " + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        try {
            if (Objects.nonNull(mileStoneIdList) && !mileStoneIdList.isEmpty()) {
                mileStoneIdList.forEach(mileStoneId -> {
                    Optional<ProjectMilestone> projMileStoneRec = projectMileStoneRepo
                            .findById(mileStoneId);
                    if (projMileStoneRec.isPresent()) {
                        UUID projectMarketId = projMileStoneRec.get().getProjectMarket().getId();
                        int puprojectMarketSeqNo = projMileStoneRec.get().getProjectMarket()
                                .getListProjectMarketSeq();
                        int pumarketCodeSeqNo = projMileStoneRec.get()
                                .getListMarketCodeByProjectSeq();
                        String marketCode = projMileStoneRec.get().getSupplierMarketCode();
                        String material = projMileStoneRec.get().getMaterial();
                        List<ProjectMilestone> projectMileStoneList = projectMileStoneRepo
                                .findByProjectMarketIdAndSupplierMarketCode(projectMarketId,
                                        marketCode);
                        if (Objects.nonNull(projectMileStoneList)
                                && !projectMileStoneList.isEmpty()) {
                            if (projectMileStoneList.size() == 1) {
                                log.debug("Deleting record from project Market");
                                projMarketRepo.deleteById(projectMarketId);
                                projMarketRepo.updateRearrangeSequence(projSetUpId,
                                        puprojectMarketSeqNo);
                            } else {
                                CommodityContract commodityContractRec = commodityContractRepo
                                        .findByProjectMarketId(projectMarketId);
                                commodityContractRec.getContractsList().forEach(contract -> {
                                    if (contract.getMaterialComponent().equals(material)) {
                                        log.debug("Deleting record from Contract");
                                        contract.setCommodityContract(null);
                                        contractsRepo.save(contract);
                                    }
                                });
                                log.debug("Deleting record from project Market Code");
                                projectMileStoneRepo.deleteById(mileStoneId);
                                projectMileStoneRepo.updateRearrangeMileStoneSequence(
                                        projectMarketId, pumarketCodeSeqNo);
                            }
                        }
                    }
                });
            }
            ProjectSetUp projectSetUp = projectSetUpRepository.findById(projSetUpId).orElse(null);
            if (projectSetUp != null) {
                log.debug("Updating record of project Set Up");
                projectSetUp.setModifiedDate(new Date());
                projectSetUp.setModifiedBy(updateUser.getEmployeeId());
                projectSetUpRepository.save(projectSetUp);
            }
            log.debug("Leave:PmfuProjectSetUpServiceImpl:deleteProjectMileStoneById");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    @Override
    public ProjectSetUpModel saveProjectSetUp(final ProjectSetUpModel projectSetUpModel,
            final String email) {
        log.debug("Entry:PmfuProjectSetUpServiceImpl:saveProjectSetUp");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        User creator = null;
        UserModel creatorModel = null;
        String creatorUserName = null;

        try {
            creator = userRepo.findByEmail(email).get(0);
            creatorUserName = creator.getFirstName().concat(" ").concat(creator.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Author",
                    "User not present in the system for the email: " + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        if (projectSetUpModel.getProjectId() == null) {
            Integer projId = projectSetUpRepository.findMaxProjectId();
            projectSetUpModel.setProjectId(projId + 1);
            projectSetUpModel.setCreatedDate(new Date());
            projectSetUpModel.setCreatedBy(creator.getEmployeeId());
        }
        projectSetUpModel.setModifiedDate(new Date());
        projectSetUpModel.setModifiedBy(creator.getEmployeeId());
        ProjectSetUp projSetUp = mapper.map(projectSetUpModel, ProjectSetUp.class);

        List<ProjectMarket> projMarketList = projSetUp.getProjectMarketList();

        if (Objects.nonNull(projMarketList) && !projMarketList.isEmpty()) {
            projMarketList.forEach(projectMarket -> {
                ProjectMarket finalProjectMarket = projectMarket;

                List<ProjectMilestone> projectMileStoneList = projectMarket
                        .getProjectMilestoneList();
                if (Objects.nonNull(projectMileStoneList) && !projectMileStoneList.isEmpty()) {
                    projectMileStoneList.forEach(projectMileStone -> {
                        ProjectMilestone finalProjectMilestone = projectMileStone;
                        projectMileStone.getCommodityStatus()
                                .setProjectMilestone(finalProjectMilestone);
                        projectMileStone.setProjectMarket(finalProjectMarket);
                    });
                }

                List<PuActions> actionsList = projectMarket.getCommodityActionPlan()
                        .getPuActionsList();
                if (Objects.nonNull(actionsList) && !actionsList.isEmpty()) {
                    CommodityActionPlan finalCommActionPlan = projectMarket
                            .getCommodityActionPlan();
                    actionsList.forEach(
                            puaction -> puaction.setCommodityActionPlan(finalCommActionPlan));
                }
                projectMarket.getCommodityActionPlan().setProjectMarket(finalProjectMarket);

                List<Contracts> contractsList = projectMarket.getCommodityContract()
                        .getContractsList();
                if (Objects.nonNull(contractsList) && !contractsList.isEmpty()) {
                    CommodityContract finalComContract = projectMarket.getCommodityContract();
                    contractsList
                            .forEach(contracts -> contracts.setCommodityContract(finalComContract));
                }
                projectMarket.getCommodityContract().setProjectMarket(finalProjectMarket);
            });
        }

        if (Objects.nonNull(projMarketList) && !projMarketList.isEmpty()) {
            ProjectSetUp finalProjSetUp = projSetUp;
            projMarketList.forEach(item -> item.setProjectSetUp(finalProjSetUp));
        }

        if (Objects.nonNull(projSetUp.getProjectSetUpAttachmentList())
                && !projSetUp.getProjectSetUpAttachmentList().isEmpty()) {
            ProjectSetUp finalProjSetUp = projSetUp;
            projSetUp.getProjectSetUpAttachmentList()
                    .forEach(item -> item.setProjectSetUp(finalProjSetUp));
        }

        projSetUp = projectSetUpRepository.save(projSetUp);
        ProjectSetUpModel projSetUpModel = mapper.map(projSetUp, ProjectSetUpModel.class);
        log.debug("Leave:PmfuProjectSetUpServiceImpl:saveProjectSetUp");
        return projSetUpModel;
    }

    @Override
    public void deletePuActionById(final UUID projSetUpId, final UUID actionId,
            final String email) {
        log.debug("Entry:PmfuProjectSetUpServiceImpl:deletePuActionById");
        User updateUser = null;
        try {
            updateUser = userRepo.findByEmail(email).get(0);
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Author",
                    "User not present in the system for the email: " + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        try {
            log.debug("Deleting record from PuActions");
            puActionsRepo.deleteById(actionId);
            ProjectSetUp projectSetUp = projectSetUpRepository.findById(projSetUpId).orElse(null);
            if (projectSetUp != null) {
                log.debug("Updating record of project Set Up");
                projectSetUp.setModifiedDate(new Date());
                projectSetUp.setModifiedBy(updateUser.getEmployeeId());
                projectSetUpRepository.save(projectSetUp);
            }
            log.debug("Leave:PmfuProjectSetUpServiceImpl:deletePuActionById");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }

    }

    @Override
    public void deleteContractById(final UUID projSetUpId, final UUID contractId,
            final String email) {
        log.debug("Entry:PmfuProjectSetUpServiceImpl:deleteContractById");
        User updateUser = null;
        try {
            updateUser = userRepo.findByEmail(email).get(0);
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Author",
                    "User not present in the system for the email: " + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        try {
            log.debug("Deleting record from Contracts");
            contractsRepo.deleteById(contractId);
            ProjectSetUp projectSetUp = projectSetUpRepository.findById(projSetUpId).orElse(null);
            if (projectSetUp != null) {
                log.debug("Updating record of project Set Up");
                projectSetUp.setModifiedDate(new Date());
                projectSetUp.setModifiedBy(updateUser.getEmployeeId());
                projectSetUpRepository.save(projectSetUp);
            }
            log.debug("Leave:PmfuProjectSetUpServiceImpl:deleteContractById");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project SetUp", Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }
}
