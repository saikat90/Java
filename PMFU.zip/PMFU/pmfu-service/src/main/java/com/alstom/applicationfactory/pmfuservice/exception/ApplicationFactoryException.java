package com.alstom.applicationfactory.pmfuservice.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import java.util.List;

@Getter
@AllArgsConstructor
public class ApplicationFactoryException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    /**
     * Http error code.
     */
    private final int errorCode;
    /**
     * List of errors.
     */
    private final List<ErrorModel> errorModelList;
}
