package com.alstom.applicationfactory.pmfuservice.projectsetup.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;

public interface ProjectMarketRepository
        extends JpaRepository<ProjectMarket, UUID>, JpaSpecificationExecutor<ProjectMarket> {

    /**
     * @param projectSetupId
     * @param supplierMarketCode
     * @return ProjectMarket
     */
    ProjectMarket findByProjectSetUpIdAndSupplierMarketCode(UUID projectSetupId,
            String supplierMarketCode);

    /**
     * @param projectId
     * @return Seq Number
     */
    @Query(value = "select count(pm.puset_up_list_of_project_market_seq) from puproject_market pm "
            + " where pm.pu_set_up_rev_id in (select pu.id from puset_up pu " + " where "
            + " pu.project_id = ?1)", nativeQuery = true)
    Integer findSeqNumber(Integer projectId);

    /**
     * @param newMC
     * @param domainCode
     * @param oldMC
     */
    @Modifying
    @Query(value = "update puproject_market "
            + "set supplier_market_code = ?1 , domain_code = ?2 where supplier_market_code = ?3", nativeQuery = true)
    void updateMarketCode(String newMC, String domainCode, String oldMC);

    /**
     * @param projectSetupId
     * @param sequenceNo
     */
    @Modifying
    @Query(value = " update puproject_market set puset_up_list_of_project_market_seq = (puset_up_list_of_project_market_seq  -1) "
            + " where " + " pu_set_up_rev_id = ?1 and "
            + " puset_up_list_of_project_market_seq > ?2", nativeQuery = true)
    void updateRearrangeSequence(UUID projectSetupId, int sequenceNo);
}
