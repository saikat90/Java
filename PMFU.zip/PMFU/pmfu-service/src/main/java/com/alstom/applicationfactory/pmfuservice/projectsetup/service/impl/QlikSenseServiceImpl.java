package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.MarketCodeMasterDataRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityStatus;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUp;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityActionPlanModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityStatusModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.QlikSenseService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "qlikService")
@Transactional
@Slf4j
public class QlikSenseServiceImpl implements QlikSenseService {

    /**
     * ProjectSetUpRepository.
     */
    @Autowired
    private ProjectSetUpRepository projSetUpRepo;
    /**
     * MarketCodeMasterDataRepository.
     */
    @Autowired
    private MarketCodeMasterDataRepository marketCodeMDRepo;

    @Override
    public Object findAllCommodityStatusData() {
        log.debug("Entry:QlikSenseServiceImpl:findAllCommodityStatusData");
        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime();
        try {
            List<QliksenseCommodityStatusModel> qlikCommodityStatusList = new ArrayList<>();
            List<ProjectSetUp> projSetUpList = projSetUpRepo.findAll();
            projSetUpList.forEach(projSetUp -> {
                projSetUp.getProjectMarketList().forEach(projectMarket -> {
                    projectMarket.getProjectMilestoneList().forEach(projectMileStone -> {
                        CommodityStatus comStatus = projectMileStone.getCommodityStatus();
                        if (projSetUp.getProjectId() != null) {
                            // Tech Input
                            QliksenseCommodityStatusModel techInputModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(techInputModel,
                                    projectMileStone);
                            techInputModel.setMileStone(Constants.TECH_INPUT);
                            techInputModel.setNeeds(comStatus.getNeedsTechInput());
                            techInputModel.setForecast(comStatus.getForecastDateTechInput());
                            techInputModel.setActual(comStatus.getActualDateTechInput());
                            techInputModel.setStatus(comStatus.getStatusTechInput());
                            if (techInputModel.getNeeds() != null
                                    && techInputModel.getActual() != null) {
                                techInputModel.setVariance(calculateDateDifference(
                                        techInputModel.getNeeds(), techInputModel.getActual()));
                                techInputModel.setOtd(
                                        techInputModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                            // Go RFQ
                            QliksenseCommodityStatusModel goRFQModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(goRFQModel, projectMileStone);
                            goRFQModel.setMileStone(Constants.GO_RFQ);
                            if (comStatus.getDfqMilestoneGoRfq() != null
                                    && comStatus.getDfqMilestoneGoRfq().equals(Constants.X)) {
                                goRFQModel.setApplicable(comStatus.getDfqMilestoneGoRfq());
                                goRFQModel.setDuration(comStatus.getDurationGoRfq());
                                goRFQModel.setNeeds(comStatus.getNeedsGoRfq());
                                goRFQModel.setForecast(comStatus.getForecastDateGoRfq());
                                goRFQModel.setActual(comStatus.getActualDateGoRfq());
                                goRFQModel.setStatus(comStatus.getStatusGoRfq());
                                if (goRFQModel.getNeeds() != null
                                        && goRFQModel.getActual() != null) {
                                    goRFQModel.setVariance(calculateDateDifference(
                                            goRFQModel.getNeeds(), goRFQModel.getActual()));
                                    goRFQModel.setOtd(
                                            goRFQModel.getVariance() <= 0 ? Constants.ON_TIME
                                                    : Constants.LATE);
                                }
                            }
                            // BA
                            QliksenseCommodityStatusModel baModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(baModel, projectMileStone);
                            baModel.setMileStone(Constants.BA);
                            if (comStatus.getDfqMilestoneBa() != null
                                    && comStatus.getDfqMilestoneBa().equals(Constants.X)) {
                                baModel.setApplicable(comStatus.getDfqMilestoneBa());
                                baModel.setDuration(comStatus.getDurationBa());
                                baModel.setNeeds(comStatus.getNeedsBa());
                                baModel.setForecast(comStatus.getForecastDateBa());
                                baModel.setActual(comStatus.getActualDateBa());
                                baModel.setStatus(comStatus.getStatusBa());
                                if (baModel.getNeeds() != null && baModel.getActual() != null) {
                                    baModel.setVariance(calculateDateDifference(baModel.getNeeds(),
                                            baModel.getActual()));
                                    baModel.setOtd(baModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                                }
                            }
                            // Go Order
                            QliksenseCommodityStatusModel goOrderModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(goOrderModel, projectMileStone);
                            goOrderModel.setMileStone(Constants.GO_ORDER);
                            if (comStatus.getDfqMilestoneGoOrder() != null
                                    && comStatus.getDfqMilestoneGoOrder().equals(Constants.X)) {
                                goOrderModel.setApplicable(comStatus.getDfqMilestoneGoOrder());
                                goOrderModel.setDuration(comStatus.getDurationGoOrder());
                                goOrderModel.setNeeds(comStatus.getNeedsGoOrder());
                                goOrderModel.setForecast(comStatus.getForecastDateGoOrder());
                                goOrderModel.setActual(comStatus.getActualDateGoOrder());
                                goOrderModel.setStatus(comStatus.getStatusGoOrder());
                                if (goOrderModel.getNeeds() != null
                                        && goOrderModel.getActual() != null) {
                                    goOrderModel.setVariance(calculateDateDifference(
                                            goOrderModel.getNeeds(), goOrderModel.getActual()));
                                    goOrderModel.setOtd(
                                            goOrderModel.getVariance() <= 0 ? Constants.ON_TIME
                                                    : Constants.LATE);
                                }
                            }
                            // PGR
                            QliksenseCommodityStatusModel pgrModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(pgrModel, projectMileStone);
                            pgrModel.setMileStone(Constants.PGR);
                            if (comStatus.getDfqMilestonePgr() != null
                                    && comStatus.getDfqMilestonePgr().equals(Constants.X)) {
                                pgrModel.setApplicable(comStatus.getDfqMilestonePgr());
                                pgrModel.setDuration(comStatus.getDurationPgr());
                                pgrModel.setNeeds(comStatus.getNeedsPgr());
                                pgrModel.setForecast(comStatus.getForecastDatePgr());
                                pgrModel.setActual(comStatus.getActualDatePgr());
                                pgrModel.setStatus(comStatus.getStatusPgr());
                                if (pgrModel.getNeeds() != null && pgrModel.getActual() != null) {
                                    pgrModel.setVariance(calculateDateDifference(
                                            pgrModel.getNeeds(), pgrModel.getActual()));
                                    pgrModel.setOtd(pgrModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                                }
                            }
                            // CGR
                            QliksenseCommodityStatusModel cgrModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(cgrModel, projectMileStone);
                            cgrModel.setMileStone(Constants.CGR);
                            if (comStatus.getDfqMilestoneGgr() != null
                                    && comStatus.getDfqMilestoneGgr().equals(Constants.X)) {
                                cgrModel.setApplicable(comStatus.getDfqMilestoneGgr());
                                cgrModel.setDuration(comStatus.getDurationCgr());
                                cgrModel.setNeeds(comStatus.getNeedsCgr());
                                cgrModel.setForecast(comStatus.getForecastDateCgr());
                                cgrModel.setActual(comStatus.getActualDateCgr());
                                cgrModel.setStatus(comStatus.getStatusGgr());
                                if (cgrModel.getNeeds() != null && cgrModel.getActual() != null) {
                                    cgrModel.setVariance(calculateDateDifference(
                                            cgrModel.getNeeds(), cgrModel.getActual()));
                                    cgrModel.setOtd(cgrModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                                }
                            }
                            // Go Prod
                            QliksenseCommodityStatusModel goProdModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(goProdModel, projectMileStone);
                            goProdModel.setMileStone(Constants.GO_PROD);
                            if (comStatus.getDfqMilestoneGoProd() != null
                                    && comStatus.getDfqMilestoneGoProd().equals(Constants.X)) {
                                goProdModel.setApplicable(comStatus.getDfqMilestoneGoProd());
                                goProdModel.setDuration(comStatus.getDurationGoProd());
                                goProdModel.setNeeds(comStatus.getNeedsGoProd());
                                goProdModel.setForecast(comStatus.getForecastDateGoProd());
                                goProdModel.setActual(comStatus.getActualDateGoProd());
                                goProdModel.setStatus(comStatus.getStatusGoProd());
                                if (goProdModel.getNeeds() != null
                                        && goProdModel.getActual() != null) {
                                    goProdModel.setVariance(calculateDateDifference(
                                            goProdModel.getNeeds(), goProdModel.getActual()));
                                    goProdModel.setOtd(
                                            goProdModel.getVariance() <= 0 ? Constants.ON_TIME
                                                    : Constants.LATE);
                                }
                            }
                            // FAI
                            QliksenseCommodityStatusModel faiModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(faiModel, projectMileStone);
                            faiModel.setMileStone(Constants.FAI);
                            if (comStatus.getDfqMilestoneFai() != null
                                    && comStatus.getDfqMilestoneFai().equals(Constants.X)) {
                                faiModel.setApplicable(comStatus.getDfqMilestoneFai());
                                faiModel.setDuration(comStatus.getDurationFai());
                                faiModel.setNeeds(comStatus.getNeedsFai());
                                faiModel.setForecast(comStatus.getForecastDateFai());
                                faiModel.setActual(comStatus.getActualDateFai());
                                faiModel.setStatus(comStatus.getStatusFai());
                                if (faiModel.getNeeds() != null && faiModel.getActual() != null) {
                                    faiModel.setVariance(calculateDateDifference(
                                            faiModel.getNeeds(), faiModel.getActual()));
                                    faiModel.setOtd(faiModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                                }
                            }
                            // FAT
                            QliksenseCommodityStatusModel fatModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(fatModel, projectMileStone);
                            fatModel.setMileStone(Constants.FAT);
                            if (comStatus.getDfqMilestoneFat() != null
                                    && comStatus.getDfqMilestoneFat().equals(Constants.X)) {
                                fatModel.setApplicable(comStatus.getDfqMilestoneFat());
                                fatModel.setDuration(comStatus.getDurationFat());
                                fatModel.setNeeds(comStatus.getNeedsFat());
                                fatModel.setForecast(comStatus.getForecastDateFat());
                                fatModel.setActual(comStatus.getActualDateFat());
                                fatModel.setStatus(comStatus.getStatusFat());
                                if (fatModel.getNeeds() != null && fatModel.getActual() != null) {
                                    fatModel.setVariance(calculateDateDifference(
                                            fatModel.getNeeds(), fatModel.getActual()));
                                    fatModel.setOtd(fatModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                                }
                            }
                            // Delivery
                            QliksenseCommodityStatusModel deliveryModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(deliveryModel,
                                    projectMileStone);
                            deliveryModel.setMileStone(Constants.DELIVERY);
                            deliveryModel.setApplicable(comStatus.getDfqMilestoneDelivery());
                            deliveryModel.setDuration(comStatus.getDurationDelivery());
                            deliveryModel.setNeeds(comStatus.getNeedsFirstNeed());
                            deliveryModel.setForecast(comStatus.getForecastDateDelivery());
                            deliveryModel.setActual(comStatus.getActualDateDelivery());
                            deliveryModel.setStatus(comStatus.getStatusDelivery());
                            if (deliveryModel.getNeeds() != null
                                    && deliveryModel.getActual() != null) {
                                deliveryModel.setVariance(calculateDateDifference(
                                        deliveryModel.getNeeds(), deliveryModel.getActual()));
                                deliveryModel
                                        .setOtd(deliveryModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            } else if (deliveryModel.getNeeds() != null) {
                                deliveryModel.setVariance(
                                        calculateDateDifference(deliveryModel.getNeeds(), today));
                                deliveryModel
                                        .setOtd(deliveryModel.getVariance() <= 0 ? Constants.ON_TIME
                                                : Constants.LATE);
                            }
                            // IQA
                            QliksenseCommodityStatusModel iqaModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(iqaModel, projectMileStone);
                            iqaModel.setMileStone(Constants.IQA);
                            if (comStatus.getDfqMilestoneIqa() != null
                                    && comStatus.getDfqMilestoneIqa().equals(Constants.X)) {
                                iqaModel.setApplicable(comStatus.getDfqMilestoneIqa());
                                iqaModel.setDuration(comStatus.getDurationIqa());
                                iqaModel.setNeeds(comStatus.getNeedsIqa());
                                iqaModel.setForecast(comStatus.getForecastDateIqa());
                                iqaModel.setActual(comStatus.getActualDateIqa());
                                iqaModel.setStatus(comStatus.getStatusIqa());
                                if (iqaModel.getNeeds() != null && iqaModel.getActual() != null) {
                                    iqaModel.setVariance(calculateDateDifference(
                                            iqaModel.getNeeds(), iqaModel.getActual()));
                                    iqaModel.setOtd(iqaModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                                }
                            }
                            // FQA
                            QliksenseCommodityStatusModel fqaModel = populateCommodityStatusProjectDetails(
                                    projSetUp);
                            populateCommodityStatusMileStoneDetails(fqaModel, projectMileStone);
                            fqaModel.setMileStone(Constants.FQA);
                            if (comStatus.getDfqMilestoneFqa() != null
                                    && comStatus.getDfqMilestoneFqa().equals(Constants.X)) {
                                fqaModel.setApplicable(comStatus.getDfqMilestoneFqa());
                                fqaModel.setDuration(comStatus.getDurationFqa());
                                fqaModel.setNeeds(comStatus.getNeedsFqa());
                                fqaModel.setForecast(comStatus.getForecastDateFqa());
                                fqaModel.setActual(comStatus.getActualDateFqa());
                                fqaModel.setStatus(comStatus.getStatusFqa());
                                if (fqaModel.getNeeds() != null && fqaModel.getActual() != null) {
                                    fqaModel.setVariance(calculateDateDifference(
                                            fqaModel.getNeeds(), fqaModel.getActual()));
                                    fqaModel.setOtd(fqaModel.getVariance() <= 0 ? Constants.ON_TIME
                                            : Constants.LATE);
                                }
                            }
                            qlikCommodityStatusList.add(techInputModel);
                            qlikCommodityStatusList.add(goRFQModel);
                            qlikCommodityStatusList.add(baModel);
                            qlikCommodityStatusList.add(goOrderModel);
                            qlikCommodityStatusList.add(pgrModel);
                            qlikCommodityStatusList.add(cgrModel);
                            qlikCommodityStatusList.add(goProdModel);
                            qlikCommodityStatusList.add(faiModel);
                            qlikCommodityStatusList.add(fatModel);
                            qlikCommodityStatusList.add(deliveryModel);
                            qlikCommodityStatusList.add(iqaModel);
                            qlikCommodityStatusList.add(fqaModel);
                        }
                    });
                });
            });

            log.debug("Leave:QlikSenseServiceImpl:findAllCommodityStatusData");
            return qlikCommodityStatusList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("QlikCommodityStatus",
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    private int calculateDateDifference(final Date needsDate, final Date actualDate) {
        long diff = actualDate.getTime() - needsDate.getTime();
        int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
        return diffDays;
    }

    private void populateCommodityStatusMileStoneDetails(
            final QliksenseCommodityStatusModel qlikCSModel,
            final ProjectMilestone projectMileStone) {
        qlikCSModel.setDomainCode(projectMileStone.getDomainCode());
        qlikCSModel.setDomainName(projectMileStone.getDomainName());
        qlikCSModel.setMarketCode(projectMileStone.getSupplierMarketCode());
        qlikCSModel.setMarketName(projectMileStone.getSupplierMarketName());
        qlikCSModel.setGlobalLocal(projectMileStone.getGlobalLocal());
        qlikCSModel.setMaterial(projectMileStone.getMaterial());
    }

    private QliksenseCommodityStatusModel populateCommodityStatusProjectDetails(
            final ProjectSetUp projSetUp) {
        QliksenseCommodityStatusModel prjCommodityStatusModel = new QliksenseCommodityStatusModel();
        prjCommodityStatusModel.setProjectId(projSetUp.getProjectId());
        prjCommodityStatusModel.setProjectName(projSetUp.getProject().getProjName());
        prjCommodityStatusModel.setCdbCode(projSetUp.getProject().getCtCode());
        prjCommodityStatusModel.setRegion(projSetUp.getAtSite().getRegion());
        prjCommodityStatusModel.setSite(projSetUp.getAtSite().getSite());
        prjCommodityStatusModel.setProductLine(projSetUp.getProductLine());
        prjCommodityStatusModel.setLastUpdate(projSetUp.getModifiedDate());
        prjCommodityStatusModel.setDescription(projSetUp.getDescription());
        prjCommodityStatusModel.setPrSm(projSetUp.getPrsm() != null ? projSetUp.getPrsm()
                .getFirstName().concat(" ").concat(projSetUp.getPrsm().getLastName()) : "");
        prjCommodityStatusModel.setPrSmDeputy(
                projSetUp.getPrsmDeputy() != null ? projSetUp.getPrsmDeputy().getFirstName()
                        .concat(" ").concat(projSetUp.getPrsmDeputy().getLastName()) : "");
        prjCommodityStatusModel.setPm(projSetUp.getPmName() != null ? projSetUp.getPmName() : "");
        prjCommodityStatusModel
                .setPrPm(projSetUp.getPrpmName() != null ? projSetUp.getPrpmName() : "");
        prjCommodityStatusModel
                .setWpc(projSetUp.getWpcName() != null ? projSetUp.getWpcName() : "");
        prjCommodityStatusModel
                .setPrScl(projSetUp.getPrsclName() != null ? projSetUp.getPrsclName() : "");
        prjCommodityStatusModel
                .setPrQsm(projSetUp.getPrqsmName() != null ? projSetUp.getPrqsmName() : "");
        prjCommodityStatusModel
                .setPrEm(projSetUp.getPremName() != null ? projSetUp.getPremName() : "");
        prjCommodityStatusModel
                .setPrScm(projSetUp.getPrscmName() != null ? projSetUp.getPrscmName() : "");
        prjCommodityStatusModel
                .setTsm(projSetUp.getTsmName() != null ? projSetUp.getTsmName() : "");
        prjCommodityStatusModel
                .setPrIdm(projSetUp.getPridmName() != null ? projSetUp.getPridmName() : "");
        prjCommodityStatusModel
                .setPrOm(projSetUp.getPromName() != null ? projSetUp.getPromName() : "");
        prjCommodityStatusModel
                .setPrIsm(projSetUp.getPrismName() != null ? projSetUp.getPrismName() : "");
        return prjCommodityStatusModel;
    }

    @Override
    public Object findAllCommodityContractData() {
        log.debug("Entry:QlikSenseServiceImpl:findAllCommodityContractData");
        try {
            List<QliksenseCommodityContractModel> qlikCommodityContractList = new ArrayList<>();
            List<ProjectSetUp> projSetUpList = projSetUpRepo.findAll();

            projSetUpList.forEach(projSetUp -> {
                projSetUp.getProjectMarketList().forEach(projectMarket -> {
                    projectMarket.getCommodityContract().getContractsList().forEach(contract -> {
                        if (projSetUp.getProjectId() != null) {
                            QliksenseCommodityContractModel commodityContractModel = populateCommodityContractProjectDetails(
                                    projSetUp);
                            populateCommodityContractDetails(commodityContractModel, projectMarket);
                            commodityContractModel.setMaterial(contract.getMaterialComponent());
                            commodityContractModel.setContractType(contract.getContractType());
                            commodityContractModel
                                    .setParticularConditions(contract.getPartConditions());
                            commodityContractModel.setStatusContract(contract.getStatus());
                            commodityContractModel.setPoRc(contract.getPo());
                            commodityContractModel.setPerfBond(contract.getPerfBond());
                            commodityContractModel.setWarrantyBond(contract.getWarrantyBond());
                            commodityContractModel.setAr(contract.getAr());
                            commodityContractModel.setPoNrc(contract.getPoNrc());
                            qlikCommodityContractList.add(commodityContractModel);
                        }
                    });
                });
            });
            log.debug("Leave:QlikSenseServiceImpl:findAllCommodityContractData");
            return qlikCommodityContractList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("QlikCommodityStatus",
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    private void populateCommodityContractDetails(final QliksenseCommodityContractModel qlikCCModel,
            final ProjectMarket projectMarket) {
        MarketCodeMasterData marketCode = marketCodeMDRepo
                .findByMarketCode(projectMarket.getSupplierMarketCode());
        if (marketCode != null) {
            qlikCCModel.setDomainName(marketCode.getDomainName());
            qlikCCModel.setMarketName(marketCode.getMarketName());
            qlikCCModel.setGlobalLocal(marketCode.getGlobalLocal());
        }
        qlikCCModel.setDomain(projectMarket.getDomainCode());
        qlikCCModel.setMarketCode(projectMarket.getSupplierMarketCode());
    }

    private QliksenseCommodityContractModel populateCommodityContractProjectDetails(
            final ProjectSetUp projSetUp) {
        QliksenseCommodityContractModel prjCommodityContractModel = new QliksenseCommodityContractModel();
        prjCommodityContractModel.setProjectId(projSetUp.getProjectId());
        prjCommodityContractModel.setProjectName(projSetUp.getProject().getProjName());
        prjCommodityContractModel.setCdbCode(projSetUp.getProject().getCtCode());
        prjCommodityContractModel.setRegion(projSetUp.getAtSite().getRegion());
        prjCommodityContractModel.setSite(projSetUp.getAtSite().getSite());
        prjCommodityContractModel.setProductLine(projSetUp.getProductLine());
        prjCommodityContractModel.setLastUpdate(projSetUp.getModifiedDate());
        prjCommodityContractModel.setDescription(projSetUp.getDescription());
        prjCommodityContractModel.setPrSm(projSetUp.getPrsm() != null ? projSetUp.getPrsm()
                .getFirstName().concat(" ").concat(projSetUp.getPrsm().getLastName()) : null);
        prjCommodityContractModel.setPrSmDeputy(
                projSetUp.getPrsmDeputy() != null ? projSetUp.getPrsmDeputy().getFirstName()
                        .concat(" ").concat(projSetUp.getPrsmDeputy().getLastName()) : "");
        prjCommodityContractModel.setPm(projSetUp.getPmName() != null ? projSetUp.getPmName() : "");
        prjCommodityContractModel
                .setPrPm(projSetUp.getPrpmName() != null ? projSetUp.getPrpmName() : "");
        prjCommodityContractModel
                .setWpc(projSetUp.getWpcName() != null ? projSetUp.getWpcName() : "");
        prjCommodityContractModel
                .setPrScl(projSetUp.getPrsclName() != null ? projSetUp.getPrsclName() : "");
        prjCommodityContractModel
                .setPrQsm(projSetUp.getPrqsmName() != null ? projSetUp.getPrqsmName() : "");
        prjCommodityContractModel
                .setPrEm(projSetUp.getPremName() != null ? projSetUp.getPremName() : "");
        prjCommodityContractModel
                .setPrScm(projSetUp.getPrscmName() != null ? projSetUp.getPrscmName() : "");
        prjCommodityContractModel
                .setTsm(projSetUp.getTsmName() != null ? projSetUp.getTsmName() : "");
        prjCommodityContractModel
                .setPrIdm(projSetUp.getPridmName() != null ? projSetUp.getPridmName() : "");
        prjCommodityContractModel
                .setPrOm(projSetUp.getPromName() != null ? projSetUp.getPromName() : "");
        prjCommodityContractModel
                .setPrIsm(projSetUp.getPrismName() != null ? projSetUp.getPrismName() : "");
        return prjCommodityContractModel;
    }

    @Override
    public Object findAllCommodityActionPlanData() {
        log.debug("Entry:QlikSenseServiceImpl:findAllCommodityActionPlanData");
        try {
            List<QliksenseCommodityActionPlanModel> qlikCommodityActionPlanList = new ArrayList<>();
            List<ProjectSetUp> projSetUpList = projSetUpRepo.findAll();

            projSetUpList.forEach(projSetUp -> {
                projSetUp.getProjectMarketList().forEach(projectMarket -> {
                    projectMarket.getCommodityActionPlan().getPuActionsList().forEach(puaction -> {
                        if (projSetUp.getProjectId() != null) {
                            QliksenseCommodityActionPlanModel commodityActionModel = populateCommodityActionProjectDetails(
                                    projSetUp);
                            commodityActionModel.setDomain(projectMarket.getDomainCode());
                            commodityActionModel
                                    .setMarketCode(projectMarket.getSupplierMarketCode());
                            commodityActionModel.setCreationDate(puaction.getCreatedDate());
                            commodityActionModel.setPic(puaction.getPic());
                            commodityActionModel.setActionDescription(puaction.getDescription());
                            commodityActionModel.setPriority(puaction.getPriority());
                            commodityActionModel.setStatus(puaction.getStatus());
                            commodityActionModel.setTarget(puaction.getTargetDate());
                            commodityActionModel.setMaterial(puaction.getMaterial());
                            qlikCommodityActionPlanList.add(commodityActionModel);
                        }
                    });
                });
            });

            log.debug("Entry:QlikSenseServiceImpl:findAllCommodityActionPlanData");
            return qlikCommodityActionPlanList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("QlikCommodityStatus",
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    private QliksenseCommodityActionPlanModel populateCommodityActionProjectDetails(
            final ProjectSetUp projSetUp) {
        QliksenseCommodityActionPlanModel prjCommodityActionModel = new QliksenseCommodityActionPlanModel();
        prjCommodityActionModel.setProjectId(projSetUp.getProjectId());
        prjCommodityActionModel.setProjectName(projSetUp.getProject().getProjName());
        prjCommodityActionModel.setCdbCode(projSetUp.getProject().getCtCode());
        prjCommodityActionModel.setRegion(projSetUp.getAtSite().getRegion());
        prjCommodityActionModel.setSite(projSetUp.getAtSite().getSite());
        prjCommodityActionModel.setProductLine(projSetUp.getProductLine());
        prjCommodityActionModel.setLastUpdate(projSetUp.getModifiedDate());
        prjCommodityActionModel.setProjectDescription(projSetUp.getDescription());
        prjCommodityActionModel.setPrSm(projSetUp.getPrsm() != null ? projSetUp.getPrsm()
                .getFirstName().concat(" ").concat(projSetUp.getPrsm().getLastName()) : null);
        prjCommodityActionModel.setPrSmDeputy(
                projSetUp.getPrsmDeputy() != null ? projSetUp.getPrsmDeputy().getFirstName()
                        .concat(" ").concat(projSetUp.getPrsmDeputy().getLastName()) : "");
        prjCommodityActionModel.setPm(projSetUp.getPmName() != null ? projSetUp.getPmName() : "");
        prjCommodityActionModel
                .setPrPm(projSetUp.getPrpmName() != null ? projSetUp.getPrpmName() : "");
        prjCommodityActionModel
                .setWpc(projSetUp.getWpcName() != null ? projSetUp.getWpcName() : "");
        prjCommodityActionModel
                .setPrScl(projSetUp.getPrsclName() != null ? projSetUp.getPrsclName() : "");
        prjCommodityActionModel
                .setPrQsm(projSetUp.getPrqsmName() != null ? projSetUp.getPrqsmName() : "");
        prjCommodityActionModel
                .setPrEm(projSetUp.getPremName() != null ? projSetUp.getPremName() : "");
        prjCommodityActionModel
                .setPrScm(projSetUp.getPrscmName() != null ? projSetUp.getPrscmName() : "");
        prjCommodityActionModel
                .setTsm(projSetUp.getTsmName() != null ? projSetUp.getTsmName() : "");
        prjCommodityActionModel
                .setPrIdm(projSetUp.getPridmName() != null ? projSetUp.getPridmName() : "");
        prjCommodityActionModel
                .setPrOm(projSetUp.getPromName() != null ? projSetUp.getPromName() : "");
        prjCommodityActionModel
                .setPrIsm(projSetUp.getPrismName() != null ? projSetUp.getPrismName() : "");
        return prjCommodityActionModel;
    }
}
