package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type QliksenseCommodityStatusModel model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QliksenseCommodityStatusModel {

    /**
     * QliksenseCommodityStatusModel project id.
     */
    private Integer projectId;

    /**
     * QliksenseCommodityStatusModel project name.
     */
    private String projectName;

    /**
     * QliksenseCommodityStatusModel cdb code.
     */
    private String cdbCode;

    /**
     * QliksenseCommodityStatusModel region.
     */
    private String region;

    /**
     * QliksenseCommodityStatusModel site.
     */
    private String site;

    /**
     * QliksenseCommodityStatusModel product line.
     */
    private String productLine;

    /**
     * QliksenseCommodityStatusModel last update.
     */
    private Date lastUpdate;

    /**
     * QliksenseCommodityStatusModel description.
     */
    private String description;

    /**
     * QliksenseCommodityStatusModel prsm.
     */
    private String prSm;

    /**
     * QliksenseCommodityStatusModel prsm deputy.
     */
    private String prSmDeputy;

    /**
     * QliksenseCommodityStatusModel pm.
     */
    private String pm;

    /**
     * QliksenseCommodityStatusModel prpm.
     */
    private String prPm;

    /**
     * QliksenseCommodityStatusModel wpc.
     */
    private String wpc;

    /**
     * QliksenseCommodityStatusModel prscl.
     */
    private String prScl;

    /**
     * QliksenseCommodityStatusModel prqsm.
     */
    private String prQsm;

    /**
     * QliksenseCommodityStatusModel prem.
     */
    private String prEm;

    /**
     * QliksenseCommodityStatusModel prscm.
     */
    private String prScm;

    /**
     * QliksenseCommodityStatusModel tsm.
     */
    private String tsm;

    /**
     * QliksenseCommodityStatusModel pridm.
     */
    private String prIdm;

    /**
     * QliksenseCommodityStatusModel prom.
     */
    private String prOm;

    /**
     * QliksenseCommodityStatusModel prism.
     */
    private String prIsm;

    /**
     * QliksenseCommodityStatusModel domain code.
     */
    private String domainCode;

    /**
     * QliksenseCommodityStatusModel domain name.
     */
    private String domainName;

    /**
     * QliksenseCommodityStatusModel market code.
     */
    private String marketCode;

    /**
     * QliksenseCommodityStatusModel market name.
     */
    private String marketName;

    /**
     * QliksenseCommodityStatusModel global local.
     */
    private String globalLocal;

    /**
     * QliksenseCommodityStatusModel material.
     */
    private String material;

    /**
     * QliksenseCommodityStatusModel milestone.
     */
    private String mileStone;

    /**
     * QliksenseCommodityStatusModel duration.
     */
    private String applicable;

    /**
     * QliksenseCommodityStatusModel duration.
     */
    private Integer duration;

    /**
     * QliksenseCommodityStatusModel needs.
     */
    private Date needs;

    /**
     * QliksenseCommodityStatusModel forecast.
     */
    private Date forecast;

    /**
     * QliksenseCommodityStatusModel actual.
     */
    private Date actual;

    /**
     * QliksenseCommodityStatusModel status.
     */
    private String status;

    /**
     * QliksenseCommodityStatusModel otd.
     */
    private String otd;

    /**
     * QliksenseCommodityStatusModel variance.
     */
    private Integer variance;

}
