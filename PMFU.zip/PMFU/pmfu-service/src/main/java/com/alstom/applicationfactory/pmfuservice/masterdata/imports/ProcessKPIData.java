package com.alstom.applicationfactory.pmfuservice.masterdata.imports;

import java.text.SimpleDateFormat;

import org.apache.poi.ss.usermodel.Row;
import org.springframework.stereotype.Component;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.AllActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMasterDataModel;

@Component
public class ProcessKPIData {

    /**
     * Date format dd/mm/yyyy.
     */
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * @param allAction
     * @param dataRow
     * @return Row value.
     */
    public final Row populateExcelRowValue(final AllActionsModel allAction, final Row dataRow) {
        dataRow.createCell(0).setCellValue(allAction.getMarketCode());
        dataRow.createCell(1)
                .setCellValue(allAction.getCreatedDate() != null
                        ? dateFormat.format(allAction.getCreatedDate())
                        : "");
        dataRow.createCell(2)
                .setCellValue(allAction.getClosingDate() != null
                        ? dateFormat.format(allAction.getClosingDate())
                        : "");
        dataRow.createCell(Constants.THREE).setCellValue(allAction.getPic());
        dataRow.createCell(Constants.FOUR).setCellValue(allAction.getDescription());
        dataRow.createCell(Constants.FIVE).setCellValue(allAction.getPriority());
        dataRow.createCell(Constants.SIX).setCellValue(allAction.getStatus());
        dataRow.createCell(Constants.SEVEN)
                .setCellValue(allAction.getTargetDate() != null
                        ? dateFormat.format(allAction.getTargetDate())
                        : "");
        dataRow.createCell(Constants.EIGHT).setCellValue(allAction.getProjectId());
        dataRow.createCell(Constants.NINE).setCellValue(allAction.getProjectName());
        dataRow.createCell(Constants.TEN).setCellValue(allAction.getDomainCode());
        dataRow.createCell(Constants.ELEVEN).setCellValue(allAction.getMaterial());
        dataRow.createCell(Constants.TWELVE)
                .setCellValue(allAction.getExportDate() != null
                        ? dateFormat.format(allAction.getExportDate())
                        : "");
        return dataRow;
    }

    /**
     * @param prjMDModel
     * @param dataRow
     * @return Row value
     */
    public final Row populateProjectMDExcelRowValue(final ProjectMasterDataModel prjMDModel,
            final Row dataRow) {

        dataRow.createCell(0).setCellValue(prjMDModel.getProjectId());
        dataRow.createCell(1).setCellValue(prjMDModel.getProjectName());
        dataRow.createCell(2).setCellValue(prjMDModel.getCdbCode());
        dataRow.createCell(Constants.THREE).setCellValue(prjMDModel.getRegion());
        dataRow.createCell(Constants.FOUR).setCellValue(prjMDModel.getSite());
        dataRow.createCell(Constants.FIVE).setCellValue(prjMDModel.getProductLine());
        dataRow.createCell(Constants.SIX).setCellValue(prjMDModel.getPrsm());
        dataRow.createCell(Constants.SEVEN).setCellValue(prjMDModel.getDomainCode());
        dataRow.createCell(Constants.EIGHT).setCellValue(prjMDModel.getMarketCode());
        dataRow.createCell(Constants.NINE).setCellValue(prjMDModel.getMaterial());
        dataRow.createCell(Constants.TEN).setCellValue(prjMDModel.getMileStone());
        dataRow.createCell(Constants.ELEVEN).setCellValue(prjMDModel.getApplicable());
        if (prjMDModel.getDuration() != null) {
            dataRow.createCell(Constants.TWELVE).setCellValue(prjMDModel.getDuration());
        }
        dataRow.createCell(Constants.THIRTEEN)
                .setCellValue(prjMDModel.getNeedsDate() != null
                        ? dateFormat.format(prjMDModel.getNeedsDate())
                        : "");
        dataRow.createCell(Constants.FOURTEEN)
                .setCellValue(prjMDModel.getForecastDate() != null
                        ? dateFormat.format(prjMDModel.getForecastDate())
                        : "");
        dataRow.createCell(Constants.FIFTEEN)
                .setCellValue(prjMDModel.getActualDate() != null
                        ? dateFormat.format(prjMDModel.getActualDate())
                        : "");
        dataRow.createCell(Constants.SIXTEEN).setCellValue(prjMDModel.getStatus());
        dataRow.createCell(Constants.SEVENTEEN).setCellValue(prjMDModel.getTime());
        if (prjMDModel.getVariance() != null) {
            dataRow.createCell(Constants.EIGHTEEN).setCellValue(prjMDModel.getVariance());
        }
        return dataRow;
    }

}
