package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.MarketCodeMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.MarketCodeMasterDataRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.MarketCodeMasterDataService;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/MDMarketCode")
@Slf4j
public class MarketCodeMasterDataController {

    /**
     * MarketCodeMasterDataService.
     */
    @Autowired
    private MarketCodeMasterDataService mdMarketCodeService;
    /**
     * MarketCodeMasterDataRepository.
     */
    @Autowired
    private MarketCodeMasterDataRepository mdMarketCodeRepository;

    /**
     * @return market code object
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public Object findAll() {
        log.debug("Entry:PmfuMarketCodeMasterDataController:findAll");
        Object result = this.mdMarketCodeRepository.findAll();
        log.debug("Leave:PmfuMarketCodeMasterDataController:findAll");
        return result;
    }

    /**
     * @param request
     * @return Market Code Object
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public Object searchMDMarketCode(
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:PmfuMarketCodeMasterDataController:SearchMDMarketCode");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = mdMarketCodeService.searchMDMarketCode(requestModel);
        log.debug("Leave:PmfuMarketCodeMasterDataController:SearchMDMarketCode");
        return res;
    }

    /**
     * @param id
     * @return MarketCodeMasterDataModel
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU')")
    public MarketCodeMasterDataModel viewMDMarketCode(@PathVariable("id") final UUID id) {
        log.debug("Entry:PmfuMarketCodeMasterDataController:ViewMDMarketCode");
        MarketCodeMasterDataModel mdMarketCodeModel = mdMarketCodeService.viewMDMarketCode(id);
        log.debug("Leave:PmfuMarketCodeMasterDataController:ViewMDMarketCode");
        return mdMarketCodeModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasRole('ADM')")
    public void deleteMDMarketCodeById(@PathVariable("id") final UUID id) {
        log.debug("Entry:PmfuMarketCodeMasterDataController:DeleteMDMarketCode");
        this.mdMarketCodeService.deleteMDMarketCodeById(id);
        log.debug("Leave:PmfuMarketCodeMasterDataController:DeleteMDMarketCode");
    }

    /**
     * @param marketCode
     * @return MarketCodeMasterDataModel
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_PMFU') and hasRole('ADM')")
    public MarketCodeMasterDataModel createMDMarketCode(
            @RequestBody @Valid final MarketCodeMasterDataModel marketCode) {
        log.debug("Entry:PmfuMarketCodeMasterDataController:CreateMDMarketCode");
        MarketCodeMasterDataModel mdMarketCodeModel = mdMarketCodeService
                .createMDMarketCode(marketCode);
        log.debug("Leave:PmfuMarketCodeMasterDataController:CreateMDMarketCode");
        return mdMarketCodeModel;
    }

    /**
     * @param marketCode
     * @return MarketCodeMasterDataModel
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_PMFU') and hasRole('ADM')")
    public MarketCodeMasterDataModel updateMDMarketCode(
            @RequestBody @Valid final MarketCodeMasterDataModel marketCode) {
        log.debug("Entry:PmfuMarketCodeMasterDataController:UpdateMDMarketCode");
        MarketCodeMasterDataModel mdMarketCodeModel = mdMarketCodeService
                .updateMDMarketCode(marketCode);
        log.debug("Leave:PmfuMarketCodeMasterDataController:UpdateMDMarketCode");
        return mdMarketCodeModel;
    }

    /**
     * @param oldMC
     * @param newMC
     * @return MarketCodeMasterDataModel
     */
    @GetMapping("/{oldMarketCode}/{newMarketCode}")
    @PreAuthorize("hasAuthority('APP_PMFU') and hasRole('ADM')")
    public MarketCodeMasterDataModel replaceMDMarketCode(
            @PathVariable("oldMarketCode") final String oldMC,
            @PathVariable("newMarketCode") final String newMC) {
        log.debug("Entry:PmfuMarketCodeMasterDataController:replaceMDMarketCode");
        MarketCodeMasterDataModel mdMarketCodeModel = mdMarketCodeService.replaceMDMarketCode(oldMC,
                newMC);
        log.debug("Leave:PmfuMarketCodeMasterDataController:replaceMDMarketCode");
        return mdMarketCodeModel;
    }
}
