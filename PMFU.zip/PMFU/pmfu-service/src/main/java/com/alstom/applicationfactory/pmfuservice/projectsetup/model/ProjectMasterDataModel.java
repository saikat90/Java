package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type project master data model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectMasterDataModel {

    /**
     * ProjectMasterDataModel project id.
     */
    private Integer projectId;

    /**
     * ProjectMasterDataModel project name.
     */
    private String projectName;

    /**
     * ProjectMasterDataModel cdb code.
     */
    private String cdbCode;

    /**
     * ProjectMasterDataModel region.
     */
    private String region;

    /**
     * ProjectMasterDataModel site.
     */
    private String site;

    /**
     * ProjectMasterDataModel product line.
     */
    private String productLine;

    /**
     * ProjectMasterDataModel prsm.
     */
    private String prsm;

    /**
     * ProjectMasterDataModel domain code.
     */
    private String domainCode;

    /**
     * ProjectMasterDataModel market code.
     */
    private String marketCode;

    /**
     * ProjectMasterDataModel material.
     */
    private String material;

    /**
     * ProjectMasterDataModel milestone.
     */
    private String mileStone;

    /**
     * ProjectMasterDataModel applicable.
     */
    private String applicable;

    /**
     * ProjectMasterDataModel duration.
     */
    private Integer duration;

    /**
     * ProjectMasterDataModel needs date.
     */
    private Date needsDate;

    /**
     * ProjectMasterDataModel forecast date.
     */
    private Date forecastDate;

    /**
     * ProjectMasterDataModel actual date.
     */
    private Date actualDate;

    /**
     * ProjectMasterDataModel time.
     */
    private String time;

    /**
     * ProjectMasterDataModel variance.
     */
    private Integer variance;

    /**
     * ProjectMasterDataModel status.
     */
    private String status;
}
