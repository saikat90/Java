package com.alstom.applicationfactory.pmfuservice.masterdata.imports;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.AtSiteService;
import com.alstom.applicationfactory.pmfuservice.util.ImportUtility;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProcessAtSiteImport {

    /**
     * ImportUtility.
     */
    @Autowired
    private ImportUtility importsUtility;
    /**
     * AtSiteService.
     */
    @Autowired
    private AtSiteService atSiteService;

    /**
     * @param atSiteSheet
     * @param atSiteList
     * @param errorList
     */
    public final void processAtSiteData(final XSSFSheet atSiteSheet, final List<AtSite> atSiteList,
            final List<String> errorList) {
        log.debug("Entry:PmfuProcessAtSiteImport:processAtSiteData");
        if (Objects.nonNull(atSiteSheet)) {
            Iterator<Row> rowItr = atSiteSheet.iterator();
            rowItr.next();
            while (rowItr.hasNext()) {
                AtSite atSiteRec = new AtSite();
                Row row = rowItr.next();
                if (row.getRowNum() >= 2) {
                    if (importsUtility.isEmptyRow(row)) {
                        break;
                    }
                    String caratCode = row.getCell(Constants.FOUR) == null ? ""
                            : row.getCell(Constants.FOUR).getStringCellValue();
                    if (caratCode.isEmpty()) {
                        errorList.add("Carat Code is empty in Row " + row.getRowNum());
                    } else if (atSiteService.isCaratCodeExists(caratCode)) {
                        errorList.add("Carat Code " + caratCode + " already exists.");
                    } else {
                        atSiteRec.setVersion(0);
                        atSiteRec.setRegion(
                                row.getCell(0) == null ? "" : row.getCell(0).getStringCellValue());
                        atSiteRec.setCountry(
                                row.getCell(1) == null ? "" : row.getCell(1).getStringCellValue());
                        atSiteRec.setUnit(
                                row.getCell(2) == null ? "" : row.getCell(2).getStringCellValue());
                        atSiteRec.setSite(row.getCell(Constants.THREE) == null ? ""
                                : row.getCell(Constants.THREE).getStringCellValue());
                        atSiteRec.setCaratCode(caratCode);
                        atSiteRec.setCaratName(row.getCell(Constants.FIVE) == null ? ""
                                : row.getCell(Constants.FIVE).getStringCellValue());
                        atSiteRec.setUnitAcronym(row.getCell(Constants.SIX) == null ? ""
                                : row.getCell(Constants.SIX).getStringCellValue());
                        atSiteRec.setBusiness(row.getCell(Constants.SEVEN) == null ? ""
                                : row.getCell(Constants.SEVEN).getStringCellValue());
                        atSiteRec.setInternalMargin(row.getCell(Constants.EIGHT) == null ? 0
                                : (double) row.getCell(Constants.EIGHT).getNumericCellValue());
                        atSiteRec.setKp(row.getCell(Constants.NINE) == null ? 0
                                : (double) row.getCell(Constants.NINE).getNumericCellValue());
                        atSiteRec.setKi(row.getCell(Constants.TEN) == null ? 0
                                : (double) row.getCell(Constants.TEN).getNumericCellValue());
                        atSiteRec.setKnpInternal(row.getCell(Constants.ELEVEN) == null ? 0
                                : (double) row.getCell(Constants.ELEVEN).getNumericCellValue());
                        atSiteRec.setKnpExternal(row.getCell(Constants.TWELVE) == null ? 0
                                : (double) row.getCell(Constants.TWELVE).getNumericCellValue());
                        atSiteRec.setStreet(row.getCell(Constants.THIRTEEN) == null ? ""
                                : row.getCell(Constants.THIRTEEN).getStringCellValue());
                        atSiteRec.setPostCode(row.getCell(Constants.FOURTEEN) == null ? ""
                                : row.getCell(Constants.FOURTEEN).getStringCellValue());
                        atSiteRec.setTown(row.getCell(Constants.FIFTEEN) == null ? ""
                                : row.getCell(Constants.FIFTEEN).getStringCellValue());
                        atSiteRec.setState(row.getCell(Constants.SIXTEEN) == null ? ""
                                : row.getCell(Constants.SIXTEEN).getStringCellValue());
                        atSiteRec.setSegment(row.getCell(Constants.SEVENTEEN) == null ? ""
                                : row.getCell(Constants.SEVENTEEN).getStringCellValue());
                        atSiteRec.setObsUsesSegmentNotRegion(
                                row.getCell(Constants.EIGHTEEN) == null ? false
                                        : row.getCell(Constants.EIGHTEEN).getBooleanCellValue());
                        atSiteRec.setCreatedDate(row.getCell(Constants.NINTEEN) == null ? new Date()
                                : row.getCell(Constants.NINTEEN).getDateCellValue());
                        atSiteRec.setCreatedBy(row.getCell(Constants.TWENTY) == null ? ""
                                : row.getCell(Constants.TWENTY).getStringCellValue());
                        atSiteList.add(atSiteRec);
                    }
                }
            }
            log.debug("Leave:PmfuProcessAtSiteImport:processAtSiteData");
        } else {
            log.error("Error while fetching the Excel Sheet");
            List<ErrorModel> errorModel = new ArrayList<>();
            errorModel.add(new ErrorModel("Error", "Error while fetching the Excel Sheet"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorModel);
        }
    }

    /**
     * @param site
     * @param dataRow
     * @return Row value
     */
    public final Row populateExcelRowValue(final AtSite site, final Row dataRow) {
        dataRow.createCell(0).setCellValue(site.getRegion());
        dataRow.createCell(1).setCellValue(site.getCountry());
        dataRow.createCell(2).setCellValue(site.getUnit());
        dataRow.createCell(Constants.THREE).setCellValue(site.getSite());
        dataRow.createCell(Constants.FOUR).setCellValue(site.getCaratCode());
        dataRow.createCell(Constants.FIVE).setCellValue(site.getCaratName());
        dataRow.createCell(Constants.SIX).setCellValue(site.getUnitAcronym());
        dataRow.createCell(Constants.SEVEN).setCellValue(site.getBusiness());
        Double intMargin = site.getInternalMargin();
        dataRow.createCell(Constants.EIGHT).setCellValue(intMargin != null ? intMargin : 0);
        Double kp = site.getKp();
        dataRow.createCell(Constants.NINE).setCellValue(kp != null ? kp : 0);
        Double ki = site.getKi();
        dataRow.createCell(Constants.TEN).setCellValue(ki != null ? ki : 0);
        Double knpInt = site.getKnpInternal();
        dataRow.createCell(Constants.ELEVEN).setCellValue(knpInt != null ? knpInt : 0);
        Double knpExt = site.getKnpExternal();
        dataRow.createCell(Constants.TWELVE).setCellValue(knpExt != null ? knpExt : 0);
        dataRow.createCell(Constants.THIRTEEN).setCellValue(site.getStreet());
        dataRow.createCell(Constants.FOURTEEN).setCellValue(site.getPostCode());
        dataRow.createCell(Constants.FIFTEEN).setCellValue(site.getTown());
        dataRow.createCell(Constants.SIXTEEN).setCellValue(site.getState());
        dataRow.createCell(Constants.SEVENTEEN).setCellValue(site.getSegment());
        dataRow.createCell(Constants.EIGHTEEN).setCellValue(site.isObsUsesSegmentNotRegion());
        dataRow.createCell(Constants.NINTEEN).setCellValue(
                site.getCreatedDate() != null ? site.getCreatedDate().toString() : "");
        dataRow.createCell(Constants.TWENTY).setCellValue(site.getCreatedBy());
        return dataRow;
    }
}
