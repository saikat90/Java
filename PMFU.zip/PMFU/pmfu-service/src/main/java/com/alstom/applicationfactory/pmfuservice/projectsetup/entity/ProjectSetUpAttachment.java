package com.alstom.applicationfactory.pmfuservice.projectsetup.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type ProjectSetUpAttachment.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "puset_up_attachments")
public class ProjectSetUpAttachment {

    /**
     * ProjectSetUpAttachment id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * ProjectSetUpAttachment version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * ProjectSetUpAttachment file name.
     */
    @Column(name = "attached_file_name")
    private String attachedFileName;

    /**
     * ProjectSetUpAttachment upload successful.
     */
    @Column(name = "upload_successfull", nullable = false)
    private Boolean uploadSuccesfull;

    /**
     * ProjectSetUpAttachment created date.
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     * ProjectSetUpAttachment modified date.
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     * ProjectSetUpAttachment created by.
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     * ProjectSetUpAttachment modified by.
     */
    @Column(name = "updated_by")
    private String modifiedBy;

    /**
     * ProjectSetUpAttachment project set up.
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = Constants.COLUMN_REF_ID, name = "set_of_pusetup_attachments_puset_up_id")
    private ProjectSetUp projectSetUp;

}
