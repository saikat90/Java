package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityContract;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityContractRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.CommodityContractService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author shanmugam.raj
 *
 */
@Service(value = "commodityContractService")
@Transactional
@Slf4j
public class CommodityContractServiceImpl implements CommodityContractService {

    /**
     * CommodityContractRepository.
     */
    @Autowired
    private CommodityContractRepository commodityContractRepository;

    @Override
    public CommodityContractModel createCommodityContract(
            final CommodityContractModel commodityContractModel) {
        log.debug("Entry:CommodityContractServiceImpl:createCommodityContract");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        CommodityContract createdCommodityContract = new CommodityContract();

        CommodityContractModel createdCommodityContractModel = new CommodityContractModel();

        CommodityContract commodityContract = mapper.map(commodityContractModel,
                CommodityContract.class);

        try {
            createdCommodityContract = commodityContractRepository.save(commodityContract);
            createdCommodityContractModel = mapper.map(createdCommodityContract,
                    CommodityContractModel.class);
        } catch (Exception e) {
            log.error("Error while creating record for Commodity Contract");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("Commodity Contract",
                    "Error while creating record for Commodity Contract"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:CommodityContractServiceImpl:createCommodityContract");
        return createdCommodityContractModel;
    }
}
