package com.alstom.applicationfactory.pmfuservice.projectsetup.entity;

import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type ProjectMarket.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "puproject_market")
public class ProjectMarket {
    /**
     * ProjectMarket id.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * ProjectMarket version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * ProjectMarket supplier market code.
     */
    @Column(name = "supplier_market_code", length = Constants.INT_LENGTH_20)
    private String supplierMarketCode;

    /**
     * ProjectMarket domain code.
     */
    @Column(name = "domain_code", length = Constants.INT_LENGTH_10)
    private String domainCode;

    /**
     * ProjectMarket project set up.
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pu_set_up_rev_id ", referencedColumnName = Constants.COLUMN_REF_ID)
    private ProjectSetUp projectSetUp;

    /**
     * ProjectMarket seq number.
     */
    @Column(name = "puset_up_list_of_project_market_seq")
    private Integer listProjectMarketSeq;

    /**
     * ProjectMarket project milestone list.
     */
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = Constants.TABLE_PROJECT_MARKET, cascade = CascadeType.ALL)
    private List<ProjectMilestone> projectMilestoneList;

    /**
     * ProjectMarket commodity contract.
     */
    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY, mappedBy = Constants.TABLE_PROJECT_MARKET, cascade = CascadeType.ALL)
    private CommodityContract commodityContract;

    /**
     * ProjectMarket commodity action plan.
     */
    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY, mappedBy = Constants.TABLE_PROJECT_MARKET, cascade = CascadeType.ALL)
    private CommodityActionPlan commodityActionPlan;
}
