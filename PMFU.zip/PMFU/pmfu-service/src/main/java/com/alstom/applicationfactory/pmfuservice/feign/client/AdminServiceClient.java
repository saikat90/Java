package com.alstom.applicationfactory.pmfuservice.feign.client;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.alstom.applicationfactory.pmfuservice.common.model.BasicSecurityUser;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ApplicationModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.EmailModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProfileModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;

@FeignClient("admin-service")
public interface AdminServiceClient {

    /**
     * Gets profile.
     * 
     * @param code - application code.
     * @return the profile.
     */
    @GetMapping("/applications/{code}/profile")
    ProfileModel getProfile(@PathVariable String code);

    /**
     * Gets authorities.
     * 
     * @param token
     * @param code
     * @param email
     * @return the authorities
     */
    @GetMapping("/application-role-users/authorities")
    Object getAuthorities(@RequestHeader("Authorization") String token, @RequestParam String code,
            @RequestParam String email);

    /**
     * Gets Email.
     * 
     * @param trigger
     * @return the email.
     */
    @GetMapping("/emails/{trigger}")
    EmailModel getEmail(@PathVariable String trigger);

    /**
     * Gets authorized user.
     * 
     * @param token
     * @param applicationCode
     * @param externalApplicationCode
     * @param username
     * @return the authorized user.
     */
    @GetMapping("/basic-auth/{applicationCode}/{externalApplicationCode}/authorized-user")
    BasicSecurityUser getAuthorizedUser(@RequestHeader("Authorization") String token,
            @PathVariable String applicationCode, @PathVariable String externalApplicationCode,
            @RequestParam String username);

    /**
     * Gets Email object.
     * 
     * @param email
     * @return the email object.
     */
    @PutMapping("/emails")
    Object updateEmail(@RequestBody Object email);

    /**
     * Find email by application id object.
     *
     * @param id      the id
     * @param request the request
     * @return the object
     */
    @PostMapping("/emails/{id}/list")
    Object findEmailByApplicationId(@PathVariable String id,
            @RequestBody(required = false) Map<String, Object> request);

    /**
     * Find roles by application id object.
     *
     * @param id      the id
     * @param request the request
     * @return the object
     */
    @PostMapping("/application-roles/application/{id}")
    Object findRolesByApplicationId(@PathVariable String id,
            @RequestBody(required = false) Map<String, Object> request);

    /**
     * Find all users object.
     *
     * @param request the request
     * @return the object
     */
    @PostMapping("/users/list")
    Object findAllUsers(@RequestBody(required = false) Map<String, Object> request);

    /**
     * Find by email list.
     *
     * @param email the email
     * @return the list
     */
    @GetMapping("/users/email/{email}")
    List<Object> findByEmail(@PathVariable String email);

    /**
     * Save all users list.
     *
     * @param users the users
     * @return the list
     */
    @PostMapping("/users/all")
    List<UserModel> saveAllUsers(@RequestBody List<UserModel> users);

    /**
     * Find unmapped application role users object.
     *
     * @param id      the id
     * @param request the request
     * @return the object
     */
    @PostMapping("/users/{id}/unmapped-users")
    Object findUnmappedApplicationRoleUsers(@PathVariable String id,
            @RequestBody Map<String, Object> request);

    /**
     * Find role users list.
     *
     * @param applicationId the application id
     * @param roleCode      the role code
     * @param request       the request
     * @return the list
     */
    @PostMapping("/application-role-users/application/{applicationId}/role/{roleCode}/list")
    Object findRoleUsers(@PathVariable String applicationId, @PathVariable String roleCode,
            @RequestBody(required = false) Map<String, Object> request);

    /**
     * Find users by application role object.
     *
     * @param appRoleId the app role id
     * @param request   the request
     * @return the object
     */
    @PostMapping("/application-role-users/application-role/{appRoleId}")
    Object findUsersByApplicationRole(@PathVariable String appRoleId,
            @RequestBody(required = false) Map<String, Object> request);

    /**
     * Save users for role object.
     *
     * @param applicationRoleUsers the application role users
     * @return the object
     */
    @PostMapping("/application-role-users/all")
    Object saveUsersForRole(@RequestBody Object applicationRoleUsers);

    /**
     * Update users for role object.
     *
     * @param applicationRoleUsers the application role users
     * @return the object
     */
    @PutMapping("/application-role-users/all")
    Object updateUsersForRole(@RequestBody Object applicationRoleUsers);

    /**
     * @param id
     * @return ApplicationModel
     */
    @GetMapping("/applications/{id}")
    ApplicationModel findById(@PathVariable String id);

    /**
     * Gets unmapped rights for application role user.
     *
     * @param appId                 the app id
     * @param applicationRoleUserId the application role user id
     * @param request               the request
     * @return the unmapped rights for application role user
     */
    @PostMapping("/rights/{appId}/user/{applicationRoleUserId}/unmapped")
    Object getUnmappedRightsForApplicationRoleUser(@PathVariable String appId,
            @PathVariable String applicationRoleUserId,
            @RequestBody(required = false) Map<String, Object> request);

    /**
     * Save application role rights object.
     *
     * @param applicationRoleUserRightsModels the application role user rights
     *                                        models
     * @return the object
     */
    @PostMapping("/application-role-user-rights")
    Object saveApplicationRoleRights(@RequestBody Object applicationRoleUserRightsModels);

    /**
     * Update application role rights object.
     *
     * @param applicationRoleUserRightsModels the application role user rights
     *                                        models
     * @return the object
     */
    @PutMapping("/application-role-user-rights")
    Object updateApplicationRoleRights(@RequestBody Object applicationRoleUserRightsModels);

    /**
     * List application role user rights object.
     *
     * @param appRoleUserId the app role user id
     * @param request       the request
     * @return the object
     */
    @PostMapping("/application-role-user-rights/{appRoleUserId}")
    Object listApplicationRoleUserRights(@PathVariable String appRoleUserId,
            @RequestBody(required = false) Map<String, Object> request);

}
