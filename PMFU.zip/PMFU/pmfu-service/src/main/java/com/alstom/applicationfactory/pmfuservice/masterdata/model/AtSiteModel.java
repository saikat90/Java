package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type ATSite Model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AtSiteModel {
    /**
     * SiteModel id.
     */
    private UUID id;

    /**
     * SiteModel version.
     */
    private Integer version;

    /**
     * SiteModel region.
     */
    private String region;

    /**
     * SiteModel country.
     */
    private String country;

    /**
     * SiteModel unit.
     */
    private String unit;

    /**
     * SiteModel site.
     */
    private String site;

    /**
     * SiteModel carat code.
     */
    @NotNull(message = Constants.CARAT_CODE_NOTEMPTY)
    private String caratCode;

    /**
     * SiteModel carat name.
     */
    private String caratName;

    /**
     * SiteModel unit acronym.
     */
    private String unitAcronym;

    /**
     * SiteModel business.
     */
    private String business;

    /**
     * SiteModel internal margin.
     */
    private Double internalMargin;

    /**
     * SiteModel kp.
     */
    private Double kp;

    /**
     * SiteModel ki.
     */
    private Double ki;

    /**
     * SiteModel knp Internal.
     */
    private Double knpInternal;

    /**
     * SiteModel knpExternal.
     */
    private Double knpExternal;

    /**
     * SiteModel street.
     */
    private String street;

    /**
     * SiteModel post code.
     */
    private String postCode;

    /**
     * SiteModel town.
     */
    private String town;

    /**
     * SiteModel state.
     */
    private String state;

    /**
     * SiteModel segment.
     */
    private String segment;

    /**
     * SiteModel obs uses segment.
     */
    private boolean obsUsesSegmentNotRegion;

    /**
     * SiteModel created date.
     */
    private Date createdDate;

    /**
     * SiteModel modified date.
     */
    private Date modifiedDate;

    /**
     * SiteModel created by.
     */
    private String createdBy;

    /**
     * SiteModel modified by.
     */
    private String modifiedBy;
}
