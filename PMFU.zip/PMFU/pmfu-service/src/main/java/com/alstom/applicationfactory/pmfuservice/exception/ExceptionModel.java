package com.alstom.applicationfactory.pmfuservice.exception;

import java.util.Date;
import java.util.List;

import lombok.Getter;

@Getter
public class ExceptionModel {
    /**
     * Http error code.
     */
    private final int errorCode;
    /**
     * Timestamp details.
     */
    private final Date timestamp;
    /**
     * Status code.
     */
    private final String status;
    /**
     * List of errors.
     */
    private final List<ErrorModel> errors;

    /**
     * Parametrized constructor.
     *
     * @param errCode   Error code(int)
     * @param sts       Status code(String)
     * @param errorList List of errors
     */
    public ExceptionModel(final int errCode, final String sts, final List<ErrorModel> errorList) {
        super();
        this.errorCode = errCode;
        this.status = sts;
        this.errors = errorList;
        this.timestamp = new Date();
    }

    /**
     * Return timestamp.
     *
     * @return Timestamp
     */
    public String getTimestamp() {
        return this.timestamp.toString();
    }
}
