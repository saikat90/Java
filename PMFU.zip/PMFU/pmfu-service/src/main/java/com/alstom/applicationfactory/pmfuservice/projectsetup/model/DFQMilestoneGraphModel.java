package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type dfq milestone graph model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DFQMilestoneGraphModel {

    /**
     * DFQMilestoneGraphModel on time go.
     */
    private Integer onTimeGo;

    /**
     * DFQMilestoneGraphModel on time no go.
     */
    private Integer onTimeNoGo;

    /**
     * DFQMilestoneGraphModel late go.
     */
    private Integer lateGo;

    /**
     * DFQMilestoneGraphModel late no go.
     */
    private Integer lateNoGo;

    /**
     * DFQMilestoneGraphModel on time not done.
     */
    private Integer onTimeNotDone;

    /**
     * DFQMilestoneGraphModel late not done.
     */
    private Integer lateNotDone;

    /**
     * DFQMilestoneGraphModel milestone type.
     */
    private String mileStoneType;

}
