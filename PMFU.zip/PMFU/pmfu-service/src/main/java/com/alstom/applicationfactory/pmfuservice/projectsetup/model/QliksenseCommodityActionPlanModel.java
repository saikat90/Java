package com.alstom.applicationfactory.pmfuservice.projectsetup.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type QliksenseCommodityActionPlan model.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QliksenseCommodityActionPlanModel {

    /**
     * QliksenseCommodityActionPlanModel project id.
     */
    private Integer projectId;

    /**
     * QliksenseCommodityActionPlanModel project name.
     */
    private String projectName;

    /**
     * QliksenseCommodityActionPlanModel cdb code.
     */
    private String cdbCode;

    /**
     * QliksenseCommodityActionPlanModel region.
     */
    private String region;

    /**
     * QliksenseCommodityActionPlanModel site.
     */
    private String site;

    /**
     * QliksenseCommodityActionPlanModel product line.
     */
    private String productLine;

    /**
     * QliksenseCommodityActionPlanModel last update.
     */
    private Date lastUpdate;

    /**
     * QliksenseCommodityActionPlanModel project description.
     */
    private String projectDescription;

    /**
     * QliksenseCommodityActionPlanModel prsm.
     */
    private String prSm;

    /**
     * QliksenseCommodityActionPlanModel prsm deputy.
     */
    private String prSmDeputy;

    /**
     * QliksenseCommodityActionPlanModel pm.
     */
    private String pm;

    /**
     * QliksenseCommodityActionPlanModel prpm.
     */
    private String prPm;

    /**
     * QliksenseCommodityActionPlanModel wpc.
     */
    private String wpc;

    /**
     * QliksenseCommodityActionPlanModel prscl.
     */
    private String prScl;

    /**
     * QliksenseCommodityActionPlanModel prqsm.
     */
    private String prQsm;

    /**
     * QliksenseCommodityActionPlanModel prem.
     */
    private String prEm;

    /**
     * QliksenseCommodityActionPlanModel prscm.
     */
    private String prScm;

    /**
     * QliksenseCommodityActionPlanModel tsm.
     */
    private String tsm;

    /**
     * QliksenseCommodityActionPlanModel pridm.
     */
    private String prIdm;

    /**
     * QliksenseCommodityActionPlanModel prom.
     */
    private String prOm;

    /**
     * QliksenseCommodityActionPlanModel prism.
     */
    private String prIsm;

    /**
     * QliksenseCommodityActionPlanModel domain.
     */
    private String domain;

    /**
     * QliksenseCommodityActionPlanModel market code.
     */
    private String marketCode;

    /**
     * QliksenseCommodityActionPlanModel creation date.
     */
    private Date creationDate;

    /**
     * QliksenseCommodityActionPlanModel pic.
     */
    private String pic;

    /**
     * QliksenseCommodityActionPlanModel action description.
     */
    private String actionDescription;

    /**
     * QliksenseCommodityActionPlanModel priority.
     */
    private String priority;

    /**
     * QliksenseCommodityActionPlanModel status.
     */
    private String status;

    /**
     * QliksenseCommodityActionPlanModel target.
     */
    private Date target;

    /**
     * QliksenseCommodityActionPlanModel material.
     */
    private String material;

}