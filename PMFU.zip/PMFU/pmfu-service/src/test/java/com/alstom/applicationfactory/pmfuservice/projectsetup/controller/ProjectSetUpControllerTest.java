package com.alstom.applicationfactory.pmfuservice.projectsetup.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMarketModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpAttachmentModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectSetUpService;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(ProjectSetUpController.class)
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
class ProjectSetUpControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProjectSetUpService projectSetUpService;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @MockBean
    private ProjectSetUpRepository projectSetUpRepository;
    @MockBean
    private Authentication authentication;
    @MockBean
    private EmailServiceClient emailServiceClient;

    private String emailProp = "test@alstomgroup.com";

    @Autowired
    private WebApplicationContext context;

    ObjectMapper mapper = new ObjectMapper();

    UUID uuid = UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8");

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);
    }

    AtSiteModel atSiteObj1 = new AtSiteModel(
            UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0, "Asia Pacific", "China",
            "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
            null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
            null, null);

    AtSiteModel atSiteObj2 = new AtSiteModel(
            UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0, "Asia Pacific", "China",
            "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
            null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
            null, null);

    ProjectModel projectObj1 = new ProjectModel(1L, "CTS302",
            "TEST FOR PMS  INTERFACE - Sustaining Project", null, "HQ ALSTOM Transport SA FR",
            true);
    ProjectModel projectObj2 = new ProjectModel(2L, "CT2270",
            "TEST FOR PMS  INTERFACE - Customer Project", "RFI - Rete Ferroviaria Italiana",
            "IS Bologna IT", true);

    UserModel userObj1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "100777182", "test", "t1", "test1@alstomgroup.com", "IS&T Project CoE");
    UserModel userObj2 = new UserModel(UUID.fromString("002cb1ba-b6e8-efc4-f22e-571d5ebdc902"),
            "228638", "test2", "t2", "test1@alstomgroup.com", "HQ-Operational Excellence-OPEX");

    ProjectMarketModel projectMarketModelObj1 = new ProjectMarketModel(
            UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"), 0, "A535", "A06", null, null,
            null, null, null);
    ProjectMarketModel projectMarketModelObj2 = new ProjectMarketModel(
            UUID.fromString("00362613-e283-ec50-48d5-c536b13c0e48"), 1, "B000", "A01", null, null,
            null, null, null);

    ProjectSetUpAttachmentModel projectSetUpAttachmentObj1 = new ProjectSetUpAttachmentModel(
            UUID.fromString("1923ddd1-d4b6-4e47-89bc-ac50ec68e5d8"), 0, "Dummy-5.pdf", true,
            new Date(), new Date(), "100769630", null, null);
    // ProjectSetUpAttachmentModel projectSetUpAttachmentObj2 = new
    // ProjectSetUpAttachmentModel(UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"));

    @MockBean
    private UserRepository userRepository;

    // private String emailProp;

    @Test
    public void testsearchProjectSetUp() throws Exception {
        List ObjProjectMarketList = new ArrayList();
        List<ProjectSetUpAttachmentModel> projectSetUpAttachmentList = new ArrayList<>();

        ObjProjectMarketList.add(projectMarketModelObj1);
        ObjProjectMarketList.add(projectMarketModelObj2);

        projectSetUpAttachmentList.add(projectSetUpAttachmentObj1);

        ProjectSetUpModel updatedProjectSetUpListModel = new ProjectSetUpModel(
                UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8"), 22, 147, projectObj1,
                "France - RATP - E-Bus", atSiteObj1, "ROLLING_STOCK",
                "Faces chaudronnerie du Projet Aptis - eBus - 02/09/2019 :"
                        + " Changement TF : 88 bus. mai 2019:Tranche ferme : 32 bus "
                        + "//Tranche conditionnelle : 68 bus 15/09/2019 : Décalage planning de"
                        + " 2 mois, 1er besoin à mi février 2020",
                userObj1, null, null, null, null, null, null, null, null, null, null, null, null,
                new Date(), new Date(), null, null, ObjProjectMarketList,
                projectSetUpAttachmentList);

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        RequestModel requestModel = RequestMapper.map(request1);
        when(projectSetUpService.searchProjectSetUp(requestModel))
                .thenReturn(updatedProjectSetUpListModel);
        RequestBuilder request = MockMvcRequestBuilders.post("/projectSetUp/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testviewProjectSetUp() throws Exception {
        List ObjProjectMarketList = new ArrayList();
        List<ProjectSetUpAttachmentModel> projectSetUpAttachmentList = new ArrayList<>();

        ObjProjectMarketList.add(projectMarketModelObj1);
        ObjProjectMarketList.add(projectMarketModelObj2);

        projectSetUpAttachmentList.add(projectSetUpAttachmentObj1);

        ProjectSetUpModel updatedProjectSetUpListModel = new ProjectSetUpModel(
                UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8"), 22, 147, projectObj1,
                "France - RATP - E-Bus", atSiteObj1, "ROLLING_STOCK",
                "Faces chaudronnerie du Projet Aptis - eBus - 02/09/2019 :"
                        + " Changement TF : 88 bus. mai 2019:Tranche ferme : 32 bus "
                        + "//Tranche conditionnelle : 68 bus 15/09/2019 : Décalage planning de"
                        + " 2 mois, 1er besoin à mi février 2020",
                userObj1, null, null, null, null, null, null, null, null, null, null, null, null,
                new Date(), new Date(), null, null, ObjProjectMarketList,
                projectSetUpAttachmentList);

        when(projectSetUpService
                .viewProjectSetUp(UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8")))
                        .thenReturn(updatedProjectSetUpListModel);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/projectSetUp/021ae86d-7578-0c1d-e986-d6d7212205d8")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testdeleteProjectSetUpById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/projectSetUp/021ae86d-7578-0c1d-e986-d6d7212205d8")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());

    }

    @Test
    public void testlistMyProjectSetUp() throws Exception {

        List ObjProjectMarketList = new ArrayList();
        List<ProjectSetUpAttachmentModel> projectSetUpAttachmentList = new ArrayList<>();

        ObjProjectMarketList.add(projectMarketModelObj1);
        ObjProjectMarketList.add(projectMarketModelObj2);

        projectSetUpAttachmentList.add(projectSetUpAttachmentObj1);

        ProjectSetUpModel updatedProjectSetUpListModel = new ProjectSetUpModel(
                UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8"), 22, 147, projectObj1,
                "France - RATP - E-Bus", atSiteObj1, "ROLLING_STOCK",
                "Faces chaudronnerie du Projet Aptis - eBus - 02/09/2019 :"
                        + " Changement TF : 88 bus. mai 2019:Tranche ferme : 32 bus "
                        + "//Tranche conditionnelle : 68 bus 15/09/2019 : Décalage planning de"
                        + " 2 mois, 1er besoin à mi février 2020",
                userObj1, null, null, null, null, null, null, null, null, null, null, null, null,
                new Date(), new Date(), null, null, ObjProjectMarketList,
                projectSetUpAttachmentList);

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        RequestModel requestModel = RequestMapper.map(request1);
        when(projectSetUpService.searchProjectSetUp(requestModel))
                .thenReturn(updatedProjectSetUpListModel);
        RequestBuilder request2 = MockMvcRequestBuilders.post("/projectSetUp/listMyProjects")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request2).andReturn();

        assertEquals(406, result.getResponse().getStatus());
    }

    @Disabled
    @Test
    public void testdeleteProjectMileStone() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.delete(
                "/projectSetUp/021ae86d-7578-0c1d-e986-d6d7212205d8/047d2fea-f2e3-e940-5099-03245d371b62")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andReturn();

        assertEquals(406, result.getResponse().getStatus());
    }

    @Disabled
    @Test
    public void testsaveProjectSetUp() throws Exception {
        List ObjProjectMarketList = new ArrayList();
        List<ProjectSetUpAttachmentModel> projectSetUpAttachmentList = new ArrayList<>();

        ObjProjectMarketList.add(projectMarketModelObj1);
        ObjProjectMarketList.add(projectMarketModelObj2);

        projectSetUpAttachmentList.add(projectSetUpAttachmentObj1);

        ProjectSetUpModel updatedProjectSetUpListModel = new ProjectSetUpModel(
                UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8"), 22, 147, projectObj1,
                "France - RATP - E-Bus", atSiteObj1, "ROLLING_STOCK",
                "Faces chaudronnerie du Projet Aptis - eBus - 02/09/2019 :"
                        + " Changement TF : 88 bus. mai 2019:Tranche ferme : 32 bus "
                        + "//Tranche conditionnelle : 68 bus 15/09/2019 : Décalage planning de"
                        + " 2 mois, 1er besoin à mi février 2020",
                userObj1, null, null, null, null, null, null, null, null, null, null, null, null,
                new Date(), new Date(), null, null, ObjProjectMarketList,
                projectSetUpAttachmentList);

        ProjectSetUpModel projectSetUpListModel = new ProjectSetUpModel(null, 22, 147, projectObj1,
                "France - RATP - E-Bus", atSiteObj1, "ROLLING_STOCK",
                "Faces chaudronnerie du Projet Aptis - eBus - 02/09/2019 :"
                        + " Changement TF : 88 bus. mai 2019:Tranche ferme : 32 bus "
                        + "//Tranche conditionnelle : 68 bus 15/09/2019 : Décalage planning de"
                        + " 2 mois, 1er besoin à mi février 2020",
                userObj1, null, null, null, null, null, null, null, null, null, null, null, null,
                new Date(), new Date(), null, null, ObjProjectMarketList,
                projectSetUpAttachmentList);

        String email = "test@alstomgroup.com";

        String json = mapper.writeValueAsString(updatedProjectSetUpListModel);

        when(projectSetUpService.saveProjectSetUp(projectSetUpListModel, email))
                .thenReturn(updatedProjectSetUpListModel);

        RequestBuilder request = MockMvcRequestBuilders.post("/projectSetUp")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Disabled
    @Test
    public void testdeletePuActionById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.delete(
                "/projectSetUp/021ae86d-7578-0c1d-e986-d6d7212205d8/00e1286c-88e9-7a24-9e6b-f8a1365fcfab")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andReturn();

        assertEquals(406, result.getResponse().getStatus());
    }

    @Test
    public void testdeleteContractById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.delete(
                "/projectSetUp/021ae86d-7578-0c1d-e986-d6d7212205d8/contracts/00e1286c-88e9-7a24-9e6b-f8a1365fcfab")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andReturn();
        assertEquals(406, result.getResponse().getStatus());
    }

}
