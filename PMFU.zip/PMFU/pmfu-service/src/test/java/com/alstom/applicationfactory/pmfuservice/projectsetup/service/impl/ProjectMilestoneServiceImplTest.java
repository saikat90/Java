package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.Project;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityActionPlan;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityContract;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityStatus;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.Contracts;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUp;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUpAttachment;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.PuActions;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityActionPlanRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityContractRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityStatusRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ContractsRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMarketRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMilestoneRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpRepository;

@ExtendWith(MockitoExtension.class)
class ProjectMilestoneServiceImplTest {

    @InjectMocks
    private ProjectMilestoneServiceImpl projectMilestoneService;
    @Mock
    private ProjectSetUpRepository projectSetUpRepository;

    @Mock
    private ProjectMarketRepository projectMarketRepository;

    @Mock
    private CommodityStatusRepository commodityStatusRepository;

    @Mock
    private ProjectMilestoneRepository projectMilestoneRepository;

    @Mock
    private CommodityActionPlanRepository commodityActionPlanRepository;

    @Mock
    private CommodityContractRepository commodityContractRepository;

    @Mock
    private ContractsRepository contractsRepository;

    Project project = new Project(Long.valueOf(147), "CT3835", "Mexico - Mexico - Ferromex ILPAC", "Rail Control",
            "Alstom Transport Mexico", false);
    AtSite site = new AtSite(UUID.fromString("1dec4272-5226-19fc-2c54-4e411a38c219"), 0, "Latin America", "Mexico",
            "Alstom Transport Mexico", "Mexico", "5323", "test", "test", "Rail Services", Double.valueOf(0),
            Double.valueOf(0), Double.valueOf(0), Double.valueOf(0), Double.valueOf(0), "test", "test", "test", "test",
            "test", false, new Date(), new Date(), "165809", "165809");
    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");
    User user2 = new User(UUID.fromString("54c22bf5-dd12-9a00-7f1c-933bb85a5b2d"), "100769630", "User B", "LastName",
            "user.b@alstomgroup.com", "IS&T Project CoE");

    CommodityContract commodityContract = new CommodityContract(UUID.fromString("f1581fbf-eb60-5fde-5129-0566381bb537"),
            0, "test", null, null);
    Contracts contract = new Contracts(UUID.fromString("5d3f5473-6217-0586-6303-4d445c37d53c"), 0, "Capteur de vitesse",
            "PO", "NO", "SINGED", "NOT_SENT", "NOT_RECEIVED", "NOT_RECEIVED", "RECEIVED", "NOT_APPLICABLE", "test",
            commodityContract);
    Contracts contract2 = new Contracts(UUID.fromString("5d3f5473-6217-0586-6303-4d445c37d55d"), 0, "Test material",
            "PO", "NO", "SINGED", "SENT", "RECEIVED", "RECEIVED", "RECEIVED", "NOT_APPLICABLE", "test",
            commodityContract);

    CommodityActionPlan commodityActionPlan = new CommodityActionPlan(
            UUID.fromString("202cb812-48e5-37a6-ed0b-b9e8ac6617c7"), 0, "Test Name", "User A", "user B", "user C", null,
            null);
    PuActions actions = new PuActions(UUID.fromString("deb365c3-0937-b6b6-2297-2162200d8728"), 0, new Date(),
            "Assia EL-HOUSSAME", "Place PO for Capteur", "1", new Date(), "OPEN", commodityActionPlan, "Capteur",
            new Date());

    @SuppressWarnings("deprecation")
    Date needsdate = new Date(2020, 07, 15);
    Calendar calendar = Calendar.getInstance();
    Date actualdate = calendar.getTime();

    CommodityStatus commodityStatus = new CommodityStatus(UUID.fromString("d59bf831-6a66-3081-4aea-5c16b9258055"), 0,
            "Capteur de vitesse", "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X", new Date(), "X",
            "Duration", null, 0, 0, 28, 1, 2, 3, 0, 0, 5, 1, new Date(), 80, "Needs", new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
            new Date(), new Date(), "Actual Date", new Date(), new Date(), new Date(), new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), "Status",
            "RECEIVED", "GO", "NO_GO", "GO", "GO", "NO_GO", "GO", "NO_GO", "GO", "NO_GO", "GO", null, "NOT_DELIVERED",
            "Status Color", "0xFF008000", "0xFF008000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", null, 0,
            "Forecast Title", new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), new Date());

    CommodityStatus commodityStatus2 = new CommodityStatus(UUID.fromString("d59bf831-6a66-3081-4aea-5c16b9258055"), 0,
            "Capteur de vitesse", "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X", needsdate, "X",
            "Duration", null, 0, 0, 28, 1, 2, 3, 0, 0, 5, 1, needsdate, 80, "Needs", needsdate, needsdate, needsdate,
            needsdate, needsdate, needsdate, needsdate, needsdate, needsdate, needsdate, needsdate, needsdate,
            needsdate, "Actual Date", null, null, null, null, null, null, null, null, null, null, null, null, null,
            "Status", "RECEIVED", "GO", "NO_GO", "GO", "GO", "NO_GO", "GO", "NO_GO", "GO", "NO_GO", "GO", null,
            "NOT_DELIVERED", "Status Color", "0xFF008000", "0xFF008000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", null, 0, "Forecast Title", new Date(), new Date(), new Date(), new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date());

    ProjectMilestone projectMileStone = new ProjectMilestone(UUID.fromString("e35e813d-b745-5f67-46c4-3dc9ec969d8b"), 0,
            "Capteur de vitesse", "0xFFFF0000", "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", needsdate, "B856", "Data Recording & Odometry",
            "B01", "Digital Mobility", "Global", "OMEDEI Davide", "test", "test", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21,
            "SNCF - France - TGV du futur", null, 0, "CT3320", 29, commodityStatus);

    ProjectMilestone projectMileStone1 = new ProjectMilestone(UUID.fromString("e35e813d-b745-5f67-46c4-3dc9ec969d9c"),
            0, "test", "0xFFFF0000", "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", needsdate, "B856", "Data Recording & Odometry", "B01",
            "Digital Mobility", "Global", "OMEDEI Davide", "test", "test", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21,
            "SNCF - France - TGV du futur", null, 0, "CT3320", 29, commodityStatus);

    ProjectMarket projectMarket = new ProjectMarket(UUID.fromString("0fed00e2-083f-ea1d-a97c-3800e968ecbf"), 0, "B856",
            "B01", null, 0, Arrays.asList(projectMileStone), commodityContract, commodityActionPlan);

    ProjectSetUp projectSetUp = new ProjectSetUp(UUID.fromString("478895ca-2d96-7b65-b5e7-d7d9d1dbca28"), 0, 29,
            project, "Test", site, "ROLLING_STOCK", "PMFU for AVELIA", user, "Test Name", "User A", "user B", "user C",
            "Test Name", "User A", "user B", "user C", user2, "Test Name", "User A", "user B", new Date(), new Date(),
            "100769630", "100777182", Arrays.asList(projectMarket), null);

    ProjectSetUpAttachment projectSetUpAttachment = new ProjectSetUpAttachment(
            UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b"), 0, "Dummy.pdf", true, new Date(), new Date(),
            "100769630", "test", projectSetUp);
    UUID projSetUpId = UUID.fromString("478895ca-2d96-7b65-b5e7-d7d9d1dbca28");

    @Test
    public void testisProjectIDAndCdbCodeExists() {
        when(projectSetUpRepository.findByProjectId(projectSetUp.getProjectId())).thenReturn(projectSetUp);
        assertThat(projectMilestoneService.isProjectIDAndCdbCodeExists(29, "CT3835")).isEqualTo(true);
    }

    @Test
    public void testisProjectIDAndCdbCodeExistsForFalse() {
        assertThat(projectMilestoneService.isProjectIDAndCdbCodeExists(29, "CT3840")).isEqualTo(false);
    }

    @Test
    public void testisProjectIDAndCdbCodeExistsForCatch() {
        when(projectSetUpRepository.findByProjectId(projectSetUp.getProjectId()))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> projectMilestoneService.isProjectIDAndCdbCodeExists(29, "CT3840"), "");
    }

    @Test
    public void testisMarketCodeAndMaterialExists() {
        when(projectMilestoneRepository.findByMarketCodeAndMaterial(29, "B856", "Capteur de vitesse"))
                .thenReturn(projectMileStone);
        ProjectMilestone expectedProjectMilestone = projectMilestoneService.isMarketCodeAndMaterialExists(29, "B856",
                "Capteur de vitesse");
        assertNotNull(expectedProjectMilestone);
    }

    @Test
    public void testisMarketCodeAndMaterialExistsForNull() {
        ProjectMilestone expectedProjectMilestone = projectMilestoneService.isMarketCodeAndMaterialExists(29, "B856",
                "Capteur de vitesse");
        assertNull(expectedProjectMilestone);
    }

    @Test
    public void testisMarketCodeAndMaterialExistsForCatch() {
        when(projectMilestoneRepository.findByMarketCodeAndMaterial(29, "B856", "Capteur de vitesse"))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> projectMilestoneService.isMarketCodeAndMaterialExists(29, "B856", "Capteur de vitesse"), "");
    }

    @Test
    public void testimportCommodityStatusRecord() {
        CommodityStatus commodityStatus = new CommodityStatus(UUID.fromString("001f2256-8e68-2c42-8d21-52de693e7863"),
                2, "Stockeur 660V LiOn 100 kWh fin de vie", "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", null,
                null, null, null, null, "Duration", null, 14, 90, 10, 0, 0, 0, 690, 0, 0, 0, null, 30, "Needs",
                new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
                new Date(), new Date(), new Date(), new Date(), new Date(), "Actual Date", new Date(), new Date(),
                new Date(), new Date(), null, null, null, null, null, null, null, null, null, "Status", "RECEIVED",
                "GO", "GO", "GO", null, null, null, null, null, null, null, null, null, "Status Color", "0xFF008000",
                "0xFF008000", "0xFFFFFF00", "0xFFFFFF00", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFFFFFF", null,
                null, null, null, null, null, 0, "Forecast Date", null, null, null, null, null, null, null, null, null,
                null, null, null, null);

        ProjectMilestone projectMilestone = new ProjectMilestone(
                UUID.fromString("0001b25c-d6de-15b7-7d2b-7bdc00eef05b"), 0, "Input Inductor - air core", null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, "CHCP", null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, null, null, null, null, null, null);
        // assertThat(projectMilestoneService.importCommodityStatusRecord(projectMilestone))
        // .isEqualTo(commodityStatus);
    }

    @Test
    public void testsaveImportedMilestoneRecords() {
        Map<String, List<ProjectMilestone>> puproject_market_projectMilestoneMap = new HashMap<>();

        ProjectMilestone projectMilestone = new ProjectMilestone(
                UUID.fromString("0001b25c-d6de-15b7-7d2b-7bdc00eef05b"), 0, "Input Inductor - air core", null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, "CHCP", null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, null, null, null, null, null, null);
        projectMilestoneService.saveImportedMilestoneRecords(puproject_market_projectMilestoneMap);
    }

}
