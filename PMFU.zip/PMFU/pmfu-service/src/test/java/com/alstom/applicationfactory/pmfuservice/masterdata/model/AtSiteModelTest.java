package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.Date;
import java.util.UUID;

import org.junit.jupiter.api.Test;

class AtSiteModelTest {
	
	private UUID id  = UUID.fromString("00714906-efad-919a-b474-cf4668633afc");
	
	private Integer version = 0;
	
	private String region = "Asia Pacific";
	
	private String country = "China";
	
	private String unit = "Shanghai Alstom Transport Co Ltd";
	
	private String site  = "Shanghai";
	
	private String caratCode = "5949";
	
	private String caratName = null;
	
	private String unitAcronym = null;
	
	private String business = "Trains";
	
	private Double internalMargin = null;
	
	private Double kp = null;
	
	private Double ki = null;
	
	private Double knpInternal = null;
	
	private Double knpExternal = null;
	
	private String street = null;
	
	private String postCode = null;
	
	private String town = null;
	
	private String state = null;
	
	private String segment = null;
	
	private boolean obsUsesSegmentNotRegion = false;
	
	private Date createdDate = new Date();
	
	private Date modifiedDate = new Date();
	
	private String createdBy = "165811";
	
	private String modifiedBy = null;
	
	 public AtSiteModel createTestSuite() {
	        return new AtSiteModel();
	    }

	    @Test
	    void testHashCode() {
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	       
	    	atSiteModel = createTestSuite();
	    	atSiteModel.hashCode();
	    }

	    
	    @Test
	    void testGetId() {
	    	AtSiteModel atSiteModel = null;
	    	atSiteModel = createTestSuite();
	        id = atSiteModel.getId();
	    }

	   
	    @Test
	    void testGetVersion() {
	        AtSiteModel atSiteModel = null;
	        atSiteModel = createTestSuite();
	        version = atSiteModel.getVersion();
	    }

	   
	    @Test
	    void testGetRegion() {
	        String region = "";
	        AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	       
	        atSiteModel = createTestSuite();
	        region = atSiteModel.getRegion();
	    }

	   
	    @Test
	    void testCountry() {
	    	String country = "";
	        AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        country = atSiteModel.getCountry();
	    }

	   
	    @Test
	    void testUnit() {
	    	String unit = "";
	        AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        unit = atSiteModel.getUnit();
	    }

	    
	    @Test
	    void testSite() {
	    	String site  = "";
	        AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        site = atSiteModel.getSite();
	    }

	   
	    @Test
	    void testCaratCode() {
	    	String caratCode = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        caratCode = atSiteModel.getCaratCode();
	    }
	   
	    @Test
	    void testCaratName() {
	    	String caratName = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        caratName = atSiteModel.getCaratName();
	    }
	    
	    @Test
	    void testUnitAcronym() {
	    	String unitAcronym = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        unitAcronym = atSiteModel.getUnitAcronym();
	    }
	    
	    @Test
	    void testBusiness() {
	    	String business = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        business = atSiteModel.getBusiness();
	    }
	    
	    @Test
	    void testInternalMargin() {
	    	Double internalMargin = 0.0d;
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        internalMargin = atSiteModel.getInternalMargin();
	    }
	    
	    @Test
	    void testKP() {
	    	Double kp = 0.0d;
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        kp = atSiteModel.getKp();
	    }
	    
	    @Test
	    void testKI() {
	    	Double ki = 0.0d;
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        ki = atSiteModel.getKi();
	    }
	    
	    @Test
	    void testKnpInternal() {
	    	Double knpInternal = 0.0d;
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        knpInternal = atSiteModel.getKnpInternal();
	    }
	    
	    @Test
	    void testKnpExternal() {
	    	Double knpExternal = 0.0d;
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        knpExternal = atSiteModel.getKnpExternal();
	    }
	    
	    @Test
	    void testStreet() {
	    	String street = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        street = atSiteModel.getStreet();
	    }
	    
	    @Test
	    void testPostCode() {
	    	String postCode = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        postCode = atSiteModel.getPostCode();
	    }
	    
	    @Test
	    void testTown() {
	    	String town = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        town = atSiteModel.getTown();
	    }
	    
	    @Test
	    void testState() {
	    	String state = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        state = atSiteModel.getState();
	    }
	    
	    @Test
	    void testSegment() {
	    	String segment = "";
	    	AtSiteModel atSiteModel = new AtSiteModel(id, 0,
	    			"Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null, "Trains",null,null,null,null,null,null,null,null,null,null,false,new Date(),new Date(),null,null);
	        atSiteModel = createTestSuite();
	        caratCode = atSiteModel.getCaratCode();
	    }
	    
	/*
	 * @Test void testCaratCode() { String caratCode = ""; AtSiteModel atSiteModel =
	 * new AtSiteModel(id, 0, "Asia Pacific", "China",
	 * "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null,
	 * "Trains",null,null,null,null,null,null,null,null,null,null,false,new
	 * Date(),new Date(),null,null); atSiteModel = createTestSuite(); caratCode =
	 * atSiteModel.getCaratCode(); }
	 * 
	 * @Test void testCaratCode() { String caratCode = ""; AtSiteModel atSiteModel =
	 * new AtSiteModel(id, 0, "Asia Pacific", "China",
	 * "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null,
	 * "Trains",null,null,null,null,null,null,null,null,null,null,false,new
	 * Date(),new Date(),null,null); atSiteModel = createTestSuite(); caratCode =
	 * atSiteModel.getCaratCode(); }
	 * 
	 * @Test void testCaratCode() { String caratCode = ""; AtSiteModel atSiteModel =
	 * new AtSiteModel(id, 0, "Asia Pacific", "China",
	 * "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null,
	 * "Trains",null,null,null,null,null,null,null,null,null,null,false,new
	 * Date(),new Date(),null,null); atSiteModel = createTestSuite(); caratCode =
	 * atSiteModel.getCaratCode(); }
	 * 
	 * @Test void testCaratCode() { String caratCode = ""; AtSiteModel atSiteModel =
	 * new AtSiteModel(id, 0, "Asia Pacific", "China",
	 * "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,null,
	 * "Trains",null,null,null,null,null,null,null,null,null,null,false,new
	 * Date(),new Date(),null,null); atSiteModel = createTestSuite(); caratCode =
	 * atSiteModel.getCaratCode(); }
	 * 
	 * 
	 * @Test void testSetName() { AtSiteModel atSiteModel = new AtSiteModel();
	 * atSiteModel.setName("Digital Work Instructions"); }
	 * 
	 * 
	 * @Test void testSetCode() { AtSiteModel atSiteModel = new AtSiteModel();
	 * atSiteModel.setCode("APP_PMFU"); }
	 * 
	 * 
	 * @Test void testSetVerified() { AtSiteModel atSiteModel = new AtSiteModel();
	 * atSiteModel.setVerified(true); }
	 * 
	 * 
	 * @Test void testSetDeleted() { AtSiteModel atSiteModel = new AtSiteModel();
	 * atSiteModel.setDeleted(false); }
	 * 
	 * 
	 * @Test void testSetAllowAllUsers() { AtSiteModel atSiteModel = new
	 * AtSiteModel(); atSiteModel.setAllowAllUsers(false); }
	 * 
	 * 
	 * @Test void testEqualsObject() { AtSiteModel atSiteModel = new AtSiteModel(id,
	 * "Digital Work Instructions", "APP_PMFU", true, false, false); atSiteModel =
	 * createTestSuite();
	 * 
	 * AtSiteModel atSiteModel_2 = new AtSiteModel(id, "Digital Work Instructions",
	 * "APP_PMFU", true, false, false);
	 * 
	 * AtSiteModel atSiteModel_3 = new AtSiteModel(id, "Digital Work Instructions",
	 * "APP_PMFU", true, true, false);
	 * 
	 * atSiteModel.equals(atSiteModel_2); atSiteModel.equals(atSiteModel_3); }
	 * 
	 * 
	 * @Test void testCanEqual() { AtSiteModel atSiteModel = new AtSiteModel(id,
	 * "Digital Work Instructions", "APP_PMFU", true, false, false); atSiteModel =
	 * createTestSuite();
	 * 
	 * AtSiteModel atSiteModel_2 = new AtSiteModel(id, "Digital Work Instructions",
	 * "APP_PMFU", true, true, false);
	 * 
	 * atSiteModel.canEqual(atSiteModel_2); }
	 * 
	 * 
	 * @Test void testToString() { AtSiteModel atSiteModel = new AtSiteModel(id,
	 * "Digital Work Instructions", "APP_PMFU", true, false, false); atSiteModel =
	 * createTestSuite();
	 * 
	 * atSiteModel.toString(); }
	 * 
	 * 
	 * @Test void testAtSiteModel() { AtSiteModel atSiteModel = null; atSiteModel =
	 * createTestSuite(); id = atSiteModel.getId(); }
	 * 
	 * 
	 * @Test void testAtSiteModelidStringStringBooleanBooleanBoolean() { AtSiteModel
	 * atSiteModel = new AtSiteModel(id, "Digital Work Instructions", "APP_PMFU",
	 * true, false, false); atSiteModel = createTestSuite(); id =
	 * atSiteModel.getId(); }
	 */
}
