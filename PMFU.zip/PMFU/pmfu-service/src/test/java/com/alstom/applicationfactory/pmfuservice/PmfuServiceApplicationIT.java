package com.alstom.applicationfactory.pmfuservice;

import org.junit.jupiter.api.Test;

class PmfuServiceApplicationIT {

    @Test
    void main() {

    }
}