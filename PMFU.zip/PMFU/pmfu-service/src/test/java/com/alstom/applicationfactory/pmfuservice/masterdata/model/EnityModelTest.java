package com.alstom.applicationfactory.pmfuservice.masterdata.model;

import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.alstom.applicationfactory.pmfuservice.common.model.BasicSecurityUser;
import com.alstom.applicationfactory.pmfuservice.common.model.FilterModel;
import com.alstom.applicationfactory.pmfuservice.common.model.JoinModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.Project;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.UserSearchQuery;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityActionPlan;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityContract;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityStatus;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.Contracts;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUp;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUpAttachment;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.PuActions;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.AllActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityActionPlanModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityStatusModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractStatusGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQDeliveryGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQEventModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQMilestoneGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMarketModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMilestoneModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpAttachmentModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpListModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.PuActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityActionPlanModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityStatusModel;

@ExtendWith(MockitoExtension.class)
class EnityModelTest {

	UUID uuid = UUID.fromString("0087ffde-477c-c89d-30ce-f00d4a99a782");

	Object obj = new Object();

	User userObj = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
			"User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

	ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions",
			"APP_PMFU", true, false, false);

	AtSiteModel atSiteModel = new AtSiteModel(uuid, 0, "Asia Pacific", "China",
			"Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", "name", "unit", "Trains", 0.0d,
			0.0d, 0.0d, 0.0d, 0.0d, "street", "code", "town", "state", "segment", false, new Date(),
			new Date(), "creadted", "updated");

	AtSite atSiteObj = new AtSite(uuid, 0, "Asia Pacific", "China",
			"Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", "name", "unit", "Trains", 0.0d,
			0.0d, 0.0d, 0.0d, 0.0d, "street", "code", "town", "state", "segment", false, new Date(),
			new Date(), "creadted", "updated");

	AtSiteSearchModel stSiteSearchModel = new AtSiteSearchModel(uuid, "America", "site");

	EmailModel emailModel = new EmailModel(Arrays.asList(new String[] { "APPROVER", "VALIDATOR" }),
			"Test Subject", "Test Body");

	MarketCodeMasterDataModel marketCodeMasterDataModel = new MarketCodeMasterDataModel(
			UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
			"Electrical/Electronic catalog parts", "C00", "Indirect Sourcing", "GLOBAL Coordinated",
			"JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21);

	MarketCodeMasterData marketCodeMasterDataObj = new MarketCodeMasterData(
			UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
			"Electrical/Electronic catalog parts", "C00", "Indirect Sourcing", "GLOBAL Coordinated",
			"JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21);

	ProfileModel profileModel = new ProfileModel(
			UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), "Digital Work Instruction",
			"APP_PMFU", "test", "test@alstomgroup.com", null);

	ProjectModel projectModel = new ProjectModel(1L, "CTS302",
			"TEST FOR PMS  INTERFACE - Sustaining Project", "RFI - Rete Ferroviaria Italiana",
			"HQ ALSTOM Transport SA FR", true);

	Project projectObj = new Project(1L, "CTS302", "TEST FOR PMS  INTERFACE - Sustaining Project",
			"RFI - Rete Ferroviaria Italiana", "HQ ALSTOM Transport SA FR", true);

	UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
			"100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

	UserSearchQueryModel userSearchQueryModel = new UserSearchQueryModel(null, userModel,
			"PMFU-Project-CT308", "Project",
			"{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
			false, false, userModel, null, new Date(), new Date(), null, null);

	UserSearchQuery userSearchQuery = new UserSearchQuery(null, userObj, "PMFU-Project-CT308",
			"Project",
			"{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
			false, false, userObj, null, new Date(), new Date(), null, null);

	UserSearchQuery userSearchQueryObj = new UserSearchQuery(null, userObj, "PMFU-Project-CT308",
			"Project",
			"{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
			false, false, userObj, null, new Date(), new Date(), null, null);

	AllActionsModel allActionsModel = new AllActionsModel("Input Inductor - air core", new Date(),
			new Date(), "MA CEDENO",
			"Inviter Satys pour plan d'action retard de 1 mois sur les plans", "1", "OPEN",
			new Date(), 1, "TEST FOR PMS  INTERFACE - Sustaining Project", "CTS302", "PLANCHERS",
			new Date());

	PuActionsModel puActionsModel = new PuActionsModel(
			UUID.fromString("00e1286c-88e9-7a24-9e6b-f8a1365fcfab"), 0, new Date(), "MA CEDENO",
			"Inviter Satys pour plan d'action retard de 1 mois sur les plans", "1", new Date(),
			"OPEN", null, "PLANCHERS", null);
	PuActions puActionsObj = new PuActions(UUID.fromString("00e1286c-88e9-7a24-9e6b-f8a1365fcfab"),
			0, new Date(), "MA CEDENO",
			"Inviter Satys pour plan d'action retard de 1 mois sur les plans", "1", new Date(),
			"OPEN", null, "PLANCHERS", null);

	ProjectMarketModel projectMarketModelModel = new ProjectMarketModel(
			UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"), 0, "A535", "A06", null, null,
			null, null, null);
	ProjectMarket projectMarketModelObj = new ProjectMarket(
			UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"), 0, "A535", "A06", null, null,
			null, null, null);

	CommodityActionPlanModel commodityActionPlanModel = new CommodityActionPlanModel(
			UUID.fromString("0014fed8-0c4a-5f71-92dd-ca64de4cf341"), 0, "buyerName",
			"commodityManagerName", "spqdName", "engName", projectMarketModelModel, null);

	CommodityActionPlan commodityActionPlanObj = new CommodityActionPlan(
			UUID.fromString("0014fed8-0c4a-5f71-92dd-ca64de4cf341"), 0, "buyerName",
			"commodityManagerName", "spqdName", "engName", projectMarketModelObj, null);

	Contracts contractObj = new Contracts(UUID.fromString("0018bccd-79b2-70c8-f671-cf188eafbee1"),
			0, "Cabin floor panel / plancher cabine", null, null, null, null, null, null, null,
			null, null, null);

	CommodityContractModel commodityContractModel = new CommodityContractModel(
			UUID.fromString("00105f70-2a6b-4198-88f6-4389bc587eb4"), 10, null,
			projectMarketModelModel, null);
	CommodityContract commodityContractObj = new CommodityContract(
			UUID.fromString("00105f70-2a6b-4198-88f6-4389bc587eb4"), 10, null,
			projectMarketModelObj, null);

	CommodityStatusModel commodityStatusModel = new CommodityStatusModel(
			UUID.fromString("001f2256-8e68-2c42-8d21-52de693e7863"), 2,
			"Stockeur 660V LiOn 100 kWh fin de vie", "SPECIFICATION", "X", "X", "X", "X", "X", "X",
			"X", null, null, null, null, null, "Duration", null, 14, 90, 10, 0, 0, 0, 690, 0, 0, 0,
			null, 30, "Needs", new Date(), new Date(), new Date(), new Date(), new Date(),
			new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
			new Date(), "Actual Date", new Date(), new Date(), new Date(), new Date(), null, null,
			null, null, null, null, null, null, null, "Status", "RECEIVED", "GO", "GO", "GO", null,
			null, null, null, null, null, null, null, null, "Status Color", "0xFF008000",
			"0xFF008000", "0xFFFFFF00", "0xFFFFFF00", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
			"0xFFFFFFFF", null, null, null, null, null, null, 0, "Forecast Date", null, null, null,
			null, null, null, null, null, null, null, null, null, null);

	CommodityStatus commodityStatusObj = new CommodityStatus(
			UUID.fromString("001f2256-8e68-2c42-8d21-52de693e7863"), 2,
			"Stockeur 660V LiOn 100 kWh fin de vie", "SPECIFICATION", "X", "X", "X", "X", "X", "X",
			"X", null, null, null, null, null, "Duration", null, 14, 90, 10, 0, 0, 0, 690, 0, 0, 0,
			null, 30, "Needs", new Date(), new Date(), new Date(), new Date(), new Date(),
			new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
			new Date(), "Actual Date", new Date(), new Date(), new Date(), new Date(), null, null,
			null, null, null, null, null, null, null, "Status", "RECEIVED", "GO", "GO", "GO", null,
			null, null, null, null, null, null, null, null, "Status Color", "0xFF008000",
			"0xFF008000", "0xFFFFFF00", "0xFFFFFF00", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
			"0xFFFFFFFF", null, null, null, null, null, null, 0, "Forecast Date", null, null, null,
			null, null, null, null, null, null, null, null, null, null);

	ContractsModel contractModel = new ContractsModel(
			UUID.fromString("0018bccd-79b2-70c8-f671-cf188eafbee1"), 0,
			"Cabin floor panel / plancher cabine", null, null, null, null, null, null, null, null,
			null, null);
	Contracts contractModelObj = new Contracts(
			UUID.fromString("0018bccd-79b2-70c8-f671-cf188eafbee1"), 0,
			"Cabin floor panel / plancher cabine", null, null, null, null, null, null, null, null,
			null, null);

	ContractStatusGraphModel contractStatusGraphModel = new ContractStatusGraphModel(1, 0, "yes");

	DFQDeliveryGraphModel dfqDeliveryGraphModel = new DFQDeliveryGraphModel(0, 1, 2, 2, null);

	DFQEventModel dfqEventModel = new DFQEventModel("N505", "rail", "Indirect Sourcing", new Date(),
			new Date(), "2019-01-14 00:00:00", 1, "active");

	DFQMilestoneGraphModel dfqMilestoneGraphModel = new DFQMilestoneGraphModel(0, 1, 2, 2, 1, 1,
			null);

	ProjectMasterDataModel projectMasterDataModel = new ProjectMasterDataModel(87,
			"Algeria - Sidi Bel Abbes Tramway RS", "CT3971", "Latin America", "Santiago",
			"Villeurbanne", "Ilona STELMACH", "A01", "A535", null, null, "yes", 2, new Date(),
			new Date(), new Date(), "2019-01-14 00:00:00", 2, "active");

	ProjectMilestoneModel projectMilestoneModel = new ProjectMilestoneModel(
			UUID.fromString("0001b25c-d6de-15b7-7d2b-7bdc00eef05b"), 0, "Input Inductor - air core",
			null, null, null, null, null, null, null, null, null, null, null, null, null, null,
			null, null, null, null, null, null, null, null, null, null, "CHCP", null, null, null,
			null, null, null, null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null, null,
			null);
	ProjectMilestone projectMilestoneObj = new ProjectMilestone(
			UUID.fromString("0001b25c-d6de-15b7-7d2b-7bdc00eef05b"), 0, "Input Inductor - air core",
			null, null, null, null, null, null, null, null, null, null, null, null, null, null,
			null, null, null, null, null, null, null, null, null, null, "CHCP", null, null, null,
			null, null, null, null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null, null, null, null, null,
			null);

	ProjectSetUpAttachmentModel projectSetUpAttachmentModel = new ProjectSetUpAttachmentModel(
			UUID.fromString("1923ddd1-d4b6-4e47-89bc-ac50ec68e5d8"), 0, "Dummy-5.pdf", true,
			new Date(), new Date(), "100769630", null, null);
	ProjectSetUpAttachment projectSetUpAttachmentObj = new ProjectSetUpAttachment(
			UUID.fromString("1923ddd1-d4b6-4e47-89bc-ac50ec68e5d8"), 0, "Dummy-5.pdf", true,
			new Date(), new Date(), "100769630", null, null);

	ProjectSetUpModel projectSetUpModel = new ProjectSetUpModel(
			UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8"), 22, 147, null,
			"France - RATP - E-Bus", null, "ROLLING_STOCK",
			"Faces chaudronnerie du Projet Aptis - eBus - 02/09/2019 :"
					+ " Changement TF : 88 bus. mai 2019:Tranche ferme : 32 bus "
					+ "//Tranche conditionnelle : 68 bus 15/09/2019 : Décalage planning de"
					+ " 2 mois, 1er besoin à mi février 2020",
			null, null, null, null, null, null, null, null, null, null, null, null, null,
			new Date(), new Date(), null, null, null, null);

	ProjectSetUp projectSetUpObj = new ProjectSetUp(
			UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8"), 22, 147, null,
			"France - RATP - E-Bus", null, "ROLLING_STOCK",
			"Faces chaudronnerie du Projet Aptis - eBus - 02/09/2019 :"
					+ " Changement TF : 88 bus. mai 2019:Tranche ferme : 32 bus "
					+ "//Tranche conditionnelle : 68 bus 15/09/2019 : Décalage planning de"
					+ " 2 mois, 1er besoin à mi février 2020",
			null, null, null, null, null, null, null, null, null, null, null, null, null,
			new Date(), new Date(), null, null, null, null);

	ProjectSetUpListModel projectSetUpListModel = new ProjectSetUpListModel(
			UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8"), 0, 29, projectModel,
			"TEST FOR PMS  INTERFACE - Sustaining Project", atSiteModel, "productLine", userModel,
			new Date(), userModel);

	QliksenseCommodityActionPlanModel qliksenseCommodityActionPlanModel = new QliksenseCommodityActionPlanModel(
			87, "France - SGP - Grand Paris Express - Red Line - MFGG", "CT3971", "region", "site",
			"ROLLING_STOCK", new Date(), "description", "prSm", "prSmDeputy", "pm", "prPm", "wpc",
			"prScl", "prQsm", "prEm", "prScm", "tsm", "prIdm", "prOm", "prIsm", "A0B0",
			"domainName", new Date(), "pic", "actionDescription", "priority", "status", new Date(),
			"material");

	QliksenseCommodityContractModel qliksenseCommodityContractModel = new QliksenseCommodityContractModel(
			87, "projectName", "cdbCode", "region", "site", "productLine", new Date(),
			"description", "prSm", "prSmDeputy", "pm", "prPm", "wpc", "prScl", "prQsm", "prEm",
			"prSCM", "tsm", "prIdm", "prOm", "prISm", "domain", "domainName", "marketCode",
			"marketName", "globalLocal", "material", "contractType", "particularConditions",
			"statusContract", "poRc", "perfBond", "warrantyBond", "ar", "poNrc");

	QliksenseCommodityStatusModel qliksenseCommodityStatusModel = new QliksenseCommodityStatusModel(
			87, "projectName", "cdbCode", "region", "site", "productLine", new Date(),
			"description", "prSm", "prSmDeputy", "pm", "prPm", "wpc", "prScl", "prQsm", "prEm",
			"prScm", "tsm", "prIdm", "prOm", "prIsm", "domainCode", "domainName", "marketCode",
			"marketName", "globalLocal", "material", "mileStone", "applicable", 10, new Date(),
			new Date(), new Date(), "status", "otd", 10);

	BasicSecurityUser basicSecurityUser = new BasicSecurityUser(uuid, "username", "password",
			false);

	FilterModel filterModel = new FilterModel("condition", null);
	JoinModel joinModel = new JoinModel("object", "type", filterModel);

	@Test
	void testEntiyAndModel() {
		userModel.toString();
		userModel.hashCode();
		userObj.toString();
		userObj.hashCode();
		userModel.equals(userModel);
		userModel.equals(null);
		userObj.equals(userObj);
		userObj.equals(null);

		applictionModel.toString();
		applictionModel.hashCode();
		applictionModel.equals(obj);
		applictionModel.equals(emailModel);
		applictionModel.equals(null);

		atSiteModel.toString();
		atSiteModel.hashCode();
		atSiteModel.toString();
		atSiteModel.hashCode();
		atSiteModel.equals(atSiteModel);
		atSiteModel.equals(null);
		atSiteObj.equals(atSiteObj);
		atSiteObj.equals(null);

		stSiteSearchModel.toString();
		stSiteSearchModel.hashCode();
		stSiteSearchModel.equals(obj);
		stSiteSearchModel.equals(stSiteSearchModel);
		stSiteSearchModel.equals(null);

		marketCodeMasterDataModel.toString();
		marketCodeMasterDataModel.hashCode();
		marketCodeMasterDataModel.toString();
		marketCodeMasterDataModel.hashCode();
		marketCodeMasterDataModel.equals(marketCodeMasterDataModel);
		marketCodeMasterDataModel.equals(null);
		marketCodeMasterDataObj.equals(marketCodeMasterDataObj);
		marketCodeMasterDataObj.equals(null);

		userSearchQueryModel.toString();
		userSearchQueryModel.hashCode();
		userSearchQueryObj.toString();
		userSearchQueryObj.hashCode();
		userSearchQueryModel.equals(userSearchQueryModel);
		userSearchQueryModel.equals(null);
		userSearchQueryObj.equals(userSearchQueryObj);
		userSearchQueryObj.equals(null);

		profileModel.toString();
		profileModel.hashCode();
		profileModel.equals(obj);
		profileModel.equals(profileModel);
		profileModel.equals(null);

		projectModel.toString();
		projectModel.hashCode();
		projectModel.toString();
		projectModel.hashCode();
		projectModel.equals(projectModel);
		projectModel.equals(null);
		projectObj.equals(projectObj);
		projectObj.equals(null);

		emailModel.toString();
		emailModel.hashCode();
		emailModel.equals(obj);
		emailModel.equals(emailModel);
		emailModel.equals(null);

		allActionsModel.toString();
		allActionsModel.hashCode();
		allActionsModel.equals(obj);
		allActionsModel.equals(allActionsModel);
		allActionsModel.equals(null);

		contractObj.toString();
		contractObj.hashCode();
		contractObj.equals(obj);
		contractObj.equals(contractObj);
		contractObj.equals(null);

		contractStatusGraphModel.toString();
		contractStatusGraphModel.hashCode();
		contractStatusGraphModel.equals(obj);
		contractStatusGraphModel.equals(contractStatusGraphModel);
		contractStatusGraphModel.equals(null);

		dfqDeliveryGraphModel.toString();
		dfqDeliveryGraphModel.hashCode();
		dfqDeliveryGraphModel.equals(obj);
		dfqDeliveryGraphModel.equals(dfqDeliveryGraphModel);
		dfqDeliveryGraphModel.equals(null);

		dfqEventModel.toString();
		dfqEventModel.hashCode();
		dfqEventModel.equals(obj);
		dfqEventModel.equals(dfqEventModel);
		dfqEventModel.equals(null);

		dfqMilestoneGraphModel.toString();
		dfqMilestoneGraphModel.hashCode();
		dfqMilestoneGraphModel.equals(obj);
		dfqMilestoneGraphModel.equals(dfqMilestoneGraphModel);
		dfqMilestoneGraphModel.equals(null);

		projectMasterDataModel.toString();
		projectMasterDataModel.hashCode();
		projectMasterDataModel.equals(obj);
		projectMasterDataModel.equals(projectMasterDataModel);
		projectMasterDataModel.equals(null);

		projectSetUpListModel.toString();
		projectSetUpListModel.hashCode();
		projectSetUpListModel.equals(obj);
		projectSetUpListModel.equals(projectSetUpListModel);
		projectSetUpListModel.equals(null);

		projectSetUpModel.toString();
		projectSetUpModel.hashCode();
		projectSetUpModel.toString();
		projectSetUpModel.hashCode();
		projectSetUpModel.equals(projectSetUpModel);
		projectSetUpModel.equals(null);
		projectSetUpObj.equals(projectSetUpObj);
		projectSetUpObj.equals(null);

		projectSetUpAttachmentModel.toString();
		projectSetUpAttachmentModel.hashCode();
		projectSetUpAttachmentModel.toString();
		projectSetUpAttachmentModel.hashCode();
		projectSetUpAttachmentModel.equals(projectSetUpAttachmentModel);
		projectSetUpAttachmentModel.equals(null);
		projectSetUpAttachmentObj.equals(projectSetUpAttachmentObj);
		projectSetUpAttachmentObj.equals(null);

		projectMilestoneModel.toString();
		projectMilestoneModel.hashCode();
		projectMilestoneModel.toString();
		projectMilestoneModel.hashCode();
		projectMilestoneModel.equals(projectMilestoneModel);
		projectMilestoneModel.equals(null);
		projectMilestoneObj.equals(projectMilestoneObj);
		projectMilestoneObj.equals(null);

		contractModel.toString();
		contractModel.hashCode();
		contractModel.toString();
		contractModel.hashCode();
		contractModel.equals(contractModel);
		contractModel.equals(null);
		contractModelObj.equals(contractModelObj);
		contractModelObj.equals(null);

		commodityStatusModel.toString();
		commodityStatusModel.hashCode();
		commodityStatusModel.toString();
		commodityStatusModel.hashCode();
		commodityStatusModel.equals(commodityStatusModel);
		commodityStatusModel.equals(null);
		commodityStatusObj.equals(commodityStatusObj);
		commodityStatusObj.equals(null);

		commodityContractModel.toString();
		commodityContractModel.hashCode();
		commodityContractModel.toString();
		commodityContractModel.hashCode();
		commodityContractModel.equals(commodityContractModel);
		commodityContractModel.equals(null);
		commodityContractObj.equals(commodityContractObj);
		commodityContractObj.equals(null);

		commodityActionPlanModel.toString();
		commodityActionPlanModel.hashCode();
		commodityActionPlanModel.toString();
		commodityActionPlanModel.hashCode();
		commodityActionPlanModel.equals(commodityActionPlanModel);
		commodityActionPlanModel.equals(null);
		commodityActionPlanObj.equals(commodityActionPlanObj);
		commodityActionPlanObj.equals(null);

		projectMarketModelModel.toString();
		projectMarketModelModel.hashCode();
		projectMarketModelModel.toString();
		projectMarketModelModel.hashCode();
		projectMarketModelModel.equals(projectMarketModelModel);
		projectMarketModelModel.equals(null);
		projectMarketModelObj.equals(projectMarketModelObj);
		projectMarketModelObj.equals(null);

		puActionsModel.toString();
		puActionsModel.hashCode();
		puActionsModel.toString();
		puActionsModel.hashCode();
		puActionsModel.equals(puActionsModel);
		puActionsModel.equals(null);
		puActionsObj.equals(puActionsObj);
		puActionsObj.equals(null);

		qliksenseCommodityActionPlanModel.toString();
		qliksenseCommodityActionPlanModel.hashCode();
		qliksenseCommodityActionPlanModel.equals(obj);
		qliksenseCommodityActionPlanModel.equals(qliksenseCommodityActionPlanModel);
		qliksenseCommodityActionPlanModel.equals(null);

		qliksenseCommodityContractModel.toString();
		qliksenseCommodityContractModel.hashCode();
		qliksenseCommodityContractModel.equals(obj);
		qliksenseCommodityContractModel.equals(qliksenseCommodityContractModel);
		qliksenseCommodityContractModel.equals(null);

		qliksenseCommodityStatusModel.toString();
		qliksenseCommodityStatusModel.hashCode();
		qliksenseCommodityStatusModel.equals(obj);
		qliksenseCommodityStatusModel.equals(qliksenseCommodityStatusModel);
		qliksenseCommodityStatusModel.equals(null);

		basicSecurityUser.toString();
		basicSecurityUser.hashCode();
		basicSecurityUser.equals(obj);
		basicSecurityUser.equals(basicSecurityUser);
		basicSecurityUser.equals(null);

		filterModel.toString();
		filterModel.hashCode();
		filterModel.equals(obj);
		filterModel.equals(filterModel);
		filterModel.equals(null);

		joinModel.toString();
		joinModel.hashCode();
		joinModel.equals(obj);
		joinModel.equals(joinModel);
		joinModel.equals(null);

		Assertions.assertTrue(true);
	}
}
