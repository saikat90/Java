package com.alstom.applicationfactory.pmfuservice.projectsetup.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityActionPlanModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.QlikSenseService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(QlikSenseController.class)
class QlikSenseControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private QlikSenseService qlikSenseService;

	@MockBean
	private AdminServiceClient adminServiceClient;
	@MockBean
	private AuthorizationConfig authConfig;
	@MockBean
	private JwtDecoder jwtDecoder;

	@Autowired
	private WebApplicationContext context;

	ObjectMapper mapper = new ObjectMapper();

	UUID uuid = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");
	
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);

		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

		when(adminServiceClient.getAuthorities("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
				"test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

		when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

		when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV")).thenReturn(null);
	}
	
	@Test
	public void testfindAllCommodityStatusData() throws Exception {
		//Object result = qlikSenseService.findAllCommodityStatusData();
		
		List<QliksenseCommodityContractModel> qlikCommodityContractList = new ArrayList<>();
		
		when(qlikSenseService.findAllCommodityStatusData())
		.thenReturn(qlikCommodityContractList);

		RequestBuilder request = MockMvcRequestBuilders.get("/qliksense/commodityStatus/kpi")
		.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}

	@Test
	public void testfindAllCommodityContractData() throws Exception{
		//Object result = qlikSenseService.findAllCommodityContractData();
		
		List<QliksenseCommodityContractModel> qlikCommodityContractList = new ArrayList<>();
		
		when(qlikSenseService.findAllCommodityContractData())
		.thenReturn(qlikCommodityContractList);

		RequestBuilder request = MockMvcRequestBuilders.get("/qliksense/commodityContract/kpi")
		.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}

	@Test
	public void findAllCommodityActionPlanData() throws Exception{
		//Object result = qlikSenseService.findAllCommodityActionPlanData();
		
		List<QliksenseCommodityActionPlanModel> qlikCommodityActionPlanList = new ArrayList<>();

		when(qlikSenseService.findAllCommodityActionPlanData())
		.thenReturn(qlikCommodityActionPlanList);

		RequestBuilder request = MockMvcRequestBuilders.get("/qliksense/commodityActionPlan/kpi")
		.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}


}
