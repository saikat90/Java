package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.AtSiteRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.AtSiteService;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(AtSiteController.class)
class AtSiteControllerTest {

    @MockBean
    private AtSiteService atSiteService;
    @MockBean
    private AtSiteRepository atSiteRepository;

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;

    @Autowired
    private WebApplicationContext context;

    ObjectMapper mapper = new ObjectMapper();

    AtSiteModel atSiteModel = new AtSiteModel(null, 0, "Asia Pacific", "China",
            "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
            null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
            null, null);

    AtSiteModel createdAtSiteModel = new AtSiteModel(
            UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0, "Asia Pacific", "China",
            "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
            null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
            null, null);

    Object updatedAtSiteModel_1 = new AtSite(
            UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0, "Asia Pacific", "China",
            "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
            null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
            null, null);

    AtSiteModel updatedAtSiteModel = new AtSiteModel(
            UUID.fromString("0087ffde-477c-c89d-30ce-f00d4a99a782"), 0, "Europe", "Greece",
            "SIG Agia Paraskevi GR", "Athens", "3252", null, null, "Rail Control", null, null, null,
            null, null, null, null, null, null, null, false, new Date(), new Date(), null, null);

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);
    }

    @Test
    public void testfindAll() throws Exception {
        AtSite atSiteObject1 = new AtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc"),
                0, "Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949",
                null, null, "Trains", null, null, null, null, null, null, null, null, null, null,
                false, new Date(), new Date(), null, null);

        AtSite atSiteObject2 = new AtSite(UUID.fromString("0087ffde-477c-c89d-30ce-f00d4a99a782"),
                0, "Europe", "Greece", "SIG Agia Paraskevi GR", "Athens", "3252", null, null,
                "Rail Control", null, null, null, null, null, null, null, null, null, null, false,
                new Date(), new Date(), null, null);

        List<AtSite> atSiteList = new ArrayList<>();

        atSiteList.add(atSiteObject1);
        atSiteList.add(atSiteObject2);

        when(atSiteRepository.findAll()).thenReturn(atSiteList);

        RequestBuilder request = MockMvcRequestBuilders.get("/atSite/list")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testsearchAtSite() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        RequestModel requestModel = RequestMapper.map(request1);
        when(atSiteService.searchAtSite(requestModel)).thenReturn(updatedAtSiteModel_1);
        RequestBuilder request = MockMvcRequestBuilders.post("/atSite/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testviewAtSite() throws Exception {
        when(atSiteService.viewAtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc")))
                .thenReturn(createdAtSiteModel);

        createdAtSiteModel.toString();
        createdAtSiteModel.hashCode();

        RequestBuilder request = MockMvcRequestBuilders
                .get("/atSite/00714906-efad-919a-b474-cf4668633afc")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testdeleteAtSiteById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/atSite/00714906-efad-919a-b474-cf4668633afc")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testcreateAtSite() throws Exception {
        String json = mapper.writeValueAsString(atSiteModel);

        when(atSiteService.createAtSite(atSiteModel)).thenReturn(createdAtSiteModel);

        RequestBuilder request = MockMvcRequestBuilders.post("/atSite")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testupdateAtSite() throws Exception {
        String json = mapper.writeValueAsString(updatedAtSiteModel);

        when(atSiteService.updateAtSite(updatedAtSiteModel)).thenReturn(updatedAtSiteModel);

        RequestBuilder request = MockMvcRequestBuilders.put("/atSite")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testfindAtSiteforSearch() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        RequestModel requestModel = RequestMapper.map(request1);
        when(atSiteService.searchAtSite(requestModel)).thenReturn(updatedAtSiteModel_1);
        RequestBuilder request = MockMvcRequestBuilders.post("/atSite/searchlist")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

}
