package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.MarketCodeMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.MarketCodeMasterDataRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMilestoneRepository;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class MarketCodeMasterDataServiceImplTest {

    @Mock
    private MarketCodeMasterDataRepository marketCodeMasterDataRepository;
    @Mock
    private ProjectMilestoneRepository projectMileStoneRepo;
    @InjectMocks
    private MarketCodeMasterDataServiceImpl mdMarketCodeService;

    UUID uuid = UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef");

    MarketCodeMasterDataModel updatedMarketCodeMaster = new MarketCodeMasterDataModel(
            UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
            "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing", "GLOBAL Coordinated",
            "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21);

    @Test
    public void testsearchMDMarketCode() {
        MarketCodeMasterDataModel marketCodeMasterData1 = new MarketCodeMasterDataModel(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        MarketCodeMasterDataModel marketCodeMasterData2 = new MarketCodeMasterDataModel(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        List<MarketCodeMasterDataModel> marketCodeMasterDataModelList = new ArrayList<>();
        marketCodeMasterDataModelList.add(marketCodeMasterData1);
        marketCodeMasterDataModelList.add(marketCodeMasterData2);

        Object obj = marketCodeMasterDataModelList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);

        when(marketCodeMasterDataRepository.findAll(requestModel.getFilterSpecification()))
                .thenReturn(marketCodeMasterDataModelList);

        marketCodeMasterDataModelList = (List<MarketCodeMasterDataModel>) mdMarketCodeService
                .searchMDMarketCode(requestModel);

        assertThat((marketCodeMasterDataModelList.size() == '2'));
    }

    @Test
    public void testviewMDMarketCode() {
        MarketCodeMasterData marketCodeMasterData = new MarketCodeMasterData(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        MarketCodeMasterDataModel marketCodeMasterDataModel = mapper.map(marketCodeMasterData,
                MarketCodeMasterDataModel.class);

        when(marketCodeMasterDataRepository
                .findById(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef")))
                        .thenReturn(Optional.of(marketCodeMasterData));

        assertThat(mdMarketCodeService.viewMDMarketCode(uuid)).isEqualTo(marketCodeMasterDataModel);
    }

    @Test
    void testviewMDMarketCodeForCatch() {
        when(marketCodeMasterDataRepository
                .findById(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef")))
                        .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> mdMarketCodeService
                        .viewMDMarketCode(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef")),
                "");
    }

    @Disabled
    @Test
    public void testdeleteMDMarketCodeById() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        MarketCodeMasterDataModel createdMarketCodeMasterDataModel = new MarketCodeMasterDataModel(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        MarketCodeMasterData alreadySavedMarketCodeMasterData = mapper
                .map(createdMarketCodeMasterDataModel, MarketCodeMasterData.class);

        when(marketCodeMasterDataRepository
                .findById(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef")))
                        .thenReturn(Optional.of(alreadySavedMarketCodeMasterData));
        mdMarketCodeService
                .deleteMDMarketCodeById(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"));
        verify(marketCodeMasterDataRepository).delete(alreadySavedMarketCodeMasterData);
    }

    @Test
    void testdeleteMDMarketCodeByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(marketCodeMasterDataRepository)
                .deleteById(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"));
        assertThrows(ApplicationFactoryException.class, () -> mdMarketCodeService
                .deleteMDMarketCodeById(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef")),
                "");
    }

    @Test
    public void testcreateMDMarketCode() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        MarketCodeMasterDataModel marketCodeMasterDataModel = new MarketCodeMasterDataModel(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        MarketCodeMasterData marketCodeMasterData = mapper.map(marketCodeMasterDataModel,
                MarketCodeMasterData.class);

        MarketCodeMasterData createdMarketCodeMaster = new MarketCodeMasterData(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        MarketCodeMasterDataModel expectedMarketCodeMaster = new MarketCodeMasterDataModel(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        when(marketCodeMasterDataRepository.save(marketCodeMasterData))
                .thenReturn(createdMarketCodeMaster);

        assertThat(mdMarketCodeService.createMDMarketCode(marketCodeMasterDataModel).getId())
                .isEqualTo(expectedMarketCodeMaster.getId());

    }

    @Test
    public void testupdateMDMarketCode() {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        MarketCodeMasterDataModel createdMarketCodeMaster = new MarketCodeMasterDataModel(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        MarketCodeMasterDataModel updatedMarketCodeMaster = new MarketCodeMasterDataModel(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        MarketCodeMasterData updatedNewMarketCodeMaster = mapper.map(updatedMarketCodeMaster,
                MarketCodeMasterData.class);
        MarketCodeMasterDataModel updatedNewMarketCodeMasterModel = mapper
                .map(updatedNewMarketCodeMaster, MarketCodeMasterDataModel.class);
        when(marketCodeMasterDataRepository.save(updatedNewMarketCodeMaster))
                .thenReturn(updatedNewMarketCodeMaster);
        // assertThat(mdMarketCodeService.updateMDMarketCode(updatedMarketCodeMaster)).isEqualTo(updatedNewMarketCodeMasterModel);
    }

    @Test
    void testupdateMDMarketCodeForElse() {
        assertThrows(ApplicationFactoryException.class,
                () -> mdMarketCodeService.updateMDMarketCode(updatedMarketCodeMaster), "");
    }

    @Test
    public void testisMarketCodeExists() {
        MarketCodeMasterData marketCodeMasterData = new MarketCodeMasterData(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        MarketCodeMasterDataModel marketCodeMasterDataModel = mapper.map(marketCodeMasterData,
                MarketCodeMasterDataModel.class);

        when(marketCodeMasterDataRepository.findByMarketCode("C030"))
                .thenReturn(marketCodeMasterData);

        assertThat(mdMarketCodeService.isMarketCodeExists("C030")).isEqualTo(true);
    }

    @Disabled
    @Test
    void testIsMarketCodeExistsForElse() {
        assertThrows(ApplicationFactoryException.class,
                () -> mdMarketCodeService.isMarketCodeExists("4445"), "");
    }

    @Test
    public void testreplaceMDMarketCode() {
        MarketCodeMasterData marketCodeMasterData = new MarketCodeMasterData(
                UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1, "C030",
                "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing",
                "GLOBAL Coordinated", "JUS Nicolas", "JUS Nicolas", "JUS Nicolas", 14, 21, 14, 21,
                21, 21, 21, 0, 0, 21);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        MarketCodeMasterDataModel marketCodeMasterDataModel = mapper.map(marketCodeMasterData,
                MarketCodeMasterDataModel.class);

        when(marketCodeMasterDataRepository.findByMarketCode("C030"))
                .thenReturn(marketCodeMasterData);

        // assertThat(mdMarketCodeService.replaceMDMarketCode("C030","C031"));

    }

    @Test
    void testreplaceMDMarketCodeForElse() {
        assertThrows(ApplicationFactoryException.class,
                () -> mdMarketCodeService.replaceMDMarketCode("4455", "6555"), "");
    }
}
