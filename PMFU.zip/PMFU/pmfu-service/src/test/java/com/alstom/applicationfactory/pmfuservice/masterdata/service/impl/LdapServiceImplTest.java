package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;

@ExtendWith(MockitoExtension.class)
class LdapServiceImplTest {

    @InjectMocks
    LdapServiceImpl ldapServiceImpl;

    User userObject = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "HQ-Operational Excellence-OPEX", "test@alstomgroup.com", "228638", "Val", "LE");

    @Disabled
    @Test
    public void testfindUsers() {
        Map<String, String> request1 = new HashMap<>();
        request1.put("pageNumber", "0");
        request1.put("pageSize", "10");

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        when(ldapServiceImpl.findUsers(request1)).thenReturn(userObject);
    }
}
