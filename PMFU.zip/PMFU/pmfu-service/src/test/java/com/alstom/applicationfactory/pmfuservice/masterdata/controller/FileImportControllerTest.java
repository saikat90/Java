package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.FileImportService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
@WebMvcTest(FileImportController.class)
class FileImportControllerTest {

    @MockBean
    private FileImportService importService;
    @MockBean
    private MultipartFile multipartFile;

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @MockBean
    private EmailServiceClient emailServiceClient;
    @Autowired
    private WebApplicationContext context;

    ObjectMapper mapper = new ObjectMapper();

    String email = "test@alstomgroup.com";

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);
    }

    @Disabled
    @Test
    public void testimportMasterDataContents() throws Exception {
        Map<String, Object> response = new HashMap();

        MockMultipartFile file = new MockMultipartFile("file", "test contract.pdf",
                MediaType.APPLICATION_PDF_VALUE, "<<pdf data>>".getBytes(StandardCharsets.UTF_8));

        ObjectMapper objectMapper = new ObjectMapper();

        MockMultipartFile metadata = new MockMultipartFile("request", "request",
                MediaType.APPLICATION_JSON_VALUE,
                objectMapper.writeValueAsString(response).getBytes(StandardCharsets.UTF_8));

        MockMultipartFile mockMultipartFile = new MockMultipartFile("user-file", "testcontract.pdf",
                "application/pdf", "test data".getBytes());

        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.fileUpload("/import/29")
                .file(mockMultipartFile);

        mockMvc.perform(builder).andExpect(status().isOk());

        /*
         * mockMvc.perform(multipart("/import/29").file(file).file(metadata)
         * .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
         * .andExpect(content().string("testcontract.pdf"));
         */

    }
}
