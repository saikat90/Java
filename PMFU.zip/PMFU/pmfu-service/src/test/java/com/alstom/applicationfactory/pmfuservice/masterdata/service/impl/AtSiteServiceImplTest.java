package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.AtSiteRepository;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;

@ExtendWith(MockitoExtension.class)
class AtSiteServiceImplTest {

    @Mock
    private AtSiteRepository atSiteRepository;
    @InjectMocks
    AtSiteServiceImpl atSiteServiceImpl;

    UUID uuid = UUID.fromString("00714906-efad-919a-b474-cf4668633afc");

    AtSite atSite = new AtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0,
            "Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null,
            null, "Trains", null, null, null, null, null, null, null, null, null, null, false,
            new Date(), new Date(), null, null);

    AtSiteModel atSiteModel = new AtSiteModel(
            UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0, "Asia Pacific", "China",
            "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
            null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
            null, null);

    @Test
    public void testsearchAtSite() {
        AtSite atSite1 = new AtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0,
                "Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949",
                null, null, "Trains", null, null, null, null, null, null, null, null, null, null,
                false, new Date(), new Date(), null, null);

        AtSite atSite2 = new AtSite(UUID.fromString("0087ffde-477c-c89d-30ce-f00d4a99a782"), 0,
                "Europe", "Greece", "SIG Agia Paraskevi GR", "Athens", "3252", null, null,
                "Rail Control", null, null, null, null, null, null, null, null, null, null, false,
                new Date(), new Date(), null, null);

        List<AtSite> atSiteList = new ArrayList<>();
        atSiteList.add(atSite1);
        atSiteList.add(atSite2);

        Object obj = atSiteList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);

        when(atSiteRepository.findAll(requestModel.getFilterSpecification()))
                .thenReturn(atSiteList);

        atSiteList = (List<AtSite>) atSiteServiceImpl.searchAtSite(requestModel);

        assertThat((atSiteList.size() == '2'));
    }

    @Test
    public void testviewAtSite() {
        AtSite atSite = new AtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0,
                "Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949",
                null, null, "Trains", null, null, null, null, null, null, null, null, null, null,
                false, new Date(), new Date(), null, null);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        AtSiteModel atSiteModel = mapper.map(atSite, AtSiteModel.class);

        when(atSiteRepository.findById(UUID.fromString("00714906-efad-919a-b474-cf4668633afc")))
                .thenReturn(Optional.of(atSite));

        assertThat(atSiteServiceImpl.viewAtSite(uuid)).isEqualTo(atSiteModel);

    }

    @Test
    void testviewAtSiteForCatch() {
        when(atSiteRepository.findById(UUID.fromString("00714906-efad-919a-b474-cf4668633afc")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class, () -> atSiteServiceImpl
                .viewAtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc")), "");
    }

    @Test
    public void testdeleteAtSiteById() {

        atSiteServiceImpl.deleteAtSiteById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"));
        verify(atSiteRepository)
                .deleteById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"));
    }

    @Test
    void testdeleteAtSiteByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(atSiteRepository)
                .deleteById(UUID.fromString("00714906-efad-919a-b474-cf4668633afc"));
        assertThrows(ApplicationFactoryException.class,
                () -> atSiteServiceImpl
                        .deleteAtSiteById(UUID.fromString("00714906-efad-919a-b474-cf4668633afc")),
                "");
    }

    @Test
    public void testcreateAtSite() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        AtSiteModel atSiteModel = new AtSiteModel(null, 0, "Asia Pacific", "China",
                "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
                null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
                null, null);

        AtSite atSite = mapper.map(atSiteModel, AtSite.class);

        AtSite createdAtSite = new AtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc"),
                0, "Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949",
                null, null, "Trains", null, null, null, null, null, null, null, null, null, null,
                false, new Date(), new Date(), null, null);

        AtSiteModel expectedAtSiteModel = new AtSiteModel(
                UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0, "Asia Pacific", "China",
                "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
                null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
                null, null);

        when(atSiteRepository.save(atSite)).thenReturn(createdAtSite);

        assertThat(atSiteServiceImpl.createAtSite(atSiteModel).getId())
                .isEqualTo(expectedAtSiteModel.getId());
    }

    @Test
    public void testupdateAtSite() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        AtSiteModel updatedAtSiteModel = new AtSiteModel(
                UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0, "Asia Pacific", "China",
                "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
                null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
                null, null);

        AtSite updatedNewAtSite = mapper.map(updatedAtSiteModel, AtSite.class);
        AtSiteModel updatedNewAtSiteModel = mapper.map(updatedNewAtSite, AtSiteModel.class);
        when(atSiteRepository.findById(UUID.fromString("00714906-efad-919a-b474-cf4668633afc")))
                .thenReturn(Optional.of(updatedNewAtSite));
        when(atSiteRepository.save(updatedNewAtSite)).thenReturn(updatedNewAtSite);
        assertThat(atSiteServiceImpl.updateAtSite(updatedAtSiteModel))
                .isEqualTo(updatedNewAtSiteModel);
    }

    @Test
    void testupdateAtSiteForCatch() {
        assertThrows(ApplicationFactoryException.class,
                () -> atSiteServiceImpl.updateAtSite(atSiteModel), "");
    }

    @Test
    public void testisCaratCodeExists() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        AtSiteModel existingAtSiteModel = new AtSiteModel(
                UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0, "Asia Pacific", "China",
                "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949", null, null, "Trains", null,
                null, null, null, null, null, null, null, null, null, false, new Date(), new Date(),
                null, null);

        AtSite existingAtSite = mapper.map(existingAtSiteModel, AtSite.class);
        when(atSiteRepository.findByCaratCode("5949")).thenReturn(existingAtSite);

        assertThat(atSiteServiceImpl.isCaratCodeExists("5949")).isEqualTo(true);
    }

    @Test
    void testisCaratCodeExistsForCatch() {

        doThrow(ApplicationFactoryException.class).when(atSiteRepository).findByCaratCode("5489");
        assertThrows(ApplicationFactoryException.class,
                () -> atSiteServiceImpl.isCaratCodeExists("5489"), "");
    }

    @Test
    public void testfindAtSiteforSearch() {
        AtSite atSite1 = new AtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0,
                "Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949",
                null, null, "Trains", null, null, null, null, null, null, null, null, null, null,
                false, new Date(), new Date(), null, null);

        List<AtSite> atSiteList = new ArrayList<>();
        atSiteList.add(atSite1);

        Object obj = atSiteList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);

        when(atSiteRepository.findAll(requestModel.getFilterSpecification()))
                .thenReturn(atSiteList);

        atSiteList = (List<AtSite>) atSiteServiceImpl.searchAtSite(requestModel);

        assertThat((atSiteList.size() == '1'));

    }

}
