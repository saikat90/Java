package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityStatus;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityStatusModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityStatusRepository;

@ExtendWith(MockitoExtension.class)
class CommodityStatusServiceImplTest {

	@Mock
	private CommodityStatusRepository commodityStatusRepository;
	@InjectMocks
	private CommodityStatusServiceImpl commodityStatusServiceImpl;
	
	CommodityStatusModel commodityStatusModel = new CommodityStatusModel(null,2,"Stockeur 660V LiOn 100 kWh fin de vie",
			"SPECIFICATION","X","X","X","X","X","X","X",null,null,null,null,null,"Duration",null,14,90,10,0,0,0,690,0,0,0,null,30,"Needs",new Date(),
			new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),
			"Actual Date",new Date(),new Date(),new Date(),new Date(),null,null,null,null,null,null,null,null,null,"Status",
			"RECEIVED","GO","GO","GO",null,null,null,null,null,null,null,null,null,"Status Color","0xFF008000","0xFF008000","0xFFFFFF00",
			"0xFFFFFF00","0xFFFF0000","0xFFFF0000","0xFFFF0000","0xFFFFFFFF",null,null,null,null,null,
			null,0,"Forecast Date",null,null,null,null,null,null,null,null,null,null,null,null,null);


	@Test
	public void testcreateCommodityStatus() {
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());


		CommodityStatusModel commodityStatusModel = new CommodityStatusModel(null,2,"Stockeur 660V LiOn 100 kWh fin de vie",
				"SPECIFICATION","X","X","X","X","X","X","X",null,null,null,null,null,"Duration",null,14,90,10,0,0,0,690,0,0,0,null,30,"Needs",new Date(),
				new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),
				"Actual Date",new Date(),new Date(),new Date(),new Date(),null,null,null,null,null,null,null,null,null,"Status",
				"RECEIVED","GO","GO","GO",null,null,null,null,null,null,null,null,null,"Status Color","0xFF008000","0xFF008000","0xFFFFFF00",
				"0xFFFFFF00","0xFFFF0000","0xFFFF0000","0xFFFF0000","0xFFFFFFFF",null,null,null,null,null,
				null,0,"Forecast Date",null,null,null,null,null,null,null,null,null,null,null,null,null);

		CommodityStatus commodityStatus = mapper.map(commodityStatusModel, CommodityStatus.class);

		CommodityStatus createdCommodityStatus = new CommodityStatus(UUID.fromString("001f2256-8e68-2c42-8d21-52de693e7863"),2,"Stockeur 660V LiOn 100 kWh fin de vie",
				"SPECIFICATION","X","X","X","X","X","X","X",null,null,null,null,null,"Duration",null,14,90,10,0,0,0,690,0,0,0,null,30,"Needs",new Date(),
				new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),
				"Actual Date",new Date(),new Date(),new Date(),new Date(),null,null,null,null,null,null,null,null,null,"Status",
				"RECEIVED","GO","GO","GO",null,null,null,null,null,null,null,null,null,"Status Color","0xFF008000","0xFF008000","0xFFFFFF00",
				"0xFFFFFF00","0xFFFF0000","0xFFFF0000","0xFFFF0000","0xFFFFFFFF",null,null,null,null,null,
				null,0,"Forecast Date",null,null,null,null,null,null,null,null,null,null,null,null,null);


		CommodityStatusModel expectedCommodityStatusModel = new CommodityStatusModel(UUID.fromString("001f2256-8e68-2c42-8d21-52de693e7863"),2,"Stockeur 660V LiOn 100 kWh fin de vie",
				"SPECIFICATION","X","X","X","X","X","X","X",null,null,null,null,null,"Duration",null,14,90,10,0,0,0,690,0,0,0,null,30,"Needs",new Date(),
				new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),new Date(),
				"Actual Date",new Date(),new Date(),new Date(),new Date(),null,null,null,null,null,null,null,null,null,"Status",
				"RECEIVED","GO","GO","GO",null,null,null,null,null,null,null,null,null,"Status Color","0xFF008000","0xFF008000","0xFFFFFF00",
				"0xFFFFFF00","0xFFFF0000","0xFFFF0000","0xFFFF0000","0xFFFFFFFF",null,null,null,null,null,
				null,0,"Forecast Date",null,null,null,null,null,null,null,null,null,null,null,null,null);


		when(commodityStatusRepository.save(commodityStatus)).thenReturn(createdCommodityStatus);

		assertThat(commodityStatusServiceImpl.createCommodityStatus(commodityStatusModel).getId()).isEqualTo(expectedCommodityStatusModel.getId());
		
	}	
	
		@Test
	    void testcreateCommodityStatusForCatch() {
	        ModelMapper mapper = new ModelMapper();
	        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
	        CommodityStatus commodityStatus = mapper.map(commodityStatusModel, CommodityStatus.class);
	        when(commodityStatusRepository.save(commodityStatus)).thenThrow(ApplicationFactoryException.class);
	        assertThrows(ApplicationFactoryException.class, () -> commodityStatusServiceImpl.createCommodityStatus(commodityStatusModel), "");
	    }

}
