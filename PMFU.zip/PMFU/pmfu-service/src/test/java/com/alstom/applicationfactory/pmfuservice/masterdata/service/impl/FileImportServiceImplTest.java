package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class FileImportServiceImplTest {
    @InjectMocks
    private FileImportServiceImpl fileImportServiceImplTest;

    @Disabled
    @Test
    public void importMasterDataContents(MultipartFile multipartFile, String emailId)
            throws IOException {
        FileInputStream inputFile = new FileInputStream("path of the file");
        MockMultipartFile file = new MockMultipartFile("file", "NameOfTheFile",
                "multipart/form-data", inputFile);

        Map<String, Object> response = new HashMap<>();

        // assertThat(fileImportServiceImplTest.importMasterDataContents(file,"test@alstomgroup.com")).isEqualTo(response);

    }

}
