package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityContract;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMarketModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMarketRepository;

@ExtendWith(MockitoExtension.class)
class ProjectMarketServiceImplTest {

	@Mock
	private ProjectMarketRepository projectMarketRepository;
	@InjectMocks
	private ProjectMarketServiceImpl projectMarketServiceImpl;
	
	ProjectMarketModel projectMarketModel = new ProjectMarketModel(UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"),0,"A535","A06",null,2,null,null,null);
	
	@Test
	public void createProjectMarketTest() {
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

		
		CommodityContractModel commodityContractModel = new CommodityContractModel(UUID.fromString("00105f70-2a6b-4198-88f6-4389bc587eb4"),10, null,null,null);
		CommodityContract commodityContract = new CommodityContract(UUID.fromString("00105f70-2a6b-4198-88f6-4389bc587eb4"),10, null,null,null);
		
		ProjectMarketModel projectMarketModel = new ProjectMarketModel(null,0,"A535","A06",null,2,null,commodityContractModel,null);

		ProjectMarket projectMarket = mapper.map(projectMarketModel, ProjectMarket.class);

		ProjectMarket createdProjectMarket = new ProjectMarket(UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"),0,"A535","A06",null,2,null,commodityContract,null);

		ProjectMarketModel expectedProjectMarketModel = new ProjectMarketModel(UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"),0,"A535","A06",null,2,null,commodityContractModel,null);

		when(projectMarketRepository.save(projectMarket)).thenReturn(createdProjectMarket);

		assertThat(projectMarketServiceImpl.createProjectMarket(projectMarketModel).getId()).isEqualTo(expectedProjectMarketModel.getId());
		
	}
	
	 @Test
	    void testcreateProjectMarketForCatch() {
	        ModelMapper mapper = new ModelMapper();
	        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
	        ProjectMarket projectMarket = mapper.map(projectMarketModel, ProjectMarket.class);
	        when(projectMarketRepository.save(projectMarket)).thenThrow(ApplicationFactoryException.class);
	        assertThrows(ApplicationFactoryException.class, () -> projectMarketServiceImpl.createProjectMarket(projectMarketModel), "");
	    }
}
