package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(UserController.class)
class UserControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private AdminServiceClient adminServiceClient;
	@MockBean
	private AuthorizationConfig authConfig;
	@MockBean
	private JwtDecoder jwtDecoder;
	@MockBean
	UserRepository userRepository;
	
	@Autowired
	private WebApplicationContext context;
	
	ObjectMapper mapper = new ObjectMapper();
	
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);

		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

		when(adminServiceClient.getAuthorities("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
				"test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

		when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

		when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV")).thenReturn(null);
	}
	
	@Test
	public void testfindAll() throws Exception {
		User userObject1 = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "IS&T Project CoE",
				"abc@alstomgroup.com", "100777188", "Jhon", "LE-GAC");

		User userObject2 = new User(UUID.fromString("002cb1ba-b6e8-efc4-f22e-571d5ebdc902"), "HQ-Operational Excellence-OPEX",
				"test@alstomgroup.com", "228638", "Val", "LE");

		List<User> userList = new ArrayList<>();

		userList.add(userObject1);
		userList.add(userObject2);

		when(userRepository.findAll()).thenReturn(userList);

		RequestBuilder request = MockMvcRequestBuilders.get("/users/list").accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
		
		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}


}
