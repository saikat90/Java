package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityContract;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.Contracts;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMarketModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.CommodityContractRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMarketRepository;

@ExtendWith(MockitoExtension.class)
class CommodityContractServiceImplTest {

	@Mock
	private CommodityContractRepository commodityContractRepository;
	@Mock
	private ProjectMarketRepository projectMarketRepository;
	@InjectMocks
	private CommodityContractServiceImpl commodityContractServiceImpl;

	CommodityContractModel commodityContractModel = new CommodityContractModel(UUID.fromString("00105f70-2a6b-4198-88f6-4389bc587eb4"),10, null,null,null);
	
	@Test
	public void testcreateCommodityContract() {
		
		 ProjectMarketModel projectMarketModel = new ProjectMarketModel(UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"),0,"A535","A06",null,11,null,null,null);
		 ProjectMarket projectMarket = new ProjectMarket(UUID.fromString("0003d580-f937-56a1-8f21-4a968055ebee"),0,"A535","A06",null,11,null,null,null);
		 
		 
		 ContractsModel contractModelObj = new ContractsModel(UUID.fromString("0018bccd-79b2-70c8-f671-cf188eafbee1"),0,"Cabin floor panel / plancher cabine",null,null,null,null,null,null,null,null,null,null);
		 Contracts contractObj = new Contracts(UUID.fromString("0018bccd-79b2-70c8-f671-cf188eafbee1"),0,"Cabin floor panel / plancher cabine",null,null,null,null,null,null,null,null,null,null);
		 
		 List<ContractsModel> contractsModelList = new ArrayList<>();
		 contractsModelList.add(contractModelObj);
		 
		 List<Contracts> contractsList = new ArrayList<>();
		 contractsList.add(contractObj);
		
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

		CommodityContractModel commodityContractModel = new CommodityContractModel(null,10, null,projectMarketModel,contractsModelList);

		CommodityContract commodityContract = mapper.map(commodityContractModel, CommodityContract.class);


		CommodityContract createdCommodityContract = new CommodityContract(UUID.fromString("00105f70-2a6b-4198-88f6-4389bc587eb4"),10, null,projectMarket,contractsList);

		CommodityContractModel expectedCommodityContractModel = new CommodityContractModel(UUID.fromString("00105f70-2a6b-4198-88f6-4389bc587eb4"),10, null,projectMarketModel,contractsModelList);

		/*
		 * when(projectMarketRepository.findById(commodityContract.getProjectMarket().
		 * getId())).thenReturn(Optional.of(projectMarket));
		 * 
		 * commodityContract.setProjectMarket(projectMarket);
		 */

		when(commodityContractRepository.save(commodityContract)).thenReturn(createdCommodityContract);

		assertThat(commodityContractServiceImpl.createCommodityContract(commodityContractModel).getId()).isEqualTo(expectedCommodityContractModel.getId());
	}
	
	 @Test
	    void testcreateCommodityContractForCatch() {
	        ModelMapper mapper = new ModelMapper();
	        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
	        CommodityContract commodityContract = mapper.map(commodityContractModel, CommodityContract.class);
	        when(commodityContractRepository.save(commodityContract)).thenThrow(ApplicationFactoryException.class);
	        assertThrows(ApplicationFactoryException.class, () -> commodityContractServiceImpl.createCommodityContract(commodityContractModel), "");
	    }
}
