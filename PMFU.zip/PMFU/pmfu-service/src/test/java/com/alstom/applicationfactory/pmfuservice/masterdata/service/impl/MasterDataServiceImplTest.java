package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.feign.client.MasterDataServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.Project;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMarketRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectMilestoneRepository;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;

@ExtendWith(MockitoExtension.class)
class MasterDataServiceImplTest {

    @MockBean
    private ProjectMarketRepository projMarketRepo;
    @MockBean
    private ProjectMilestoneRepository projectMileStoneRepo;
    @InjectMocks
    private MasterDataServiceImpl masterDataServiceImpl;
    @MockBean
    private MasterDataServiceClient masterDataServiceClient;

    @Disabled
    @Test
    public void testsearchMDMarketCode() {
        Project updatedProjectModel_1 = new Project(1L, "CTS302",
                "TEST FOR PMS  INTERFACE - Sustaining Project", null, "HQ ALSTOM Transport SA FR",
                true);

        Project updatedProjectModel_2 = new Project(2L, "CT2270",
                "TEST FOR PMS  INTERFACE - Customer Project", "RFI - Rete Ferroviaria Italiana",
                "IS Bologna IT", true);

        List<Project> projectList = new ArrayList<>();
        projectList.add(updatedProjectModel_1);
        projectList.add(updatedProjectModel_2);

        Object obj = projectList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);

        when(masterDataServiceClient.getProjectData(request1)).thenReturn(projectList);

        projectList = (List<Project>) masterDataServiceImpl.getProjectData(request1);

        assertThat((projectList.size() == '2'));
    }

}
