package com.alstom.applicationfactory.pmfuservice;

import org.junit.jupiter.api.Test;

class PmfuServiceApplicationTest {

    @Test
    void main() {

    }
}