package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.UserSearchQuery;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserSearchQueryModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.UserSearchQueryRepository;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;

@ExtendWith(MockitoExtension.class)
class UserSearchQueryServiceImplTest {

    @Mock
    private UserSearchQueryRepository userSearchQueryRepo;
    @InjectMocks
    private UserSearchQueryServiceImpl userSearchQueryServiceImpl;

    UUID uuid = UUID.fromString("dc091937-227f-4999-8b2e-586d96480768");
    String email = "test@alstomgroup.com";

    UserModel userObject = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "IS&T Project CoE", "test@alstomgroup.com", "1007771", "Valerie", "LE-GAC");

    UserSearchQueryModel userSearchQueryModel = new UserSearchQueryModel(null, userObject,
            "PMFU-Project-CT308", "Project",
            "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
            false, false, userObject, null, new Date(), new Date(), null, null);

    @Disabled
    @Test
    public void testlistSavedQuery() {
        AtSite atSite1 = new AtSite(UUID.fromString("00714906-efad-919a-b474-cf4668633afc"), 0,
                "Asia Pacific", "China", "Shanghai Alstom Transport Co Ltd", "Shanghai", "5949",
                null, null, "Trains", null, null, null, null, null, null, null, null, null, null,
                false, new Date(), new Date(), null, null);

        List<AtSite> atSiteList = new ArrayList<>();
        atSiteList.add(atSite1);

        Object obj = atSiteList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);

        when(userSearchQueryRepo.findAll(requestModel.getFilterSpecification()))
                .thenReturn(atSiteList);

        // atSiteList = (List<AtSite>)
        // userSearchQueryServiceImpl.listSavedQuery(requestModel);

        assertThat((atSiteList.size() == '1'));
    }

    @Test
    void testlistSavedQueryForElse() {
        assertThrows(ApplicationFactoryException.class,
                () -> userSearchQueryServiceImpl.listSavedQuery("test@alstomgroup.com", "project"),
                "");
    }

    @Disabled
    @Test
    public void testdeleteUserQueryById() {
        UserModel userObject = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "IS&T Project CoE",
                "test@alstomgroup.com", "1007771", "Valerie", "LE-GAC");

        UserSearchQueryModel userSearchQueryModel = new UserSearchQueryModel(null, userObject,
                "PMFU-Project-CT308", "Project",
                "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
                false, false, userObject, null, new Date(), new Date(), null, null);

        UserSearchQueryModel createdUserSearchQueryModel = new UserSearchQueryModel(
                UUID.fromString("dc091937-227f-4999-8b2e-586d96480768"), userObject,
                "PMFU-Project-CT308", "Project",
                "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
                false, false, userObject, null, new Date(), new Date(), null, null);

        UserSearchQueryModel updateUserSearchQueryModel = new UserSearchQueryModel(
                UUID.fromString("dc091937-227f-4999-8b2e-586d96480768"), userObject,
                "PMFU-Project-CT308", "Project",
                "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT381\"}]}}",
                false, false, userObject, null, new Date(), new Date(), null, null);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserSearchQuery alreadySavedAtSite = mapper.map(userSearchQueryModel,
                UserSearchQuery.class);

        when(userSearchQueryRepo.findById(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df")))
                .thenReturn(Optional.of(alreadySavedAtSite));
        userSearchQueryServiceImpl
                .deleteUserQueryById(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"));
        verify(userSearchQueryRepo).delete(alreadySavedAtSite);
    }

    @Disabled
    @Test
    void testdeleteUserQueryByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(userSearchQueryRepo)
                .deleteById(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"));
        assertThrows(ApplicationFactoryException.class, () -> userSearchQueryServiceImpl
                .deleteUserQueryById(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df")), "");
    }

    @Test
    public void testviewSavedQuery() {
        User userObject = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
                "IS&T Project CoE", "test@alstomgroup.com", "1007771", "Valerie", "LE-GAC");

        UserSearchQuery userSearchQuery = new UserSearchQuery(null, userObject,
                "PMFU-Project-CT308", "Project",
                "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
                false, false, userObject, null, new Date(), new Date(), null, null);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserSearchQueryModel userSearchQueryModelModel = mapper.map(userSearchQuery,
                UserSearchQueryModel.class);

        when(userSearchQueryRepo.findById(UUID.fromString("dc091937-227f-4999-8b2e-586d96480768")))
                .thenReturn(Optional.of(userSearchQuery));

        assertThat(userSearchQueryServiceImpl.viewSavedQuery(uuid))
                .isEqualTo(userSearchQueryModelModel);
    }

    @Test
    void testviewSavedQueryForCatch() {
        when(userSearchQueryRepo.findById(UUID.fromString("dc091937-227f-4999-8b2e-586d96480768")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> userSearchQueryServiceImpl
                        .viewSavedQuery(UUID.fromString("dc091937-227f-4999-8b2e-586d96480768")),
                "");
    }

    @Disabled
    @Test
    public void testcreateSavedSearchQuery() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "IS&T Project CoE",
                "test@alstomgroup.com", "1007771", "Valerie", "LE-GAC");

        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
                "IS&T Project CoE", "test@alstomgroup.com", "1007771", "Valerie", "LE-GAC");

        UserSearchQueryModel userSearchQueryModel = new UserSearchQueryModel(null, userObject,
                "PMFU-Project-CT308", "Project",
                "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
                false, false, userObject, null, new Date(), new Date(), null, null);

        UserSearchQuery userSearchQuery = mapper.map(userSearchQueryModel, UserSearchQuery.class);

        UserSearchQuery createdUserSearchQuery = new UserSearchQuery(
                UUID.fromString("dc091937-227f-4999-8b2e-586d96480768"), user, "PMFU-Project-CT308",
                "Project",
                "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
                false, false, user, null, new Date(), new Date(), null, null);

        UserSearchQueryModel expectedUserSearchQueryModel = new UserSearchQueryModel(
                UUID.fromString("dc091937-227f-4999-8b2e-586d96480768"), userObject,
                "PMFU-Project-CT308", "Project",
                "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
                false, false, userObject, null, new Date(), new Date(), null, null);

        when(userSearchQueryRepo.save(userSearchQuery)).thenReturn(createdUserSearchQuery);

        assertThat(userSearchQueryServiceImpl
                .createSavedSearchQuery(email, expectedUserSearchQueryModel).getId())
                        .isEqualTo(expectedUserSearchQueryModel.getId());
    }

    @Disabled
    @Test
    void testcreateSavedSearchQueryForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        UserSearchQuery userSearchQuery = mapper.map(userSearchQueryModel, UserSearchQuery.class);
        when(userSearchQueryRepo.save(userSearchQuery))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class, () -> userSearchQueryServiceImpl
                .createSavedSearchQuery("test@alstomgroup.com", userSearchQueryModel), "");
    }

    @Disabled
    @Test
    public void testupdateSavedSearchQuery() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        UserSearchQueryModel userSearchQueryModel = new UserSearchQueryModel(null, userObject,
                "PMFU-Project-CT308", "Project",
                "{\"filter\":{\"condition\":\"and\",\"filterConditions\":[{\"type\":\"String\",\"field\":\"ctCode\",\"data\":\"CT380\"}]}}",
                false, false, userObject, null, new Date(), new Date(), null, null);

        UserSearchQuery updatedNewUserSearchQuery = mapper.map(userSearchQueryModel,
                UserSearchQuery.class);
        UserSearchQueryModel updatedNewFleetModel = mapper.map(updatedNewUserSearchQuery,
                UserSearchQueryModel.class);
        when(userSearchQueryRepo.save(updatedNewUserSearchQuery))
                .thenReturn(updatedNewUserSearchQuery);
        assertThat(userSearchQueryServiceImpl.updateSavedSearchQuery(email, userSearchQueryModel))
                .isEqualTo(userSearchQueryModel);

    }

    @Test
    void testupdateSavedSearchQueryForElse() {
        assertThrows(ApplicationFactoryException.class, () -> userSearchQueryServiceImpl
                .updateSavedSearchQuery("test@alstomgroup.com", userSearchQueryModel), "");
    }
}
