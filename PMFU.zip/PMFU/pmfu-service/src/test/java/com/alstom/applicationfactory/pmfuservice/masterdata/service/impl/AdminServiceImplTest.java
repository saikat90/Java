/**
 * 
 */
package com.alstom.applicationfactory.pmfuservice.masterdata.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;

import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ApplicationModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.EmailModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProfileModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;

/**
 * @author shalini.jayakumar
 *
 */
@ExtendWith(MockitoExtension.class)
class AdminServiceImplTest {

    @Mock
    private AdminServiceClient adminServiceClient;
    @InjectMocks
    AdminServiceImpl adminService;
    @Mock
    Authentication authentication;

    ApplicationModel applicationModel = new ApplicationModel(
            UUID.fromString("f0ce5c29-9385-4853-9483-ecd1e74062e7"), "Digital Work Instructions",
            "APP_DWI", true, false, false);
    EmailModel emailModel = new EmailModel(Arrays.asList(new String[] { "APPROVER", "VALIDATOR" }),
            "Test Subject", "Test Body");

    UserModel user = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
    UserModel user2 = new UserModel(UUID.fromString("54c22bf5-dd12-9a00-7f1c-933bb85a5b2d"),
            "100769630", "User B", "LastName", "user.b@alstomgroup.com", "IS&T Project CoE");

    // RoleModel role = new
    // RoleModel(UUID.fromString("f0ce5c29-9385-4853-9483-ecd1e74063f8"), "ADMIN",
    // "ADM", true, false);

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#findById(java.lang.String)}.
     */
    @Test
    void testFindById() {
        when(adminServiceClient.findById("f0ce5c29-9385-4853-9483-ecd1e74062e7"))
                .thenReturn(applicationModel);
        ApplicationModel applicationBean = adminService
                .findById("f0ce5c29-9385-4853-9483-ecd1e74062e7");
        assertEquals(applicationBean, applicationModel);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#getProfile(java.lang.String, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testGetProfile() {
        ProfileModel profileModel = new ProfileModel(
                UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), "Digital Work Instruction",
                "APP_DWI", "test", "test@alstomgroup.com", null);
        when(adminServiceClient.getProfile("APP_DWI")).thenReturn(profileModel);
        ProfileModel profileBean = adminService.getProfile("APP_DWI", authentication);
        assertEquals(profileBean, profileModel);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#findEmailByApplicationId(java.lang.String, java.util.Map)}.
     */
    @Test
    void testFindEmailByApplicationId() {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        List<EmailModel> emailList = new ArrayList<>();
        emailList.add(emailModel);
        when(adminServiceClient.findEmailByApplicationId("f0ce5c29-9385-4853-9483-ecd1e74062e7",
                request1)).thenReturn(applicationModel);
        Object emails = emailList;
        Object obj = adminService.findEmailByApplicationId("f0ce5c29-9385-4853-9483-ecd1e74062e7",
                request1);
        assertEquals(emails.toString().length() > 0, obj.toString().length() > 0);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#findRolesByApplicationId(java.lang.String, java.util.Map)}.
     */
    @Test
    void testFindRolesByApplicationId() {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        Object[] str = { "id", false, applicationModel, "roleModel" };
        Object obj = str;
        when(adminServiceClient.findRolesByApplicationId("f0ce5c29-9385-4853-9483-ecd1e74062e7",
                request1)).thenReturn(obj);
        Object obj1 = adminService.findRolesByApplicationId("f0ce5c29-9385-4853-9483-ecd1e74062e7",
                request1);
        assertNotNull(obj1);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#updateEmail(java.lang.Object)}.
     */
    @Test
    void testUpdateEmail() {
        when(adminServiceClient.updateEmail(emailModel)).thenReturn(emailModel);
        Object obj = adminService.updateEmail(emailModel);
        assertNotNull(obj);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#findAllUsers(java.util.Map)}.
     */
    @Test
    void testFindAllUsers() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);

        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);

        Object obj = userlist;

        when(adminServiceClient.findAllUsers(request)).thenReturn(obj);
        Object obj1 = adminService.findAllUsers(request);
        int len = obj.toString().length();
        assertEquals(obj1.toString().length(), len);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#saveAllUsers(java.util.List)}.
     */
    @Test
    void testSaveAllUsers() {
        List<UserModel> userCreatedlist = new ArrayList<>();
        userCreatedlist.add(user);
        List<UserModel> userlist = new ArrayList<>();
        user.setId(null);
        userlist.add(user);
        when(adminServiceClient.saveAllUsers(userlist)).thenReturn(userCreatedlist);
        List<UserModel> userReturnlist = this.adminService.saveAllUsers(userlist);
        assertEquals(userReturnlist.size(), userlist.size());
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#findRoleUsers(java.lang.String, java.lang.String, java.util.Map)}.
     */
    @Test
    void testFindRoleUsers() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);
        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);
        when(adminServiceClient.findRoleUsers("f0ce5c29-9385-4853-9483-ecd1e74062e7", "ADM",
                request)).thenReturn(userlist);
        Object userReturnlist = adminService.findRoleUsers("f0ce5c29-9385-4853-9483-ecd1e74062e7",
                "ADM", request);
        assertNotNull(userReturnlist);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#findUnmappedApplicationRoleUsers(java.lang.String, java.util.Map)}.
     */
    @Test
    void testFindUnmappedApplicationRoleUsers() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);
        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);
        when(adminServiceClient
                .findUnmappedApplicationRoleUsers("f0ce5c29-9385-4853-9483-ecd1e74062e7", request))
                        .thenReturn(userlist);
        Object userReturnlist = adminService
                .findUnmappedApplicationRoleUsers("f0ce5c29-9385-4853-9483-ecd1e74062e7", request);
        assertNotNull(userReturnlist);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#findUsersByApplicationRole(java.lang.String, java.util.Map)}.
     */
    @Test
    void testFindUsersByApplicationRole() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);

        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);

        Object obj = userlist;
        when(adminServiceClient.findUsersByApplicationRole("VALIDATOR", request)).thenReturn(obj);
        Object userReturnlist = adminService.findUsersByApplicationRole("VALIDATOR", request);
        assertNotNull(userReturnlist);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#saveUsersForRole(java.lang.Object)}.
     */
    @Test
    void testSaveUsersForRole() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);

        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);

        Object obj = userlist;
        when(adminServiceClient.saveUsersForRole(obj)).thenReturn(obj);
        Object userReturnlist = adminService.saveUsersForRole(obj);
        assertNotNull(userReturnlist);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#updateUsersForRole(java.lang.Object)}.
     */
    @Test
    void testUpdateUsersForRole() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);

        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);

        Object obj = userlist;
        when(adminServiceClient.updateUsersForRole(obj)).thenReturn(obj);
        Object userReturnlist = adminService.updateUsersForRole(obj);
        assertNotNull(userReturnlist);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#getUnmappedRightsForApplicationRoleUser(java.lang.String, java.lang.String, java.util.Map)}.
     */
    @Test
    void testGetUnmappedRightsForApplicationRoleUser() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);

        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);

        Object obj = userlist;
        when(adminServiceClient.getUnmappedRightsForApplicationRoleUser("APP_PMFP",
                "60411148-419b-455c-80aa-bde941882136", request)).thenReturn(obj);
        Object userReturnlist = adminService.getUnmappedRightsForApplicationRoleUser("APP_PMFP",
                "60411148-419b-455c-80aa-bde941882136", request);
        assertNotNull(userReturnlist);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#listApplicationRoleUserRights(java.lang.String, java.util.Map)}.
     */
    @Test
    void testListApplicationRoleUserRights() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);

        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);

        Object obj = userlist;
        when(adminServiceClient
                .listApplicationRoleUserRights("60411148-419b-455c-80aa-bde941882136", request))
                        .thenReturn(obj);
        Object userReturnlist = adminService
                .listApplicationRoleUserRights("60411148-419b-455c-80aa-bde941882136", request);
        assertNotNull(userReturnlist);

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#saveApplicationRoleRights(java.lang.Object)}.
     */
    @Test
    void testSaveApplicationRoleRights() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);

        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);

        Object obj = userlist;
        when(adminServiceClient.saveApplicationRoleRights(obj)).thenReturn(obj);
        Object userReturnlist = adminService.saveApplicationRoleRights(obj);
        assertNotNull(userReturnlist);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.service.impl.AdminServiceImpl#updateApplicationRoleRights(java.lang.Object)}.
     */
    @Test
    void testUpdateApplicationRoleRights() {
        Map<String, Object> request = new HashMap<>();
        request.put("pageNumber", "0");
        request.put("pageSize", "10");
        request.put("isPaged", "false");
        request.put("filterJoins", null);
        request.put("sort", null);

        List<UserModel> userlist = new ArrayList<>();
        userlist.add(user);

        Object obj = userlist;
        when(adminServiceClient.updateApplicationRoleRights(obj)).thenReturn(obj);
        Object userReturnlist = adminService.updateApplicationRoleRights(obj);
        assertNotNull(userReturnlist);
    }

}
