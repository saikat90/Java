package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUpAttachment;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpAttachmentModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpAttachmentRepository;

@ExtendWith(MockitoExtension.class)
class ProjectSetUpAttachmentServiceImplTest {

    @Mock
    private ProjectSetUpAttachmentRepository projectSetUpAttachmentRepository;
    @InjectMocks
    private ProjectSetUpAttachmentServiceImpl projectSetUpAttachmentService;
    @Mock
    private UserRepository userRepository;
    @Mock
    private MultipartFile file;
    @Mock
    private File file1;

    ProjectSetUpAttachmentModel projectSetUpAttachmentModel = new ProjectSetUpAttachmentModel(
            UUID.fromString("1923ddd1-d4b6-4e47-89bc-ac50ec68e5d8"), 0, "Dummy-5.pdf", true, new Date(), new Date(),
            "100769630", null, null);

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");
    User user2 = new User(UUID.fromString("54c22bf5-dd12-9a00-7f1c-933bb85a5b2d"), "100769630", "User B", "LastName",
            "user.b@alstomgroup.com", "IS&T Project CoE");
    ProjectSetUpAttachment projectSetUpAttachment = new ProjectSetUpAttachment(
            UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b"), 0, "Dummy.pdf", true, new Date(), new Date(),
            "100769630", "test", null);

    @Test
    public void testuploadAttachment() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        projectSetUpAttachment = null;
        when(projectSetUpAttachmentRepository.save(Mockito.any(ProjectSetUpAttachment.class)))
                .thenReturn(projectSetUpAttachment);

        /*
         * ProjectSetUpAttachmentModel expectedAttachmentModel =
         * projectSetUpAttachmentService.uploadAttachment(file,
         * "user.ar@alstomgroup.com");
         */
        /*
         * ProjectSetUpAttachmentModel expectedAttachmentModel =
         * mapper.map(projectSetUpAttachment, ProjectSetUpAttachmentModel.class);
         */
        // assertThat(projectSetUpAttachmentService.uploadAttachment(file,
        // "user.ar@alstomgroup.com"))
        // .isEqualTo(expectedAttachmentModel);

        // assertNotNull(expectedAttachmentModel);
        assertThrows(ApplicationFactoryException.class,
                () -> projectSetUpAttachmentService.uploadAttachment(file, "user.ar@alstomgroup.com"), "");
    }

    @Test
    public void testuploadAttachmentForNullUser() {
        String email = "user.ar@alstomgroup.com";
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> projectSetUpAttachmentService.uploadAttachment(file, email), "");
    }

    @Test
    void testuploadAttachmentForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);

        when(projectSetUpAttachmentRepository.save(Mockito.any(ProjectSetUpAttachment.class)))
                .thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> projectSetUpAttachmentService.uploadAttachment(file, "user.ar@alstomgroup.com"), "");

    }

    @Test
    void testdeleteAttachmentById() {
        projectSetUpAttachmentService.deleteAttachmentById(projectSetUpAttachment.getId());
        verify(projectSetUpAttachmentRepository).deleteById(projectSetUpAttachment.getId());

    }

    @Test
    void testdeleteAttachmentByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(projectSetUpAttachmentRepository)
                .deleteById(projectSetUpAttachment.getId());
        assertThrows(ApplicationFactoryException.class,
                () -> projectSetUpAttachmentService.deleteAttachmentById(projectSetUpAttachment.getId()), "");

    }

    @Test
    void testdownloadAttachmentForElse() {
        assertThrows(ApplicationFactoryException.class,
                () -> projectSetUpAttachmentService.downloadAttachment(projectSetUpAttachment.getId()), "");
    }

    @Test
    void testdownloadAttachment() {
        when(projectSetUpAttachmentRepository.findById(projectSetUpAttachment.getId()))
                .thenReturn(Optional.of(projectSetUpAttachment));
        File file = projectSetUpAttachmentService.downloadAttachment(projectSetUpAttachment.getId());
        assertNotNull(file);
    }

    @Test
    void testreadFileToByteArray() {
        assertThrows(NullPointerException.class, () -> projectSetUpAttachmentService.readFileToByteArray(file1), "");
    }

}
