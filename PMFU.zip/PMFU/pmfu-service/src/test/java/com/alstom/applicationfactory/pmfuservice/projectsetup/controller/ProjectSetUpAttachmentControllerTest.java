
package com.alstom.applicationfactory.pmfuservice.projectsetup.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.pmfuservice.exception.ErrorModel;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpAttachmentModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.ProjectSetUpAttachmentService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
@WebMvcTest(ProjectSetUpAttachmentController.class)
class ProjectSetUpAttachmentControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private ProjectSetUpAttachmentService projectSetUpAttachmentService;
    @MockBean
    private EmailServiceClient emailServiceClient;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;

    @Autowired
    private WebApplicationContext context;

    ObjectMapper mapper = new ObjectMapper();
    private Path workingDir;

    UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");

    /**
     * init method for file
     */
    @BeforeEach
    public void init() {
        this.workingDir = Path.of("", "src/test/resources");
    }

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    @Test
    public void testuploadAttachment() throws Exception {
        ProjectSetUpAttachmentModel projSetUpAttachmentModel = new ProjectSetUpAttachmentModel(
                UUID.fromString("1168246d-965b-552f-08d2-198bb804400b"), 0, "dummy.pdf", true,
                new Date(), new Date(), "test", "test", null);

        String json = mapper.writeValueAsString(projSetUpAttachmentModel);

        MockMultipartFile file = new MockMultipartFile("file", "hello.txt",
                MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());

        when(projectSetUpAttachmentService.uploadAttachment(file, "test@alstomgroup.com"))
                .thenReturn(projSetUpAttachmentModel);

        /*
         * RequestBuilder request =
         * MockMvcRequestBuilders.post("/projectSetUpAttachment/upload")
         * .accept(MediaType.APPLICATION_JSON).content(json)
         * .contentType(MediaType.APPLICATION_JSON);
         * 
         * MvcResult result =
         * mockMvc.perform(request).andExpect(status().isOk()).andReturn();
         */

        MvcResult result = mockMvc
                .perform(multipart("/projectSetUpAttachment/upload").file(file).param("userEmail",
                        "test@alstomgroup.com"))
                .andDo(print()).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testdownloadAttachment() throws Exception {
        File file;
        Path downloadPath = this.workingDir.resolve("Warning_Sign.png");

        file = new File(downloadPath.toUri());

        byte[] expected_file = readFileToByteArray(file);

        when(projectSetUpAttachmentService.downloadAttachment(uuid)).thenReturn(file);
        when(projectSetUpAttachmentService.readFileToByteArray(file)).thenReturn(expected_file);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/projectSetUpAttachment/005a6076-6001-f39d-6de7-ee13fc92c33b")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testdeleteAttachmentById() throws Exception {

        RequestBuilder request = MockMvcRequestBuilders
                .delete("/projectSetUpAttachment/005a6076-6001-f39d-6de7-ee13fc92c33b")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    private static byte[] readFileToByteArray(File file) {
        FileInputStream fis = null;
        // Creating a byte array using the length of the file
        // file.length returns long which is cast to int
        byte[] bArray = new byte[(int) file.length()];
        try {
            fis = new FileInputStream(file);
            int count = fis.read(bArray);
        } catch (IOException e) {
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.ERROR_LABEL, Constants.ATTACHMENT_READ_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errors);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                }
            }
        }
        return bArray;
    }
}
