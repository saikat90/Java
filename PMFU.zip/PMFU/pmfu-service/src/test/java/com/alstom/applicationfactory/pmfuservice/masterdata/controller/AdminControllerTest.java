package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ApplicationModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProfileModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.AdminService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
@WebMvcTest(AdminController.class)
class AdminControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private WebApplicationContext context;
    @MockBean
    private RequestModel requestModel;
    @MockBean
    private AdminService adminService;
    @MockBean
    private Authentication authentication;
    @MockBean
    private EmailServiceClient emailServiceClient;

    ObjectMapper mapper = new ObjectMapper();

    UserModel user = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "IS&T Project CoE", "test@alstomgroup.com", "777182", "Valerie", "LE-GAC");

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    @Test
    public void testfindById() throws Exception {
        ApplicationModel applicationModel = new ApplicationModel(
                UUID.fromString("4d4c16a1-23a0-4b66-b6ff-b065f654602b"), "PMFU", "APP_PMFU", true,
                false, true);
        when(adminService.findById("4d4c16a1-23a0-4b66-b6ff-b065f654602b"))
                .thenReturn(applicationModel);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/applications/4d4c16a1-23a0-4b66-b6ff-b065f654602b")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testgetProfile() throws Exception {
        ProfileModel profileModel = new ProfileModel(
                UUID.fromString("4d4c16a1-23a0-4b66-b6ff-b065f654602b"), "PMFU", "APP_PMFU", "test",
                "test@alstomgroup.com", new HashSet(Arrays.asList(new String("APP_ADM"),
                        new String("ADM_PROXY"), new String("APP_PMFU"))));
        when(adminService.getProfile("APP_ADM", authentication)).thenReturn(profileModel);

        RequestBuilder request = MockMvcRequestBuilders.get("/applications/APP_ADM/profile")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testupdateEmail() throws Exception {
        String json = mapper.writeValueAsString("test@alstomgroup.com");
        when(adminService.updateEmail("test")).thenReturn("test@alstomgroup.com");

        RequestBuilder request = MockMvcRequestBuilders.put("/emails")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testfindEmailByApplicationId() throws Exception {

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = mapper.writeValueAsString(request1);
        when(adminService.findEmailByApplicationId("4d4c16a1-23a0-4b66-b6ff-b065f654602b",
                request1)).thenReturn("test@alstomgroup.com");

        RequestBuilder request = MockMvcRequestBuilders
                .post("/emails/4d4c16a1-23a0-4b66-b6ff-b065f654602b/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testfindRolesByApplicationId() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = mapper.writeValueAsString(request1);
        when(adminService.findRolesByApplicationId("4d4c16a1-23a0-4b66-b6ff-b065f654602b",
                request1)).thenReturn("test@alstomgroup.com");

        RequestBuilder request = MockMvcRequestBuilders
                .post("/application-roles/application/4d4c16a1-23a0-4b66-b6ff-b065f654602b")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testfindAllUsers() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        List<UserModel> userModelList = new ArrayList<UserModel>();

        UserModel createdUserModel = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        userModelList.add(createdUserModel);

        String json = mapper.writeValueAsString(request1);
        when(adminService.findAllUsers(request1)).thenReturn(userModelList);

        RequestBuilder request = MockMvcRequestBuilders.post("/users/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testsaveAllUsers() throws Exception {
        List<UserModel> userList = new ArrayList<UserModel>();
        List<UserModel> userModelList = new ArrayList<UserModel>();

        UserModel userModel = new UserModel(null, "100777182", "User A", "LastName",
                "user.ar@alstomgroup.com", "IS&T Project CoE");

        UserModel createdUserModel = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        userList.add(userModel);
        userModelList.add(createdUserModel);

        String json = mapper.writeValueAsString(userList);

        when(adminService.saveAllUsers(userList)).thenReturn(userModelList);
        RequestBuilder request = MockMvcRequestBuilders.post("/users/all")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testfindUnmappedApplicationRoleUsers() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = mapper.writeValueAsString(user);
        when(adminService.findUnmappedApplicationRoleUsers("03e657fc-0c20-bc4e-a755-9d0233c9d8c3",
                request1)).thenReturn(user);

        RequestBuilder request = MockMvcRequestBuilders
                .post("/users/4d4c16a1-23a0-4b66-b6ff-b065f654602b/unmapped-users")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testfindRoleUsers() throws Exception {

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = mapper.writeValueAsString(user);
        when(adminService.findRoleUsers("4d4c16a1-23a0-4b66-b6ff-b065f654602b", "ADM", request1))
                .thenReturn(user);

        RequestBuilder request = MockMvcRequestBuilders.post(
                "/application-role-users/application/4d4c16a1-23a0-4b66-b6ff-b065f654602b/role/ADM/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testfindUsersByApplicationRole() throws Exception {

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = mapper.writeValueAsString(user);
        when(adminService.findUsersByApplicationRole("36379ee2-202c-49d1-9d26-cc104da58d21",
                request1)).thenReturn(user);

        RequestBuilder request = MockMvcRequestBuilders.post(
                "/application-role-users/application-role/36379ee2-202c-49d1-9d26-cc104da58d21")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testsaveUsersForRole() throws Exception {
        String json = mapper.writeValueAsString(user);

        when(adminService.saveUsersForRole(user)).thenReturn(user);
        RequestBuilder request = MockMvcRequestBuilders.post("/application-role-users/all")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testupdateUsersForRole() throws Exception {

        String json = mapper.writeValueAsString(user);
        when(adminService.updateUsersForRole(user)).thenReturn(new Object());

        RequestBuilder request = MockMvcRequestBuilders.put("/application-role-users/all")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testgetUnmappedRightsForApplicationRoleUser() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = mapper.writeValueAsString(user);
        when(adminService.getUnmappedRightsForApplicationRoleUser(
                "4d4c16a1-23a0-4b66-b6ff-b065f654602b", "86694c37-42ef-46ba-84ed-2e93740e6ed2",
                request1)).thenReturn(user);

        RequestBuilder request = MockMvcRequestBuilders.post(
                "/rights/4d4c16a1-23a0-4b66-b6ff-b065f654602b/user/86694c37-42ef-46ba-84ed-2e93740e6ed2/unmapped")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testsaveApplicationRoleRights() throws Exception {

        String json = mapper.writeValueAsString(user);

        when(adminService.saveApplicationRoleRights(user)).thenReturn(user);
        RequestBuilder request = MockMvcRequestBuilders.post("/application-role-user-rights")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testupdateApplicationRoleRights() throws Exception {
        String json = mapper.writeValueAsString(user);

        when(adminService.updateApplicationRoleRights(user)).thenReturn(user);
        RequestBuilder request = MockMvcRequestBuilders.put("/application-role-user-rights")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void listApplicationRoleUserRights() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = mapper.writeValueAsString(user);
        when(adminService.listApplicationRoleUserRights("f1dd1165-56c0-4fb0-8573-67a4c3b11b35",
                request1)).thenReturn(user);
        RequestBuilder request = MockMvcRequestBuilders
                .post("/application-role-user-rights/f1dd1165-56c0-4fb0-8573-67a4c3b11b35")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }
}
