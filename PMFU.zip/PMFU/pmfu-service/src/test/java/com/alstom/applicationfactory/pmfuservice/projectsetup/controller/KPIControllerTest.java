package com.alstom.applicationfactory.pmfuservice.projectsetup.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.AllActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractStatusGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQDeliveryGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQEventModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQMilestoneGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.repository.ProjectSetUpRepository;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.KPIService;
import com.alstom.applicationfactory.pmfuservice.projectsetup.service.QlikSenseService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(KPIController.class)
class KPIControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private KPIService kpiService;
    @MockBean
    private QlikSenseService qlikSenseService;

    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private WebApplicationContext context;

    ObjectMapper mapper = new ObjectMapper();

    UUID uuid = UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8");

    @MockBean
    private ProjectSetUpRepository projSetUpRepo;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    @Test
    public void testgetDFQEventData() throws Exception {

        UUID id = UUID.fromString("021ae86d-7578-0c1d-e986-d6d7212205d8");

        DFQEventModel dfqEventObject1 = new DFQEventModel("N506", "rail", "Indirect Sourcing",
                new Date(), new Date(), "2019-01-14 00:00:00", 1, "active");

        DFQEventModel dfqEventObject2 = new DFQEventModel("N505", "rail", "Indirect Sourcing",
                new Date(), new Date(), "2019-01-14 00:00:00", 1, "active");

        List<DFQEventModel> dfqEventList = new ArrayList<>();

        dfqEventList.add(dfqEventObject1);
        dfqEventList.add(dfqEventObject1);

        when(kpiService.getDFQEventData(id, "2")).thenReturn(dfqEventList);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/KPI/DFQEvent/021ae86d-7578-0c1d-e986-d6d7212205d8/2")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testgetProjectMasterData() throws Exception {

        ProjectMasterDataModel projectMasterObject1 = new ProjectMasterDataModel(87,
                "Algeria - Sidi Bel Abbes Tramway RS", "CT3971", "Latin America", "Santiago",
                "Villeurbanne", "Ilona STELMACH", "A01", "A535", null, null, "yes", 2, new Date(),
                new Date(), new Date(), "2019-01-14 00:00:00", 2, "active");
        ProjectMasterDataModel projectMasterObject2 = new ProjectMasterDataModel(143,
                "ALM - Tramway d'ANGERS", "CT2576", "France", "Villeurbanne", "Rolling Stock",
                "Alex ONO", "B01", "B000", null, null, "yes", 2, new Date(), new Date(), new Date(),
                "2019-01-14 00:00:00", 2, "active");

        List<ProjectMasterDataModel> projectMasterDataList = new ArrayList<>();
        projectMasterDataList.add(projectMasterObject1);
        projectMasterDataList.add(projectMasterObject2);

        when(kpiService.getProjectMasterData(uuid)).thenReturn(projectMasterDataList);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/KPI/project/021ae86d-7578-0c1d-e986-d6d7212205d8")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testgetContractStatus() throws Exception {

        ContractStatusGraphModel contractStatusGraphObject1 = new ContractStatusGraphModel(1, 0,
                "yes");
        ContractStatusGraphModel contractStatusGraphObject2 = new ContractStatusGraphModel(1, 0,
                "yes");

        List<ContractStatusGraphModel> contractStatusList = new ArrayList();
        contractStatusList.add(contractStatusGraphObject1);
        contractStatusList.add(contractStatusGraphObject2);

        when(kpiService.getContractStatus(uuid)).thenReturn(contractStatusList);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/KPI/contractStatus/021ae86d-7578-0c1d-e986-d6d7212205d8")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testgetDFQMileStoneGraph() throws Exception {

        DFQMilestoneGraphModel dfqMilestoneGraphModelObject1 = new DFQMilestoneGraphModel(0, 1, 2,
                2, 1, 1, null);
        DFQMilestoneGraphModel dfqMilestoneGraphModelObject2 = new DFQMilestoneGraphModel(0, 1, 2,
                2, 3, 1, null);

        List<DFQMilestoneGraphModel> dfqMilestoneGraphList = new ArrayList();
        dfqMilestoneGraphList.add(dfqMilestoneGraphModelObject1);
        dfqMilestoneGraphList.add(dfqMilestoneGraphModelObject2);

        when(kpiService.getDFQMileStoneGraph(uuid)).thenReturn(dfqMilestoneGraphList);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/KPI/dfqMileStoneGraph/021ae86d-7578-0c1d-e986-d6d7212205d8")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testgetDFQDeliveryGraph() throws Exception {

        DFQDeliveryGraphModel dfqDeliveryGraphModelObject1 = new DFQDeliveryGraphModel(0, 1, 2, 2,
                null);
        DFQDeliveryGraphModel dfqDeliveryGraphModelObject2 = new DFQDeliveryGraphModel(0, 1, 2, 2,
                null);

        List<DFQDeliveryGraphModel> dfqDeliveryList = new ArrayList<>();
        dfqDeliveryList.add(dfqDeliveryGraphModelObject1);
        dfqDeliveryList.add(dfqDeliveryGraphModelObject1);

        when(kpiService.getDFQDeliveryGraph(uuid)).thenReturn(dfqDeliveryList);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/KPI/dfqDeliveryGraph/021ae86d-7578-0c1d-e986-d6d7212205d8")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    @Test
    public void testgetAllActions() throws Exception {

        AllActionsModel allActionsModel_1 = new AllActionsModel("A050", new Date(), new Date(),
                "PIC", "Description", "1", "OPEN", new Date(), 100, "Test Project1", "A07",
                "Test Material 1", new Date());
        AllActionsModel allActionsModel_2 = new AllActionsModel("A050", new Date(), new Date(),
                "PIC", "Description", "2", "OPEN", new Date(), 101, "Test Project2", "A07",
                "Test Material 2", new Date());

        List<AllActionsModel> allActionsModelList = new ArrayList<>();
        allActionsModelList.add(allActionsModel_1);
        allActionsModelList.add(allActionsModel_2);

        when(kpiService.getAllActions(uuid, "OPEN")).thenReturn(allActionsModelList);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/KPI/021ae86d-7578-0c1d-e986-d6d7212205d8/allActions/OPEN")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }
}
