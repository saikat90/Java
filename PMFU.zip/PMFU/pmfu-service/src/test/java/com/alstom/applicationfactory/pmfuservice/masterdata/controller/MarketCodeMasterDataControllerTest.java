package com.alstom.applicationfactory.pmfuservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.pmfuservice.common.constant.Constants;
import com.alstom.applicationfactory.pmfuservice.common.model.RequestModel;
import com.alstom.applicationfactory.pmfuservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.pmfuservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.MarketCodeMasterData;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.MarketCodeMasterDataModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.repository.MarketCodeMasterDataRepository;
import com.alstom.applicationfactory.pmfuservice.masterdata.service.MarketCodeMasterDataService;
import com.alstom.applicationfactory.pmfuservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(MarketCodeMasterDataController.class)
class MarketCodeMasterDataControllerTest {

	@MockBean
	private MarketCodeMasterDataService mdMarketCodeService;
	@MockBean
	private MarketCodeMasterDataRepository mdMarketCodeRepository;
	
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private AdminServiceClient adminServiceClient;
	@MockBean
	private AuthorizationConfig authConfig;
	@MockBean
	private JwtDecoder jwtDecoder;

	@Autowired
	private WebApplicationContext context;
	
	ObjectMapper mapper = new ObjectMapper();
	
	MarketCodeMasterDataModel marketCodeMasterDataModel = new MarketCodeMasterDataModel(null, 1,
			"C030", "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing", "GLOBAL Coordinated", "JUS Nicolas","JUS Nicolas", "JUS Nicolas",14,21,14,21,21,21,21,0,0,21);
			
	
	Object updatedMarketCodeMasterDataModel_1 = new MarketCodeMasterData(UUID.fromString("00f034e5-e020-b064-6dd3-49ba18554a79"), 1,
			"N506", "ME - Production Machines", "C00", "Indirect Sourcing", "GLOBAL Coordinated", "TLEMCANI Yassine","ROJAS Alexander", "ROJAS Alexander",14,21,14,21,21,21,21,0,0,21);
	
	MarketCodeMasterDataModel createdMarketCodeMasterDataModel = new MarketCodeMasterDataModel(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1,
			"C030", "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing", "GLOBAL Coordinated", "JUS Nicolas","JUS Nicolas", "JUS Nicolas",14,21,14,21,21,21,21,0,0,21);

	MarketCodeMasterDataModel updateMarketCodeMasterDataModel = new MarketCodeMasterDataModel(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1,
			"C030", "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing", "GLOBAL Coordinated", "JUS Nicolas","JUS Nicolas", "JUS Nicolas",14,21,14,21,21,21,21,0,0,21);

	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);

		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

		when(adminServiceClient.getAuthorities("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_PMFU",
				"test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

		when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

		when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV")).thenReturn(null);
	}
	

	@Test
	public void testfindAll() throws Exception {
		MarketCodeMasterData marketCodeMasterDataObject1 = new MarketCodeMasterData(UUID.fromString("00f034e5-e020-b064-6dd3-49ba18554a79"), 1,
				"N506", "ME - Production Machines", "C00", "Indirect Sourcing", "GLOBAL Coordinated", "TLEMCANI Yassine","ROJAS Alexander", "ROJAS Alexander",14,21,14,21,21,21,21,0,0,21);

		MarketCodeMasterData marketCodeMasterDataObject2 = new MarketCodeMasterData(UUID.fromString("020111ea-e1f3-4961-006a-7a81c86eb5ef"), 1,
				"C030", "Electrical/Electronic catalog parts", "C00", "Indirect Sourcing", "GLOBAL Coordinated", "JUS Nicolas","JUS Nicolas", "JUS Nicolas",14,21,14,21,21,21,21,0,0,21);

		List<MarketCodeMasterData> marketCodeMasterDataList = new ArrayList<>();

		marketCodeMasterDataList.add(marketCodeMasterDataObject1);
		marketCodeMasterDataList.add(marketCodeMasterDataObject2);
		
		
		when(mdMarketCodeRepository.findAll()).thenReturn(marketCodeMasterDataList);

		RequestBuilder request = MockMvcRequestBuilders.get("/MDMarketCode/list").accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
		
		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}

	@Test
	public void testsearchMDMarketCode() throws Exception {
		Map<String, Object> request1 = new HashMap<>();
		request1.put("pageNumber", 0);
		request1.put("pageSize", 10);
		request1.put("isPaged", true);
		request1.put("filterJoins", null);
		request1.put("sort", null);

		String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

		RequestModel requestModel = RequestMapper.map(request1);
		when(mdMarketCodeService.searchMDMarketCode(requestModel)).thenReturn(updatedMarketCodeMasterDataModel_1);
		RequestBuilder request = MockMvcRequestBuilders.post("/MDMarketCode/list").accept(MediaType.APPLICATION_JSON)
				.content(json).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
		
		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}

	@Test
	public void testviewMDMarketCode() throws Exception {
		when(mdMarketCodeService.viewMDMarketCode(UUID.fromString("00f034e5-e020-b064-6dd3-49ba18554a79")))
		.thenReturn(createdMarketCodeMasterDataModel);

		RequestBuilder request = MockMvcRequestBuilders.get("/MDMarketCode/00f034e5-e020-b064-6dd3-49ba18554a79")
		.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
		
		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}

	@Test
	public void testdeleteMDMarketCodeById() throws Exception {
		RequestBuilder request = MockMvcRequestBuilders.delete("/MDMarketCode/00f034e5-e020-b064-6dd3-49ba18554a79")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
		
		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}

	@Test
	public void testcreateMDMarketCode() throws Exception {
		String json = mapper.writeValueAsString(marketCodeMasterDataModel);

		when(mdMarketCodeService.createMDMarketCode(marketCodeMasterDataModel)).thenReturn(createdMarketCodeMasterDataModel);

		RequestBuilder request = MockMvcRequestBuilders.post("/MDMarketCode").accept(MediaType.APPLICATION_JSON)
				.content(json).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
		
		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}

	@Test
	public void testupdateMDMarketCode() throws Exception {
		String json = mapper.writeValueAsString(updateMarketCodeMasterDataModel);

		when(mdMarketCodeService.updateMDMarketCode(updateMarketCodeMasterDataModel)).thenReturn(updateMarketCodeMasterDataModel);

		RequestBuilder request = MockMvcRequestBuilders.put("/MDMarketCode").accept(MediaType.APPLICATION_JSON)
				.content(json).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
		
		 assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
	}

	@Test
	public void testreplaceMDMarketCode() {
		mdMarketCodeService.replaceMDMarketCode("B750","A100");
	}

}
