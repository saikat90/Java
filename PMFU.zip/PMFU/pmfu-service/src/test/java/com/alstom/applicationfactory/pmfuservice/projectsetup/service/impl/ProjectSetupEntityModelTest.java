/**
 */
package com.alstom.applicationfactory.pmfuservice.projectsetup.service.impl;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.alstom.applicationfactory.pmfuservice.masterdata.entity.AtSite;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.Project;
import com.alstom.applicationfactory.pmfuservice.masterdata.entity.User;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.AtSiteModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.pmfuservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityActionPlan;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityContract;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.CommodityStatus;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.Contracts;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMarket;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectMilestone;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUp;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.ProjectSetUpAttachment;
import com.alstom.applicationfactory.pmfuservice.projectsetup.entity.PuActions;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityActionPlanModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.CommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractStatusGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ContractsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQDeliveryGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQEventModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.DFQMilestoneGraphModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMarketModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectMilestoneModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpAttachmentModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.ProjectSetUpModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.PuActionsModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityActionPlanModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityContractModel;
import com.alstom.applicationfactory.pmfuservice.projectsetup.model.QliksenseCommodityStatusModel;

/**
 * @author 100769630
 */
class ProjectSetupEntityModelTest {

    String testString = "Test";

    Project project = new Project(Long.valueOf(147), "CT3835", "Mexico - Mexico - Ferromex ILPAC",
            "Rail Control", "Alstom Transport Mexico", false);

    Project project2 = new Project(Long.valueOf(147), "CT3835", "Mexico - Mexico - Ferromex ILPAC",
            "Rail Control", "Alstom Transport Mexico", false);

    ProjectModel projectModel = new ProjectModel(Long.valueOf(147), "CT3835",
            "Mexico - Mexico - Ferromex ILPAC", "Rail Control", "Alstom Transport Mexico", false);

    ProjectModel projectModel2 = new ProjectModel(Long.valueOf(147), "CT3835",
            "Mexico - Mexico - Ferromex ILPAC", "Rail Control", "Alstom Transport Mexico", false);

    AtSite site = new AtSite(UUID.fromString("1dec4272-5226-19fc-2c54-4e411a38c219"), 0,
            "Latin America", "Mexico", "Alstom Transport Mexico", "Mexico", "5323", "test", "test",
            "Rail Services", Double.valueOf(0), Double.valueOf(0), Double.valueOf(0),
            Double.valueOf(0), Double.valueOf(0), "test", "test", "test", "test", "test", false,
            new Date(), new Date(), "165809", "165809");

    AtSite site2 = new AtSite(UUID.fromString("1dec4272-5226-19fc-2c54-4e411a38c219"), 0,
            "Latin America", "Mexico", "Alstom Transport Mexico", "Mexico", "5323", "test", "test",
            "Rail Services", Double.valueOf(0), Double.valueOf(0), Double.valueOf(0),
            Double.valueOf(0), Double.valueOf(0), "test", "test", "test", "test", "test", false,
            new Date(), new Date(), "165809", "165809");

    AtSiteModel siteModel = new AtSiteModel(UUID.fromString("1dec4272-5226-19fc-2c54-4e411a38c219"),
            0, "Latin America", "Mexico", "Alstom Transport Mexico", "Mexico", "5323", "test",
            "test", "Rail Services", Double.valueOf(0), Double.valueOf(0), Double.valueOf(0),
            Double.valueOf(0), Double.valueOf(0), "test", "test", "test", "test", "test", false,
            new Date(), new Date(), "165809", "165809");

    AtSiteModel siteModel2 = new AtSiteModel(
            UUID.fromString("1dec4272-5226-19fc-2c54-4e411a38c219"), 0, "Latin America", "Mexico",
            "Alstom Transport Mexico", "Mexico", "5323", "test", "test", "Rail Services",
            Double.valueOf(0), Double.valueOf(0), Double.valueOf(0), Double.valueOf(0),
            Double.valueOf(0), "test", "test", "test", "test", "test", false, new Date(),
            new Date(), "165809", "165809");

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
            "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    User user3 = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
            "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    UserModel userModel3 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    User user2 = new User(UUID.fromString("54c22bf5-dd12-9a00-7f1c-933bb85a5b2d"), "100769630",
            "User B", "LastName", "user.b@alstomgroup.com", "IS&T Project CoE");
    UserModel user2Model = new UserModel(UUID.fromString("54c22bf5-dd12-9a00-7f1c-933bb85a5b2d"),
            "100769630", "User B", "LastName", "user.b@alstomgroup.com", "IS&T Project CoE");

    CommodityContract commodityContract = new CommodityContract(
            UUID.fromString("f1581fbf-eb60-5fde-5129-0566381bb537"), 0, "test", null, null);

    CommodityContract commodityContract2 = new CommodityContract(
            UUID.fromString("f1581fbf-eb60-5fde-5129-0566381bb537"), 0, "test", null, null);

    CommodityContractModel commodityContractModel = new CommodityContractModel(
            UUID.fromString("f1581fbf-eb60-5fde-5129-0566381bb537"), 0, "test", null, null);

    CommodityContractModel commodityContractModel2 = new CommodityContractModel(
            UUID.fromString("f1581fbf-eb60-5fde-5129-0566381bb537"), 0, "test", null, null);

    Contracts contract = new Contracts(UUID.fromString("5d3f5473-6217-0586-6303-4d445c37d53c"), 0,
            "Capteur de vitesse", "PO", "NO", "SINGED", "NOT_SENT", "NOT_RECEIVED", "NOT_RECEIVED",
            "RECEIVED", "NOT_APPLICABLE", "test", commodityContract);

    ContractsModel contractModel = new ContractsModel(
            UUID.fromString("5d3f5473-6217-0586-6303-4d445c37d53c"), 0, "Capteur de vitesse", "PO",
            "NO", "SINGED", "NOT_SENT", "NOT_RECEIVED", "NOT_RECEIVED", "RECEIVED",
            "NOT_APPLICABLE", "test", commodityContractModel);

    Contracts contract2 = new Contracts(UUID.fromString("5d3f5473-6217-0586-6303-4d445c37d55d"), 0,
            "Test material", "PO", "NO", "SINGED", "SENT", "RECEIVED", "RECEIVED", "RECEIVED",
            "NOT_APPLICABLE", "test", commodityContract);

    ContractsModel contract2Model = new ContractsModel(
            UUID.fromString("5d3f5473-6217-0586-6303-4d445c37d55d"), 0, "Test material", "PO", "NO",
            "SINGED", "SENT", "RECEIVED", "RECEIVED", "RECEIVED", "NOT_APPLICABLE", "test",
            commodityContractModel);

    CommodityActionPlan commodityActionPlan = new CommodityActionPlan(
            UUID.fromString("202cb812-48e5-37a6-ed0b-b9e8ac6617c7"), 0, "Test Name", "User A",
            "user B", "user C", null, null);

    CommodityActionPlan commodityActionPlan2 = new CommodityActionPlan(
            UUID.fromString("202cb812-48e5-37a6-ed0b-b9e8ac6617c7"), 0, "Test Name", "User A",
            "user B", "user C", null, null);

    CommodityActionPlanModel commodityActionPlanModel = new CommodityActionPlanModel(
            UUID.fromString("202cb812-48e5-37a6-ed0b-b9e8ac6617c7"), 0, "Test Name", "User A",
            "user B", "user C", null, null);

    CommodityActionPlanModel commodityActionPlanModel2 = new CommodityActionPlanModel(
            UUID.fromString("202cb812-48e5-37a6-ed0b-b9e8ac6617c7"), 0, "Test Name", "User A",
            "user B", "user C", null, null);

    PuActions actions = new PuActions(UUID.fromString("deb365c3-0937-b6b6-2297-2162200d8728"), 0,
            new Date(), "Assia EL-HOUSSAME", "Place PO for Capteur", "1", new Date(), "OPEN",
            commodityActionPlan, "Capteur", new Date());

    PuActions actions2 = new PuActions(UUID.fromString("deb365c3-0937-b6b6-2297-2162200d8728"), 0,
            new Date(), "Assia EL-HOUSSAME", "Place PO for Capteur", "1", new Date(), "OPEN",
            commodityActionPlan, "Capteur", new Date());

    PuActionsModel actionsModel = new PuActionsModel(
            UUID.fromString("deb365c3-0937-b6b6-2297-2162200d8728"), 0, new Date(),
            "Assia EL-HOUSSAME", "Place PO for Capteur", "1", new Date(), "OPEN",
            commodityActionPlanModel, "Capteur", new Date());

    PuActionsModel actionsModel2 = new PuActionsModel(
            UUID.fromString("deb365c3-0937-b6b6-2297-2162200d8728"), 0, new Date(),
            "Assia EL-HOUSSAME", "Place PO for Capteur", "1", new Date(), "OPEN",
            commodityActionPlanModel, "Capteur", new Date());

    @SuppressWarnings("deprecation")
    Date needsdate = new Date(2020, 07, 15);
    Calendar calendar = Calendar.getInstance();
    Date actualdate = calendar.getTime();

    CommodityStatus commodityStatus = new CommodityStatus(
            UUID.fromString("d59bf831-6a66-3081-4aea-5c16b9258055"), 0, "Capteur de vitesse",
            "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X", new Date(), "X",
            "Duration", null, 0, 0, 28, 1, 2, 3, 0, 0, 5, 1, new Date(), 80, "Needs", new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), "Actual Date", new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), "Status", "RECEIVED", "GO",
            "NO_GO", "GO", "GO", "NO_GO", "GO", "NO_GO", "GO", "NO_GO", "GO", null, "NOT_DELIVERED",
            "Status Color", "0xFF008000", "0xFF008000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", null, 0, "Forecast Title", new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date());

    CommodityStatus commodityStatus2 = new CommodityStatus(
            UUID.fromString("d59bf831-6a66-3081-4aea-5c16b9258055"), 0, "Capteur de vitesse",
            "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X", needsdate, "X",
            "Duration", null, 0, 0, 28, 1, 2, 3, 0, 0, 5, 1, needsdate, 80, "Needs", needsdate,
            needsdate, needsdate, needsdate, needsdate, needsdate, needsdate, needsdate, needsdate,
            needsdate, needsdate, needsdate, needsdate, "Actual Date", null, null, null, null, null,
            null, null, null, null, null, null, null, null, "Status", "RECEIVED", "GO", "NO_GO",
            "GO", "GO", "NO_GO", "GO", "NO_GO", "GO", "NO_GO", "GO", null, "NOT_DELIVERED",
            "Status Color", "0xFF008000", "0xFF008000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", null, 0, "Forecast Title", new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date(), new Date(), new Date(), new Date(),
            new Date(), new Date(), new Date(), new Date());

    ProjectMilestone projectMileStone = new ProjectMilestone(
            UUID.fromString("e35e813d-b745-5f67-46c4-3dc9ec969d8b"), 0, "Capteur de vitesse",
            "0xFFFF0000", "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", needsdate, "B856",
            "Data Recording & Odometry", "B01", "Digital Mobility", "Global", "OMEDEI Davide",
            "test", "test", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21, "SNCF - France - TGV du futur",
            null, 0, "CT3320", 29, commodityStatus);

    ProjectMilestoneModel projectMileStoneModel = new ProjectMilestoneModel(
            UUID.fromString("e35e813d-b745-5f67-46c4-3dc9ec969d8b"), 0, "Capteur de vitesse",
            "0xFFFF0000", "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", needsdate, "B856",
            "Data Recording & Odometry", "B01", "Digital Mobility", "Global", "OMEDEI Davide",
            "test", "test", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21, "SNCF - France - TGV du futur",
            null, 0, "CT3320", 29, null);

    ProjectMilestone projectMileStone1 = new ProjectMilestone(
            UUID.fromString("e35e813d-b745-5f67-46c4-3dc9ec969d9c"), 0, "test", "0xFFFF0000",
            "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", needsdate, "B856",
            "Data Recording & Odometry", "B01", "Digital Mobility", "Global", "OMEDEI Davide",
            "test", "test", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21, "SNCF - France - TGV du futur",
            null, 0, "CT3320", 29, commodityStatus);

    ProjectMilestoneModel projectMileStone1Model = new ProjectMilestoneModel(
            UUID.fromString("e35e813d-b745-5f67-46c4-3dc9ec969d9c"), 0, "test", "0xFFFF0000",
            "SPECIFICATION", "X", "X", "X", "X", "X", "X", "X", "X", "X", "X", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000",
            "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", "0xFFFF0000", needsdate, "B856",
            "Data Recording & Odometry", "B01", "Digital Mobility", "Global", "OMEDEI Davide",
            "test", "test", 14, 21, 14, 21, 21, 21, 21, 0, 0, 21, "SNCF - France - TGV du futur",
            null, 0, "CT3320", 29, null);

    ProjectMarket projectMarket = new ProjectMarket(
            UUID.fromString("0fed00e2-083f-ea1d-a97c-3800e968ecbf"), 0, "B856", "B01", null, 0,
            Arrays.asList(projectMileStone), commodityContract, commodityActionPlan);

    ProjectMarket projectMarket2 = new ProjectMarket(
            UUID.fromString("0fed00e2-083f-ea1d-a97c-3800e968ecbf"), 0, "B856", "B01", null, 0,
            Arrays.asList(projectMileStone), commodityContract, commodityActionPlan);

    ProjectMarketModel projectMarketModel = new ProjectMarketModel(
            UUID.fromString("0fed00e2-083f-ea1d-a97c-3800e968ecbf"), 0, "B856", "B01", null, 0,
            Arrays.asList(projectMileStone1Model), commodityContractModel,
            commodityActionPlanModel);

    ProjectMarketModel projectMarketModel2 = new ProjectMarketModel(
            UUID.fromString("0fed00e2-083f-ea1d-a97c-3800e968ecbf"), 0, "B856", "B01", null, 0,
            Arrays.asList(projectMileStone1Model), commodityContractModel,
            commodityActionPlanModel);

    ProjectSetUp projectSetUp = new ProjectSetUp(
            UUID.fromString("478895ca-2d96-7b65-b5e7-d7d9d1dbca28"), 0, 29, project, "Test", site,
            "ROLLING_STOCK", "PMFU for AVELIA", user, "Test Name", "User A", "user B", "user C",
            "Test Name", "User A", "user B", "user C", user2, "Test Name", "User A", "user B",
            new Date(), new Date(), "100769630", "100777182", Arrays.asList(projectMarket), null);

    ProjectSetUp projectSetUp2 = new ProjectSetUp(
            UUID.fromString("478895ca-2d96-7b65-b5e7-d7d9d1dbca28"), 0, 29, project, "Test", site,
            "ROLLING_STOCK", "PMFU for AVELIA", user, "Test Name", "User A", "user B", "user C",
            "Test Name", "User A", "user B", "user C", user2, "Test Name", "User A", "user B",
            new Date(), new Date(), "100769630", "100777182", Arrays.asList(projectMarket), null);

    ProjectSetUpModel projectSetUpModel = new ProjectSetUpModel(
            UUID.fromString("478895ca-2d96-7b65-b5e7-d7d9d1dbca28"), 0, 29, projectModel, "Test",
            siteModel, "ROLLING_STOCK", "PMFU for AVELIA", userModel, "Test Name", "User A",
            "user B", "user C", "Test Name", "User A", "user B", "user C", user2Model, "Test Name",
            "User A", "user B", new Date(), new Date(), "100769630", "100777182", null, null);

    ProjectSetUpModel projectSetUpModel2 = new ProjectSetUpModel(
            UUID.fromString("478895ca-2d96-7b65-b5e7-d7d9d1dbca28"), 0, 29, projectModel, "Test",
            siteModel, "ROLLING_STOCK", "PMFU for AVELIA", userModel, "Test Name", "User A",
            "user B", "user C", "Test Name", "User A", "user B", "user C", user2Model, "Test Name",
            "User A", "user B", new Date(), new Date(), "100769630", "100777182", null, null);

    ProjectSetUpAttachment projectSetUpAttachment = new ProjectSetUpAttachment(
            UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b"), 0, "Dummy.pdf", true,
            new Date(), new Date(), "100769630", "test", projectSetUp);

    ProjectSetUpAttachment projectSetUpAttachment2 = new ProjectSetUpAttachment(
            UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b"), 0, "Dummy.pdf", true,
            new Date(), new Date(), "100769630", "test", projectSetUp);

    ProjectSetUpAttachmentModel projectSetUpAttachmentModel = new ProjectSetUpAttachmentModel(
            UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b"), 0, "Dummy.pdf", true,
            new Date(), new Date(), "100769630", "test", projectSetUpModel);

    ProjectSetUpAttachmentModel projectSetUpAttachmentModel2 = new ProjectSetUpAttachmentModel(
            UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b"), 0, "Dummy.pdf", true,
            new Date(), new Date(), "100769630", "test", projectSetUpModel);

    QliksenseCommodityActionPlanModel qlikCommodityActionPlanModel = new QliksenseCommodityActionPlanModel(
            29, "Mexico - Mexico - Ferromex ILPAC", "CT3835", "Mexico", "Rail Service",
            "ROLLING_STOCK", new Date(), "Test Desc", "User Name1", "Test Name", "User A", "user B",
            "user C", "Test Name", "User A", "user B", "user C", "User D", "Test Name", "User A",
            "user B", "B01", "B856", new Date(), "test pic", "action desc", "P1", "SIGNED",
            new Date(), "Capteur de vitesse");

    QliksenseCommodityActionPlanModel qlikCommodityActionPlanModel2 = new QliksenseCommodityActionPlanModel(
            29, "Mexico - Mexico - Ferromex ILPAC", "CT3835", "Mexico", "Rail Service",
            "ROLLING_STOCK", new Date(), "Test Desc", "User Name1", "Test Name", "User A", "user B",
            "user C", "Test Name", "User A", "user B", "user C", "User D", "Test Name", "User A",
            "user B", "B01", "B856", new Date(), "test pic", "action desc", "P1", "SIGNED",
            new Date(), "Capteur de vitesse");

    QliksenseCommodityStatusModel qlikCommodityStatusModel = new QliksenseCommodityStatusModel(29,
            "Mexico - Mexico - Ferromex ILPAC", "CT3835", "Mexico", "Rail Service", "ROLLING_STOCK",
            new Date(), "Test Desc", "User Name1", "Test Name", "User A", "user B", "user C",
            "Test Name", "User A", "user B", "user C", "User D", "Test Name", "User A", "user B",
            "B01", "Digital Mobility", "B856", "Data Recording & Odometry", "Global",
            "Capteur de vitesse", "Tech Imput", "X", 14, new Date(), new Date(), new Date(), "GO",
            "LATE", 0);

    QliksenseCommodityStatusModel qlikCommodityStatusModel2 = new QliksenseCommodityStatusModel(29,
            "Mexico - Mexico - Ferromex ILPAC", "CT3835", "Mexico", "Rail Service", "ROLLING_STOCK",
            new Date(), "Test Desc", "User Name1", "Test Name", "User A", "user B", "user C",
            "Test Name", "User A", "user B", "user C", "User D", "Test Name", "User A", "user B",
            "B01", "Digital Mobility", "B856", "Data Recording & Odometry", "Global",
            "Capteur de vitesse", "Tech Imput", "X", 14, new Date(), new Date(), new Date(), "GO",
            "LATE", 0);

    QliksenseCommodityContractModel qlikCommodityContractModel = new QliksenseCommodityContractModel(
            29, "Mexico - Mexico - Ferromex ILPAC", "CT3835", "Mexico", "Rail Service",
            "ROLLING_STOCK", new Date(), "Test Desc", "User Name1", "Test Name", "User A", "user B",
            "user C", "Test Name", "User A", "user B", "user C", "User D", "Test Name", "User A",
            "user B", "B01", "Digital Mobility", "B856", "Data Recording & Odometry", "Global",
            "Capteur de vitesse", "PO", "NO", "SINGED", "NOT_SENT", "NOT_RECEIVED", "NOT_RECEIVED",
            "RECEIVED", "NOT_APPLICABLE");

    QliksenseCommodityContractModel qlikCommodityContractModel2 = new QliksenseCommodityContractModel(
            29, "Mexico - Mexico - Ferromex ILPAC", "CT3835", "Mexico", "Rail Service",
            "ROLLING_STOCK", new Date(), "Test Desc", "User Name1", "Test Name", "User A", "user B",
            "user C", "Test Name", "User A", "user B", "user C", "User D", "Test Name", "User A",
            "user B", "B01", "Digital Mobility", "B856", "Data Recording & Odometry", "Global",
            "Capteur de vitesse", "PO", "NO", "SINGED", "NOT_SENT", "NOT_RECEIVED", "NOT_RECEIVED",
            "RECEIVED", "NOT_APPLICABLE");

    ContractStatusGraphModel contractStatusGraphModel = new ContractStatusGraphModel(0, 0,
            "Perf Bond");
    ContractStatusGraphModel contractStatusGraphModel2 = new ContractStatusGraphModel(0, 0,
            "Perf Bond");
    DFQMilestoneGraphModel dfqMileStoneGraphModel = new DFQMilestoneGraphModel(1, 2, 0, 1, 0, 2,
            "GO RFQ");
    DFQMilestoneGraphModel dfqMileStoneGraphModel2 = new DFQMilestoneGraphModel(1, 2, 0, 1, 0, 2,
            "GO RFQ");
    DFQEventModel dfqEventModel = new DFQEventModel("B856", "Capteur de vitesse", "Tech Imput",
            new Date(), new Date(), "GO", 0, "LATE");
    DFQEventModel dfqEventModel2 = new DFQEventModel("B856", "Capteur de vitesse", "Tech Imput",
            new Date(), new Date(), "GO", 0, "LATE");
    DFQDeliveryGraphModel dfqDeliveryGraphModel = new DFQDeliveryGraphModel(0, 2, 0, 4,
            "LATE DELIVERED");
    DFQDeliveryGraphModel dfqDeliveryGraphModel2 = new DFQDeliveryGraphModel(0, 2, 0, 4,
            "LATE DELIVERED");

    /**
     * @throws java.lang.Exception
     */
    @BeforeEach
    void setUp() throws Exception {
    }

    @Test
    void test() {
        project.toString();
        project.hashCode();
        projectModel.toString();
        projectModel.hashCode();
        project.equals(project2);
        project.equals(testString);
        // project.equals(null);
        projectModel.equals(projectModel2);
        projectModel.equals(testString);
        projectModel.equals(null);

        site.toString();
        site.hashCode();
        siteModel.toString();
        siteModel.hashCode();
        site.equals(site2);
        site.equals(testString);
        site.equals(null);
        siteModel.equals(siteModel2);
        siteModel.equals(testString);
        siteModel.equals(null);

        user.toString();
        user.hashCode();
        userModel.toString();
        userModel.hashCode();
        user.equals(user3);
        user.equals(testString);
        user.equals(null);
        userModel.equals(userModel3);
        userModel.equals(testString);
        userModel.equals(null);

        commodityContract.toString();
        commodityContract.hashCode();
        commodityContractModel.toString();
        commodityContractModel.hashCode();
        commodityContract.equals(commodityContract2);
        commodityContract.equals(testString);
        commodityContract.equals(null);
        commodityContractModel.equals(commodityContractModel2);
        commodityContractModel.equals(testString);
        commodityContractModel.equals(null);

        contract.toString();
        contract.hashCode();
        contractModel.toString();
        contractModel.hashCode();
        contract.equals(contract2);
        contract.equals(null);
        contractModel.equals(contract2Model);
        contractModel.equals(null);

        commodityActionPlan.toString();
        commodityActionPlan.hashCode();
        commodityActionPlanModel.toString();
        commodityActionPlanModel.hashCode();
        commodityActionPlan.equals(commodityActionPlan2);
        commodityActionPlan.equals(null);
        commodityActionPlanModel.equals(commodityActionPlanModel2);
        commodityActionPlanModel.equals(null);

        actions.toString();
        actions.hashCode();
        actionsModel.toString();
        actionsModel.hashCode();
        actions.equals(actions2);
        actions.equals(null);
        actionsModel.equals(actionsModel2);
        actionsModel.equals(null);

        commodityStatus.toString();
        commodityStatus.hashCode();
        commodityStatus.equals(commodityStatus2);
        commodityStatus.equals(null);

        projectMileStone.toString();
        projectMileStone.hashCode();
        projectMileStoneModel.toString();
        projectMileStoneModel.hashCode();
        projectMileStone.equals(projectMileStone1);
        projectMileStone.equals(null);
        projectMileStoneModel.equals(projectMileStone1Model);
        projectMileStoneModel.equals(null);

        projectMarket.toString();
        projectMarket.hashCode();
        projectMarketModel.toString();
        projectMarketModel.hashCode();
        projectMarket.equals(projectMarket2);
        projectMarket.equals(null);
        projectMarketModel.equals(projectMarketModel2);
        projectMarketModel.equals(null);

        projectSetUp.toString();
        projectSetUp.hashCode();
        projectSetUpModel.toString();
        projectSetUpModel.hashCode();
        projectSetUp.equals(projectSetUp2);
        projectSetUp.equals(null);
        projectSetUpModel.equals(projectSetUpModel2);
        projectSetUpModel.equals(null);

        projectSetUpAttachment.toString();
        projectSetUpAttachment.hashCode();
        projectSetUpAttachmentModel.toString();
        projectSetUpAttachmentModel.hashCode();
        projectSetUpAttachment.equals(projectSetUpAttachment2);
        projectSetUpAttachment.equals(null);
        projectSetUpAttachmentModel.equals(projectSetUpAttachmentModel2);
        projectSetUpAttachmentModel.equals(null);

        qlikCommodityActionPlanModel.toString();
        qlikCommodityActionPlanModel.hashCode();
        qlikCommodityActionPlanModel.equals(qlikCommodityActionPlanModel2);
        qlikCommodityActionPlanModel.equals(null);

        qlikCommodityStatusModel.toString();
        qlikCommodityStatusModel.hashCode();
        qlikCommodityStatusModel.equals(qlikCommodityStatusModel2);
        qlikCommodityStatusModel.equals(null);

        qlikCommodityContractModel.toString();
        qlikCommodityContractModel.hashCode();
        qlikCommodityContractModel.equals(qlikCommodityContractModel2);
        qlikCommodityContractModel.equals(null);

        contractStatusGraphModel.toString();
        contractStatusGraphModel.hashCode();
        contractStatusGraphModel.equals(contractStatusGraphModel2);
        contractStatusGraphModel.equals(null);

        dfqMileStoneGraphModel.toString();
        dfqMileStoneGraphModel.hashCode();
        dfqMileStoneGraphModel.equals(dfqMileStoneGraphModel2);
        dfqMileStoneGraphModel.equals(null);

        dfqEventModel.toString();
        dfqEventModel.hashCode();
        dfqEventModel.equals(dfqEventModel);
        dfqEventModel.equals(null);

        dfqDeliveryGraphModel.toString();
        dfqDeliveryGraphModel.hashCode();
        dfqDeliveryGraphModel.equals(dfqDeliveryGraphModel2);
        dfqDeliveryGraphModel.equals(null);

        assertThat(true);
    }

}
