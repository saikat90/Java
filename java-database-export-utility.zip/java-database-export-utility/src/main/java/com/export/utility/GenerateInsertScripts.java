package com.export.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.jdbc.Blob;

public class GenerateInsertScripts {
	private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";

	private static Connection conn = null;
	private static String jdbcURL;
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

	public static void main(String[] args) throws Exception {
		if (args.length < 1) {
			error();
			System.exit(1);
		}

		File tablefile = new File("C:\\mysql\\tables.txt");
		File logs = new File("C:\\mysql\\logs.txt");
		logs.createNewFile();
		FileWriter writeToFile = new FileWriter(logs);
		List<String> tableList = new ArrayList<String>();
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(tablefile));
			String line = reader.readLine();
			while (line != null) {
				tableList.add(line);
				// read next line
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println(tableList.toString());

		jdbcURL = args[0];
		jdbcURL = jdbcURL + "?useSSL=false&useUnicode=yes&characterEncoding=UTF-8";
		String jdbc_user = args[1];
		String jdbc_password = args[2];

		Class.forName(JDBC_DRIVER);

		// Calling procedure to export dwi users - Start
		Connection conn_for_export_user = null;
		try {

			conn_for_export_user = DriverManager.getConnection(jdbcURL, jdbc_user, jdbc_password);

			CallableStatement statement = conn_for_export_user.prepareCall("{call dwi_user_migration()}");
			statement.execute();
			statement.close();
			System.out.println("Stored procedure called successfully!");
			writeToFile.write("Stored procedure called successfully! \n");

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (conn_for_export_user != null)
				try {
					conn_for_export_user.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		// Calling procedure to export dwi users - Start
		try {
			writeToFile.write("EXPORTS OF INSERT SCRIPTS - SARTS - " + new Date() + "\n");
			tableList.stream().forEach(tableName -> {
				if (tableName.length() > 1) {
					try {
						conn = DriverManager.getConnection(jdbcURL, jdbc_user, jdbc_password);
						writeToFile.write("Generating Insert statements for: " + tableName + "\n");
						generateInsertStatements(conn, tableName.trim());
						System.out.println(tableName.toLowerCase() + " -----> Insert Script Generated Successfully");
						// writeToFile.write("***********************************************" +
						// tableName.toLowerCase()
						// + " -----> Insert Script Generated Successfully \n");
						writeToFile.write(
								"***********************************************Insert Script Generated Successfully \n");
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						if (conn != null)
							try {
								conn.close();
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					}
				}
			});
			writeToFile.write("EXPORTS OF INSERT SCRIPTS - ENDS - " + new Date() + "\n");
			writeToFile.close();
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	private static void generateInsertStatements(Connection conn, String tableName) throws Exception {
		log("Generating Insert statements for: " + tableName);
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM " + tableName);
		ResultSetMetaData rsmd = rs.getMetaData();
		int numColumns = rsmd.getColumnCount();
		int[] columnTypes = new int[numColumns];
		String columnNames = "";
		for (int i = 0; i < numColumns; i++) {
			columnTypes[i] = rsmd.getColumnType(i + 1);
			if (i != 0) {
				columnNames += ",";
			}
			columnNames += rsmd.getColumnName(i + 1);
		}

		java.util.Date d = null;
		// PrintWriter p = new PrintWriter(new FileWriter(tableName + "_insert.sql"));
		PrintWriter printWriter = new PrintWriter(new FileWriter("C:\\mysql\\" + tableName + "_insert.sql"));
		// p.println("set sqlt off");
		// p.println("set sqlblanklines on");
		// p.println("set define off");
		while (rs.next()) {
			String columnValues = "";
			for (int i = 0; i < numColumns; i++) {
				if (i != 0) {
					columnValues += ",";
				}

				switch (columnTypes[i]) {
				case Types.BIGINT:
				case Types.BIT:
				case Types.BOOLEAN:
				case Types.DECIMAL:
				case Types.DOUBLE:
				case Types.FLOAT:
				case Types.INTEGER:
				case Types.SMALLINT:
				case Types.TINYINT:
					String v = rs.getString(i + 1);
					columnValues += v;
					break;
				case Types.LONGVARBINARY:
					Blob blob = (Blob) rs.getBlob(i + 1);
					if (blob != null) {
						int content_length = (int) blob.length();
						byte[] bArray = blob.getBytes(1, content_length);
						StringBuffer sb = new StringBuffer();
						for (byte b : bArray) {
							sb.append(String.format("%02X", b));
						}
						columnValues += "decode('" + sb.toString() + "','hex')";
					} else {
						columnValues += "null";
					}

					break;
				case Types.DATE:
					d = rs.getDate(i + 1);
				case Types.TIME:
					if (d == null)
						d = rs.getTime(i + 1);
				case Types.TIMESTAMP:
					if (d == null)
						d = rs.getTimestamp(i + 1);

					if (d == null) {
						columnValues += "null";
					} else {
						columnValues += "TO_DATE('" + dateFormat.format(d) + "', 'YYYY/MM/DD HH24:MI:SS')";
					}
					break;

				default:
					v = rs.getString(i + 1);
					if (v != null) {
						columnValues += "'" + v.replaceAll("'", "''") + "'";
					} else {
						columnValues += "null";
					}
					break;
				}
			}
			printWriter.println(String.format("insert into %s (%s) values (%s);\n", tableName.toLowerCase(),
					columnNames.toLowerCase(), columnValues));
		}
		printWriter.close();
	}

	private static void log(String s) {
		System.out.println(s);
	}

	private static void error() {
		System.out.println("PROVIDE DATABASE DETAILS TO PROCEED FURTHER");
	}
}
