package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;

public interface FleetService {

    /**
     * @param fleet
     * @return FleetModel.
     */
    FleetModel updateFleet(FleetModel fleet);

    /**
     * @param requestModel
     * @return FleetModel.
     */
    Object searchFleet(RequestModel requestModel);

    /**
     * @param fleetId
     * @return FleetModel.
     */
    FleetModel viewFleet(UUID fleetId);

    /**
     * @param id
     */
    void deleteFleet(UUID id);

    /**
     * @param fleetModel
     * @return FleetModel.
     */
    FleetModel saveFleet(FleetModel fleetModel);

}
