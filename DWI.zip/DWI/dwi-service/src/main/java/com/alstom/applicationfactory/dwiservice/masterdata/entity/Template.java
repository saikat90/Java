package com.alstom.applicationfactory.dwiservice.masterdata.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dwitemplates")
public class Template {

    /**
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     */
    @Column(nullable = false, name = "title")
    private String title;

    /**
     */
    @Column(nullable = false, length = 1, name = "active")
    private boolean active;

    /**
     */
    @Column(nullable = true, name = "dwi_templatedescription")
    @Type(type = "text")
    private String dwiTemplateDescription;

    /**
     */
    @Column(name = "content")
    @Type(type = "text")
    private String content;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_project_id")
    private Project project;
}
