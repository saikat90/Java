package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionAttachment;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionAttachmentRepository;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionAttachmentService;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service(value = "instructionAttachment")
@Transactional
@Slf4j
@RefreshScope
public class InstructionAttachmentServiceImpl implements InstructionAttachmentService {

    /**
     * InstructionAttachmentRepository.
     */
    @Autowired
    private InstructionAttachmentRepository instructionAttachmentRepository;
    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;
    /**
     * base path for storing attachments.
     */
    @Value("${dwi.attachment.upload.path}")
    private String basePath;

    /**
     * @param instructionAttachmentModel
     * @return InstructionAttachmentModel.
     */
    @Override
    public InstructionAttachmentModel createDwiAttachment(
            final InstructionAttachmentModel instructionAttachmentModel) {
        log.debug("Entry:InstructionAttachmentServiceImpl:createInstructionAttachment.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        InstructionAttachmentModel instructionAttachmentCreatedBean = new InstructionAttachmentModel();
        InstructionAttachment instructionAttachment = mapper.map(instructionAttachmentModel,
                InstructionAttachment.class);

        try {
            instructionAttachment = instructionAttachmentRepository.save(instructionAttachment);
            instructionAttachmentCreatedBean = mapper.map(instructionAttachment,
                    InstructionAttachmentModel.class);
        } catch (Exception e) {
            log.error("Error while creating record for InstructionAttachment.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACHMENT,
                    Constants.INSTRUCTION_ATTACHMENT_CREATE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:InstructionAttachmentServiceImpl:createInstructionAttachment.");
        return instructionAttachmentCreatedBean;
    }

    /**
     * @param instructionAttachmentId
     */
    @Override
    public void deleteInstructionAttachmentById(final UUID instructionAttachmentId) {
        log.debug("Entry:InstructionAttachmentServiceImpl:DeleteInstructionAttachment.");
        try {
            instructionAttachmentRepository.deleteById(instructionAttachmentId);
            log.debug("Leave:InstructionAttachmentServiceImpl:DeleteInstructionAttachment.");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL,
                    Constants.INSTRUCTION_ATTACHMENT_DELETE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param instructionAttachmentId
     * @return file of the uploaded attachment.
     */
    @Override
    public File downloadDwiAttachment(final UUID instructionAttachmentId) {
        InstructionAttachmentModel insAttachmentModel = viewInstructionAttachment(
                instructionAttachmentId);
        File file;
        if (null != insAttachmentModel) {
            String uuidPath = getFilePath(insAttachmentModel.getId().toString());
            Path downloadPath = Paths
                    .get(basePath + uuidPath + insAttachmentModel.getAttachedFileName());
            file = new File(downloadPath.toUri());
        } else {
            log.error("Error occurred while fetching attachment.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACHMENT,
                    Constants.INSTRUCTION_ATTACHMENT_VIEW_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        return file;
    }

    /**
     * @param file
     * @param userEmail
     * @return InstructionAttachmentModel.
     */
    @Override
    public InstructionAttachmentModel uploadAttachment(final MultipartFile file,
            final String userEmail) {

        if (file.isEmpty()) {
            log.error("Attached file is empty");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACHMENT,
                    Constants.INSTRUCTION_ATTACHMENT_EMPTY));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        try {
            String attachedFileName = file.getOriginalFilename();

            // Perform an insert into dwiattachments_documents tables first

            InstructionAttachmentModel insAttachmentModel = new InstructionAttachmentModel();

            InstructionAttachmentModel insAttachmentCreatedBean = new InstructionAttachmentModel();

            User userEntity = null;

            insAttachmentModel.setAttachedFileName(attachedFileName);
            try {
                userEntity = userRepository.findByEmail(userEmail).get(0);
            } catch (NullPointerException ex) {
                log.debug("User not present in the system for the email: " + userEmail);
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.APPROVER,
                        Constants.USER_NOT_PRESENT_FOR_MAIL + userEmail));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            if (null != userEntity) {
                insAttachmentModel.setCreatedBy(userEntity.getEmployeeId());
            }
            insAttachmentModel.setCreatedDate(new Timestamp(new Date().getTime()));
            insAttachmentModel.setVersion(0);
            insAttachmentModel.setUploadSuccesfull(true);

            insAttachmentCreatedBean = createDwiAttachment(insAttachmentModel);

            if (null != insAttachmentCreatedBean) {

                String uuidString = insAttachmentCreatedBean.getId().toString();

                // Get file path from column UUID table & dwiattachments_documents

                String uuidPath = getFilePath(uuidString);

                byte[] bytes = file.getBytes();

                // path to create directories based on UUID
                Path directoryPath = Paths.get(basePath + uuidPath);
                // Getting absolute path for storing images
                Path uploadPath = Paths.get(basePath + uuidPath + file.getOriginalFilename());
                // Creating directories from above path (directoryPath)
                Files.createDirectories(directoryPath);
                // Writing content
                Files.write(uploadPath, bytes);
            }
            return insAttachmentCreatedBean;
        } catch (IOException e) {
            log.error("Error while performing upload");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACHMENT, Constants.UPLOAD_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
    }

    /**
     * @param uuidString
     * @return path of the stored attachments.
     */
    protected String getFilePath(final String uuidString) {
        String uuidPath = "/";
        Pattern pattern = Pattern.compile(Constants.UUID_PATTERN);
        Matcher matcher = pattern.matcher(uuidString);

        if (matcher.find()) {
            for (int i = 1; i <= matcher.groupCount(); i++) {
                uuidPath = uuidPath + matcher.group(i) + "/";
            }
        }
        return uuidPath;
    }

    /**
     * @param instructionAttachmentId
     * @return InstructionAttachmentModel.
     */
    @Override
    public InstructionAttachmentModel viewInstructionAttachment(
            final UUID instructionAttachmentId) {
        log.debug("Entry:InstructionAttachmentServiceImpl:ViewInstructionAttachment.");
        InstructionAttachment instructionAttachment;
        InstructionAttachmentModel instructionAttachmentBean = new InstructionAttachmentModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            instructionAttachment = instructionAttachmentRepository
                    .findById(instructionAttachmentId).orElse(null);
            if (null != instructionAttachment) {
                instructionAttachmentBean = mapper.map(instructionAttachment,
                        InstructionAttachmentModel.class);
                log.debug("Leave:InstructionAttachmentServiceImpl:ViewInstructionAttachment.");
            }
            return instructionAttachmentBean;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.INSTRUCTION_ATTACHMENT,
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param oldId
     * @param newId
     */
    @Override
    public void copyInstructionAttachmentById(final UUID oldId, final UUID newId) {

        List<InstructionAttachment> oldAttachmentList = instructionAttachmentRepository
                .findByDWIInstructionsId(oldId);

        List<InstructionAttachment> newAttachmentList = instructionAttachmentRepository
                .findByDWIInstructionsId(newId);

        oldAttachmentList.stream().forEach(oldAttachment -> {
            newAttachmentList.stream().forEach(newAttachment -> {
                if (oldAttachment.getAttachedFileName()
                        .equals(newAttachment.getAttachedFileName())) {
                    String newUuid = newAttachment.getId().toString();

                    File file = downloadDwiAttachment(oldAttachment.getId());
                    BufferedInputStream bf = null;
                    try {
                        bf = new BufferedInputStream(new FileInputStream(file));
                        if (null != bf) {
                            String uuidPath = getFilePath(newUuid);
                            byte[] bytes = bf.readAllBytes();
                            // path to create directories based on UUID
                            Path directoryPath = Paths.get(basePath + uuidPath);
                            // Getting absolute path for storing images
                            Path uploadPath = Paths.get(basePath + uuidPath + file.getName());
                            // Creating directories from above path (directoryPath)
                            Files.createDirectories(directoryPath);
                            // Writing content
                            Files.write(uploadPath, bytes);
                        }
                    } catch (IOException e) {
                        List<ErrorModel> errors = new ArrayList<>();
                        errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACHMENT,
                                Constants.ATTACHMENT_COPY_ERROR));
                        throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errors);
                    } finally {
                        try {
                            bf.close();
                        } catch (IOException e) {
                            log.error("Error while copying file.");
                        }
                    }
                }
            });
        });
    }

    /**
     * @param file
     * @return
     */
    @Override
    public byte[] readFileToByteArray(final File file) {
        FileInputStream fis = null;
        // Creating a byte array using the length of the file
        // file.length returns long which is cast to int
        byte[] bArray = new byte[(int) file.length()];
        try {
            fis = new FileInputStream(file);
            int count = fis.read(bArray);
        } catch (IOException e) {
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACHMENT,
                    Constants.INSTRUCTION_ATTACHMENT_READ_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errors);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    log.error("Error while reading file.");
                }
            }
        }
        return bArray;
    }

}
