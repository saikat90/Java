package com.alstom.applicationfactory.dwiservice.masterdata.entity;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dwiwork_flow_template")
public class WorkFlowTemplate {

    /**
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     */
    @Column(nullable = false, length = Constants.HUNDRED, name = "dwi_work_flow_template_name", unique = true)
    private String workFlowTemplateName;

    /**
     */
    @Column(nullable = false, length = 1, name = "active")
    private boolean active;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "project_id")
    private Project project;

    /**
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     */
    @Column(name = "updated_by")
    private String modifiedBy;

    /**
     */
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "workFlowTemplate", cascade = CascadeType.ALL)
    private List<WorkFlowTemplateDesc> actions;

}
