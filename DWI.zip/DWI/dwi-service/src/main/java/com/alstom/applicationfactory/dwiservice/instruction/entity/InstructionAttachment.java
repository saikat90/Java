package com.alstom.applicationfactory.dwiservice.instruction.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "dwiattachments_documents")
public class InstructionAttachment {

    /**
     * primary key of InstructionAttachment.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * stores the version of InstructionAttachment.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * form id.
     */
    @Column(name = "dwi_form_id")
    private String dwiFormId;

    /**
     * attachmentText.
     */
    @Column(length = Constants.FIVE_HUNDERD, name = "attachment_text")
    private String attachmentText;

    /**
     */
    @Column(name = "attached_file_name")
    private String attachedFileName;

    /**
     */
    @Column(name = "upload_successfull", nullable = false)
    private Boolean uploadSuccesfull;

    /**
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     */
    @Column(name = "updated_by")
    private String modifiedBy;

    /**
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "set_of_dwiattachments_dwinstructions_id")
    private Instructions instructions;
}
