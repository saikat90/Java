package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.logging.log4j.util.Strings;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.dwiservice.instruction.entity.EditionControlComments;
import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionAttachment;
import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionWorkFlowDetails;
import com.alstom.applicationfactory.dwiservice.instruction.entity.Instructions;
import com.alstom.applicationfactory.dwiservice.instruction.entity.WINumberPerProject;
import com.alstom.applicationfactory.dwiservice.instruction.entity.WorkFlowActionHistory;
import com.alstom.applicationfactory.dwiservice.instruction.enums.Actions;
import com.alstom.applicationfactory.dwiservice.instruction.enums.Status;
import com.alstom.applicationfactory.dwiservice.instruction.enums.SubStatus;
import com.alstom.applicationfactory.dwiservice.instruction.model.EditionControlCommentsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionWorkFlowDetailsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsListModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.WorkFlowActionHistoryModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.EditionControlCommentsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionAttachmentRepository;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionWorkFlowDetailsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.repository.WINumberPerProjectRepository;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionAttachmentService;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionsService;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.DwiHeader;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Tag;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.EmailModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.NotificationSettingsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.DwiHeaderRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.NotificationSettingsService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "instructionsService")
@Transactional
@Slf4j
@RefreshScope
public class InstructionsServiceImpl implements InstructionsService {

    /**
     * InstructionsRepository.
     */
    @Autowired
    private InstructionsRepository instructionsRepository;
    /**
     * NotificationSettingsService.
     */
    @Autowired
    private NotificationSettingsService settingsService;
    /**
     * EmailServiceClient.
     */
    @Autowired
    private EmailServiceClient emailServiceClient;
    /**
     * AdminServiceClient.
     */
    @Autowired
    private AdminServiceClient adminServiceClient;
    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;
    /**
     * EditionControlCommentsRepository.
     */
    @Autowired
    private EditionControlCommentsRepository editionCCRepository;
    /**
     * WINumberPerProjectRepository.
     */
    @Autowired
    private WINumberPerProjectRepository wiNumberPerProjectRepository;
    /**
     * InstructionAttachmentRepository.
     */
    @Autowired
    private InstructionAttachmentRepository instructionAttachmentRepository;
    /**
     * InstructionWorkFlowDetailsRepository.
     */
    @Autowired
    private InstructionWorkFlowDetailsRepository instructionWFDetailsRepository;
    /**
     * DwiHeaderRepository.
     */
    @Autowired
    private DwiHeaderRepository dwiHeaderRepository;
    /**
     * InstructionAttachmentService.
     */
    @Autowired
    private InstructionAttachmentService instructionAttachmentService;

    /**
     * date format
     */
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * work instructions submitted.
     */
    @Value("${dwi.events.instruction.submitted}")
    private String wiSubmitted;
    /**
     * work instructions validated.
     */
    @Value("${dwi.events.instruction.validated}")
    private String wiValidated;
    /**
     * work instructions approved.
     */
    @Value("${dwi.events.instruction.approved}")
    private String wiApproved;
    /**
     * work instructions rejected.
     */
    @Value("${dwi.events.instruction.rejected}")
    private String wiRejected;
    /**
     * work instructions comments.
     */
    @Value("${dwi.events.instruction.addComments}")
    private String wiAddComments;
    /**
     * work instructions auto reminder for validation.
     */
    @Value("${dwi.events.instruction.autoreminder.validation}")
    private String wiAutoreminderValidation;
    /**
     * work instructions auto reminder for approval.
     */
    @Value("${dwi.events.instruction.autoreminder.approval}")
    private String wiAutoreminderApproval;

    /**
     * @param request
     * @return
     */
    @Override
    public Object searchInstructions(final RequestModel request) {

        log.debug("Entry:DwiInstructionsServiceImpl:searchInstructions.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.instructionsRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(instructions -> mapper.map(instructions, InstructionsListModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.instructionsRepository.findAll(request.getFilterSpecification()).stream()
                    .map(instructions -> mapper.map(instructions, InstructionsListModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:DwiInstructionsServiceImpl:searchInstructions.");
        return result;
    }

    /**
     * @param instructionModel
     * @param editionControlComment
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel saveasDraftInstruction(final InstructionsModel instructionModel,
            final String editionControlComment, final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:saveasDraftInstruction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        User creator = null;
        UserModel creatorModel = null;
        String creatorUserName = null;
        Instructions oldInstruction = null;
        try {
            creator = userRepository.findByEmail(email).get(0);
            creatorUserName = creator.getFirstName().concat(" ").concat(creator.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(
                    new ErrorModel(Constants.AUTHOR, Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        List<InstructionWorkFlowDetailsModel> workFlowDetailsModelsList = new ArrayList<>();
        List<InstructionWorkFlowDetails> oldWfDetails = new ArrayList<>();
        List<WorkFlowActionHistoryModel> wfHistoryModelList = new ArrayList<>();
        EditionControlCommentsModel editionCCModel = new EditionControlCommentsModel();
        byte[] history = new byte[Constants.INST_BYTE_LENGTH];
        List<InstructionAttachment> insAttachList = new ArrayList<>();
        creatorModel = mapper.map(creator, UserModel.class);
        WorkFlowActionHistoryModel wfHistoryModel = new WorkFlowActionHistoryModel();
        wfHistoryModel.setVersion(0);
        wfHistoryModel.setWfhActionDate(new Date());
        wfHistoryModel.setWfhUser(creatorModel);
        wfHistoryModel.setWfhUserName(creatorUserName);
        wfHistoryModel.setWfhUserComments(instructionModel.getApproverValidatorComments());
        wfHistoryModel.setWfhdepartment(creatorModel.getDepartment());
        if (Objects.isNull(instructionModel.getId())) {
            wfHistoryModel.setWfhOperation(Constants.CREATED);
            instructionModel.setCreatedDate(new Date());
            instructionModel.setCreatedBy(creatorModel.getEmployeeId());
            String dwiNumber = generateWorkInstructionNumber(instructionModel.getProject());
            instructionModel.setDwiNumber(dwiNumber);
            editionCCModel = new EditionControlCommentsModel();
            editionCCModel.setComments(editionControlComment);
            editionCCModel.setDwiEdition(instructionModel.getDwiEdition());
            editionCCModel.setDwiNumber(instructionModel.getDwiNumber());
            editionCCModel.setSubmittedDate(new Date());
            editionCCModel.setUser(creatorModel);
            editionCCModel.setVersion(0);

            List<WorkFlowTemplateDescModel> workFlowTempDescList = instructionModel
                    .getWorkFlowTemplate().getActions();
            workFlowTempDescList.forEach(item -> {
                InstructionWorkFlowDetailsModel wfDetailModel = new InstructionWorkFlowDetailsModel();
                wfDetailModel.setVersion(0);
                wfDetailModel.setDwiActions(item.getDwiActions());
                wfDetailModel.setFunction(item.getFunction());
                wfDetailModel.setName(item.getName());
                wfDetailModel.setApproverOrValidatorUser(item.getValidateApproveUser());
                wfDetailModel.setApprovedRejectDate(null);
                wfDetailModel.setApproverAction(null);
                wfDetailModel.setWfTemplateDescSeq(item.getWfTemplateDescSeq());
                workFlowDetailsModelsList.add(wfDetailModel);
            });
            String his = dateFormat.format(new Date()).concat(Constants.INFO_DELIMITER)
                    .concat(creatorUserName).concat(Constants.INFO_DELIMITER)
                    .concat(Constants.OBJ_CREATED);
            history = his.getBytes();
            instructionModel.setHistory(history);

        } else {
            wfHistoryModel.setWfhOperation(Constants.MODIFIED);
            instructionModel.setModifiedDate(new Date());
            instructionModel.setModifiedBy(creatorModel.getEmployeeId());
            EditionControlComments editionCC = this.editionCCRepository
                    .findByInstructionsId(instructionModel.getId()).get(0);
            if (Objects.nonNull(editionCC)) {
                editionCC.setComments(editionControlComment);
                editionCC.setSubmittedDate(new Date());
                editionCC.setVersion(editionCC.getVersion() + 1);
                editionCCModel = mapper.map(editionCC, EditionControlCommentsModel.class);

            } else {
                editionCCModel = new EditionControlCommentsModel();
                editionCCModel.setComments(editionControlComment);
                editionCCModel.setDwiEdition(instructionModel.getDwiEdition());
                editionCCModel.setDwiNumber(instructionModel.getDwiNumber());
                editionCCModel.setSubmittedDate(new Date());
                editionCCModel.setUser(creatorModel);
                editionCCModel.setVersion(0);
            }

            oldInstruction = this.instructionsRepository.findById(instructionModel.getId())
                    .orElse(null);

            if (Objects.nonNull(oldInstruction)) {
                Project newProject = mapper.map(instructionModel.getProject(), Project.class);
                if (!(oldInstruction.getProject().equals(newProject))) {
                    instructionModel.setWorkFlowDetailsList(null);
                    oldWfDetails = instructionWFDetailsRepository
                            .findByInstructionsId(instructionModel.getId());
                    oldWfDetails.forEach(item -> {
                        item.setInstructions(null);
                    });

                    List<WorkFlowTemplateDescModel> workFlowTempDescList = instructionModel
                            .getWorkFlowTemplate().getActions();
                    workFlowTempDescList.forEach(item -> {
                        InstructionWorkFlowDetailsModel wfDetailModel = new InstructionWorkFlowDetailsModel();
                        wfDetailModel.setVersion(0);
                        wfDetailModel.setDwiActions(item.getDwiActions());
                        wfDetailModel.setFunction(item.getFunction());
                        wfDetailModel.setName(item.getName());
                        wfDetailModel.setApproverOrValidatorUser(item.getValidateApproveUser());
                        wfDetailModel.setApprovedRejectDate(null);
                        wfDetailModel.setApproverAction(null);
                        wfDetailModel.setWfTemplateDescSeq(item.getWfTemplateDescSeq());
                        workFlowDetailsModelsList.add(wfDetailModel);
                    });
                }
            }

        }
        instructionModel.setEditionControlComments(editionCCModel);
        wfHistoryModelList.add(wfHistoryModel);

        instructionModel.setWorkFlowActionHistoryList(wfHistoryModelList);
        instructionModel.setFirstValidator(null);
        instructionModel.setApprover(null);
        instructionModel.setAuthor(creatorModel);
        instructionModel.setDwiSubStatus(SubStatus.NEW.toString());
        instructionModel.setApproverValidatorComments(null);
        instructionModel.setWorkFlowDetailsList(workFlowDetailsModelsList);
        Instructions instruction = mapper.map(instructionModel, Instructions.class);

        if (!Objects.isNull(instructionModel.getId())) {
            String hisValue = Constants.INFO_NEWLINE.concat(dateFormat.format(new Date()))
                    .concat(Constants.INFO_DELIMITER).concat(creatorUserName)
                    .concat(Constants.INFO_DELIMITER).concat(Constants.OBJ_MODIFIED);
            appendhistory(instruction, hisValue);
        }

        if (Objects.nonNull(instruction.getWorkFlowActionHistoryList())
                && !instruction.getWorkFlowActionHistoryList().isEmpty()) {
            Instructions finalInstruction = instruction;
            instruction.getWorkFlowActionHistoryList()
                    .forEach(item -> item.setWfhInstructions(finalInstruction));
        }

        if (Objects.nonNull(instruction.getEditionControlComments())) {
            Instructions finalInstruction = instruction;
            instruction.getEditionControlComments().setInstructions(finalInstruction);
        }

        if (instruction.getInstructiontagsList().isEmpty()) {
            instruction.setInstructiontagsList(null);
        }

        if (Objects.nonNull(instruction.getWorkFlowDetailsList())
                && !instruction.getWorkFlowDetailsList().isEmpty()) {
            Instructions finalInstruction = instruction;
            instruction.getWorkFlowDetailsList()
                    .forEach(item -> item.setInstructions(finalInstruction));
        }

        if (!oldWfDetails.isEmpty() && Objects.nonNull(oldWfDetails)) {
            instruction.getWorkFlowDetailsList().addAll(oldWfDetails);
        }

        if (instruction.getInstructionApproversList().isEmpty()) {
            instruction.setInstructionApproversList(null);
        }
        if (instruction.getInstructionValidatorsList().isEmpty()) {
            instruction.setInstructionValidatorsList(null);
        }

        insAttachList = instruction.getInstructionAttachmentList();
        if (Objects.isNull(instruction.getId()) && Objects.nonNull(insAttachList)
                && !insAttachList.isEmpty()) {
            instruction.setInstructionAttachmentList(null);
            instruction = this.instructionsRepository.save(instruction);

            Instructions finalInstruction = instruction;
            insAttachList.forEach(item -> item.setInstructions(finalInstruction));
            List<InstructionAttachment> newInsAttachList = instructionAttachmentRepository
                    .saveAll(insAttachList);
            instruction.setInstructionAttachmentList(newInsAttachList);
        } else {

            if (Objects.nonNull(insAttachList) && !insAttachList.isEmpty()) {
                Instructions finalInstruction = instruction;
                insAttachList.forEach(item -> item.setInstructions(finalInstruction));
            }
            instruction = this.instructionsRepository.save(instruction);
        }
        InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
        log.debug("Leave:DwiInstructionsServiceImpl:saveasDraftInstruction.");
        return savedInstructionModel;
    }

    /**
     * @param instructionModel
     * @param editionControlComment
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel submitInstruction(final InstructionsModel instructionModel,
            final String editionControlComment, final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:submitInstruction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        User creator = null;
        UserModel creatorModel = null;
        String creatorUserName = null;
        Instructions oldInstruction = null;
        try {
            creator = userRepository.findByEmail(email).get(0);
            creatorUserName = creator.getFirstName().concat(" ").concat(creator.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(
                    new ErrorModel(Constants.AUTHOR, Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        creatorModel = mapper.map(creator, UserModel.class);
        List<InstructionWorkFlowDetailsModel> workFlowDetailsModelsList = new ArrayList<>();
        List<WorkFlowActionHistoryModel> wfHistoryModelList = new ArrayList<>();
        List<InstructionWorkFlowDetails> oldWfDetails = new ArrayList<>();
        EditionControlCommentsModel editionCCModel = new EditionControlCommentsModel();
        WorkFlowActionHistoryModel wfHistoryModel = new WorkFlowActionHistoryModel();
        wfHistoryModel.setVersion(0);
        wfHistoryModel.setWfhActionDate(new Date());
        wfHistoryModel.setWfhUser(creatorModel);
        wfHistoryModel.setWfhUserName(creatorUserName);
        wfHistoryModel.setWfhUserComments(instructionModel.getApproverValidatorComments());
        wfHistoryModel.setWfhOperation(Status.SUBMITTED.toString());
        wfHistoryModel.setWfhdepartment(creatorModel.getDepartment());
        wfHistoryModelList.add(wfHistoryModel);
        instructionModel.setDwiSubmittedDate(new Date());
        instructionModel.setAuthor(creatorModel);
        instructionModel.setModifiedDate(new Date());
        instructionModel.setModifiedBy(creatorModel.getEmployeeId());
        EditionControlComments editionCC = this.editionCCRepository
                .findByInstructionsId(instructionModel.getId()).get(0);
        if (Objects.nonNull(editionCC)) {
            editionCC.setComments(editionControlComment);
            editionCC.setSubmittedDate(new Date());
            editionCC.setVersion(editionCC.getVersion() + 1);
            editionCCModel = mapper.map(editionCC, EditionControlCommentsModel.class);
        } else {
            editionCCModel = new EditionControlCommentsModel();
            editionCCModel.setComments(editionControlComment);
            editionCCModel.setDwiEdition(instructionModel.getDwiEdition());
            editionCCModel.setDwiNumber(instructionModel.getDwiNumber());
            editionCCModel.setSubmittedDate(new Date());
            editionCCModel.setUser(creatorModel);
            editionCCModel.setVersion(0);
        }
        oldInstruction = this.instructionsRepository.findById(instructionModel.getId())
                .orElse(null);

        if (Objects.nonNull(oldInstruction)) {
            Project newProject = mapper.map(instructionModel.getProject(), Project.class);
            if (!(oldInstruction.getProject().equals(newProject))) {
                instructionModel.setWorkFlowDetailsList(null);
                oldWfDetails = instructionWFDetailsRepository
                        .findByInstructionsId(instructionModel.getId());
                oldWfDetails.forEach(item -> {
                    item.setInstructions(null);
                });

                List<WorkFlowTemplateDescModel> workFlowTempDescList = instructionModel
                        .getWorkFlowTemplate().getActions();
                workFlowTempDescList.forEach(item -> {
                    InstructionWorkFlowDetailsModel wfDetailModel = new InstructionWorkFlowDetailsModel();
                    wfDetailModel.setVersion(0);
                    wfDetailModel.setDwiActions(item.getDwiActions());
                    wfDetailModel.setFunction(item.getFunction());
                    wfDetailModel.setName(item.getName());
                    wfDetailModel.setApproverOrValidatorUser(item.getValidateApproveUser());
                    wfDetailModel.setApprovedRejectDate(null);
                    wfDetailModel.setApproverAction(null);
                    wfDetailModel.setWfTemplateDescSeq(item.getWfTemplateDescSeq());
                    workFlowDetailsModelsList.add(wfDetailModel);
                });
                instructionModel.setWorkFlowDetailsList(workFlowDetailsModelsList);
            }
        }

        instructionModel.setEditionControlComments(editionCCModel);
        instructionModel.setWorkFlowActionHistoryList(wfHistoryModelList);
        instructionModel.setApproverValidatorComments(null);
        String hisValue = Constants.INFO_NEWLINE.concat(dateFormat.format(new Date()))
                .concat(Constants.INFO_DELIMITER).concat(creatorUserName)
                .concat(Constants.INFO_DELIMITER);
        if (instructionModel.getDwiStatus().equals(Status.DRAFT.toString())
                || instructionModel.getDwiStatus().equals(Status.REJECTED.toString())) {
            instructionModel.setDwiStatus(Status.SUBMITTED.toString());
            hisValue = hisValue.concat(Constants.INFO_SUBMIT);
        }
        if (instructionModel.getDwiStatus().equals(Status.IMPORTED.toString())) {
            instructionModel.setDwiStatus(Status.IMPORT_SUBMITTED.toString());
            hisValue = hisValue.concat(Constants.INFO_IMPORT);
        }
        Instructions instruction = mapper.map(instructionModel, Instructions.class);
        appendhistory(instruction, hisValue);

        if (Objects.nonNull(instruction.getWorkFlowActionHistoryList())
                && !instruction.getWorkFlowActionHistoryList().isEmpty()) {
            Instructions finalInstruction = instruction;
            instruction.getWorkFlowActionHistoryList()
                    .forEach(item -> item.setWfhInstructions(finalInstruction));
        }

        if (Objects.nonNull(instruction.getEditionControlComments())) {
            Instructions finalInstruction = instruction;
            instruction.getEditionControlComments().setInstructions(finalInstruction);
        }

        if (Objects.nonNull(instruction.getWorkFlowDetailsList())
                && !instruction.getWorkFlowDetailsList().isEmpty()) {
            Instructions finalInstruction = instruction;
            instruction.getWorkFlowDetailsList()
                    .forEach(item -> item.setInstructions(finalInstruction));
        }

        if (!oldWfDetails.isEmpty() && Objects.nonNull(oldWfDetails)) {
            instruction.getWorkFlowDetailsList().addAll(oldWfDetails);
        }

        if (Objects.nonNull(instruction.getInstructionAttachmentList())
                && !instruction.getInstructionAttachmentList().isEmpty()) {
            Instructions finalInstruction = instruction;
            instruction.getInstructionAttachmentList()
                    .forEach(item -> item.setInstructions(finalInstruction));
        }

        if (instruction.getInstructiontagsList().isEmpty()) {
            instruction.setInstructiontagsList(null);
        }

        if (instruction.getInstructionApproversList().isEmpty()) {
            instruction.setInstructionApproversList(null);
        }

        if (instruction.getInstructionValidatorsList().isEmpty()) {
            instruction.setInstructionValidatorsList(null);
        }

        instruction = this.instructionsRepository.save(instruction);
        InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
        sendNotification(instruction, Status.SUBMITTED.toString());
        log.debug("Leave:DwiInstructionsServiceImpl:submitInstruction.");
        return savedInstructionModel;
    }

    /**
     * @param instructionId
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel viewInstruction(final UUID instructionId) {
        log.debug("Entry:DwiInstructionsServiceImpl:viewInstructions.");
        Instructions instruc;
        InstructionsModel instrucModel = null;
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            instruc = instructionsRepository.findById(instructionId).orElse(null);
            if (Objects.nonNull(instruc)) {
                instrucModel = mapper.map(instruc, InstructionsModel.class);
            }
            log.debug("Leave:DwiInstructionsServiceImpl:viewInstructions.");
            return instrucModel;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL,
                    Constants.INSTRUCTION_VIEW_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param instructionId
     */
    @Override
    public void deleteInstructionById(final UUID instructionId) {
        log.debug("Entry:DwiInstructionsServiceImpl:deleteInstruction.");
        try {
            this.instructionsRepository.deleteById(instructionId);
            log.debug("Leave:DwiInstructionsServiceImpl:deleteInstruction.");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.INSTRUCTION,
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param id
     * @param comment
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel validateInstruction(final UUID id, final String comment,
            final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:validateInstruction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        User validator = null;
        String validatorUserName = null;
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        List<InstructionWorkFlowDetails> wfDetailsList = instruction.getWorkFlowDetailsList();
        try {
            validator = userRepository.findByEmail(email).get(0);
            validatorUserName = validator.getFirstName().concat(" ")
                    .concat(validator.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.VALIDATOR,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        instruction.setFirstValidator(validator);
        instruction.setDwiValidatedDate(new Date());
        instruction.setDwiStatus(Status.VALIDATED.toString());
        instruction.setApproverValidatorComments(comment);
        List<WorkFlowActionHistory> wfHistoryList = instruction.getWorkFlowActionHistoryList();
        WorkFlowActionHistory wfHistory = new WorkFlowActionHistory();
        wfHistory.setVersion(0);
        wfHistory.setWfhActionDate(new Date());
        wfHistory.setWfhUser(validator);
        wfHistory.setWfhUserName(validatorUserName);
        wfHistory.setWfhUserComments(comment);
        wfHistory.setWfhOperation(Status.VALIDATED.toString());
        wfHistory.setWfhdepartment(validator.getDepartment());
        wfHistory.setWfhInstructions(instruction);
        wfHistoryList.add(wfHistory);
        instruction.setWorkFlowActionHistoryList(wfHistoryList);
        wfDetailsList.forEach(item -> {
            if (item.getDwiActions().equals(Actions.DESIGN.toString())
                    || item.getDwiActions().equals(Actions.VALIDATE.toString())) {
                item.setApprovedRejectDate(new Date());
                item.setApproverAction(Status.VALIDATED.toString());
            }
        });
        String hisValue = Constants.INFO_NEWLINE.concat(dateFormat.format(new Date()))
                .concat(Constants.INFO_DELIMITER).concat(validatorUserName)
                .concat(Constants.INFO_DELIMITER).concat(Constants.INFO_VALIDATE);
        appendhistory(instruction, hisValue);
        this.instructionsRepository.save(instruction);
        InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
        sendNotification(instruction, Status.VALIDATED.toString());
        log.debug("Leave:DwiInstructionsServiceImpl:validateInstruction.");
        return savedInstructionModel;
    }

    /**
     * @param id
     * @param comment
     * @param dwiStaticLink
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel approveInstruction(final UUID id, final String comment,
            final String dwiStaticLink, final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:approveInstruction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        User approver = null;
        String approverUserName = null;
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        List<InstructionWorkFlowDetails> wfDetailsList = instruction.getWorkFlowDetailsList();
        try {
            approver = userRepository.findByEmail(email).get(0);
            approverUserName = approver.getFirstName().concat(" ").concat(approver.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.APPROVER,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        instruction.setApprover(approver);
        instruction.setDwiApprovedDate(new Date());
        instruction.setApproverValidatorComments(comment);
        instruction.setDwiStaticLink(dwiStaticLink);
        instruction.setApprovedActiveEdition(true);
        List<WorkFlowActionHistory> wfHistoryList = new ArrayList<>();
        WorkFlowActionHistory wfHistory = new WorkFlowActionHistory();
        wfHistory.setVersion(0);
        wfHistory.setWfhActionDate(new Date());
        wfHistory.setWfhUser(approver);
        wfHistory.setWfhUserName(approverUserName);
        wfHistory.setWfhUserComments(comment);
        wfHistory.setWfhOperation(Status.APPROVED.toString());
        wfHistory.setWfhdepartment(approver.getDepartment());
        wfHistory.setWfhInstructions(instruction);
        wfHistoryList.add(wfHistory);
        instruction.setWorkFlowActionHistoryList(wfHistoryList);
        wfDetailsList.forEach(item -> {
            if (item.getDwiActions().equals(Actions.APPROVED.toString())) {
                item.setApprovedRejectDate(new Date());
                item.setApproverAction(Status.APPROVED.toString());
            }
        });

        String hisValue = Constants.INFO_NEWLINE.concat(dateFormat.format(new Date()))
                .concat(Constants.INFO_DELIMITER).concat(approverUserName)
                .concat(Constants.INFO_DELIMITER).concat(Constants.INFO_APPROVE)
                .concat(Constants.INFO_NEWLINE).concat("Static link is set to ")
                .concat(dwiStaticLink);
        appendhistory(instruction, hisValue);

        generatePdf(instruction);

        if (instruction.getDwiStatus().equals(Status.IMPORT_SUBMITTED.toString())) {
            wfDetailsList.forEach(item -> {
                if (item.getDwiActions().equals(Actions.VALIDATE.toString())
                        || item.getDwiActions().equals(Actions.DESIGN.toString())) {
                    item.setInstructions(null);
                }
            });
        }
        instruction.setDwiStatus(Status.APPROVED.toString());

        instruction = instructionsRepository.save(instruction);
        InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
        sendNotification(instruction, Status.APPROVED.toString());
        log.debug("Leave:DwiInstructionsServiceImpl:approveInstruction.");
        return savedInstructionModel;
    }

    /**
     * @param instruction
     */
    private void generatePdf(final Instructions instruction) {
        StringBuffer newContent = new StringBuffer();
        DwiHeader header = null;
        Project project = instruction.getProject();
        List<DwiHeader> dwiHeaderList = dwiHeaderRepository.findByProjectId(project.getId());
        if (Objects.nonNull(dwiHeaderList) && !dwiHeaderList.isEmpty()) {
            header = dwiHeaderList.get(0);
        }
        if (Objects.nonNull(header)) {
            String content = header.getContent().toString();
            newContent.append(content);
            convertDefaultValues(instruction, newContent, "{$Title}", instruction.getDwiTitle());
            convertDefaultValues(instruction, newContent, "{$DWI_number}",
                    instruction.getDwiNumber());
            String authorFullName = instruction.getAuthor().getFirstName().concat(" ")
                    .concat(instruction.getAuthor().getLastName());
            convertDefaultValues(instruction, newContent, "{$Author}", authorFullName);
            convertDefaultValues(instruction, newContent, "{$Edition}",
                    instruction.getDwiEdition().toString());
            convertDefaultValues(instruction, newContent, "{$Project}",
                    instruction.getProject().getProjName());
            convertDefaultValues(instruction, newContent, "{$Fleet}",
                    instruction.getFleet().getFleetName());
            convertDefaultValues(instruction, newContent, "{$Process}",
                    instruction.getProcess().getProcessName());
            convertDefaultValues(instruction, newContent, "{$Revision}",
                    instruction.getRevision().getRevisionName());
            convertDefaultValues(instruction, newContent, "{$Reference}",
                    instruction.getDwiReference());

            EditionControlComments eCC = instruction.getEditionControlComments();
            buildEditionControlTable(eCC, newContent);
            buildWFControlTable(instruction.getWorkFlowDetailsList(), newContent);
        }
        appendLongDescComputed(instruction, newContent);

    }

    /**
     * @param eCC
     * @param newContent
     */
    private void buildEditionControlTable(final EditionControlComments eCC,
            final StringBuffer newContent) {
        StringBuffer eTcomments = new StringBuffer();

        eTcomments.append("<tr style='height: 18px;>");
        eTcomments.append("<td style='width: 9.3729%; height: 18px;'>");
        eTcomments.append(eCC.getDwiEdition());
        eTcomments.append("</td>");

        eTcomments.append("<td style='width: 20.33%;'>");
        eTcomments.append(dateFormat.format(eCC.getSubmittedDate()));
        eTcomments.append("</td>");

        eTcomments.append("<td style='width: 20.33%; height: 18px;'>");
        eTcomments.append(eCC.getComments() != null ? eCC.getComments() : "");
        eTcomments.append("</td>");

        eTcomments.append("<td style='width: 49.967%; height: 18px;'>");
        eTcomments.append(
                eCC.getUser().getFirstName().concat(" ").concat(eCC.getUser().getLastName()));
        eTcomments.append("</td>");
        eTcomments.append("</tr>");
        String subStringToReplace = "<td style=\"width: 9.3729%; height: 18px;\" colspan=\"4\">${EDITION_CONTROL_COMMENTS}</td>";
        int position = newContent.lastIndexOf(subStringToReplace);
        if (position != -1) {
            newContent.replace(position, position + subStringToReplace.length(),
                    eTcomments.toString());
        }
    }

    /**
     * @param workFlowDetailsList
     * @param newContent
     */
    private void buildWFControlTable(final List<InstructionWorkFlowDetails> workFlowDetailsList,
            final StringBuffer newContent) {
        StringBuffer wfComments = new StringBuffer();
        String subStringToReplace = "<td style=\"width: 100%; height: 18px;\" colspan=\"4\">${WORKFLOW_COMMENTS}</td>";
        workFlowDetailsList.forEach(dwiWFRow -> {
            wfComments.append("<tr style='height: 18px;>");
            wfComments.append("<td style='width: 9.55446%; height: 18px;'>");
            wfComments.append(dwiWFRow.getDwiActions());
            wfComments.append("</td>");

            wfComments.append("<td style='width: 20.1485%; height: 18px;'>");
            wfComments.append(dwiWFRow.getApproverOrValidatorUser().getFirstName().concat(" ")
                    .concat(dwiWFRow.getApproverOrValidatorUser().getLastName()));
            wfComments.append("</td>");

            wfComments.append("<td style='width: 20.5445%; height: 18px;'>");
            wfComments.append(dwiWFRow.getFunction().getDwiFunctionName());
            wfComments.append("</td>");

            wfComments.append("<td style='width: 49.7525%; height: 18px;'>");
            wfComments.append(dwiWFRow.getApprovedRejectDate() != null
                    ? dateFormat.format(dwiWFRow.getApprovedRejectDate())
                    : "");
            wfComments.append("</td>");
            wfComments.append("</tr>");
        });
        int position = newContent.lastIndexOf(subStringToReplace);
        if (position != -1) {
            newContent.replace(position, position + subStringToReplace.length(),
                    wfComments.toString());
        }
    }

    /**
     * @param instruction
     * @param newContent
     */
    private void appendLongDescComputed(final Instructions instruction,
            final StringBuffer newContent) {
        try {
            byte[] longDescComputed = newContent.toString().getBytes();
            byte[] longDesc = instruction.getDwiLongDesc() != null
                    ? instruction.getDwiLongDesc().getBytes()
                    : new byte[0];
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            os.writeBytes(longDescComputed);
            os.writeBytes(longDesc);
            longDescComputed = os.toByteArray();

            os.close();
            instruction.setDwiLongDescComputed(longDescComputed);
        } catch (IOException e) {
            log.error("Error occurred while fetching attachment.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACHMENT,
                    Constants.INSTRUCTION_ATTACHMENT_VIEW_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
    }

    /**
     * @param id
     */
    @Override
    public void archiveInstruction(final UUID id) {
        log.debug("Entry:DwiInstructionsServiceImpl:archiveInstruction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        Instructions prevInstruction = new Instructions();
        if (instruction != null) {
            if (instruction.getDwiEdition() != 1
                    && instruction.getDwiSubStatus().equals(SubStatus.NEW_VERSION.toString())) {
                int edition = instruction.getDwiEdition() - 1;
                prevInstruction = this.instructionsRepository
                        .findByDwiNumberAndDwiEdition(instruction.getDwiNumber(), edition);
                prevInstruction.setDwiStatus(Status.ARCHIVED.toString());
                prevInstruction.setApprovedActiveEdition(false);
                prevInstruction = this.instructionsRepository.save(prevInstruction);
            }
        }
        log.debug("Leave:DwiInstructionsServiceImpl:archiveInstruction.");
    }

    /**
     * @param id
     * @param comment
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel rejectInstruction(final UUID id, final String comment,
            final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:rejectInstruction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        User rejecter = null;
        String rejecterUserName = null;
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        List<InstructionWorkFlowDetails> wfDetailsList = instruction.getWorkFlowDetailsList();
        try {
            rejecter = userRepository.findByEmail(email).get(0);
            rejecterUserName = rejecter.getFirstName().concat(" ").concat(rejecter.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.APPROVER,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        instruction.setDwiRejectedDate(new Date());
        instruction.setApproverValidatorComments(comment);
        List<WorkFlowActionHistory> wfHistoryList = new ArrayList<>();
        WorkFlowActionHistory wfHistory = new WorkFlowActionHistory();
        wfHistory.setVersion(0);
        wfHistory.setWfhActionDate(new Date());
        wfHistory.setWfhUser(rejecter);
        wfHistory.setWfhUserName(rejecterUserName);
        wfHistory.setWfhUserComments(comment);
        wfHistory.setWfhdepartment(rejecter.getDepartment());
        String action = null;
        switch (instruction.getDwiStatus()) {
        case "SUBMITTED":
            wfHistory.setWfhOperation(Constants.REJECTED_BY_VALIDATOR);
            instruction.setFirstValidator(rejecter);
            action = Status.REJECTED.toString();
            wfDetailsList.forEach(item -> {
                if (item.getDwiActions().equals(Actions.VALIDATE.toString())) {
                    item.setApprovedRejectDate(new Date());
                    item.setApproverAction(Status.REJECTED.toString());
                }
            });
            break;
        case "VALIDATED":
        case "IMPORTED":
        case "IMPORT_SUBMITTED":
            wfHistory.setWfhOperation(Constants.REJECTED_BY_APPROVER);
            instruction.setApprover(rejecter);
            action = Status.REJECTED.toString();
            wfDetailsList.forEach(item -> {
                if (item.getDwiActions().equals(Actions.APPROVED.toString())) {
                    item.setApprovedRejectDate(new Date());
                    item.setApproverAction(Status.REJECTED.toString());
                }
            });
            break;
        default:
            break;
        }
        wfHistory.setWfhInstructions(instruction);
        wfHistoryList.add(wfHistory);
        instruction.setWorkFlowActionHistoryList(wfHistoryList);
        instruction.setDwiStatus(Status.REJECTED.toString());
        String hisValue = Constants.INFO_NEWLINE.concat(dateFormat.format(new Date()))
                .concat(Constants.INFO_DELIMITER).concat(rejecterUserName)
                .concat(Constants.INFO_DELIMITER).concat(Constants.INFO_REJECT);
        appendhistory(instruction, hisValue);
        this.instructionsRepository.save(instruction);
        InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
        sendNotification(instruction, action);
        log.debug("Leave:DwiInstructionsServiceImpl:rejectInstruction.");
        return savedInstructionModel;
    }

    /**
     * instructionAutoReminder.
     */
    @Override
    // @Scheduled(cron = "0 0 1 * * *")
    public void instructionAutoReminder() {
        log.debug("Entry:DwiInstructionsServiceImpl:instructionAutoReminder.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        NotificationSettingsModel settings = settingsService.getSettings();

        Status submittedStatus = Status.SUBMITTED;
        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR,
                -(settings.getVerificationAutoReminderWaitingPeriod() > 0
                        ? settings.getVerificationAutoReminderWaitingPeriod()
                        : 2));
        Date reminderDate = c.getTime();
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions
                .add(RequestModifier.getfilterCondition("String", "dwiStatus", submittedStatus));
        filterConditions.add(
                RequestModifier.getfilterCondition("Date", "dwiSubmittedDate", reminderDate, "le"));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        List<Instructions> instructionSubmittedList = instructionsRepository
                .findAll(requestModel.getFilterSpecification());
        if (Objects.nonNull(instructionSubmittedList) && !instructionSubmittedList.isEmpty()) {
            instructionSubmittedList.forEach(instruction -> {
                sendNotification(instruction, Constants.AUTO_REMINDER_VALIDATION);
            });
        }

        Status verifiedStatus = Status.VALIDATED;
        request = RequestModifier.defaultRequestMapIfEmpty(null);
        c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR,
                -(settings.getApprovalAutoReminderWaitingPeriod() > 0
                        ? settings.getApprovalAutoReminderWaitingPeriod()
                        : 2));
        reminderDate = c.getTime();
        filterConditions = new ArrayList<>();
        filterConditions
                .add(RequestModifier.getfilterCondition("String", "dwiStatus", verifiedStatus));
        filterConditions.add(
                RequestModifier.getfilterCondition("Date", "dwiValidatedDate", reminderDate, "le"));
        requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        List<Instructions> instructionVerifiedList = instructionsRepository
                .findAll(requestModel.getFilterSpecification());
        if (Objects.nonNull(instructionVerifiedList) && !instructionVerifiedList.isEmpty()) {
            instructionVerifiedList.forEach(instruction -> {
                sendNotification(instruction, Constants.AUTO_REMINDER_APPROVAL);
            });
        }
        log.debug("Leave:DwiInstructionsServiceImpl:instructionAutoReminder.");
    }

    /**
     * @param instruction
     * @param action
     */
    private void sendNotification(final Instructions instruction, final String action) {
        log.debug("Entry:DwiInstructionsServiceImpl:sendNotification.");
        EmailModel email = null;
        String instructionTrigger = null;
        if (Objects.nonNull(instruction)) {
            try {
                List<InstructionWorkFlowDetails> wfDetailsList = instruction
                        .getWorkFlowDetailsList();
                List<User> approversList = new ArrayList<>();
                List<User> validatorsList = new ArrayList<>();
                wfDetailsList.forEach(item -> {
                    if (item.getDwiActions().equals(Actions.APPROVED.toString())) {
                        approversList.add(item.getApproverOrValidatorUser());
                    }
                    if (item.getDwiActions().equals(Actions.VALIDATE.toString())) {
                        validatorsList.add(item.getApproverOrValidatorUser());
                    }
                });

                String creator = instruction.getAuthor().getEmail();
                String validator = instruction.getFirstValidator() != null
                        ? instruction.getFirstValidator().getEmail()
                        : "";
                String approver = instruction.getApprover() != null
                        ? instruction.getApprover().getEmail()
                        : "";
                String author = instruction.getAuthor().getEmail();

                if (null != action) {

                    switch (action) {
                    case "SUBMITTED":
                        instructionTrigger = this.wiSubmitted;
                        break;
                    case "VALIDATED":
                        instructionTrigger = this.wiValidated;
                        break;
                    case "APPROVED":
                        instructionTrigger = this.wiApproved;
                        break;
                    case "REJECTED":
                        instructionTrigger = this.wiRejected;
                        break;
                    case "ADDCOMMENTS":
                        instructionTrigger = this.wiAddComments;
                        break;
                    case "AUTO_REMINDER_VALIDATION":
                        instructionTrigger = this.wiAutoreminderValidation;
                        break;
                    case "AUTO_REMINDER_APPROVAL":
                        instructionTrigger = this.wiAutoreminderApproval;
                        break;
                    default:
                        instructionTrigger = null;

                    }
                }

                List<String> toMails = new ArrayList<>();
                if (Strings.isNotBlank(instructionTrigger)) {
                    email = this.adminServiceClient.getEmail(instructionTrigger);
                    if (!Objects.isNull(email)) {
                        for (String roleCode : email.getRecipients()) {
                            switch (roleCode) {
                            case "CREATOR":
                                toMails.add(creator);
                                break;
                            case "APPROVER":
                                if (!approver.equals("")) {
                                    toMails.add(approver);
                                }
                                if (Objects.nonNull(approversList) && !approversList.isEmpty()) {
                                    approversList.forEach(
                                            approverUser -> toMails.add(approverUser.getEmail()));
                                }
                                break;
                            case "VALIDATOR":
                                if (!validator.equals("")) {
                                    toMails.add(validator);
                                }
                                if (Objects.nonNull(validatorsList) && !validatorsList.isEmpty()) {
                                    validatorsList.forEach(
                                            validatorUser -> toMails.add(validatorUser.getEmail()));
                                }
                                break;
                            case "AUTHOR":
                                toMails.add(author);
                                break;
                            default:
                                break;
                            }
                        }
                        if (!toMails.isEmpty()) {
                            email.setRecipients(toMails);
                            emailBuilder(instruction, email);
                            this.emailServiceClient.sendMail(email);
                            log.info("Email Sent Successfully for " + instruction.getDwiNumber());
                        } else {
                            log.error(Constants.MSG_EMAIL_RECIPIENT_ARE_NOT_ADDED + " "
                                    + instruction.getDwiNumber());
                            /*
                             * List<ErrorModel> errors = new ArrayList<>(); errors.add( new
                             * ErrorModel(Constants.FIELD_EMAIL,
                             * Constants.MSG_EMAIL_RECIPIENT_ARE_NOT_ADDED)); throw new
                             * ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
                             */
                        }
                    }
                }
            } catch (Exception ex) {
                log.error("Email Server down :" + ex);
            }
            log.debug("Leave:DwiInstructionsServiceImpl:sendNotification.");
        }
    }

    /**
     * @param instruction
     * @param email
     */
    private void emailBuilder(final Instructions instruction, final EmailModel email) {
        log.debug("Entry:DwiInstructionsServiceImpl:emailBuilder.");
        String subject = email.getSubject();
        String content = email.getBody();
        StringBuffer newSubject = new StringBuffer();
        newSubject.append(subject.toString());
        convertDefaultValues(instruction, newSubject, "{$dwinstructions.dwiNumber}",
                instruction.getDwiNumber().toString());
        convertDefaultValues(instruction, newSubject, "{$dwinstructions.dwiEdition}",
                instruction.getDwiEdition().toString());
        StringBuffer newContent = new StringBuffer();
        newContent.append(content.toString());
        convertDefaultValues(instruction, newContent, "{$dwinstructions.dwiNumber}",
                instruction.getDwiNumber());
        convertDefaultValues(instruction, newContent, "{$dwinstructions.dwiEdition}",
                instruction.getDwiEdition().toString());
        convertDefaultValues(instruction, newContent, "{$dwinstructions.dwiProject}",
                instruction.getProject().getProjName());
        convertDefaultValues(instruction, newContent, "{$dwinstructions.dwiProcess}",
                instruction.getProcess().getProcessName());
        convertDefaultValues(instruction, newContent, "{$dwinstructions.dwiRevision}",
                instruction.getRevision().getRevisionName());
        convertDefaultValues(instruction, newContent, "{$dwinstructions.dwiTitle}",
                instruction.getDwiTitle());
        convertDefaultValues(instruction, newContent, "{$dwinstructions.dwiAuthor}",
                instruction.getAuthor().getEmail());
        if (null != instruction.getApproverValidatorComments()) {
            convertDefaultValues(instruction, newContent,
                    "{$dwinstructions.approverValidatorComments}",
                    instruction.getApproverValidatorComments());
        }
        convertDefaultValues(instruction, newContent, "{$dwinstructions.id}",
                instruction.getId().toString());
        email.setSubject(newSubject.toString());
        email.setBody(newContent.toString());

        log.debug("Leave:DwiInstructionsServiceImpl:emailBuilder.");
    }

    /**
     * @param instruction
     * @param newSubject
     * @param subString
     * @param replacement
     */
    private void convertDefaultValues(final Instructions instruction, final StringBuffer newSubject,
            final String subString, final String replacement) {
        int position = newSubject.indexOf(subString);
        while (position != -1) {
            newSubject.replace(position, position + subString.length(), replacement);
            position += replacement.length(); // Move to the end of the replacement
            position = newSubject.indexOf(subString, position);
        }

    }

    /**
     * @param projectModel
     * @return work instructions generated number.
     */
    private String generateWorkInstructionNumber(final ProjectModel projectModel) {
        log.debug("Entry:DwiInstructionsServiceImpl:generateWorkInstructionNumber.");
        String incrementNumber = "1";
        String wiNumber = null;
        WINumberPerProject wiEntry = null;
        ModelMapper mapper = new ModelMapper();
        Project project = mapper.map(projectModel, Project.class);
        wiEntry = wiNumberPerProjectRepository.findByProjectId(project.getId());
        if (Objects.nonNull(wiEntry)) {
            int incrementedNumber = Integer.parseInt(wiEntry.getGeneratedNumber()) + 1;

            incrementNumber = String.valueOf(incrementedNumber);
            wiEntry.setGeneratedNumber(incrementNumber);
            wiEntry.setVersion(Integer.valueOf(incrementNumber));
            wiEntry.setProject(project);
            wiEntry = wiNumberPerProjectRepository.save(wiEntry);
        } else {
            WINumberPerProject newWiEntry = new WINumberPerProject();
            newWiEntry.setGeneratedNumber(incrementNumber);
            newWiEntry.setVersion(Integer.valueOf(incrementNumber));
            newWiEntry.setProject(project);
            newWiEntry = wiNumberPerProjectRepository.save(newWiEntry);
        }
        wiNumber = Constants.DWI_NUMBER_PREFIX.concat(Constants.DWI_NUMBER_DELIMITER)
                .concat(project.getProjName()).concat(Constants.DWI_NUMBER_DELIMITER)
                .concat(incrementNumber);
        log.debug("Leave:DwiInstructionsServiceImpl:generateWorkInstructionNumber.");
        return wiNumber;
    }

    /**
     * @param id
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel createNewVersion(final UUID id, final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:createNewVersion.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        User creator = null;
        String creatorUserName = null;
        Instructions instruction;
        Instructions newInstruction = new Instructions();
        List<WorkFlowActionHistory> wfHistoryList = new ArrayList<>();
        EditionControlComments editionCC = new EditionControlComments();
        List<InstructionWorkFlowDetails> oldWFDetailsList = new ArrayList<>();
        List<InstructionWorkFlowDetails> newWFDetailsList = new ArrayList<>();
        List<Tag> newTagList = new ArrayList<>();
        List<Tag> oldTagList = new ArrayList<>();
        byte[] history = new byte[Constants.INST_BYTE_LENGTH];
        List<InstructionAttachment> oldAttachList = new ArrayList<>();
        List<InstructionAttachment> newAttachList = new ArrayList<>();

        try {
            creator = userRepository.findByEmail(email).get(0);
            creatorUserName = creator.getFirstName().concat(" ").concat(creator.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(
                    new ErrorModel(Constants.AUTHOR, Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        instruction = this.instructionsRepository.findById(id).orElse(null);
        if (Objects.nonNull(instruction)) {
            instruction.setNewEditionCreated(true);
            this.instructionsRepository.save(instruction);
        } else {
            log.debug("Instruction not available.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        newInstruction.setId(null);
        newInstruction.setDwiEdition(instruction.getDwiEdition() + 1);
        newInstruction.setDwiStatus(Status.DRAFT.toString());
        newInstruction.setDwiSubStatus(SubStatus.NEW_VERSION.toString());
        newInstruction.setCreatedDate(new Date());
        newInstruction.setCreatedBy(creator.getEmployeeId());
        newInstruction.setAuthor(creator);
        newInstruction.setFirstValidator(null);
        newInstruction.setDwiValidatedDate(null);
        newInstruction.setDwiApprovedDate(null);
        newInstruction.setApprover(null);
        newInstruction.setApproverValidatorComments(null);
        newInstruction.setModifiedDate(null);
        newInstruction.setModifiedBy(null);
        newInstruction.setDwiSubmittedDate(null);
        newInstruction.setDwiRejectedDate(null);
        newInstruction.setNewEditionCreated(false);
        newInstruction.setApprovedActiveEdition(false);
        newInstruction.setDwiStaticLink(null);
        newInstruction.setDwiLongDescComputed(null);
        newInstruction.setVersion(0);
        newInstruction.setDwiFleet(instruction.getDwiFleet());
        newInstruction.setDwiLongDesc(instruction.getDwiLongDesc());
        newInstruction.setDwiLongDescHeader(instruction.getDwiLongDescHeader());
        newInstruction.setDwiNumber(instruction.getDwiNumber());
        newInstruction.setDwiReference(instruction.getDwiReference());
        newInstruction.setDwiTitle(instruction.getDwiTitle());
        newInstruction.setFleet(instruction.getFleet());
        // newInstruction.setHistory(null);
        newInstruction.setInstructionApproversList(null);
        newInstruction.setInstructionValidatorsList(null);
        newInstruction.setProcess(instruction.getProcess());
        newInstruction.setProject(instruction.getProject());
        newInstruction.setRevision(instruction.getRevision());
        newInstruction.setWorkFlowTemplate(instruction.getWorkFlowTemplate());
        String his = dateFormat.format(new Date()).concat(Constants.INFO_DELIMITER)
                .concat(creatorUserName).concat(Constants.INFO_DELIMITER)
                .concat(Constants.OBJ_CREATED);
        history = his.getBytes();
        newInstruction.setHistory(history);

        WorkFlowActionHistory wfHistory = new WorkFlowActionHistory();
        wfHistory.setVersion(0);
        wfHistory.setWfhActionDate(new Date());
        wfHistory.setWfhUser(creator);
        wfHistory.setWfhUserName(creatorUserName);
        wfHistory.setWfhUserComments(null);
        wfHistory.setWfhOperation(Constants.NEW_VERSION_CREATED);
        wfHistory.setWfhdepartment(creator.getDepartment());
        wfHistory.setWfhInstructions(newInstruction);
        wfHistoryList.add(wfHistory);

        newInstruction.setWorkFlowActionHistoryList(wfHistoryList);

        editionCC.setComments(instruction.getEditionControlComments().getComments());
        editionCC.setDwiEdition(newInstruction.getDwiEdition());
        editionCC.setDwiNumber(newInstruction.getDwiNumber());
        editionCC.setSubmittedDate(new Date());
        editionCC.setUser(creator);
        editionCC.setVersion(0);
        newInstruction.setEditionControlComments(editionCC);

        oldWFDetailsList = instruction.getWorkFlowDetailsList();
        oldWFDetailsList.forEach(item -> {
            InstructionWorkFlowDetails wfDetailtemp = new InstructionWorkFlowDetails();
            wfDetailtemp.setVersion(0);
            wfDetailtemp.setDwiActions(item.getDwiActions());
            wfDetailtemp.setFunction(item.getFunction());
            wfDetailtemp.setName(item.getName());
            wfDetailtemp.setApproverOrValidatorUser(item.getApproverOrValidatorUser());
            wfDetailtemp.setApprovedRejectDate(null);
            wfDetailtemp.setApproverAction(null);
            wfDetailtemp.setWfTemplateDescSeq(item.getWfTemplateDescSeq());
            newWFDetailsList.add(wfDetailtemp);

        });

        newInstruction.setWorkFlowDetailsList(newWFDetailsList);

        oldTagList = instruction.getInstructiontagsList();
        if (Objects.nonNull(oldTagList)) {
            oldTagList.forEach(item -> {
                Tag tagRec = new Tag();
                tagRec.setId(item.getId());
                tagRec.setVersion(item.getVersion());
                tagRec.setDwTags(item.getDwTags());
                newTagList.add(tagRec);
            });
        }
        newInstruction.setInstructiontagsList(newTagList);

        if (Objects.nonNull(newInstruction.getEditionControlComments())) {
            Instructions finalInstruction = newInstruction;
            newInstruction.getEditionControlComments().setInstructions(finalInstruction);
        }

        if (Objects.nonNull(newInstruction.getWorkFlowDetailsList())
                && !newInstruction.getWorkFlowDetailsList().isEmpty()) {
            Instructions finalInstruction = newInstruction;
            newInstruction.getWorkFlowDetailsList().forEach(item -> {
                item.setInstructions(finalInstruction);
            });
        }

        oldAttachList = instruction.getInstructionAttachmentList();
        if (Objects.nonNull(oldAttachList)) {
            oldAttachList.forEach(item -> {
                InstructionAttachment insAttach = new InstructionAttachment();
                insAttach.setAttachedFileName(item.getAttachedFileName());
                insAttach.setAttachmentText(item.getAttachmentText());
                insAttach.setCreatedBy(item.getCreatedBy());
                insAttach.setCreatedDate(new Date());
                insAttach.setDwiFormId(item.getDwiFormId());
                insAttach.setModifiedBy(null);
                insAttach.setModifiedDate(null);
                insAttach.setUploadSuccesfull(item.getUploadSuccesfull());
                insAttach.setVersion(0);
                newAttachList.add(insAttach);
            });
        }
        newInstruction.setInstructionAttachmentList(newAttachList);

        if (Objects.nonNull(newInstruction.getInstructionAttachmentList())
                && !newInstruction.getInstructionAttachmentList().isEmpty()) {
            Instructions finalInstruction = newInstruction;
            newInstruction.getInstructionAttachmentList()
                    .forEach(item -> item.setInstructions(finalInstruction));
        }

        if (newInstruction.getInstructiontagsList().isEmpty()) {
            newInstruction.setInstructiontagsList(null);
        }

        Instructions savedInstruction = instructionsRepository.save(newInstruction);
        InstructionsModel savedInstructionModel = viewInstruction(savedInstruction.getId());
        log.debug("Leave:DwiInstructionsServiceImpl:createNewVersion.");

        return savedInstructionModel;
    }

    /**
     * @param instruction
     * @param hisValue
     */
    private void appendhistory(final Instructions instruction, final String hisValue) {
        byte[] oldHistory = instruction.getHistory();
        byte[] newHistory = hisValue.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(oldHistory);
        os.writeBytes(newHistory);
        oldHistory = os.toByteArray();
        instruction.setHistory(oldHistory);
    }

    /**
     * @param id
     */
    @Override
    public void copyAttachment(final UUID id) {
        log.debug("Entry:DwiInstructionsServiceImpl:copyAttachment.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        Instructions prevInstruction = new Instructions();
        if (instruction.getDwiEdition() != 1) {
            int edition = instruction.getDwiEdition() - 1;
            prevInstruction = this.instructionsRepository
                    .findByDwiNumberAndDwiEdition(instruction.getDwiNumber(), edition);
        }
        instructionAttachmentService.copyInstructionAttachmentById(prevInstruction.getId(), id);
        log.debug("Leave:DwiInstructionsServiceImpl:copyAttachment.");
    }

    /**
     * @param id
     * @param instructionAttachmentModel
     * @param comment
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel addComments(final UUID id,
            final InstructionAttachmentModel instructionAttachmentModel, final String comment,
            final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:addComments.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        User worker = null;
        String workerUserName = null;
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        try {
            worker = userRepository.findByEmail(email).get(0);
            workerUserName = worker.getFirstName().concat(" ").concat(worker.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.ERROR_LABEL,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        List<WorkFlowActionHistory> wfHistoryList = new ArrayList<>();
        WorkFlowActionHistory wfHistory = new WorkFlowActionHistory();
        wfHistory.setVersion(0);
        wfHistory.setWfhActionDate(new Date());
        wfHistory.setWfhUser(worker);
        wfHistory.setWfhUserName(workerUserName);
        wfHistory.setWfhUserComments(comment != null ? comment : "");
        wfHistory.setWfhOperation(Constants.MODIFIED);
        wfHistory.setWfhdepartment(worker.getDepartment());
        wfHistory.setWfhInstructions(instruction);

        if (Objects.nonNull(instructionAttachmentModel)) {
            InstructionAttachment insAttach = mapper.map(instructionAttachmentModel,
                    InstructionAttachment.class);
            wfHistory.setInstructionAttachment(insAttach);
            insAttach.setInstructions(instruction);
        }

        wfHistoryList.add(wfHistory);
        instruction.setWorkFlowActionHistoryList(wfHistoryList);
        instruction.setApproverValidatorComments(comment != null ? comment : "");
        String hisValue = Constants.INFO_NEWLINE.concat(dateFormat.format(new Date()))
                .concat(Constants.INFO_DELIMITER).concat(workerUserName)
                .concat(Constants.INFO_DELIMITER).concat(Constants.COMMENTS_ADDED);
        appendhistory(instruction, hisValue);
        this.instructionsRepository.save(instruction);
        InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
        sendNotification(instruction, Constants.ADDCOMMENTS);
        log.debug("Leave:DwiInstructionsServiceImpl:addComments.");
        return savedInstructionModel;
    }

    /**
     * @param id
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel viewPreviousVersion(final UUID id, final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:viewPreviousVersion.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        User approver = null;
        String approverUserName = null;
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        try {
            approver = userRepository.findByEmail(email).get(0);
            approverUserName = approver.getFirstName().concat(" ").concat(approver.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(
                    new ErrorModel(Constants.AUTHOR, Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        Instructions prevInstruction = new Instructions();
        InstructionsModel instructionModel = null;
        if (instruction.getDwiEdition() != 1) {
            int edition = instruction.getDwiEdition() - 1;
            prevInstruction = this.instructionsRepository
                    .findByDwiNumberAndDwiEdition(instruction.getDwiNumber(), edition);
        }

        if (Objects.nonNull(prevInstruction)) {
            instructionModel = mapper.map(prevInstruction, InstructionsModel.class);
        }

        return instructionModel;
    }

    /**
     * @param id
     * @param comment
     * @param email
     * @return Instruc.tionsModel
     */
    @Override
    public InstructionsModel validateInstructionByAction(final UUID id, final String comment,
            final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:validateInstructionByAction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        User validator = new User();
        String validatorUserName = null;
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        List<InstructionWorkFlowDetails> wfDetailsList = instruction.getWorkFlowDetailsList();
        try {
            validator = userRepository.findByEmail(email).get(0);
            validatorUserName = validator.getFirstName().concat(" ")
                    .concat(validator.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.VALIDATOR,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        final User valiateUser = validator;
        List<User> validatorsList = new ArrayList<>();
        List<User> validatedList = new ArrayList<>();
        wfDetailsList.forEach(item -> {
            if (item.getDwiActions().equals(Actions.VALIDATE.toString())) {
                validatorsList.add(item.getApproverOrValidatorUser());
                if (item.getApproverAction() != null) {
                    validatedList.add(item.getApproverOrValidatorUser());
                }
            }
        });

        if (Objects.nonNull(validatorsList) && !validatorsList.contains(validator)) {
            log.debug("User not allowed to validate the Work Instruction.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.VALIDATION,
                    Constants.WORKFLOW_VALIDATOR_ERROR + validatorUserName));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        } else if (Objects.nonNull(validatedList) && validatedList.contains(validator)) {
            log.debug("User already validated the Work Instruction.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.VALIDATION,
                    Constants.WORKFLOW_VALIDATOR_ERROR + validatorUserName));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        } else {
            instruction.setFirstValidator(validator);
            instruction.setDwiValidatedDate(new Date());
            instruction.setApproverValidatorComments(comment);
            List<WorkFlowActionHistory> wfHistoryList = instruction.getWorkFlowActionHistoryList();
            WorkFlowActionHistory wfHistory = new WorkFlowActionHistory();
            wfHistory.setVersion(0);
            wfHistory.setWfhActionDate(new Date());
            wfHistory.setWfhUser(validator);
            wfHistory.setWfhUserName(validatorUserName);
            wfHistory.setWfhUserComments(comment);
            wfHistory.setWfhOperation(Status.VALIDATED.toString());
            wfHistory.setWfhdepartment(validator.getDepartment());
            wfHistory.setWfhInstructions(instruction);
            wfHistoryList.add(wfHistory);
            instruction.setWorkFlowActionHistoryList(wfHistoryList);
            wfDetailsList.forEach(item -> {
                if (item.getDwiActions().equals(Actions.VALIDATE.toString())) {
                    if (item.getApproverOrValidatorUser().equals(valiateUser)) {
                        item.setApprovedRejectDate(new Date());
                        item.setApproverAction(Status.VALIDATED.toString());
                        validatedList.add(item.getApproverOrValidatorUser());
                    }
                }
            });
            String hisValue = Constants.INFO_NEWLINE.concat(dateFormat.format(new Date()))
                    .concat(Constants.INFO_DELIMITER).concat(validatorUserName)
                    .concat(Constants.INFO_DELIMITER).concat(Constants.INFO_VALIDATE);
            appendhistory(instruction, hisValue);

            if (validatorsList.size() == validatedList.size()) {
                instruction.setDwiStatus(Status.VALIDATED.toString());
                sendNotification(instruction, Status.VALIDATED.toString());
            } else {
                instruction.setDwiStatus(Status.SUBMITTED.toString());
            }

            this.instructionsRepository.save(instruction);
            InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
            log.debug("Leave:DwiInstructionsServiceImpl:validateInstructionByAction.");
            return savedInstructionModel;
        }

    }

    /**
     * @param id
     * @param comment
     * @param dwiStaticLink
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel approveInstructionByAction(final UUID id, final String comment,
            final String dwiStaticLink, final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:approveInstructionByAction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        User approver = null;
        String approverUserName = null;
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        List<InstructionWorkFlowDetails> wfDetailsList = instruction.getWorkFlowDetailsList();
        try {
            approver = userRepository.findByEmail(email).get(0);
            approverUserName = approver.getFirstName().concat(" ").concat(approver.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.APPROVER,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        final User approveUser = approver;
        List<User> approversList = new ArrayList<>();
        List<User> approvedList = new ArrayList<>();
        wfDetailsList.forEach(item -> {
            if (item.getDwiActions().equals(Actions.APPROVED.toString())) {
                approversList.add(item.getApproverOrValidatorUser());
                if (item.getApproverAction() != null) {
                    approvedList.add(item.getApproverOrValidatorUser());
                }
            }
        });

        if (Objects.nonNull(approversList) && !approversList.contains(approver)) {
            log.debug("User not allowed to approve the Work Instruction.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.APPROVER,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + approverUserName));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        } else if (Objects.nonNull(approvedList) && approvedList.contains(approver)) {
            log.debug("User already approved the Work Instruction.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.APPROVER,
                    Constants.WORK_INSTRUCTION_ALREADY_APPROVED + approverUserName));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        } else {
            instruction.setApprover(approver);
            instruction.setDwiApprovedDate(new Date());
            instruction.setApproverValidatorComments(comment);
            instruction.setDwiStaticLink(dwiStaticLink);
            instruction.setApprovedActiveEdition(true);
            List<WorkFlowActionHistory> wfHistoryList = new ArrayList<>();
            WorkFlowActionHistory wfHistory = new WorkFlowActionHistory();
            wfHistory.setVersion(0);
            wfHistory.setWfhActionDate(new Date());
            wfHistory.setWfhUser(approver);
            wfHistory.setWfhUserName(approverUserName);
            wfHistory.setWfhUserComments(comment);
            wfHistory.setWfhOperation(Status.APPROVED.toString());
            wfHistory.setWfhdepartment(approver.getDepartment());
            wfHistory.setWfhInstructions(instruction);
            wfHistoryList.add(wfHistory);
            instruction.setWorkFlowActionHistoryList(wfHistoryList);
            wfDetailsList.forEach(item -> {
                if (item.getDwiActions().equals(Actions.APPROVED.toString())) {
                    if (item.getApproverOrValidatorUser().equals(approveUser)) {
                        item.setApprovedRejectDate(new Date());
                        item.setApproverAction(Status.APPROVED.toString());
                        approvedList.add(item.getApproverOrValidatorUser());
                    }
                }
            });

            String hisValue = Constants.INFO_NEWLINE.concat(dateFormat.format(new Date()))
                    .concat(Constants.INFO_DELIMITER).concat(approverUserName)
                    .concat(Constants.INFO_DELIMITER).concat(Constants.INFO_APPROVE);
            appendhistory(instruction, hisValue);

            if (approversList.size() == approvedList.size()) {
                generatePdf(instruction);
                if (instruction.getDwiStatus().equals(Status.IMPORT_SUBMITTED.toString())) {
                    wfDetailsList.forEach(item -> {
                        if (item.getDwiActions().equals(Actions.VALIDATE.toString())
                                || item.getDwiActions().equals(Actions.DESIGN.toString())) {
                            item.setInstructions(null);
                        }
                    });
                }
                String hisValue1 = Constants.INFO_NEWLINE.concat(Constants.STATIC_LINK_ADD)
                        .concat(dwiStaticLink);
                appendhistory(instruction, hisValue1);
                instruction.setDwiStatus(Status.APPROVED.toString());
                sendNotification(instruction, Status.APPROVED.toString());
            } else {
                if (instruction.getDwiStatus().equals(Status.IMPORT_SUBMITTED.toString())) {
                    instruction.setDwiStatus(Status.IMPORT_SUBMITTED.toString());
                } else {
                    instruction.setDwiStatus(Status.VALIDATED.toString());
                }
            }

            instruction = instructionsRepository.save(instruction);
            InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
            log.debug("Leave:DwiInstructionsServiceImpl:approveInstructionByAction.");
            return savedInstructionModel;
        }
    }

    /**
     * @param id
     * @param instructionAttachmentModel
     * @param email
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel addAttachment(final UUID id,
            final InstructionAttachmentModel instructionAttachmentModel, final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:addAttachment.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        User worker = null;
        String workerUserName = null;
        if (Objects.isNull(instruction)) {
            log.debug("Work Instruction not available in the application.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION,
                    Constants.WORK_INSTRUCTIONS_NOT_AVAILABLE));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        try {
            worker = userRepository.findByEmail(email).get(0);
            workerUserName = worker.getFirstName().concat(" ").concat(worker.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.ERROR_LABEL,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        List<InstructionAttachment> attachmentList = new ArrayList<>();
        InstructionAttachment insAttach = mapper.map(instructionAttachmentModel,
                InstructionAttachment.class);
        insAttach.setInstructions(instruction);
        attachmentList.add(insAttach);
        instruction.setInstructionAttachmentList(attachmentList);
        List<WorkFlowActionHistory> wfHistoryList = new ArrayList<>();
        WorkFlowActionHistory wfHistory = new WorkFlowActionHistory();
        wfHistory.setVersion(0);
        wfHistory.setWfhActionDate(new Date());
        wfHistory.setWfhUser(worker);
        wfHistory.setWfhUserName(workerUserName);
        wfHistory.setWfhUserComments("");
        wfHistory.setWfhOperation(Constants.ATTACH_ADDED);
        wfHistory.setWfhdepartment(worker.getDepartment());
        wfHistory.setWfhInstructions(instruction);
        wfHistoryList.add(wfHistory);
        instruction.setWorkFlowActionHistoryList(wfHistoryList);
        this.instructionsRepository.save(instruction);
        InstructionsModel savedInstructionModel = viewInstruction(instruction.getId());
        log.debug("Leave:DwiInstructionsServiceImpl:addAttachment.");
        return savedInstructionModel;
    }

    /**
     * @param request
     * @return object of instructions.
     */
    @Override
    public Object searchUserInstructions(final RequestModel request) {

        log.debug("Entry:DwiInstructionsServiceImpl:searchInstructions.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.instructionsRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(instructions -> mapper.map(instructions, InstructionsListModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.instructionsRepository.findAll(request.getFilterSpecification()).stream()
                    .map(instructions -> mapper.map(instructions, InstructionsListModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:DwiInstructionsServiceImpl:searchInstructions.");
        return result;
    }
}
