package com.alstom.applicationfactory.dwiservice.instruction.model;

import java.util.Date;
import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EditionControlCommentsModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    @JsonIgnore
    private InstructionsModel instructions;

    /**
     */
    private String dwiNumber;

    /**
     */
    private Integer dwiEdition;

    /**
     */
    private UserModel user;

    /**
     */
    private Date submittedDate;

    /**
     */
    private String comments;

}
