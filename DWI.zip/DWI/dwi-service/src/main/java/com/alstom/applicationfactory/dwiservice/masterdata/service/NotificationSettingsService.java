package com.alstom.applicationfactory.dwiservice.masterdata.service;

import com.alstom.applicationfactory.dwiservice.masterdata.model.NotificationSettingsModel;

public interface NotificationSettingsService {

    /**
     * @param settingsModel
     * @return NotificationSettingsModel.
     */
    NotificationSettingsModel updateSettings(NotificationSettingsModel settingsModel);

    /**
     * @param settingsModel
     * @return NotificationSettingsModel.
     */
    NotificationSettingsModel saveSettings(NotificationSettingsModel settingsModel);

    /**
     * @return NotificationSettingsModel.
     */
    NotificationSettingsModel getSettings();
}
