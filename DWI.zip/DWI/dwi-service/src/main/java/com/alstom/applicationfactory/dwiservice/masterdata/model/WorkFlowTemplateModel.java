package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkFlowTemplateModel {

    /**
     */
    private UUID id;
    /**
     */
    private Integer version;
    /**
     */
    @NotNull(message = "Work Flow Template Name name should be unique and non-empty")
    private String workFlowTemplateName;
    /**
     */
    private boolean active;
    /**
     */
    private ProjectModel project;
    /**
     */
    private Date createdDate;
    /**
     */
    private Date modifiedDate;
    /**
     */
    private String createdBy;
    /**
     */
    private String modifiedBy;
    /**
     */
    private List<WorkFlowTemplateDescModel> actions;
}
