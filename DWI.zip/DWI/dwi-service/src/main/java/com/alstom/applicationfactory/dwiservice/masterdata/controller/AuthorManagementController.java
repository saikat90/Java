package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsListModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.AuthorManagementService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/author")
@Slf4j
public class AuthorManagementController {

    /**
     * AuthorManagementService.
     */
    @Autowired
    private AuthorManagementService authorManagementService;

    /**
     * @param request
     * @return object of author management.
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getAllAuthorManagement(
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:AuthorManagementController:getAllAuthorManagement.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = authorManagementService.searchAuthorManagement(requestModel);
        log.debug("Leave:AuthorManagementController:getAllAuthorManagement.");
        return res;
    }

    /**
     * @param request
     * @return object of searched author management.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchProcess(@RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:AuthorManagementController:getAllAuthorManagement.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = authorManagementService.searchAuthorManagement(requestModel);
        log.debug("Leave:AuthorManagementController:getAllAuthorManagement.");
        return res;
    }

    /**
     * @param instruction
     * @return InstructionsModel.
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public InstructionsModel updateAuthorManagement(
            @RequestBody @Valid final InstructionsModel instruction) {
        log.debug("Entry:AuthorManagementController:updateAuthorManagement.");
        InstructionsModel instrumentsModel = authorManagementService
                .updateAuthorManagement(instruction);
        log.debug("Leave:AuthorManagementController:updateAuthorManagement.");
        return instrumentsModel;
    }

    /**
     * @param id
     * @param userModel
     * @return InstructionsListModel
     */
    @PostMapping("/{id}/updateAuthor")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('PROJ_MANAGER','ADM')")
    public InstructionsListModel updateAuthor(@PathVariable final UUID id,
            @RequestBody @Valid final UserModel userModel) {
        log.debug("Entry:AuthorManagementController:updateAuthorManagement.");
        InstructionsListModel instrumentsModel = authorManagementService.updateAuthor(id,
                userModel);
        log.debug("Entry:AuthorManagementController:updateAuthorManagement.");
        return instrumentsModel;
    }
}
