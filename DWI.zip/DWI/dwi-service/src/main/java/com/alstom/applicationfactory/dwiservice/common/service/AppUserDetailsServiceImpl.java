package com.alstom.applicationfactory.dwiservice.common.service;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.alstom.applicationfactory.dwiservice.common.model.AppUserDetails;
import com.alstom.applicationfactory.dwiservice.common.model.BasicSecurityUser;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class AppUserDetailsServiceImpl implements UserDetailsService {

    /**
     * Admin service feign client.
     */
    @Autowired
    private AdminServiceClient adminServiceClient;

    /**
     * Http servlet request.
     */
    @Autowired
    private HttpServletRequest request;

    /**
     * Application code.
     */
    private String applicationCode;

    /**
     * External application code. eg: actuator, qlikSense etc
     */
    private String externalApplicationCode;

    /**
     * Parameterized constructor.
     * 
     * @param appCode
     * @param extAppCode
     */
    public AppUserDetailsServiceImpl(final String appCode, final String extAppCode) {
        this.applicationCode = appCode;
        this.externalApplicationCode = extAppCode;
    }

    /**
     * Fetches the user details of the user.
     * 
     * @param username username of user
     * @return user details object
     * @throws UsernameNotFoundException
     */
    @Override
    public UserDetails loadUserByUsername(final String username) {
        BasicSecurityUser user = this.adminServiceClient.getAuthorizedUser(request.getHeader("Authorization"),
                this.applicationCode, this.externalApplicationCode, username);
        if (Objects.isNull(user)) {
            throw new UsernameNotFoundException("User not found");
        } else {
            return new AppUserDetails(user);
        }
    }
}
