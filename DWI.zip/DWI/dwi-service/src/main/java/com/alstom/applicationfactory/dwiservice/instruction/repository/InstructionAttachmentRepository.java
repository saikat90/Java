package com.alstom.applicationfactory.dwiservice.instruction.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionAttachment;

public interface InstructionAttachmentRepository
        extends JpaRepositoryImplementation<InstructionAttachment, UUID>,
        JpaSpecificationExecutor<InstructionAttachment> {

    /**
     * @param id
     * @return list of InstructionAttachment.
     */
    @Query(value = "select * from dwiattachments_documents dd where dd.set_of_dwiattachments_dwinstructions_id  = ?1", nativeQuery = true)
    List<InstructionAttachment> findByDWIInstructionsId(UUID id);
}
