package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Function;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.ProjectUserRole;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.FunctionRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProjectService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "projectService")
@Transactional
@Slf4j
public class ProjectServiceImpl implements ProjectService {

    /**
     * ProjectRepository.
     */
    @Autowired
    private ProjectRepository projectRepository;

    /**
     * WorkFlowTemplateRepository.
     */
    @Autowired
    private WorkFlowTemplateRepository wfTemplateRepository;

    /**
     * FunctionRepository.
     */
    @Autowired
    private FunctionRepository functionRepository;

    /**
     * @param projectBean
     * @return ProjectModel.
     */
    @Override
    public ProjectModel createProject(final ProjectModel projectBean) {
        log.debug("Entry:DwiProjectServiceImpl:createProject.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        ProjectModel projectCreatedBean = new ProjectModel();
        Project project = mapper.map(projectBean, Project.class);

        if (!Objects.isNull(projectBean.getProjectUserRoles())) {
            Project finalProject = project;
            List<ProjectUserRole> userRoleList = projectBean.getProjectUserRoles().stream()
                    .map(projectUserRoleModel -> {
                        ProjectUserRole userRole = mapper.map(projectUserRoleModel,
                                ProjectUserRole.class);
                        userRole.setProject(finalProject);
                        return userRole;
                    }).collect(Collectors.toList());
            project.setProjectUserRoles(userRoleList);
        }

        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("String", "projName",
                projectBean.getProjName(), "eq"));
        filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active", true));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        long count = this.projectRepository.count(requestModel.getFilterSpecification());

        if (count == 0) {
            project = projectRepository.save(project);
            projectCreatedBean = mapper.map(project, ProjectModel.class);
        } else {
            log.error("Record already exists for the project. Please update existing value.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.PROJECT_LABEL, Constants.RECORD_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:DwiProjectServiceImpl:createProject.");
        return projectCreatedBean;
    }

    /**
     * @param projectModel
     * @return ProjectModel.
     */
    @Override
    public ProjectModel updateProject(final ProjectModel projectModel) {
        log.debug("Entry:DwiProjectServiceImpl:UpdateProject.");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        ProjectModel projectBean = new ProjectModel();
        try {
            Project project = mapper.map(projectModel, Project.class);
            Project projectRecord = projectRepository.findById(projectModel.getId()).orElse(null);
            if (null != projectRecord) {
                if (!Objects.isNull(project.getProjectUserRoles())) {
                    project.getProjectUserRoles().forEach(userRole -> {
                        userRole.setProject(project);
                    });
                }
                Project projectResult = projectRepository.save(project);
                projectBean = mapper.map(projectResult, ProjectModel.class);
                log.debug("Leave:DwiProjectServiceImpl:UpdateProject.");
            } else {
                log.error("Record does not exists for the project.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.PROJECT_LABEL, Constants.RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return projectBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel("Project", "Unable to update Project");
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }

    }

    /**
     * @param request
     * @return searchProject.
     */
    @Override
    public Object searchProject(final RequestModel request) {
        log.debug("Entry:DwiProjectServiceImpl:SearchProject.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.projectRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(project -> mapper.map(project, ProjectModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.projectRepository.findAll(request.getFilterSpecification()).stream()
                    .map(project -> mapper.map(project, ProjectModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:DwiProjectServiceImpl:SearchProject.");
        return result;
    }

    /**
     * @param projectId
     * @return ProjectModel.
     */
    @Override
    public ProjectModel viewProject(final UUID projectId) {
        log.debug("Entry:DwiProjectServiceImpl:ViewProject.");
        Project project;
        ProjectModel projectBean = new ProjectModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            project = projectRepository.findById(projectId).orElse(null);
            if (null != project) {
                projectBean = mapper.map(project, ProjectModel.class);
                log.debug("Leave:DwiProjectServiceImpl:ViewProject.");
            }
            return projectBean;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.PROJECT_LABEL, Constants.VIEW_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param projectId
     */
    @Override
    public void deleteProjectById(final UUID projectId) {
        log.debug("Entry:DwiProjectServiceImpl:DeleteProject");
        try {
            projectRepository.deleteById(projectId);
            log.debug("Leave:DwiProjectServiceImpl:DeleteProject");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.PROJECT_LABEL, Constants.DELETE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }

    }

    /**
     * @param projectId
     * @param functionModel
     * @return ProjectModel.
     */
    @Override
    public ProjectModel addFunction(final UUID projectId, final FunctionModel functionModel) {
        log.debug("Entry:DwiProjectServiceImpl:addFunction.");
        Project project;
        ProjectModel projectBean = new ProjectModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            project = projectRepository.findById(projectId).orElse(null);
            if (null != project) {
                List<Function> projFunctions = project.getProjFunctions();
                Function function = mapper.map(functionModel, Function.class);
                projFunctions.add(function);
                project.setProjFunctions(projFunctions);
                Project projectResult = projectRepository.save(project);
                projectBean = mapper.map(projectResult, ProjectModel.class);
                log.debug("Leave:DwiProjectServiceImpl:addFunction.");
            }
            return projectBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.PROJECT_LABEL,
                    Constants.INTERNAL_ERROR_MSG);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param projectId
     * @param functionId
     * @return ProjectModel.
     */
    @Override
    public ProjectModel deleteFunction(final UUID projectId, final UUID functionId) {
        log.debug("Entry:DwiProjectServiceImpl:deleteFunction.");
        Project project;
        ProjectModel projectBean = new ProjectModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            project = projectRepository.findById(projectId).orElse(null);
            if (null != project) {
                List<Function> projFunctions = project.getProjFunctions();
                Function function = functionRepository.findById(functionId).orElse(null);
                projFunctions.remove(function);
                project.setProjFunctions(projFunctions);
                Project projectResult = projectRepository.save(project);
                projectBean = mapper.map(projectResult, ProjectModel.class);
                log.debug("Leave:DwiProjectServiceImpl:deleteFunction.");
            }
            return projectBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.PROJECT_LABEL, Constants.DELETE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param projectId
     * @return getUnassignedFunctions
     */
    @Override
    public Object getUnassignedFunctions(final UUID projectId) {
        log.debug("Entry:DwiProjectServiceImpl:GetUnassignedProjectFunctions.");
        List<Function> allFuncList = new ArrayList<>();
        Project project = projectRepository.findById(projectId).orElse(null);
        if (project != null) {
            List<Function> functionList = project.getProjFunctions();
            Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
            List<Map<String, Object>> filterConditions = new ArrayList<>();
            filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active", true));
            RequestModel requestModel = RequestMapper
                    .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
            allFuncList = functionRepository.findAll(requestModel.getFilterSpecification());
            allFuncList.removeAll(functionList);
            log.debug("Leave:DwiProjectServiceImpl:GetUnassignedProjectFunctions.");
        }
        return allFuncList;
    }

    /**
     * @return getUnassignedProjects
     */
    @Override
    public Object getUnassignedProjects() {
        log.debug("Entry:DwiProjectServiceImpl:GetUnassignedProjects.");
        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active", true));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        List<Project> allProjectList = this.projectRepository
                .findAll(requestModel.getFilterSpecification());
        List<WorkFlowTemplate> wfTemplateList = this.wfTemplateRepository.findAll();
        List<Project> wfTempProjectList = wfTemplateList.stream().map(wftemplate -> {
            Project project = wftemplate.getProject();
            return project;
        }).collect(Collectors.toList());
        allProjectList.removeAll(wfTempProjectList);
        log.debug("Leave:DwiProjectServiceImpl:GetUnassignedProjects.");
        return allProjectList;
    }

    /**
     * @param projectId
     * @return getAllFunctionsForProject
     */
    @Override
    public Object getAllFunctionsForProject(final UUID projectId) {
        log.debug("Entry:DwiProjectServiceImpl:GetAllFunctionsForProject.");
        List<Function> functionList = new ArrayList<>();
        Project project = projectRepository.findById(projectId).orElse(null);
        if (project != null) {
            functionList = project.getProjFunctions();
            log.debug("Entry:DwiProjectServiceImpl:GetAllFunctionsForProject.");
        }
        return functionList;
    }
}
