package com.alstom.applicationfactory.dwiservice.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.alstom.applicationfactory.dwiservice.masterdata.model.EmailModel;

@FeignClient("mail-service")
public interface EmailServiceClient {
    /**
     * @param email
     */
    @PostMapping("/email/send")
    void sendMail(@RequestBody EmailModel email);
}
