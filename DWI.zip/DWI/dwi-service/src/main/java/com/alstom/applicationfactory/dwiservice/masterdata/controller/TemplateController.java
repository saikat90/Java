package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.TemplateService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/template")
@Slf4j
public class TemplateController {

    /**
     * TemplateService.
     */
    @Autowired
    private TemplateService templateService;

    /**
     * @param request
     * @return list of all templates.
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getAllTemplates(@RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:TemplateController:getAllTemplates.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        // filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active",
        // true));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object checkLists = templateService.searchTemplate(requestModel);
        log.debug("Leave:TemplateController:getAllTemplates.");
        return checkLists;
    }

    /**
     * @param request
     * @return templates.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchTemplates(@RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:TemplateController:searchTemplates.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        // filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active",
        // true));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object checkLists = templateService.searchTemplate(requestModel);
        log.debug("Leave:TemplateController:searchTemplates.");
        return checkLists;
    }

    /**
     * @param templateModel
     * @param authentication
     * @return TemplateModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public TemplateModel createTemplateModel(@RequestBody @Valid final TemplateModel templateModel,
            final Authentication authentication) {
        log.debug("Entry:TemplateController:createTemplateModel.");
        TemplateModel createdTemplateModel = new TemplateModel();
        createdTemplateModel = templateService.saveTemplate(templateModel);
        log.debug("Leave:TemplateController:createTemplateModel.");
        return createdTemplateModel;
    }

    /**
     * @param templateModel
     * @param authentication
     * @return TemplateModel
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public TemplateModel updateTemplate(@RequestBody @Valid final TemplateModel templateModel,
            final Authentication authentication) {
        log.debug("Entry:TemplateController:updateTemplate.");
        TemplateModel updatedTemplateModel = new TemplateModel();
        updatedTemplateModel = templateService.updateTemplate(templateModel);
        log.debug("Leave:TemplateController:updateTemplate.");
        return updatedTemplateModel;
    }

    /**
     * @param id
     * @param authentication
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteTemplate(@PathVariable final UUID id, final Authentication authentication) {
        log.debug("Entry:TemplateController:deleteTemplate.");
        templateService.deleteTemplate(id);
        log.debug("Leave:TemplateController:deleteTemplate.");
    }

    /**
     * @param projectId
     * @param request
     * @return list of all templates for a project.
     */
    @PostMapping("/{projectId}/list")
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public Object getAllTemplateForProject(@PathVariable("projectId") final UUID projectId,
            @RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:TemplateController:getAllTemplateForProject.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "project.id", projectId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object res = this.templateService.searchTemplate(requestModel);
        log.debug("Leave:TemplateController:getAllTemplateForProject.");
        return res;
    }
}
