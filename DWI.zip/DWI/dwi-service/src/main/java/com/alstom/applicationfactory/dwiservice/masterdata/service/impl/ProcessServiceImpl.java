package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProcessRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProcessService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "processService")
@Transactional
@Slf4j
public class ProcessServiceImpl implements ProcessService {

    /**
     * ProcessRepository.
     */
    @Autowired
    private ProcessRepository processRepository;

    /**
     * @param processBean
     * @return ProcessModel.
     */
    @Override
    public ProcessModel createProcess(final ProcessModel processBean) {
        log.debug("Entry:DwiProcessServiceImpl:createProcess.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        ProcessModel createdProcessModel = new ProcessModel();

        if (processBean.getFleet() == null) {
            log.error("Fleet is mandatory.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.PROCESS_LABEL, Constants.SELECT_FLEET_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        Process process = mapper.map(processBean, Process.class);

        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("String", "processName",
                processBean.getProcessName(), "eq"));
        filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active", true));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        long count = this.processRepository.count(requestModel.getFilterSpecification());

        if (count == 0) {
            process = processRepository.save(process);
            createdProcessModel = mapper.map(process, ProcessModel.class);
        } else {
            log.error("Record already exists for the process. Please update existing value.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.PROCESS_LABEL, Constants.RECORD_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:DwiProcessServiceImpl:createProcess.");
        return createdProcessModel;
    }

    /**
     * @param processModel
     * @return ProcessModel.
     */
    @Override
    public ProcessModel updateProcess(final ProcessModel processModel) {
        log.debug("Entry:DwiProcessServiceImpl:updateProcess.");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        ProcessModel processBean = new ProcessModel();
        try {
            if (processModel.getFleet() == null) {
                log.error("Fleet is mandatory.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.PROCESS_LABEL, Constants.SELECT_FLEET_ERROR));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            Process process = mapper.map(processModel, Process.class);
            Process processRecord = processRepository.findById(processModel.getId()).orElse(null);
            if (null != processRecord) {
                Process processResult = processRepository.save(process);
                processBean = mapper.map(processResult, ProcessModel.class);
                log.debug("Leave:DwiProcessServiceImpl:updateProcess.");
            } else {
                log.error("Record does not exists for the process.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.PROCESS_LABEL, Constants.RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return processBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.PROCESS_LABEL, Constants.UPDATE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param request
     * @return searchProcess.
     */
    @Override
    public Object searchProcess(final RequestModel request) {
        log.debug("Entry:DwiProcessServiceImpl:searchProcess.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.processRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(process -> mapper.map(process, ProcessModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.processRepository.findAll(request.getFilterSpecification()).stream()
                    .map(process -> mapper.map(process, ProcessModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:DwiProcessServiceImpl:searchProcess.");
        return result;
    }

    /**
     * @param processId
     * @return ProcessModel.
     */
    @Override
    public ProcessModel viewProcess(final UUID processId) {
        log.debug("Entry:DwiProcessServiceImpl:viewProcess");
        Process process;
        ProcessModel processBean = new ProcessModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            process = processRepository.findById(processId).orElse(null);
            if (null != process) {
                processBean = mapper.map(process, ProcessModel.class);
                log.debug("Leave:DwiProcessServiceImpl:viewProcess.");
            }
            return processBean;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.PROCESS_LABEL, Constants.VIEW_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param processId
     */
    @Override
    public void deleteProcessById(final UUID processId) {
        log.debug("Entry:DwiProcessServiceImpl:deleteProcess.");
        try {
            processRepository.deleteById(processId);
            log.debug("Leave:DwiProcessServiceImpl:deleteProcess.");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.PROCESS_LABEL, Constants.DELETE_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }
}
