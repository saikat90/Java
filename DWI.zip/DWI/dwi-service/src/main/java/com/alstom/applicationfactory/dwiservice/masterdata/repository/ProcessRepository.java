package com.alstom.applicationfactory.dwiservice.masterdata.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;

@Repository
public interface ProcessRepository
        extends JpaRepository<Process, UUID>, JpaSpecificationExecutor<Process> {
    /**
     * @param name
     * @return list of process by name
     */
    List<Process> findByProcessName(String name);

    /**
     * @param name
     * @param id
     * @return list of process by name & fleet id.
     */
    List<Process> findByProcessNameAndFleetId(String name, UUID id);
}
