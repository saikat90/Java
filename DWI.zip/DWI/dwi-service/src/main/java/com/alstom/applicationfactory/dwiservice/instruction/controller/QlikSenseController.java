package com.alstom.applicationfactory.dwiservice.instruction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.instruction.service.QliksenseService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/qliksense")
@Slf4j
public class QlikSenseController {

    /**
     * QliksenseService.
     */
    @Autowired
    private QliksenseService qliksenseService;

    /**
     * @return InstructionsQliksenseModel for Qlik KPI.
     */
    @GetMapping("/instructions/kpi")
    public Object findAll() {
        log.debug("Entry:qliksenseController:findAll.");
        Object result = qliksenseService.findAll();
        log.debug("Entry:qliksenseController:findAll.");
        return result;
    }

}
