package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import javax.validation.Valid;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsListModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;

public interface AuthorManagementService {

    /**
     * @param requestModel
     * @return searchAuthorManagement.
     */
    Object searchAuthorManagement(RequestModel requestModel);

    /**
     * @param instructionModel
     * @return InstructionsModel.
     */
    InstructionsModel updateAuthorManagement(InstructionsModel instructionModel);

    /**
     * @param id
     * @param userModel
     * @return InstructionsListModel.
     */
    InstructionsListModel updateAuthor(UUID id, @Valid UserModel userModel);
}
