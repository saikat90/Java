package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectUserRoleModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProjectUserRoleService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/projects/{projectId}/projectUserRoles")
@Slf4j
public class ProjectUserRoleController {

    /**
     * ProjectUserRoleService.
     */
    @Autowired
    private ProjectUserRoleService projectUserRoleService;

    /**
     * @param projId
     * @param userRoleMap
     * @return list of project user role model.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Map<String, List<ProjectUserRoleModel>> userRoleActions(
            @PathVariable("projectId") final UUID projId,
            @RequestBody @Valid final Map<String, List<ProjectUserRoleModel>> userRoleMap) {
        log.debug("Entry:DwiProjectUserRoleController:userRoleActions.");
        Map<String, List<ProjectUserRoleModel>> res = projectUserRoleService.userRoleActions(projId,
                userRoleMap);
        log.debug("Leave:DwiProjectUserRoleController:userRoleActions.");
        return res;
    }

    /**
     * @param projectId
     * @param request
     * @return searched project roles.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchProjectUserRoles(@PathVariable("projectId") final UUID projectId,
            @RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:DwiProjectUserRoleController:searchProjectUserRoles.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "project.id", projectId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object res = projectUserRoleService.searchProjectUserRoles(projectId, requestModel);
        log.debug("Leave:DwiProjectUserRoleController:searchProjectUserRoles.");
        return res;
    }

    /**
     * @param projId
     * @param role
     * @return list of user model.
     */
    @PostMapping("/usersList")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public List<UserModel> getUsersForRole(@PathVariable("projectId") final UUID projId,
            @RequestParam final String role) {
        log.debug("Entry:DwiProjectUserRoleController:getUsersForRole.");
        List<UserModel> users = projectUserRoleService.getUsersForRole(projId, role);
        log.debug("Leave:DwiProjectUserRoleController:getUsersForRole.");
        return users;
    }

}
