package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.FleetService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/fleets")
@Slf4j
public class FleetController {

    /**
     * FleetService.
     */
    @Autowired
    private FleetService fleetService;

    /**
     * @param fleetModel
     * @return FleetModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public FleetModel createFleetModel(@RequestBody @Valid final FleetModel fleetModel) {
        log.debug("Entry:FleetController:createFleetModel.");
        FleetModel createdFleetModel = new FleetModel();
        createdFleetModel = fleetService.saveFleet(fleetModel);
        log.debug("Leave:FleetController:checkFleetModel.");
        return createdFleetModel;
    }

    /**
     * @param fleetModel
     * @return FleetModel.
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public FleetModel updateFleet(@RequestBody @Valid final FleetModel fleetModel) {
        log.debug("Entry:FleetController:updateFleet.");
        FleetModel updatedFleetModel = new FleetModel();
        updatedFleetModel = fleetService.updateFleet(fleetModel);
        log.debug("Leave:FleetController:updateFleet.");
        return updatedFleetModel;
    }

    /**
     * @param request
     * @return object searched fleet.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchFleet(@RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:FleetController:searchFleet.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object checkLists = fleetService.searchFleet(requestModel);
        log.debug("Leave:FleetController:searchFleet.");
        return checkLists;
    }

    /**
     * @param request
     * @return all fleets.
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getAllFleet(@RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:FleetController:getAllFleet.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        // filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active",
        // true));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object checkLists = fleetService.searchFleet(requestModel);
        log.debug("Leave:FleetController:getAllFleet.");
        return checkLists;
    }

    /**
     * @param id
     * @return FleetModel.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public FleetModel viewFleet(@PathVariable("id") final UUID id) {
        log.debug("Entry:FleetController:viewFleet.");
        FleetModel fleetModel = fleetService.viewFleet(id);
        log.debug("Leave:FleetController:viewCheckListTemplate.");
        return fleetModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteFleet(@PathVariable final UUID id) {
        log.debug("Entry:FleetController:deleteFleet.");
        fleetService.deleteFleet(id);
        log.debug("Leave:FleetController:deleteFleet.");
    }

    /**
     * @param projectId
     * @param request
     * @return all fleets for a project.
     */
    @PostMapping("/{projectId}/list")
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public Object getAllFleetForProject(@PathVariable("projectId") final UUID projectId,
            @RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:DwiFleetController:getAllFleetForProject.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "project.id", projectId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object res = this.fleetService.searchFleet(requestModel);
        log.debug("Leave:DwiFleetController:getAllFleetForProject.");
        return res;
    }
}
