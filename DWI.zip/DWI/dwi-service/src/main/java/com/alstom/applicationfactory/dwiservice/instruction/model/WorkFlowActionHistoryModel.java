package com.alstom.applicationfactory.dwiservice.instruction.model;

import java.util.Date;
import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkFlowActionHistoryModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    private Date wfhActionDate;

    /**
     */
    private String wfhdepartment;

    /**
     */
    private UserModel wfhUser;

    /**
     */
    private String wfhUserName;

    /**
     */
    private String wfhOperation;

    /**
     */
    private String wfhUserComments;

    /**
     */
    @JsonIgnore
    private InstructionsModel wfhInstructions;

    /**
     */
    private Integer wfhActionSeq;

    /**
     */
    private InstructionAttachmentModel instructionAttachment;

}
