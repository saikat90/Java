package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.zip.Deflater;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.instruction.entity.RTEMedia;
import com.alstom.applicationfactory.dwiservice.instruction.model.RTEMediaModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.RTEMediaRepository;
import com.alstom.applicationfactory.dwiservice.instruction.service.RTEMediaService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "rtmMediaService")
@Transactional
@Slf4j
@RefreshScope
public class RTEMediaServiceImpl implements RTEMediaService {

    /**
     * RTEMediaRepository.
     */
    @Autowired
    private RTEMediaRepository rteMediaRepository;

    /**
     * @param id
     * @return RTEMediaModel.
     */
    @Override
    public RTEMediaModel getImage(final UUID id) {

        log.debug("Entry:RTEMediaServiceImpl:getImage.");
        RTEMedia rteMedia;
        RTEMediaModel rteModel = new RTEMediaModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            rteMedia = rteMediaRepository.findById(id).orElse(null);
            if (null != rteMedia) {
                rteModel = mapper.map(rteMedia, RTEMediaModel.class);
                log.debug("Leave:RTEMediaServiceImpl:getImage");
            }

            return rteModel;

        } catch (Exception e) {
            log.error("Error while fetching RTE media Image.");
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL, Constants.RTEMEDIA_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }

    }

    /**
     * @param file
     * @return RTEMediaModel.
     */
    @Override
    public RTEMediaModel uploadImage(final MultipartFile file) {
        log.debug("Entry:RTEMediaServiceImpl:uploadImage.");
        // Duplication check of image is Done
        List<ErrorModel> errors = new ArrayList<>();
        RTEMediaModel rteMediaModel = new RTEMediaModel();

        try {
            log.debug("Original Image Byte Size - " + file.getBytes().length);

            Deflater deflater = new Deflater();
            deflater.setInput(file.getBytes());
            deflater.finish();
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream(file.getBytes().length);
            byte[] buffer = new byte[Constants.BYTE_1024];
            while (!deflater.finished()) {
                int count = deflater.deflate(buffer);
                outputStream.write(buffer, 0, count);
            }
            outputStream.close();

            log.debug("Compressed Image Byte Size - " + outputStream.toByteArray().length);

            rteMediaModel.setContent(file.getBytes());
            rteMediaModel.setVersion(0);
            rteMediaModel.setName(file.getResource().getFilename());

            ModelMapper mapper = new ModelMapper();
            mapper.getConfiguration().setSkipNullEnabled(true)
                    .setPropertyCondition(Conditions.isNotNull());

            RTEMedia rteMedia = mapper.map(rteMediaModel, RTEMedia.class);

            RTEMedia rteMediaObj = this.rteMediaRepository.save(rteMedia);
            rteMediaModel = mapper.map(rteMediaObj, RTEMediaModel.class);

        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
            errors.add(new ErrorModel(Constants.ERROR_LABEL, Constants.RTEMEDIA_SAVE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        log.debug("Leave:RTEMediaServiceImpl:uploadImage.");
        return rteMediaModel;

    }

    /**
     * @param id
     */
    @Override
    public void deleteImageById(final UUID id) {
        log.debug("Entry:RTEMediaServiceImpl:deleteImage.");
        try {
            this.rteMediaRepository.deleteById(id);
            log.debug("Leave:RTEMediaServiceImpl:deleteImage.");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL,
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }
}
