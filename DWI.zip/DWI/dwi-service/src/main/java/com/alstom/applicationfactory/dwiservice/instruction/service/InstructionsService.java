package com.alstom.applicationfactory.dwiservice.instruction.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;

public interface InstructionsService {

    /**
     * @param requestModel
     * @return objects of Instructions.
     */
    Object searchInstructions(RequestModel requestModel);

    /**
     * @param id
     * @return InstructionsModel.
     */
    InstructionsModel viewInstruction(UUID id);

    /**
     * @param id
     */
    void deleteInstructionById(UUID id);

    /**
     * instructionAutoReminder.
     */
    void instructionAutoReminder();

    /**
     * @param id
     * @param comment
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel validateInstruction(UUID id, String comment, String email);

    /**
     * @param id
     * @param comment
     * @param dwiStaticLink
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel approveInstruction(UUID id, String comment, String dwiStaticLink,
            String email);

    /**
     * @param id
     * @param comment
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel rejectInstruction(UUID id, String comment, String email);

    /**
     * @param instructionModel
     * @param editionControlComment
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel saveasDraftInstruction(InstructionsModel instructionModel,
            String editionControlComment, String email);

    /**
     * @param instructionModel
     * @param editionControlComment
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel submitInstruction(InstructionsModel instructionModel,
            String editionControlComment, String email);

    /**
     * @param id
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel createNewVersion(UUID id, String email);

    /**
     * @param id
     */
    void copyAttachment(UUID id);

    /**
     * @param id
     * @param instructionAttachmentModel
     * @param comment
     * @param email
     * @return InstructionsModel
     */
    InstructionsModel addComments(UUID id, InstructionAttachmentModel instructionAttachmentModel,
            String comment, String email);

    /**
     * @param id
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel viewPreviousVersion(UUID id, String email);

    /**
     * @param id
     */
    void archiveInstruction(UUID id);

    /**
     * @param id
     * @param comment
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel validateInstructionByAction(UUID id, String comment, String email);

    /**
     * @param id
     * @param comment
     * @param dwiStaticLink
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel approveInstructionByAction(UUID id, String comment, String dwiStaticLink,
            String email);

    /**
     * @param id
     * @param instructionAttachmentModel
     * @param email
     * @return InstructionsModel.
     */
    InstructionsModel addAttachment(UUID id, InstructionAttachmentModel instructionAttachmentModel,
            String email);

    /**
     * @param requestModel
     * @return objects of Instructions.
     */
    Object searchUserInstructions(RequestModel requestModel);
}
