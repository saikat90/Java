package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectUserRoleModel {

    /**
     */
    private UUID id;
    /**
     */
    @NotNull(message = "User is mandatory")
    private UserModel user;
    /**
     */
    @NotNull(message = "Role is mandatory for User")
    private String role;
    /**
     */
    @JsonIgnore
    private ProjectModel project;
}
