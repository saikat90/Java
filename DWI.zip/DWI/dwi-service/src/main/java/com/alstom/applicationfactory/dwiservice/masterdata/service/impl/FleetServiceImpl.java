package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.FleetRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.FleetService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "fleetService")
@Transactional
@Slf4j
public class FleetServiceImpl implements FleetService {

    /**
     * FleetRepository.
     */
    @Autowired
    private FleetRepository fleetRepository;

    /**
     * ProjectRepository.
     */
    @Autowired
    private ProjectRepository projectRepository;

    /**
     * @param request
     * @return
     */
    @Override
    public Object searchFleet(final RequestModel request) {
        log.debug("Entry:DwiFleetServiceImpl:searchFleet.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.fleetRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(
                    response.getContent().stream().map(fleet -> mapper.map(fleet, FleetModel.class))
                            .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.fleetRepository.findAll(request.getFilterSpecification()).stream()
                    .map(fleet -> mapper.map(fleet, FleetModel.class)).collect(Collectors.toList());
        }
        log.debug("Leave:DwiFleetServiceImpl:searchProcess.");
        return result;
    }

    /**
     * @param fleetId
     * @return
     */
    @Override
    public FleetModel viewFleet(final UUID fleetId) {
        log.debug("Entry:FleetServiceImpl:viewFleet.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        FleetModel fleetModel = null;
        try {
            Fleet fleet = fleetRepository.findById(fleetId).orElse(null);

            if (Objects.isNull(fleet)) {
                log.error("No fleet present.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.FLEET_LABEL, Constants.VIEW_ERROR));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            } else {
                fleetModel = mapper.map(fleet, FleetModel.class);
            }
        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.FLEET_LABEL, Constants.VIEW_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:FleetServiceImpl:viewFleet.");
        return fleetModel;
    }

    /**
     * @param fleetModel
     * @return
     */
    @Override
    public FleetModel saveFleet(final FleetModel fleetModel) {
        log.debug("Entry:saveFleetServiceImpl:saveFleet.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        List<ErrorModel> errors = new ArrayList<>();
        FleetModel createdFleetModel = new FleetModel();

        if (fleetModel.getProject() == null) {
            log.error("Project is mandatory.");
            errors.add(new ErrorModel(Constants.FLEET_LABEL, Constants.SELECT_PROJECT_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        List<Fleet> fleetList = getDuplicateFleet(fleetModel);
        if (!fleetList.isEmpty()) {
            Fleet fleet = fleetList.get(0);
            errors.add(new ErrorModel(Constants.FLEET_LABEL, Constants.RECORD_NOT_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        try {
            Fleet fleetObj = mapper.map(fleetModel, Fleet.class);
            Project proj = projectRepository.findById(fleetObj.getProject().getId()).orElse(null);
            fleetObj.setProject(proj);

            Fleet fleet = this.fleetRepository.save(fleetObj);
            createdFleetModel = mapper.map(fleet, FleetModel.class);
        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
            errors.add(new ErrorModel(Constants.FLEET_LABEL, Constants.UPDATE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:saveFleetServiceImpl:saveFleet.");
        return createdFleetModel;
    }

    /**
     * @param fleet
     * @return list of Fleet
     */
    private List<Fleet> getDuplicateFleet(final FleetModel fleet) {
        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("String", "fleetName",
                fleet.getFleetName(), "eq"));
        filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active", true));

        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        List<Fleet> templateList = fleetRepository.findAll(requestModel.getFilterSpecification());
        return templateList;
    }

    /**
     * @param fleetModel
     * @return FleetModel.
     */
    @Override
    public FleetModel updateFleet(final FleetModel fleetModel) {
        log.debug("Entry:FleetServiceImpl:updateFleet.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        FleetModel updatedFleetModel = new FleetModel();
        try {
            if (fleetModel.getProject() == null) {
                log.error("Project is mandatory.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.FLEET_LABEL, Constants.SELECT_PROJECT_ERROR));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }

            Fleet fleetRequest = mapper.map(fleetModel, Fleet.class);

            if (null != fleetRequest) {
                Fleet template = this.fleetRepository.save(fleetRequest);
                updatedFleetModel = mapper.map(template, FleetModel.class);
            }

        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
            ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL, Constants.UPDATE_ERROR);
            List<ErrorModel> errorModelList = new ArrayList<>();
            errorModelList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorModelList);
        }
        log.debug("Leave:FleetServiceImpl:updateFleet.");
        return updatedFleetModel;
    }

    /**
     * @param id
     */
    @Override
    public void deleteFleet(final UUID id) {
        log.debug("Entry:FleetServiceImpl:deleteFleet.");
        try {
            Fleet fleet = fleetRepository.findById(id).orElse(null);
            if (Objects.isNull(fleet)) {
                log.error("No fleet present.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.FLEET_LABEL, Constants.RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            } else {
                fleetRepository.delete(fleet);
            }
        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.FLEET_LABEL, Constants.DELETE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:FleetServiceImpl:deleteFleet.");
    }
}
