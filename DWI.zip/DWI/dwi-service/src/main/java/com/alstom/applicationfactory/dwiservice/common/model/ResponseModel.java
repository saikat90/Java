package com.alstom.applicationfactory.dwiservice.common.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseModel {

    /**
     * ResponseModel - page number.
     */
    private int pageNumber;
    /**
     * ResponseModel - pageSize - total number of records to be displaye in single.
     * page
     */
    private int pageSize;
    /**
     * ResponseModel - returns total records.
     */
    private long totalElements;
    /**
     * ResponseModel - returns total number of pages as per page size.
     */
    private int totalPages;
    /**
     * ResponseModel - returns the content.
     */
    private List<Object> content = new ArrayList<>();

}
