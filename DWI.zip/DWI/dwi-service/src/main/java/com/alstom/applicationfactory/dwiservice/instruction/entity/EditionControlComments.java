package com.alstom.applicationfactory.dwiservice.instruction.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "dwiedition_control_comments")
public class EditionControlComments {

    /**
     * Edition control primary key.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     * Edition control version.
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     * Referenced Instruction for Edition Control.
     */
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(referencedColumnName = "id", name = "dwi_form_id")
    private Instructions instructions;

    /**
     * Edition control - dwi number.
     */
    @Column(name = "dwi_number", length = Constants.FIFTY)
    private String dwiNumber;

    /**
     * Edition control - dwi edition.
     */
    private Integer dwiEdition;

    /**
     * Referenced user for Edition Control.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_author_id")
    private User user;

    /**
     * Edition control - used for storing created / submitted date.
     */
    @Column(name = "dwi_submitted_date")
    private Date submittedDate;

    /**
     * Edition control - comments entered.
     */
    @Column(length = Constants.FIVE_HUNDERD)
    private String comments;
}
