package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.instruction.service.FileManagerService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "fileManager")
@Transactional
@Slf4j
@RefreshScope
public class FileManagerServiceImpl implements FileManagerService {

    /**
     * file path for storing attachments.
     */
    @Value("${dwi.attachment.filemanager.path}")
    private String filePath;

    /**
     * @param imageSource
     * @return array of bytes of image.
     */
    @Override
    public byte[] getImage(final String imageSource) {
        File file;
        Path downloadPath = Paths.get(filePath + imageSource);
        file = new File(downloadPath.toUri());
        byte[] fileInBytes = readFileToByteArray(file);
        return fileInBytes;
    }

    /**
     * @param file
     * @return array of bytes.
     */
    private static byte[] readFileToByteArray(final File file) {
        FileInputStream fis = null;
        // Creating a byte array using the length of the file
        // file.length returns long which is cast to int
        byte[] bArray = new byte[(int) file.length()];
        try {
            fis = new FileInputStream(file);
            int count = fis.read(bArray);
        } catch (IOException e) {
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.ERROR_LABEL, Constants.ATTACHMENT_READ_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errors);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    log.error("Error while reading file.");
                }
            }
        }
        return bArray;
    }
}
