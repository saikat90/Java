package com.alstom.applicationfactory.dwiservice.instruction.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionWorkFlowDetails;

@Repository
public interface InstructionWorkFlowDetailsRepository
        extends JpaRepositoryImplementation<InstructionWorkFlowDetails, UUID> {

    /**
     * @param id
     * @return list of InstructionWorkFlowDetails
     */
    List<InstructionWorkFlowDetails> findByInstructionsId(UUID id);

    /**
     * @param id
     */
    void deleteByInstructionsId(UUID id);

}
