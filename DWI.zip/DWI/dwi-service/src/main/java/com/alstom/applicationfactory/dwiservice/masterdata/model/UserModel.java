package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserModel {

    /**
     */
    private UUID id;

    /**
     */
    @Size(min = 1, max = Constants.THIRTY, message = "Employee ID should be 1-30 characters")
    @NotNull(message = "Employee ID should not be empty")
    private String employeeId;

    /**
     */
    @Size(min = 1, max = Constants.FIFTY, message = "First Name should be 1-50 characters")
    @NotNull(message = "First Name should not be empty")
    private String firstName;

    /**
     */
    @Size(min = 1, max = Constants.FIFTY, message = "Last Name should be 1-50 characters")
    @NotNull(message = "Last Name should not be empty")
    private String lastName;

    /**
     */
    @Size(min = 1, max = Constants.HUNDRED, message = "Email should be 1-100 characters")
    @NotNull(message = "Email should not be empty")
    private String email;

    /**
     */
    @Size(min = 1, max = Constants.FIFTY, message = "Department should be 1-50 characters")
    @NotNull(message = "Department should not be empty")
    private String department;

}
