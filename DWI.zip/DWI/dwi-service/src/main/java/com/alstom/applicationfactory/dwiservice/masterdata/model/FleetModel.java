package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FleetModel {

    /**
     */
    private UUID id;
    /**
     */
    private Integer version;
    /**
     */
    @NotNull(message = "Fleet name should not be empty")
    private String fleetName;
    /**
     */
    @NotNull(message = "Project name should not be empty")
    private ProjectModel project;
    /**
     */
    private boolean active;
    /**
     */
    private Date createdDate;
    /**
     */
    private Date modifiedDate;
    /**
     */
    private String createdBy;
    /**
     */
    private String modifiedBy;

}
