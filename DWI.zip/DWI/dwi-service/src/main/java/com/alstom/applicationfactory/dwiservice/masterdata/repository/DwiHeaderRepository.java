package com.alstom.applicationfactory.dwiservice.masterdata.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.DwiHeader;;

@Repository
public interface DwiHeaderRepository
        extends JpaRepositoryImplementation<DwiHeader, UUID>, JpaSpecificationExecutor<DwiHeader> {
    /**
     * @param id
     * @return list of DwiHeader.
     */
    List<DwiHeader> findByProjectId(UUID id);
}
