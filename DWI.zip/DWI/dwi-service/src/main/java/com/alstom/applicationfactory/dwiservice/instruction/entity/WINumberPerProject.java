package com.alstom.applicationfactory.dwiservice.instruction.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "dwigenerate_winumber_based_project")
public class WINumberPerProject {

    /**
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     */
    @Column(name = "generated_winumber", length = Constants.TEN)
    private String generatedNumber;

    /**
     */
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(referencedColumnName = "id", name = "dwi_project_id")
    private Project project;

}
