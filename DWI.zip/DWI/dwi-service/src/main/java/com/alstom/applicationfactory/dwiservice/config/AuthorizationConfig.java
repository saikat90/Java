package com.alstom.applicationfactory.dwiservice.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@RefreshScope
@Configuration
@Data
public class AuthorizationConfig {
    /**
     * Email property code used for application factory.
     */
    @Value("${application.factory.jwt.emailProp}")
    private String emailProp;
    /**
     * Authorities property code used for application factory.
     */
    @Value("${application.factory.jwt.authoritiesProp}")
    private String authoritiesProp;
    /**
     * Token type property code used for application factory.
     */
    @Value("${application.factory.jwt.tokenType}")
    private String tokenType;
}
