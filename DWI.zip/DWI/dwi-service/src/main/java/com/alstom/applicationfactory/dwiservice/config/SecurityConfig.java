package com.alstom.applicationfactory.dwiservice.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.service.AppUserDetailsServiceImpl;

import lombok.extern.slf4j.Slf4j;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
@Slf4j
public class SecurityConfig {
    @Configuration
    @Order(Constants.ACTUATOR_ORDER)
    public static class ActuatorSecurityConfig extends WebSecurityConfigurerAdapter {

        /**
         * Password encoder.
         */
        @Autowired
        private PasswordEncoder passwordEncoder;

        /**
         * Actuator application code.
         */
        @Value("${application.factory.external.application.actuator}")
        private String actuatorAppCode;

        /**
         * Application Code.
         */
        @Value("${application.code}")
        private String appCode;

        /**
         * Configures http security for actuator end points.
         * 
         * @param http HttpSecurity object
         * @throws Exception exception
         */
        @Override
        protected void configure(final HttpSecurity http) throws Exception {
            http.headers().contentTypeOptions().and().xssProtection().and().cacheControl().and()
                    .httpStrictTransportSecurity().and().frameOptions().and()
                    .contentSecurityPolicy(Constants.CONTENT_SECURITY_POLICY);

            http.csrf().disable().antMatcher(Constants.ACTUATOR_ENPOINTS)
                    .authorizeRequests(r -> r.anyRequest().authenticated()).httpBasic(Customizer.withDefaults())
                    .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        }

        /**
         * Configure authentication manager with user details service and the password
         * encoder for actuator end points.
         *
         * @param auth Authentication manager builder for configuration.
         * @throws Exception exception
         */
        @Override
        protected void configure(final AuthenticationManagerBuilder auth) throws Exception {
            auth.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder);
        }

        /**
         * User details service for application code and actuator.
         *
         * @return User details service
         */
        @Override
        @Bean
        public UserDetailsService userDetailsService() {
            return new AppUserDetailsServiceImpl(appCode, actuatorAppCode);
        }

    }

    @Configuration
    @Order(Constants.QLIK_SENSE_ORDER)
    public static class QlikSenseSecurityConfig extends WebSecurityConfigurerAdapter {

        /**
         * Password Encoder.
         */
        @Autowired
        private PasswordEncoder passwordEncoder;
        /**
         * QlikSense application code.
         */
        @Value("${application.factory.external.application.qlikSense}")
        private String qlikSenseAppCode;
        /**
         * Application code.
         */
        @Value("${application.code}")
        private String appCode;

        /**
         * Configures http security for QlikSense end points.
         *
         * @param http HttpSecurity object
         * @throws Exception exception
         */
        @Override
        protected void configure(final HttpSecurity http) throws Exception {
            http.headers().contentTypeOptions().and().xssProtection().and().cacheControl().and()
                    .httpStrictTransportSecurity().and().frameOptions().and()
                    .contentSecurityPolicy(Constants.CONTENT_SECURITY_POLICY);

            http.csrf().disable().antMatcher(Constants.QLIK_SENSE_ENPOINTS)
                    .authorizeRequests(r -> r.anyRequest().authenticated()).httpBasic(Customizer.withDefaults())
                    .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        }

        /**
         * Configure authentication manager with user details service and the password
         * encoder for QlikSense end points.
         *
         * @param auth Authentication manager builder for configuration.
         * @throws Exception exception
         */
        @Override
        protected void configure(final AuthenticationManagerBuilder auth) throws Exception {
            auth.userDetailsService(qlickUserDetailsService()).passwordEncoder(passwordEncoder);
        }

        /**
         * User details service for application code and QlikSense.
         *
         * @return User details service
         */
        @Bean
        public UserDetailsService qlickUserDetailsService() {
            return new AppUserDetailsServiceImpl(appCode, qlikSenseAppCode);
        }

    }

    @Configuration
    @Order(Constants.IMAGE_ORDER)
    public static class ImageSecurityConfig extends WebSecurityConfigurerAdapter {

        /**
         * Configures http security for rte media end points.
         *
         * @param http HttpSecurity object
         * @throws Exception exception
         */
        @Override
        protected void configure(final HttpSecurity http) throws Exception {
            http.headers().contentTypeOptions().and().xssProtection().and().cacheControl().and()
                    .httpStrictTransportSecurity().and().frameOptions().and()
                    .contentSecurityPolicy(Constants.CONTENT_SECURITY_POLICY);

            http.csrf().disable().antMatcher(Constants.RTE_MEDIA_ENPOINTS)
                    .authorizeRequests(r -> r.anyRequest().permitAll()).sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        }

    }

    @Configuration
    @Order(Constants.API_ORDER)
    public static class ApiSecurityConfig extends WebSecurityConfigurerAdapter {

        /**
         * Custom Jwt authentication converter for getting granted authorities
         * information.
         */
        @Autowired
        private CustomJwtAuthenticationConverter customJwtAuthenticationConverter;

        /**
         * Configures http security for api end points.
         *
         * @param http HttpSecurity object
         * @throws Exception Exception
         */
        @Override
        protected void configure(final HttpSecurity http) throws Exception {
            http.headers().contentTypeOptions().and().xssProtection().and().cacheControl().and()
                    .httpStrictTransportSecurity().and().frameOptions().and()
                    .contentSecurityPolicy(Constants.CONTENT_SECURITY_POLICY);

            http.authorizeRequests(r -> r.anyRequest().fullyAuthenticated()).sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().oauth2ResourceServer().jwt()
                    .jwtAuthenticationConverter(customJwtAuthenticationConverter);
        }

    }
}
