package com.alstom.applicationfactory.dwiservice.instruction.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.instruction.model.EditionControlCommentsModel;

public interface EditionControlCommentsService {

    /**
     * @param id
     * @return EditionControlCommentsModel.
     */
    EditionControlCommentsModel getEditionControlComments(UUID id);

}
