package com.alstom.applicationfactory.dwiservice.masterdata.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.ProjectUserRole;

@Repository
public interface ProjectUserRoleRepository
        extends JpaRepository<ProjectUserRole, UUID>, JpaSpecificationExecutor<ProjectUserRole> {

    /**
     * @param id
     * @param role
     * @return list of project user by role by project id.
     */
    List<ProjectUserRole> findByProjectIdAndRole(UUID id, String role);

    /**
     * @param id
     * @return list of project user by role by user id.
     */
    List<ProjectUserRole> findByUserId(UUID id);
}
