package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.Map;

public interface LdapService {
    /**
     * @param request
     * @return list of users.
     */
    Object findUsers(Map<String, String> request);
}
