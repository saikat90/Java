package com.alstom.applicationfactory.dwiservice.instruction.enums;

public enum SubStatus {
    /**
     * List of Sub Status.
     */
    NEW, NEW_VERSION
}
