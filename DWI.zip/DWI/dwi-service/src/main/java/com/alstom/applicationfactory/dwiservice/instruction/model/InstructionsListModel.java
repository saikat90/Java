package com.alstom.applicationfactory.dwiservice.instruction.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InstructionsListModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    private String dwiStatus;

    /**
     */
    @NotNull(message = "Dwi Number cannot be empty")
    private String dwiNumber;

    /**
     */
    private Integer dwiEdition;

    /**
     */
    private String dwiTitle;

    /**
     */
    private String dwiReference;

    /**
     */
    private ProjectModel project;

    /**
     */
    private ProcessModel process;

    /**
     */
    private RevisionModel revision;

    /**
     */
    private UserModel author;

    /**
     */
    private FleetModel fleet;

    /**
     */
    private String dwiStaticLink;

    /**
     */
    private Date createdDate;
}
