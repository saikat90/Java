package com.alstom.applicationfactory.dwiservice.instruction.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RTEMediaModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    private String name;

    /**
     */
    @NotNull(message = "Content is mandatory")
    private byte[] content;

}
