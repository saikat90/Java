package com.alstom.applicationfactory.dwiservice.listener;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;

@Configuration
public class KafkaTopicListener {

    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;
    /*
     * @Autowired private ProjectRepository projectRepository;
     */

    /**
     * @param records
     */
    @KafkaListener(topics = "user-list", groupId = "dwi-service")
    public void refreshUsers(List<Map> records) {
        this.userRepository.saveAll(records.stream()
                .map(record -> new User(UUID.fromString((String) record.get("id")),
                        (String) record.get("employeeId"), (String) record.get("firstName"),
                        (String) record.get("lastName"), (String) record.get("email"),
                        (String) record.get("department")))
                .collect(Collectors.toList()));
    }
}
