package com.alstom.applicationfactory.dwiservice.instruction.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionAttachmentService;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/instructionAttachment")
@Slf4j
public class InstructionAttachmentController {

    /**
     * InstructionAttachmentService.
     */
    @Autowired
    private InstructionAttachmentService instructionAttachmentService;

    /**
     * @param file
     * @param userEmail
     * @return InstructionAttachmentModel.
     */
    @PostMapping("/upload")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public InstructionAttachmentModel uploadAttachment(
            @RequestParam("file") final MultipartFile file,
            @RequestParam("userEmail") final String userEmail) {
        log.debug("Entry:InstructionAttachmentController:uploadAttachment.");
        InstructionAttachmentModel instructionAttachmentModel = instructionAttachmentService
                .uploadAttachment(file, userEmail);
        log.debug("Leave:InstructionAttachmentController:uploadAttachment.");
        return instructionAttachmentModel;
    }

    /**
     * @param instructionAttachmentId
     * @param response
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void downloadDwiAttachment(@PathVariable("id") final UUID instructionAttachmentId,
            final HttpServletResponse response) {
        log.debug("Entry:InstructionAttachmentController:deleteInstructionAttachment.");
        try {
            File file = instructionAttachmentService.downloadDwiAttachment(instructionAttachmentId);
            Path path = Paths.get(file.toURI());
            String mimeType = Files.probeContentType(path);

            response.setContentType(mimeType);
            response.setHeader("Content-Disposition",
                    "attachment;filename=\"" + file.getName() + "\"");
            response.getOutputStream()
                    .write(instructionAttachmentService.readFileToByteArray(file));
            response.getOutputStream().close();
        } catch (IOException e) {
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("File ", "Error in reading attachments"));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errors);
        }
        log.debug("Leave:InstructionAttachmentController:deleteInstructionAttachment.");
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteInstructionAttachmentById(@PathVariable("id") final UUID id) {
        log.debug("Entry:InstructionAttachmentController:deleteInstructionAttachment.");
        this.instructionAttachmentService.deleteInstructionAttachmentById(id);
        log.debug("Leave:InstructionAttachmentController:deleteInstructionAttachment.");
    }
}
