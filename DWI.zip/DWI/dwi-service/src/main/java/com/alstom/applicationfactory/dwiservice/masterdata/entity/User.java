package com.alstom.applicationfactory.dwiservice.masterdata.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "af_user")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class User implements Serializable {
    /**
     */
    @Id
    private UUID id;
    /**
     */
    @Column(nullable = false, length = Constants.THIRTY)
    private String employeeId;

    /**
     */
    @Column(nullable = false, length = Constants.FIFTY)
    private String firstName;

    /**
     */
    @Column(nullable = false, length = Constants.FIFTY)
    private String lastName;

    /**
     */
    @Column(nullable = false, length = Constants.HUNDRED)
    private String email;

    /**
     */
    @Column(nullable = false, length = Constants.FIFTY)
    private String department;
}
