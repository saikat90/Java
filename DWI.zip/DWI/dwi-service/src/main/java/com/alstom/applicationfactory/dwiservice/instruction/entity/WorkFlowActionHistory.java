package com.alstom.applicationfactory.dwiservice.instruction.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dwiwork_flow_action_history")
public class WorkFlowActionHistory {

    /**
     */
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    private UUID id;

    /**
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     */
    @Column(name = "dwi_wfaction_date")
    private Date wfhActionDate;

    /**
     */
    @Column(name = "dwi_wfdepartment", length = Constants.THIRTY_SIX)
    private String wfhdepartment;

    /**
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_wfuser_id")
    private User wfhUser;

    /**
     */
    @Column(name = "dwi_wfuser_name", length = Constants.TWO_HUNDRED)
    private String wfhUserName;

    /**
     */
    @Column(name = "dwi_wfoperation", length = Constants.THIRTY_SIX)
    private String wfhOperation;

    /**
     */
    @Column(name = "dwi_wfuser_comments", length = Constants.FIVE_HUNDERD)
    private String wfhUserComments;

    /**
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dw_instructions_id")
    private Instructions wfhInstructions;

    /**
     */
    @Column(name = "dwinstructions_dwi_work_flow_action_history_seq")
    private Integer wfhActionSeq;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_comments_image_id")
    private InstructionAttachment instructionAttachment;
}
