package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.FunctionRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.FunctionService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/function")
@Slf4j
public class FunctionController {

    /**
     * FunctionService.
     */
    @Autowired
    private FunctionService functionService;

    /**
     * FunctionRepository.
     */
    @Autowired
    private FunctionRepository functionRepository;

    /**
     * @param function
     * @return FunctionModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public FunctionModel createFunction(@RequestBody @Valid final FunctionModel function) {
        log.debug("Entry:DwiFunctionController:createFunction.");
        FunctionModel createdFunctionModel = functionService.createFunction(function);
        log.debug("Leave:DwiFunctionController:createFunction.");
        return createdFunctionModel;
    }

    /**
     * @param function
     * @return FunctionModel
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public FunctionModel updateFunction(@RequestBody @Valid final FunctionModel function) {
        log.debug("Entry:FunctionController:updateFunction.");
        FunctionModel updatedFunctionModel = functionService.updateFunction(function);
        log.debug("Leave:FunctionController:updateFunction.");
        return updatedFunctionModel;
    }

    /**
     * @param request
     * @return object of fucntion.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchFunction(@RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:DwiFunctionController:searchFunction.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = functionService.findAll(requestModel);
        log.debug("Leave:DwiFunctionController:searchFunction.");
        return res;
    }

    /**
     * @param id
     * @return FunctionModel.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public FunctionModel viewFunction(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiFunctionController:viewFunction.");
        FunctionModel functionModel = functionService.viewFunction(id);
        log.debug("Leave:DwiFunctionController:viewFunction.");
        return functionModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteFunctionById(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiFunctionController:deleteFunction.");
        this.functionService.deleteFunctionById(id);
        log.debug("Leave:DwiFunctionController:deleteFunction.");
    }

    /**
     * @return all functions.
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getAllFunction() {
        log.debug("Entry:DwiFunctionController:getAllFunction.");
        Object res = functionRepository.findAll();
        log.debug("Leave:DwiFunctionController:getAllFunction.");
        return res;
    }
}
