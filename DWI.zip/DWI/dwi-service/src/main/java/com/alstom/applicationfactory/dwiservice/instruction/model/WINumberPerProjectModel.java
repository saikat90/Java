package com.alstom.applicationfactory.dwiservice.instruction.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WINumberPerProjectModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    @NotNull(message = "DWI generated number should not be empty")
    private String generatedNumber;

    /**
     */
    @NotNull(message = "Project is mandatory")
    private ProjectModel project;

}
