package com.alstom.applicationfactory.dwiservice.instruction.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.instruction.entity.RTEMedia;

@Repository
public interface RTEMediaRepository extends JpaRepository<RTEMedia, UUID>, JpaSpecificationExecutor<RTEMedia> {

}
