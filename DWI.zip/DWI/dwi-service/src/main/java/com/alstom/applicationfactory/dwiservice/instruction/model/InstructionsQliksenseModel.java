package com.alstom.applicationfactory.dwiservice.instruction.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InstructionsQliksenseModel {

    /**
     */
    private String dwiNumber;
    /**
     */
    private Integer dwiEdition;
    /**
     */
    private Boolean approvedActiveEdition;
    /**
     */
    private String dwiReference;
    /**
     */
    private String dwiStatus;
    /**
     */
    private String dwiProjectName;
    /**
     */
    private String projectManager;
    /**
     */
    private String dwiAuthorFirstName;
    /**
     */
    private String dwiAuthorLastName;
    /**
     */
    private String dwiFleetName;
    /**
     */
    private String dwiProcessName;
    /**
     */
    private String dwiRevisionName;
    /**
     */
    private String userFirstName;
    /**
     */
    private String userLastName;
    /**
     */
    private String userRole;

}
