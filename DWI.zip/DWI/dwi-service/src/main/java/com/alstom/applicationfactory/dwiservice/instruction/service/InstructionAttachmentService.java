package com.alstom.applicationfactory.dwiservice.instruction.service;

import java.io.File;
import java.util.UUID;

import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;

public interface InstructionAttachmentService {

    /**
     * @param instructionAttachmentModel
     * @return InstructionAttachmentModel.
     */
    InstructionAttachmentModel createDwiAttachment(
            InstructionAttachmentModel instructionAttachmentModel);

    /**
     * @param instructionAttachmentId
     */
    void deleteInstructionAttachmentById(UUID instructionAttachmentId);

    /**
     * @param instructionAttachmentId
     * @return uploaded file.
     */
    File downloadDwiAttachment(UUID instructionAttachmentId);

    /**
     * @param file
     * @param userEmail
     * @return InstructionAttachmentModel.
     */
    InstructionAttachmentModel uploadAttachment(MultipartFile file, String userEmail);

    /**
     * @param instructionAttachmentId
     * @return InstructionAttachmentModel.
     */
    InstructionAttachmentModel viewInstructionAttachment(UUID instructionAttachmentId);

    /**
     * @param oldId
     * @param newId
     */
    void copyInstructionAttachmentById(UUID oldId, UUID newId);

    /**
     * @param file
     * @return array of bites
     */
    byte[] readFileToByteArray(File file);
}
