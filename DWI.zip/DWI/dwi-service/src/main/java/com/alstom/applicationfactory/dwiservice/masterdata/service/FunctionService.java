package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;

public interface FunctionService {

    /**
     * @param function
     * @return FunctionModel.
     */
    FunctionModel createFunction(FunctionModel function);

    /**
     * @param function
     * @return FunctionModel.
     */
    FunctionModel updateFunction(FunctionModel function);

    /**
     * @param requestModel
     * @return FunctionModel.
     */
    Object findAll(RequestModel requestModel);

    /**
     * @param functionId
     * @return FunctionModel.
     */
    FunctionModel viewFunction(UUID functionId);

    /**
     * @param functionId
     */
    void deleteFunctionById(UUID functionId);
}
