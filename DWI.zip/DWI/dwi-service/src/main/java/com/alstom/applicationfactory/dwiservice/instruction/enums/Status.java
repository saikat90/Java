package com.alstom.applicationfactory.dwiservice.instruction.enums;

public enum Status {
    /**
     * List of Status.
     */
    DRAFT, SUBMITTED, IMPORTED, VALIDATED, APPROVED, REJECTED, ARCHIVED, IMPORT_SUBMITTED
}
