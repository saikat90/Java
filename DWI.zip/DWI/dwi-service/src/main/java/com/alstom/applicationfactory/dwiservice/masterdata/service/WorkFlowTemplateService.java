package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;

public interface WorkFlowTemplateService {

    /**
     * @param workFlowTemplate
     * @return WorkFlowTemplateModel.
     */
    WorkFlowTemplateModel createWorkFlowTemplate(WorkFlowTemplateModel workFlowTemplate);

    /**
     * @param workFlowTemplate
     * @return WorkFlowTemplateModel.
     */
    WorkFlowTemplateModel updateWorkFlowTemplate(WorkFlowTemplateModel workFlowTemplate);

    /**
     * @param requestModel
     * @return searchWorkFlowTemplate.
     */
    Object searchWorkFlowTemplate(RequestModel requestModel);

    /**
     * @param workFlowTemplateId
     * @return WorkFlowTemplateModel.
     */
    WorkFlowTemplateModel viewWorkFlowTemplate(UUID workFlowTemplateId);

    /**
     * @param workFlowTemplateId
     */
    void deleteWorkFlowTemplateById(UUID workFlowTemplateId);
}
