package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.masterdata.model.NotificationSettingsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.NotificationSettingsService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/settings")
@Slf4j
public class NotificationSettingsController {

    /**
     * NotificationSettingsService.
     */
    @Autowired
    private NotificationSettingsService settingsService;

    /**
     * @return NotificationSettingsModel.
     */
    @GetMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public NotificationSettingsModel getSettings() {
        log.debug("Entry:NotificationSettingsController:getSettings.");
        NotificationSettingsModel settingsModel = this.settingsService.getSettings();
        log.debug("Leave:NotificationSettingsController:getSettings.");
        return settingsModel;
    }

    /**
     * @param settingsModel
     * @return NotificationSettingsModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public NotificationSettingsModel saveSettings(
            @RequestBody @Valid final NotificationSettingsModel settingsModel) {
        log.debug("Entry:NotificationSettingsController:saveSettings.");
        NotificationSettingsModel createdNotificationSettingsModel = new NotificationSettingsModel();
        createdNotificationSettingsModel = this.settingsService.saveSettings(settingsModel);
        log.debug("Leave:NotificationSettingsController:saveSettings.");
        return createdNotificationSettingsModel;
    }

    /**
     * @param settingsModel
     * @return NotificationSettingsModel.
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public NotificationSettingsModel updateSettings(
            @RequestBody @Valid final NotificationSettingsModel settingsModel) {
        log.debug("Entry:NotificationSettingsController:updateSettings.");
        NotificationSettingsModel updatedNotificationSettingsModel = new NotificationSettingsModel();
        updatedNotificationSettingsModel = this.settingsService.updateSettings(settingsModel);
        log.debug("Leave:NotificationSettingsController:updateSettings.");
        return updatedNotificationSettingsModel;
    }
}
