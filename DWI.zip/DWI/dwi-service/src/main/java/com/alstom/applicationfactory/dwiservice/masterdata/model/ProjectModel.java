package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectModel {

    /**
     */
    private UUID id;
    /**
     */
    private Integer version;
    /**
     */
    @NotNull(message = "Project name should not be empty")
    private String projName;
    /**
     */
    private UserModel projectManager;
    /**
     */
    private boolean active;
    /**
     */
    private Date createdDate;
    /**
     */
    private Date modifiedDate;
    /**
     */
    private String createdBy;
    /**
     */
    private String modifiedBy;
    /**
     */
    private List<FunctionModel> projFunctions;
    /**
     */
    private List<ProjectUserRoleModel> projectUserRoles;
}
