package com.alstom.applicationfactory.dwiservice.instruction.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.instruction.entity.EditionControlComments;

@Repository
public interface EditionControlCommentsRepository
        extends JpaRepositoryImplementation<EditionControlComments, UUID> {
    /**
     * @param id
     * @return list of EditionControlComments
     */
    List<EditionControlComments> findByInstructionsId(UUID id);

    /**
     * @param id
     */
    void deleteByInstructionsId(UUID id);

}
