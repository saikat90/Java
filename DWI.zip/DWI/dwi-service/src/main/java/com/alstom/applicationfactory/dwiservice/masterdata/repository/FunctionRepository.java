package com.alstom.applicationfactory.dwiservice.masterdata.repository;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.Function;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface FunctionRepository extends JpaRepository<Function, UUID>, JpaSpecificationExecutor<Function> {
}
