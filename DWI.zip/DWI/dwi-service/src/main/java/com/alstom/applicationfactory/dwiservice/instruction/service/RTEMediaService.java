package com.alstom.applicationfactory.dwiservice.instruction.service;

import java.util.UUID;

import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.instruction.model.RTEMediaModel;

public interface RTEMediaService {

    /**
     * @param id
     * @return RTEMediaModel.
     */
    RTEMediaModel getImage(UUID id);

    /**
     * @param file
     * @return RTEMediaModel.
     */
    RTEMediaModel uploadImage(MultipartFile file);

    /**
     * @param id
     */
    void deleteImageById(UUID id);
}
