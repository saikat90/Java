package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectUserRoleModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;

public interface ProjectUserRoleService {

    /**
     * @param projId
     * @param userRoleMap
     * @return list of ProjectUserRoleModel.
     */
    Map<String, List<ProjectUserRoleModel>> userRoleActions(UUID projId,
            @Valid Map<String, List<ProjectUserRoleModel>> userRoleMap);

    /**
     * @param projectId
     * @param requestModel
     * @return ProjectUserRole.
     */
    Object searchProjectUserRoles(UUID projectId, RequestModel requestModel);

    /**
     * @param projectId
     * @param role
     * @return list of UserModel.
     */
    List<UserModel> getUsersForRole(UUID projectId, String role);

    /**
     * @param email
     * @return list of UUID.
     */
    List<UUID> getProjectForUser(String email);

    /**
     * @param email
     * @return list of ProjectModel.
     */
    List<ProjectModel> getProjectModelForUser(String email);
}
