package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FunctionModel {

    /**
     */
    private UUID id;

    /**
     */
    @NotNull(message = "Version should not be empty")
    private Integer version;

    /**
     */
    @Size(min = Constants.ONE, max = Constants.HUNDRED, message = "Fuction Name should be 1-100 characters")
    @NotNull(message = "Fuction Name should not be empty")
    private String dwiFunctionName;

    /**
     */
    private boolean active;

    /**
     */
    private Date createdDate;

    /**
     */
    private Date modifiedDate;

    /**
     */
    private String createdBy;

    /**
     */
    private String updatedBy;

}
