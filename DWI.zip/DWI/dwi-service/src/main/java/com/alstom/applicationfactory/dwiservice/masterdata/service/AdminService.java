package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.List;
import java.util.Map;

import org.springframework.security.core.Authentication;

import com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProfileModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;

public interface AdminService {
    /**
     * @param code
     * @param authentication
     * @return ProfileModel.
     */
    ProfileModel getProfile(String code, Authentication authentication);

    /**
     * @param id
     * @param request
     * @return findEmailByApplicationId
     */
    Object findEmailByApplicationId(String id, Map<String, Object> request);

    /**
     * @param id
     * @param request
     * @return findRolesByApplicationId
     */
    Object findRolesByApplicationId(String id, Map<String, Object> request);

    /**
     * @param email
     * @return updateEmail.
     */
    Object updateEmail(Object email);

    /**
     * @param request
     * @return findAllUsers.
     */
    Object findAllUsers(Map<String, Object> request);

    /**
     * @param users
     * @return list of UserModel.
     */
    List<UserModel> saveAllUsers(List<UserModel> users);

    /**
     * @param applicationId
     * @param roleCode
     * @param request
     * @return findRoleUsers.
     */
    Object findRoleUsers(String applicationId, String roleCode, Map<String, Object> request);

    /**
     * @param id
     * @param request
     * @return findUnmappedApplicationRoleUsers
     */
    Object findUnmappedApplicationRoleUsers(String id, Map<String, Object> request);

    /**
     * @param appRoleId
     * @param request
     * @return findUsersByApplicationRole.
     */
    Object findUsersByApplicationRole(String appRoleId, Map<String, Object> request);

    /**
     * @param applicationRoleUsers
     * @return saveUsersForRole.
     */
    Object saveUsersForRole(Object applicationRoleUsers);

    /**
     * @param applicationRoleUsers
     * @return updateUsersForRole.
     */
    Object updateUsersForRole(Object applicationRoleUsers);

    /**
     * @param id
     * @return findById.
     */
    ApplicationModel findById(String id);

    /**
     * @param appId
     * @param applicationRoleUserId
     * @param request
     * @return getUnmappedRightsForApplicationRoleUser
     */
    Object getUnmappedRightsForApplicationRoleUser(String appId, String applicationRoleUserId,
            Map<String, Object> request);

    /**
     * @param appRoleUserId
     * @param request
     * @return listApplicationRoleUserRights.
     */
    Object listApplicationRoleUserRights(String appRoleUserId, Map<String, Object> request);

    /**
     * @param applicationRoleUserRightsModels
     * @return saveApplicationRoleRights.
     */
    Object saveApplicationRoleRights(Object applicationRoleUserRightsModels);

    /**
     * @param applicationRoleUserRightsModels
     * @return updateApplicationRoleRights
     */
    Object updateApplicationRoleRights(Object applicationRoleUserRightsModels);
}
