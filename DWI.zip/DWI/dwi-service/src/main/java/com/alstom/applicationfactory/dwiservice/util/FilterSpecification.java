package com.alstom.applicationfactory.dwiservice.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.EntityType;

import org.springframework.data.jpa.domain.Specification;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.FilterJoinsModel;
import com.alstom.applicationfactory.dwiservice.common.model.FilterModel;
import com.alstom.applicationfactory.dwiservice.common.model.JoinModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FilterSpecification<T> implements Specification<T> {

    /**
     * FilterJoinsModel.
     */
    private FilterJoinsModel filterJoins;

    /**
     * @param filterJoinsParam
     */
    public FilterSpecification(final FilterJoinsModel filterJoinsParam) {
        super();
        this.filterJoins = filterJoinsParam;
    }

    /**
     * joinMap.
     */
    private Map<String, Join> joinMap;

    /**
     * @param root
     * @param criteriaQuery
     * @param builder
     * @return Predicate.
     */
    @Override
    public Predicate toPredicate(final Root<T> root, final CriteriaQuery<?> criteriaQuery,
            final CriteriaBuilder builder) {
        List<JoinModel> joins = this.filterJoins.getJoins();
        joinMap = new HashMap<>();
        EntityType rootModel = root.getModel();
        if (Objects.nonNull(joins)) {
            for (JoinModel join : joins) {
                Join tableJoin = root.join(join.getObject().toString(),
                        JoinType.valueOf(join.getType()));
                if (Objects.nonNull(join.getFilter())) {
                    Predicate joinPredicate = this.getPredicates(join.getFilter(), tableJoin,
                            builder);
                    tableJoin.on(joinPredicate);
                }
                joinMap.put(join.getObject(), tableJoin);
            }
        }
        return Objects.nonNull(this.filterJoins.getFilter())
                ? this.getPredicates(this.filterJoins.getFilter(), root, builder)
                : null;
    }

    /**
     * @param filterModel
     * @param root
     * @param builder
     * @return Predicate.
     */
    Predicate getPredicates(final FilterModel filterModel, final Path root,
            final CriteriaBuilder builder) {
        List<Predicate> predicates = filterModel.getFilterConditions().stream().map(filter -> {
            if (Objects.nonNull(filter.getFilter())) {
                return getPredicates(filter.getFilter(), root, builder);
            } else {
                Predicate predicate = null;
                String[] props = filter.getField().split("\\.");
                Class rootJavaType = null;
                Class propJavaType = null;
                Path rootPath = null;
                Path<?> path = null;
                try {
                    for (String prop : props) {
                        if (Objects.isNull(rootJavaType)) {
                            if (root.get(prop).getJavaType().getSimpleName().equalsIgnoreCase("set")
                                    || root.get(prop).getJavaType().getSimpleName()
                                            .equalsIgnoreCase("list")) {
                                rootPath = joinMap.get(prop);
                                if (Objects.isNull(rootPath)) {
                                    Join tableJoin = ((Root<T>) root).join(prop, JoinType.INNER);
                                    joinMap.put(prop, tableJoin);
                                    rootPath = tableJoin;
                                }
                                rootJavaType = rootPath.getJavaType();
                                continue;
                            } else {
                                rootPath = root;
                                rootJavaType = rootPath.getJavaType();
                            }
                        }
                        propJavaType = Objects.isNull(propJavaType)
                                ? rootJavaType.getDeclaredField(prop).getType()
                                : propJavaType.getDeclaredField(prop).getType();
                        path = Objects.isNull(path) ? rootPath.get(prop) : path.get(prop);
                    }
                } catch (NoSuchFieldException ex) {
                    log.error(ex.getLocalizedMessage(), ex);
                    List<ErrorModel> errors = new ArrayList<>();
                    errors.add(new ErrorModel(ex.getLocalizedMessage(), ex.getLocalizedMessage()));
                    throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
                }
                switch (filter.getType()) {
                case "String":
                    Path<String> pathString = (Path<String>) path;
                    if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("eq")) {
                        predicate = (builder.equal(builder.lower(pathString),
                                filter.getData().toString().toLowerCase()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-eq")) {
                        predicate = (builder.notEqual(builder.lower(pathString),
                                filter.getData().toString().toLowerCase()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("in")) {
                        predicate = (path.in(filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("like")) {
                        predicate = (builder.like(builder.lower(pathString),
                                "%" + filter.getData().toString().toLowerCase() + "%"));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("null")) {
                        predicate = (builder.isNull(path));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-null")) {
                        predicate = (builder.isNotNull(path));
                    } else {
                        predicate = (builder.like(builder.lower(pathString),
                                "%" + filter.getData().toString().toLowerCase() + "%"));
                    }
                    break;
                case "Integer":
                    Path<Integer> pathInteger = (Path<Integer>) path;
                    if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("eq")) {
                        predicate = (builder.equal(pathInteger, (filter.getData())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-eq")) {
                        predicate = (builder.notEqual(pathInteger, (filter.getData())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("in")) {
                        predicate = (path.in(filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("null")) {
                        predicate = (builder.isNull(path));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-null")) {
                        predicate = (builder.isNotNull(path));
                    } else {
                        predicate = (builder.equal(pathInteger, (filter.getData())));
                    }
                    break;
                case "Long":
                    Path<Long> pathLong = (Path<Long>) path;
                    if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("eq")) {
                        predicate = (builder.equal(pathLong, (filter.getData())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-eq")) {
                        predicate = (builder.notEqual(pathLong, (filter.getData())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("in")) {
                        predicate = (path.in(filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("null")) {
                        predicate = (builder.isNull(path));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-null")) {
                        predicate = (builder.isNotNull(path));
                    } else {
                        predicate = (builder.equal(pathLong, (filter.getData())));
                    }
                    break;
                case "Double":
                    Path<Double> pathDouble = (Path<Double>) path;
                    if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("eq")) {
                        predicate = (builder.equal(pathDouble, (filter.getData())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-eq")) {
                        predicate = (builder.notEqual(pathDouble, (filter.getData())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("in")) {
                        predicate = (path.in(filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("null")) {
                        predicate = (builder.isNull(path));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-null")) {
                        predicate = (builder.isNotNull(path));
                    } else {
                        predicate = (builder.equal(pathDouble, (filter.getData())));
                    }
                    break;
                case "Float":
                    Path<Float> pathFloat = (Path<Float>) path;
                    if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("eq")) {
                        predicate = (builder.equal(pathFloat, (filter.getData())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-eq")) {
                        predicate = (builder.notEqual(pathFloat, (filter.getData())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("in")) {
                        predicate = (path.in(filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("null")) {
                        predicate = (builder.isNull(path));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-null")) {
                        predicate = (builder.isNotNull(path));
                    } else {
                        predicate = (builder.equal(pathFloat, (filter.getData())));
                    }
                    break;
                case "UUID":
                    Path<UUID> pathUUID = (Path<UUID>) path;
                    if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("eq")) {
                        predicate = (builder.equal(pathUUID,
                                UUID.fromString(filter.getData().toString())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-eq")) {
                        predicate = (builder.notEqual(pathUUID,
                                UUID.fromString(filter.getData().toString())));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("in")) {
                        predicate = (path.in(filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("null")) {
                        predicate = (builder.isNull(path));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-null")) {
                        predicate = (builder.isNotNull(path));
                    } else {
                        predicate = (builder.equal(pathUUID,
                                UUID.fromString(filter.getData().toString())));
                    }
                    break;
                case "Boolean":
                    Path<Boolean> pathBoolean = (Path<Boolean>) path;
                    predicate = (builder.equal(pathBoolean, filter.getData()));
                    break;
                case "Enum":
                    if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("eq")) {
                        Object enumValue = null;
                        for (Object value : propJavaType.getEnumConstants()) {
                            if (value.toString().equalsIgnoreCase(filter.getData().toString())) {
                                enumValue = value;
                                break;
                            }
                        }
                        predicate = (builder.equal(path, enumValue));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-eq")) {
                        Object enumValue = null;
                        for (Object value : propJavaType.getEnumConstants()) {
                            if (value.toString().equalsIgnoreCase(filter.getData().toString())) {
                                enumValue = value;
                                break;
                            }
                        }
                        predicate = (builder.notEqual(path, enumValue));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("in")) {
                        List<Object> enumInValue = new ArrayList<>();
                        final Class propFinalJavaType = propJavaType;
                        ((List) filter.getData()).stream().forEach(data -> {
                            for (Object value : propFinalJavaType.getEnumConstants()) {
                                if (value.toString().equalsIgnoreCase(data.toString())) {
                                    enumInValue.add(value);
                                    break;
                                }
                            }
                        });
                        predicate = (path.in(enumInValue));
                        break;
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("null")) {
                        predicate = (builder.isNull(path));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-null")) {
                        predicate = (builder.isNotNull(path));
                    } else {
                        Object enumValue = null;
                        for (Object value : propJavaType.getEnumConstants()) {
                            if (value.toString().equalsIgnoreCase(filter.getData().toString())) {
                                enumValue = value;
                                break;
                            }
                        }
                        predicate = (builder.equal(path, enumValue));
                    }
                    break;
                case "Date":
                    Path<Date> pathDate = (Path<Date>) path;
                    if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("eq")) {
                        predicate = (builder.equal(pathDate, filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-eq")) {
                        predicate = (builder.notEqual(pathDate, filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("le")) {
                        predicate = (builder.lessThanOrEqualTo(pathDate, (Date) filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("in")) {
                        predicate = (path.in(filter.getData()));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("null")) {
                        predicate = (builder.isNull(path));
                    } else if (!Objects.isNull(filter.getOperator())
                            && filter.getOperator().equalsIgnoreCase("not-null")) {
                        predicate = (builder.isNotNull(path));
                    } else {
                        predicate = (builder.equal(pathDate, filter.getData()));
                    }
                    break;
                default:
                }
                return predicate;
            }
        }).collect(Collectors.toList());
        if (Objects.nonNull(filterModel.getCondition())
                && filterModel.getCondition().equalsIgnoreCase("or")) {
            return builder.or(predicates.toArray(Predicate[]::new));
        } else {
            return builder.and(predicates.toArray(Predicate[]::new));
        }
    }

}
