package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.util.UUID;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alstom.applicationfactory.dwiservice.instruction.entity.EditionControlComments;
import com.alstom.applicationfactory.dwiservice.instruction.model.EditionControlCommentsModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.EditionControlCommentsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.service.EditionControlCommentsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service(value = "editionControlCommentsService")
public class EditionControlCommentsServiceImpl implements EditionControlCommentsService {

    /**
     * EditionControlCommentsRepository.
     */
    @Autowired
    private EditionControlCommentsRepository editionControlCommentsRepository;

    /**
     * @param id
     * @return
     */
    @Override
    public EditionControlCommentsModel getEditionControlComments(final UUID id) {
        log.debug("Entry:EditionControlCommentsServiceImpl:getEditionControlComments.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        EditionControlComments editionCComment = this.editionControlCommentsRepository
                .findByInstructionsId(id).get(0);
        EditionControlCommentsModel editionCCommentModel = mapper.map(editionCComment,
                EditionControlCommentsModel.class);
        log.debug("Leave:EditionControlCommentsServiceImpl:getEditionControlComments.");
        return editionCCommentModel;
    }

}
