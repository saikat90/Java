package com.alstom.applicationfactory.dwiservice.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorModel {
    /**
     * ErrorModel - field name to be diplayed on run time error.
     */
    private String fieldName;
    /**
     * ErrorModel - error message to displayed on run time error.
     */
    private String error;
}
