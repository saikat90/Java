package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.RevisionRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.RevisionService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "revisionService")
@Transactional
@Slf4j
public class RevisionServiceImpl implements RevisionService {

    /**
     * RevisionRepository.
     */
    @Autowired
    private RevisionRepository revisionRepository;

    /**
     * @param revisionBean
     * @return RevisionModel.
     */
    @Override
    public RevisionModel createRevision(final RevisionModel revisionBean) {
        log.debug("Entry:DwiRevisionServiceImpl:createRevision.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        RevisionModel createdRevisionModel = new RevisionModel();
        if (revisionBean.getProcess() == null) {
            log.error("Process is mandatory.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.REVISION_LABEL, Constants.SELECT_PROCESS_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        Revision revision = mapper.map(revisionBean, Revision.class);

        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("String", "revisionName",
                revisionBean.getRevisionName(), "eq"));
        filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active", true));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        long count = this.revisionRepository.count(requestModel.getFilterSpecification());

        if (count == 0) {
            revision = revisionRepository.save(revision);
            createdRevisionModel = mapper.map(revision, RevisionModel.class);
        } else {
            log.error("Record already exists for the revision. Please update existing value.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.REVISION_LABEL, Constants.RECORD_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:DwiRevisionServiceImpl:createRevision.");
        return createdRevisionModel;
    }

    /**
     * @param revisionModel
     * @return RevisionModel.
     */
    @Override
    public RevisionModel updateRevision(final RevisionModel revisionModel) {
        log.debug("Entry:DwiRevisionServiceImpl:updateRevision");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        RevisionModel revisionBean = new RevisionModel();
        try {

            if (revisionModel.getProcess() == null) {
                log.error("Process is mandatory.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(
                        new ErrorModel(Constants.REVISION_LABEL, Constants.SELECT_PROCESS_ERROR));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            Revision revision = mapper.map(revisionModel, Revision.class);
            Revision revisionRecord = revisionRepository.findById(revisionModel.getId())
                    .orElse(null);
            if (null != revisionRecord) {
                Revision revisionResult = revisionRepository.save(revision);
                revisionBean = mapper.map(revisionResult, RevisionModel.class);
                log.debug("Leave:DwiRevisionServiceImpl:updateRevision.");
            } else {
                log.error("Record does not exists for the revision.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.REVISION_LABEL, Constants.RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return revisionBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.REVISION_LABEL,
                    Constants.UPDATE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param request
     * @return searchRevision.
     */
    @Override
    public Object searchRevision(final RequestModel request) {
        log.debug("Entry:DwiRevisionServiceImpl:searchRevision.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.revisionRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(revision -> mapper.map(revision, RevisionModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.revisionRepository.findAll(request.getFilterSpecification()).stream()
                    .map(revision -> mapper.map(revision, RevisionModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:DwiRevisionServiceImpl:searchRevision.");
        return result;
    }

    /**
     * @param revisionId
     * @return RevisionModel.
     */
    @Override
    public RevisionModel viewRevision(final UUID revisionId) {
        log.debug("Entry:DwiRevisionServiceImpl:viewRevision.");
        Revision revision;
        RevisionModel revisionBean = new RevisionModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            revision = revisionRepository.findById(revisionId).orElse(null);
            if (null != revision) {
                revisionBean = mapper.map(revision, RevisionModel.class);
                log.debug("Leave:DwiRevisionServiceImpl:viewRevision.");
            }
            return revisionBean;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.REVISION_LABEL, Constants.VIEW_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param revisionId
     */
    @Override
    public void deleteRevisionById(final UUID revisionId) {
        log.debug("Entry:DwiRevisionServiceImpl:deleteRevision.");
        try {
            revisionRepository.deleteById(revisionId);
            log.debug("Leave:DwiRevisionServiceImpl:deleteRevision.");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.REVISION_LABEL,
                    Constants.DELETE_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }
}
