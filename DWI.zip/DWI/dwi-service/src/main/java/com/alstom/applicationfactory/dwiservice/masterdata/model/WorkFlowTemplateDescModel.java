package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkFlowTemplateDescModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    @NotNull(message = "Please select Action!!")
    private String dwiActions;

    /**
     */
    @NotNull(message = "Function is mandatory")
    private FunctionModel function;

    /**
     */
    private String name;

    /**
     */
    private UserModel validateApproveUser;

    /**
     */
    private String comments;

    /**
     */
    @JsonIgnore
    private WorkFlowTemplateModel workFlowTemplate;

    /**
     */
    private Integer wfTemplateDescSeq;
}
