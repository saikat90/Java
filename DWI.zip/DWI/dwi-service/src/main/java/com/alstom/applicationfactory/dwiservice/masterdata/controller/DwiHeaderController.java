package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.DwiHeaderModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.DwiHeaderRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.DwiHeaderService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/dwiHeader")
@Slf4j
public class DwiHeaderController {

    /**
     * DwiHeaderService.
     */
    @Autowired
    private DwiHeaderService dwiHeaderService;

    /**
     * DwiHeaderRepository.
     */
    @Autowired
    private DwiHeaderRepository dwiHeaderRepository;

    /**
     * @param request
     * @return dwi header objects.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchAllDwiHeader(
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:DwiHeaderController:searchDwiHeader.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = dwiHeaderService.findAll(requestModel);
        log.debug("Leave:DwiHeaderController:searchDwiHeader.");
        return res;
    }

    /**
     * @return findAll Object
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getAllDwiHeader() {
        log.debug("Entry:DwiHeaderController:getAllDwiHeader.");
        Object res = dwiHeaderRepository.findAll();
        log.debug("Leave:DwiHeaderController:getAllDwiHeader.");
        return res;
    }

    /**
     * @param dwiHeader
     * @return DwiHeaderModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public DwiHeaderModel createDwiHeader(@RequestBody @Valid final DwiHeaderModel dwiHeader) {
        log.debug("Entry:DwiHeaderController:createDwiHeader.");
        DwiHeaderModel dwiHeaderModel = dwiHeaderService.createDwiHeader(dwiHeader);
        log.debug("Leave:DwiHeaderController:createDwiHeader.");
        return dwiHeaderModel;
    }

    /**
     * @param dwiHeader
     * @return DwiHeaderModel.
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public DwiHeaderModel updateDwiHeader(@RequestBody @Valid final DwiHeaderModel dwiHeader) {
        log.debug("Entry:DwiHeaderController:updateDwiHeader.");
        DwiHeaderModel dwiHeaderModel = dwiHeaderService.updateDwiHeader(dwiHeader);
        log.debug("Leave:DwiHeaderController:updateDwiHeader.");
        return dwiHeaderModel;
    }

    /**
     * @param id
     * @return DwiHeaderModel.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public DwiHeaderModel viewDwiHeader(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiHeaderController:viewDwiHeader.");
        DwiHeaderModel dwiHeaderModel = dwiHeaderService.viewDwiHeader(id);
        log.debug("Leave:DwiHeaderController:viewDwiHeader.");
        return dwiHeaderModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteDwiHeaderById(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiHeaderController:deleteDwiHeader.");
        this.dwiHeaderService.deleteDwiHeaderById(id);
        log.debug("Leave:DwiHeaderController:deleteDwiHeader.");
    }
}
