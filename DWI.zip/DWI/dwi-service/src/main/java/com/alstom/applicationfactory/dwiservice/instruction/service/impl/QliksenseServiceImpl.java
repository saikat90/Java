package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsQliksenseModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.service.QliksenseService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "qliksenseService")
@Transactional
@Slf4j
public class QliksenseServiceImpl implements QliksenseService {

    /**
     * InstructionsRepository.
     */
    @Autowired
    private InstructionsRepository instructionsRepository;

    /**
     * @return object of qlik kpi data.
     */
    @Override
    public Object findAll() {
        log.debug("Entry:DWI QliksenseServiceImpl:findAll.");

        List<InstructionsQliksenseModel> qlikList = null;

        List<Object[]> qlikInstructionsList = this.instructionsRepository.findAllQliksenseData();

        if (Objects.nonNull(qlikInstructionsList)) {
            qlikList = qlikInstructionsList.stream().map(instructions -> {
                InstructionsQliksenseModel instructionsQliksenseModel = new InstructionsQliksenseModel();
                instructionsQliksenseModel.setDwiNumber(String.valueOf(instructions[0]));
                instructionsQliksenseModel
                        .setDwiEdition(Integer.parseInt(String.valueOf(instructions[1])));
                instructionsQliksenseModel
                        .setApprovedActiveEdition(Boolean.valueOf(String.valueOf(instructions[2])));
                instructionsQliksenseModel
                        .setDwiReference(String.valueOf(instructions[Constants.THREE]));
                instructionsQliksenseModel
                        .setDwiStatus(String.valueOf(instructions[Constants.FOUR]));
                instructionsQliksenseModel
                        .setDwiProjectName(String.valueOf(instructions[Constants.FIVE]));
                instructionsQliksenseModel
                        .setProjectManager(String.valueOf(instructions[Constants.SIX]));
                instructionsQliksenseModel
                        .setDwiAuthorFirstName(String.valueOf(instructions[Constants.SEVEN]));
                instructionsQliksenseModel
                        .setDwiAuthorLastName(String.valueOf(instructions[Constants.EIGHT]));
                instructionsQliksenseModel
                        .setDwiFleetName(String.valueOf(instructions[Constants.NINE]));
                instructionsQliksenseModel
                        .setDwiProcessName(String.valueOf(instructions[Constants.TEN]));
                instructionsQliksenseModel
                        .setDwiRevisionName(String.valueOf(instructions[Constants.ELEVEN]));
                instructionsQliksenseModel
                        .setUserFirstName(String.valueOf(instructions[Constants.TWELVE]));
                instructionsQliksenseModel
                        .setUserLastName(String.valueOf(instructions[Constants.THIRTEEN]));
                instructionsQliksenseModel
                        .setUserRole(String.valueOf(instructions[Constants.FOURTEEN]));

                return instructionsQliksenseModel;
            }).collect(Collectors.toList());
        }
        log.debug("Leave:DWI QliksenseServiceImpl:findAll.");
        return qlikList;
    }
}
