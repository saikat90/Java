package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Function;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.FunctionRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.FunctionService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "functionService")
@Transactional
@Slf4j
public class FunctionServiceImpl implements FunctionService {

    /**
     * FunctionRepository.
     */
    @Autowired
    private FunctionRepository functionRepository;

    /**
     * @param functionModel
     * @return FunctionModel.
     */
    @Override
    public FunctionModel createFunction(final FunctionModel functionModel) {
        log.debug("Entry:FunctionServiceImpl:createFunction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        Function function = mapper.map(functionModel, Function.class);

        FunctionModel createdFunctionModel = new FunctionModel();

        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("String", "dwiFunctionName",
                functionModel.getDwiFunctionName(), "eq"));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        long count = this.functionRepository.count(requestModel.getFilterSpecification());

        if (count == 0) {
            function = functionRepository.save(function);
            createdFunctionModel = mapper.map(function, FunctionModel.class);
        } else {
            log.error("Record already exists for the function. Please update existing value.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.FUNCTION_LABEL, Constants.RECORD_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:FunctionServiceImpl:createFunction.");
        return createdFunctionModel;
    }

    /**
     * @param functionModel
     * @return FunctionModel.
     */
    @Override
    public FunctionModel updateFunction(final FunctionModel functionModel) {
        log.debug("Entry:FunctionServiceImpl:updateFunction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        FunctionModel functionBean = new FunctionModel();
        try {
            Function function = mapper.map(functionModel, Function.class);
            Function functionRecord = functionRepository.findById(functionModel.getId())
                    .orElse(null);
            if (null != functionRecord) {
                Function functionResult = functionRepository.save(function);
                functionBean = mapper.map(functionResult, FunctionModel.class);
                log.debug("Leave:FunctionServiceImpl:UpdateProject.");
            } else {
                log.error("Record does not exists for the Function.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.FUNCTION_LABEL, Constants.RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return functionBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.FUNCTION_LABEL,
                    Constants.UPDATE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param request
     * @return findAll.
     */
    @Override
    public Object findAll(final RequestModel request) {

        log.debug("Entry:FunctionServiceImpl:findAll.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            result = mapper.map(
                    this.functionRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
        } else {
            result = this.functionRepository.findAll(request.getFilterSpecification()).stream()
                    .map(function -> mapper.map(function, FunctionModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:FunctionServiceImpl:findAll.");
        return result;
    }

    /**
     * @param functionId
     * @return FunctionModel.
     */
    @Override
    public FunctionModel viewFunction(final UUID functionId) {
        log.debug("Entry:FunctionServiceImpl:viewFunction.");
        Function function;
        FunctionModel functionModel = null;
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        function = functionRepository.findById(functionId).orElse(null);
        if (null != function) {
            functionModel = mapper.map(function, FunctionModel.class);
            log.debug("Leave:FunctionSServiceImpl:viewFunction.");
        }
        return functionModel;
    }

    /**
     * @param functionId
     */
    @Override
    public void deleteFunctionById(final UUID functionId) {
        log.debug("Entry:FunctionServiceImpl:deleteFunction.");

        try {
            functionRepository.deleteById(functionId);
            log.debug("Leave:FunctionServiceImpl:deleteFunction.");
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.FUNCTION_LABEL,
                    Constants.DELETE_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }
}
