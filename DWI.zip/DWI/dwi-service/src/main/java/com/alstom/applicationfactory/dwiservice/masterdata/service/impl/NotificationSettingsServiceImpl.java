package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.NotificationSettings;
import com.alstom.applicationfactory.dwiservice.masterdata.model.NotificationSettingsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.NotificationSettingsRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.NotificationSettingsService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "notificationSettingsService")
@Transactional
@Slf4j
public class NotificationSettingsServiceImpl implements NotificationSettingsService {

    /**
     * NotificationSettingsRepository.
     */
    @Autowired
    private NotificationSettingsRepository settingsRepository;

    /**
     * @param settingsModel
     * @return NotificationSettingsModel.
     */
    @Override
    public NotificationSettingsModel updateSettings(final NotificationSettingsModel settingsModel) {
        log.debug("Entry:NotificationSettingsServiceImpl:updateSettings.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        long count = this.settingsRepository.count();
        NotificationSettingsModel updatedNotificationSettingsModel = new NotificationSettingsModel();
        if (count == 1) {
            NotificationSettings settings = this.settingsRepository.findById(settingsModel.getId())
                    .orElse(null);
            if (Objects.nonNull(settings)) {
                updatedNotificationSettingsModel = mapper.map(
                        this.settingsRepository
                                .save(mapper.map(settingsModel, NotificationSettings.class)),
                        NotificationSettingsModel.class);
            } else {
                log.error("Not able to updaate notification settings.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.NOTIFICATION_SETTINGS_LABEL,
                        Constants.UPDATE_ERROR));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }

        } else if (count == 0) {
            log.error("No settings found. Please add new notification settings.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.NOTIFICATION_SETTINGS_LABEL,
                    Constants.RECORD_NOT_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:NotificationSettingsServiceImpl:updateSettings.");
        return updatedNotificationSettingsModel;
    }

    /**
     * @param settingsModel
     * @return NotificationSettingsModel.
     */
    @Override
    public NotificationSettingsModel saveSettings(final NotificationSettingsModel settingsModel) {
        log.debug("Entry:NotificationSettingsServiceImpl:saveSettings.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        NotificationSettingsModel createdNotificationSettingsModel = new NotificationSettingsModel();

        if (this.settingsRepository.count() == 0) {
            createdNotificationSettingsModel = mapper.map(
                    this.settingsRepository
                            .save(mapper.map(settingsModel, NotificationSettings.class)),
                    NotificationSettingsModel.class);
        } else {
            log.error("Settings already exist. Please update existing settings.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(
                    new ErrorModel(Constants.NOTIFICATION_SETTINGS_LABEL, Constants.RECORD_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:NotificationSettingsServiceImpl:saveSettings.");
        return createdNotificationSettingsModel;
    }

    /**
     * @return NotificationSettingsModel.
     */
    @Override
    public NotificationSettingsModel getSettings() {
        log.debug("Entry:NotificationSettingsServiceImpl:getSettings.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        NotificationSettingsModel settingsModel = new NotificationSettingsModel();
        long count = this.settingsRepository.count();
        if (count == 1) {
            settingsModel = mapper.map(this.settingsRepository.findAll().get(0),
                    NotificationSettingsModel.class);
        } else if (count > 1) {
            log.error(
                    "Multiple settings found. Only one settings is allowed. Please remove others.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.NOTIFICATION_SETTINGS_LABEL,
                    Constants.NOTIFICATION_SETTINGS_FOUND_MANY));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:NotificationSettingsServiceImpl:getSettings.");
        return settingsModel;
    }

}
