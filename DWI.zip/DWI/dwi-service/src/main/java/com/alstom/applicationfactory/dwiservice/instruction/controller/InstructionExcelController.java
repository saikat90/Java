package com.alstom.applicationfactory.dwiservice.instruction.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.exception.ExcelException;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionExcelService;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/instructionExcel")
@Slf4j
@RefreshScope
public class InstructionExcelController {

    /**
     * InstructionExcelService.
     */
    @Autowired
    private InstructionExcelService instructionExcelService;

    /**
     * email address of the user object.
     */
    @Value("${application.factory.jwt.emailProp}")
    private String emailProp;

    /**
     * @param file
     * @param authentication
     * @return ExcelException
     */
    @PostMapping("/import")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ExcelException importExcel(@RequestParam("file") final MultipartFile file,
            final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:importExcel.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        return this.instructionExcelService.importExcel(file, email);

    }
}
