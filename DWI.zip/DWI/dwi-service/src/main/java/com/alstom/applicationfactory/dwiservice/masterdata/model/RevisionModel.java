package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RevisionModel {

    /**
     */
    private UUID id;
    /**
     */
    private Integer version;
    /**
     */
    @NotNull(message = "Revision name should not be empty")
    private String revisionName;
    /**
     */
    private boolean active;
    /**
     */
    private Date createdDate;
    /**
     */
    private Date modifiedDate;
    /**
     */
    private String createdBy;
    /**
     */
    private String modifiedBy;
    /**
     */
    @NotNull(message = "process should not be empty")
    private ProcessModel process;

}
