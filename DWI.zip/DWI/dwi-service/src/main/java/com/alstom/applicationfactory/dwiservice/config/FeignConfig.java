package com.alstom.applicationfactory.dwiservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alstom.applicationfactory.dwiservice.feign.Interceptor;

import feign.RequestInterceptor;

@Configuration
public class FeignConfig {
    /**
     * FeignConfig - Request Interceptor for feign client.
     * 
     * @return Request interceptor for feign client
     */
    @Bean
    public RequestInterceptor getFeignClientInterceptor() {
        return new Interceptor();
    }
}
