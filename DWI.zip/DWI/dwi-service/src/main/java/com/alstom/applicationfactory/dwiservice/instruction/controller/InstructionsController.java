package com.alstom.applicationfactory.dwiservice.instruction.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionsService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/instructions")
@Slf4j
@RefreshScope
public class InstructionsController {

    /**
     * InstructionsService.
     */
    @Autowired
    private InstructionsService instructionsService;

    /**
     * email address of the user object.
     */
    @Value("${application.factory.jwt.emailProp}")
    private String emailProp;

    /**
     * @param request
     * @return Instruction object.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchInstruction(
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:DwiInstructionsController:searchInstructions.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = instructionsService.searchInstructions(requestModel);
        log.debug("Leave:DwiInstructionsController:searchInstructions.");
        return res;
    }

    /**
     * @param instruction
     * @param editionControlComment
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('AUTHOR','ADM')")
    public InstructionsModel saveasDraftInstruction(@RequestParam final String instruction,
            @RequestParam final String editionControlComment, final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:saveasDraftInstruction.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InstructionsModel instructionModel = null;
        try {
            instructionModel = mapper.readValue(instruction, InstructionsModel.class);
        } catch (JsonProcessingException ex) {
            log.debug("Could not parse instruction values. Please try again!", ex);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION, Constants.INSTRUCTION_PARSE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        instructionModel = instructionsService.saveasDraftInstruction(instructionModel,
                editionControlComment, email);
        log.debug("Leave:DwiInstructionsController:saveasDraftInstruction.");
        return instructionModel;
    }

    /**
     * @param instruction
     * @param editionControlComment
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping("/submit")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('AUTHOR','ADM')")
    public InstructionsModel submitInstruction(@RequestParam final String instruction,
            @RequestParam final String editionControlComment, final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:submitInstruction.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InstructionsModel instructionModel = null;
        try {
            instructionModel = mapper.readValue(instruction, InstructionsModel.class);
        } catch (JsonProcessingException ex) {
            log.debug("Could not parse instruction values. Please try again!", ex);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION, Constants.INSTRUCTION_PARSE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        instructionModel = instructionsService.submitInstruction(instructionModel,
                editionControlComment, email);
        log.debug("Leave:DwiInstructionsController:submitInstruction.");
        return instructionModel;
    }

    /**
     * @param id
     * @return InstructionsModel.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public InstructionsModel viewInstruction(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiInstructionsController:viewInstruction.");
        InstructionsModel instructionModel = instructionsService.viewInstruction(id);
        log.debug("Leave:DwiInstructionsController:viewInstruction.");
        return instructionModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('AUTHOR','ADM','PROJ_MANAGER')")
    public void deleteInstructionById(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiInstructionsController:deleteInstruction.");
        this.instructionsService.deleteInstructionById(id);
        log.debug("Leave:DwiInstructionsController:deleteInstruction.");
    }

    /**
     * @param id
     * @param comment
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping("/{id}/validate")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('VALIDATOR','ADM')")
    public InstructionsModel validateInstruction(@PathVariable final UUID id,
            @RequestParam final String comment, final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:validateInstruction.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        List<String> roles = new ArrayList();
        authentication.getAuthorities().stream().forEach(item -> {
            String auth = item.getAuthority();
            if (auth.contains("ROLE_")) {
                roles.add(auth.replace("ROLE_", ""));
            }
        });
        InstructionsModel instructionModel = null;
        if (roles.contains("ADM")) {
            instructionModel = instructionsService.validateInstruction(id, comment, email);
        } else if (roles.contains("VALIDATOR")) {
            instructionModel = instructionsService.validateInstructionByAction(id, comment, email);
        }
        log.debug("Leave:DwiInstructionsController:validateInstruction.");
        return instructionModel;
    }

    /**
     * @param id
     * @param comment
     * @param dwiStaticLink
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping("/{id}/approve")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('APPROVER','ADM')")
    public InstructionsModel approveInstruction(@PathVariable final UUID id,
            @RequestParam final String comment, @RequestParam final String dwiStaticLink,
            final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:approveInstruction.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        List<String> roles = new ArrayList();
        authentication.getAuthorities().stream().forEach(item -> {
            String auth = item.getAuthority();
            if (auth.contains("ROLE_")) {
                roles.add(auth.replace("ROLE_", ""));
            }
        });
        InstructionsModel instructionModel = null;
        if (roles.contains("ADM")) {
            instructionModel = instructionsService.approveInstruction(id, comment, dwiStaticLink,
                    email);
        } else if (roles.contains("APPROVER")) {
            instructionModel = instructionsService.approveInstructionByAction(id, comment,
                    dwiStaticLink, email);
        }
        log.debug("Leave:DwiInstructionsController:approveInstruction.");
        return instructionModel;
    }

    /**
     * @param id
     */
    @PostMapping("/{id}/archive")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void archiveInstruction(@PathVariable final UUID id) {
        log.debug("Entry:DwiInstructionsController:archiveInstruction.");
        instructionsService.archiveInstruction(id);
        log.debug("Leave:DwiInstructionsController:archiveInstruction.");
    }

    /**
     * @param id
     * @param comment
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping("/{id}/reject")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('VALIDATOR','APPROVER','ADM')")
    public InstructionsModel rejectInstruction(@PathVariable final UUID id,
            @RequestParam final String comment, final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:rejectInstruction.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        InstructionsModel instructionModel = instructionsService.rejectInstruction(id, comment,
                email);
        log.debug("Leave:DwiInstructionsController:rejectInstruction.");
        return instructionModel;
    }

    /**
     * @param id
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping("/{id}/createNewVersion")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('AUTHOR','ADM')")
    public InstructionsModel createNewVersion(@PathVariable final UUID id,
            final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:rejectInstruction.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        InstructionsModel instructionModel = instructionsService.createNewVersion(id, email);
        return instructionModel;
    }

    /**
     * @param id
     */
    @PostMapping("/{id}/copyAttachment")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void copyAttachment(@PathVariable final UUID id) {
        log.debug("Entry:DwiInstructionsController:copyAttachment.");
        instructionsService.copyAttachment(id);
        log.debug("Entry:DwiInstructionsController:copyAttachment.");
    }

    /**
     * instructionAutoReminder.
     */
    @Scheduled(cron = "0 0 1 * * *")
    @PostMapping("/auto-reminder")
    // @PreAuthorize("hasAuthority('APP_DWI')")
    public void instructionAutoReminder() {
        log.debug("Entry:DwiInstructionsController:instructionAutoReminder.");
        this.instructionsService.instructionAutoReminder();
        log.debug("Leave:DwiInstructionsController:instructionAutoReminder.");
    }

    /**
     * @param id
     * @param comment
     * @param attachment
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping("/{id}/addComment")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('WORKER','ADM','AUTHOR','PROJ_MANAGER')")
    public InstructionsModel addComments(@PathVariable final UUID id,
            @RequestParam final String comment, @RequestParam final String attachment,
            final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:addComments.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InstructionAttachmentModel instructionAttachmentModel = null;
        try {
            instructionAttachmentModel = mapper.readValue(attachment,
                    InstructionAttachmentModel.class);
        } catch (JsonProcessingException ex) {
            log.debug("Could not parse instruction Attachment values. Please try again!", ex);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACH_ERROR,
                    Constants.INSTRUCTION_ATTACH_ERROR_MSG));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        InstructionsModel instructionModel = instructionsService.addComments(id,
                instructionAttachmentModel, comment, email);
        log.debug("Leave:DwiInstructionsController:addComments.");
        return instructionModel;

    }

    /**
     * @param id
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping("/{id}/viewPreviousVersion")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('AUTHOR','ADM','PROJ_MANAGER','VALIDATOR','APPROVER')")
    public InstructionsModel viewPreviousVersion(@PathVariable final UUID id,
            final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:viewPreviousVersion.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        InstructionsModel instructionModel = instructionsService.viewPreviousVersion(id, email);
        log.debug("Leave:DwiInstructionsController:viewPreviousVersion.");
        return instructionModel;
    }

    /**
     * @param id
     * @param attachment
     * @param authentication
     * @return InstructionsModel.
     */
    @PostMapping("/{id}/addAttachment")
    @PreAuthorize("hasAuthority('APP_DWI') and hasAnyRole('WORKER','ADM')")
    public InstructionsModel addAttachment(@PathVariable final UUID id,
            @RequestParam final String attachment, final Authentication authentication) {
        log.debug("Entry:DwiInstructionsController:addAttachment.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InstructionAttachmentModel instructionAttachmentModel = null;
        try {
            instructionAttachmentModel = mapper.readValue(attachment,
                    InstructionAttachmentModel.class);
        } catch (JsonProcessingException ex) {
            log.debug("Could not parse instruction Attachment values. Please try again!", ex);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.INSTRUCTION_ATTACH_ERROR,
                    Constants.INSTRUCTION_ATTACH_ERROR_MSG));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        InstructionsModel instructionModel = instructionsService.addAttachment(id,
                instructionAttachmentModel, email);
        log.debug("Leave:DwiInstructionsController:addAttachment.");
        return instructionModel;

    }

}
