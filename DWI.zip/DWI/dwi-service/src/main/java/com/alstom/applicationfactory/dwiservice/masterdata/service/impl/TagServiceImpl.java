package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.exception.ExcelException;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Tag;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TagModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.TagRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.TagService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "tagService")
@Transactional
@Slf4j
public class TagServiceImpl implements TagService {

    /**
     * TagRepository.
     */
    @Autowired
    private TagRepository tagRepository;

    /**
     * @param tagBean
     * @return TagModel.
     */
    @Override
    public TagModel createTag(final TagModel tagBean) {
        log.debug("Entry:TagServiceImpl:createTag.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        TagModel createdTagModel = new TagModel();

        if (tagBean.getDwTags() == null) {
            log.error("Tag is mandatory.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.TAGS_LABEL, Constants.MANDATORY));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        Tag tag = mapper.map(tagBean, Tag.class);

        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(
                RequestModifier.getfilterCondition("String", "dwTags", tagBean.getDwTags(), "eq"));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        long count = this.tagRepository.count(requestModel.getFilterSpecification());

        if (count == 0) {
            tag = tagRepository.save(tag);
            createdTagModel = mapper.map(tag, TagModel.class);
        } else {
            log.error("Record already exists for the tag. Please update existing value.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.TAGS_LABEL, Constants.RECORD_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:TagServiceImpl:createTag.");
        return createdTagModel;
    }

    /**
     * @param tagModel
     * @return TagModel.
     */
    @Override
    public TagModel updateTag(final TagModel tagModel) {
        log.debug("Entry:TagServiceImpl:updateTag.");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        TagModel tagBean = new TagModel();
        try {

            if (tagModel.getDwTags() == null) {
                log.error("Tag is mandatory.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.TAGS_LABEL, Constants.MANDATORY));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }

            Tag tag = mapper.map(tagModel, Tag.class);
            Tag tagRecord = tagRepository.findById(tagModel.getId()).orElse(null);
            if (null != tag) {
                Tag tagResult = tagRepository.save(tag);
                tagBean = mapper.map(tagResult, TagModel.class);
                log.debug("Leave:TagServiceImpl:updateTag.");
            }
            return tagBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.TAGS_LABEL, Constants.UPDATE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param request
     * @return searchTag.
     */
    @Override
    public Object searchTag(final RequestModel request) {
        log.debug("Entry:TagServiceImpl:searchTag.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.tagRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(tag -> mapper.map(tag, TagModel.class)).collect(Collectors.toList()));
            result = response;
        } else {
            result = this.tagRepository.findAll(request.getFilterSpecification()).stream()
                    .map(tag -> mapper.map(tag, TagModel.class)).collect(Collectors.toList());
        }
        log.debug("Leave:TagServiceImpl:searchTag.");
        return result;
    }

    /**
     * @param tagId
     * @return TagModel.
     */
    @Override
    public TagModel viewTag(final UUID tagId) {
        log.debug("Entry:TagServiceImpl:viewTag.");
        Tag tag;
        TagModel tagBean = new TagModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            tag = tagRepository.findById(tagId).orElse(null);
            if (null != tag) {
                tagBean = mapper.map(tag, TagModel.class);
                log.debug("Leave:TagServiceImpl:viewTag.");
            }
            return tagBean;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.TAGS_LABEL, Constants.VIEW_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param tagId
     */
    @Override
    public void deleteTag(final UUID tagId) {
        log.debug(".");
        Tag tag;
        TagModel tagBean = new TagModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            tag = tagRepository.findById(tagId).orElse(null);
            if (null != tag) {
                tagRepository.delete(tag);
                log.debug("Leave:TagServiceImpl:deleteTag.");
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.TAGS_LABEL, Constants.DELETE_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param file
     * @return ExcelException.
     */
    @Override
    public ExcelException importExcel(final MultipartFile file) {
        log.debug("Entry:TagServiceImpl:importExcel.");

        TagModel tagModel = new TagModel();

        ModelMapper mapper = new ModelMapper();
        ExcelException excelException = new ExcelException();
        List<String> listError = new ArrayList<String>();

        try {

            Sheet sheet = null;
            InstructionsModel insModel = null;
            InputStream inputStream = file.getInputStream();

            String fileContentType = file.getContentType();

            if (fileContentType.equals("application/vnd.ms-excel")) {
                HSSFWorkbook wb = new HSSFWorkbook(inputStream);
                sheet = wb.getSheetAt(0);
                // Excel computaion(.xls)
                excelException = populateExcel(sheet);

            } else if (fileContentType
                    .equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                XSSFWorkbook wb = new XSSFWorkbook(inputStream);
                sheet = wb.getSheetAt(0);
                // Excel computation(.xlsx)
                excelException = populateExcel(sheet);

            } else {
                listError.add("Please upload file in (xls/xlsx) format ");
                excelException.setErrorDescription(listError);
            }

            log.debug("Leave:TagServiceImpl:importExcel.");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.TAGS_LABEL,
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errorModels);
        }
        return excelException;
    }

    /**
     * @param classType
     * @return checkExistingData
     */
    public final Long checkExistingData(final Object classType) {
        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        long count = 0L;

        if (classType instanceof TagModel) {

            TagModel tagModel = (TagModel) classType;
            filterConditions.add(RequestModifier.getfilterCondition("String", "dwTags",
                    tagModel.getDwTags(), "eq"));
            // filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active",
            // true));
            RequestModel requestModel = RequestMapper
                    .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
            count = tagRepository.count(requestModel.getFilterSpecification());

        }

        return count;
    }

    /**
     * @param sheet
     * @return ExcelException
     */
    public ExcelException populateExcel(final Sheet sheet) {
        int rowCount = 3, successRowCount = 0, failureRowCount = 0, blank = 0;
        List<String> listError = new ArrayList<String>();
        ModelMapper mapper = new ModelMapper();
        TagModel tagModel = null;
        List<TagModel> listTagModel = new ArrayList<TagModel>();

        log.debug("Number of rows in excel sheet : " + sheet.getPhysicalNumberOfRows());
        if (sheet.getPhysicalNumberOfRows() < 51) {
            for (Row row : sheet) // iteration over row using for each loop
            {
                long count = 0L;
                boolean failure = false;
                int j = 0;
                tagModel = new TagModel();
                TagModel tagModelDemo = new TagModel();

                if (row.getRowNum() == 0 || row.getRowNum() == 1) {
                    continue;
                }
                blank = 0;

                for (Cell cell : row) // iteration over cell using for each loop
                {
                    blank = 1;
                    switch (cell.getCellType()) {
                    case BLANK:
                        failure = true;
                        if (j == 0) {
                            listError.add("Tags is Blank for Row " + rowCount);
                        }
                        break;

                    case STRING: // field that represents string cell type
                        // getting the value of the cell as a string
                        log.debug(cell.getStringCellValue() + "\t\t");

                        if (j == 0) {
                            if (!cell.getStringCellValue().isBlank()) {

                                tagModelDemo.setDwTags(cell.getStringCellValue());
                                count = checkExistingData(tagModelDemo);
                                if (count == 0) {
                                    tagModel.setDwTags(tagModelDemo.getDwTags());
                                    tagModel.setVersion(0);
                                } else {
                                    failure = true;
                                    listError.add("dwitags - " + tagModelDemo.getDwTags()
                                            + " is already present in dwitags db ");
                                }
                            }
                        }

                        break;
                    default:
                        break;
                    }

                    j++;
                }

                if (blank == 1) {
                    if (!failure) {
                        successRowCount++;
                        listTagModel.add(tagModel);
                    } else {
                        failureRowCount++;
                    }
                } else {
                    listError.add("In Row - " + rowCount + " errorneous blank cell is there");
                }

                rowCount++;
            }

            // save it in DB
            List<TagModel> newTagModelList = new ArrayList<TagModel>();
            for (TagModel newTagModel : listTagModel) {
                newTagModelList.add(createTag(newTagModel));
            }

        } else {
            listError.add("Unable to import data as number of rows are greater than 50.");
        }

        return new ExcelException(successRowCount, failureRowCount, listError);
    }

}
