package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ExcelException;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TagModel;

public interface TagService {

    /**
     * @param process
     * @return TagModel.
     */
    TagModel createTag(TagModel process);

    /**
     * @param process
     * @return TagModel.
     */
    TagModel updateTag(TagModel process);

    /**
     * @param requestModel
     * @return TagModel.
     */
    Object searchTag(RequestModel requestModel);

    /**
     * @param processId
     * @return TagModel.
     */
    TagModel viewTag(UUID processId);

    /**
     * @param processId
     */
    void deleteTag(UUID processId);

    /**
     * @param file
     * @return ExcelException
     */
    ExcelException importExcel(@RequestParam("file") MultipartFile file);
}
