package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;

public interface RevisionService {

    /**
     * @param revision
     * @return RevisionModel.
     */
    RevisionModel createRevision(RevisionModel revision);

    /**
     * @param revision
     * @return RevisionModel.
     */
    RevisionModel updateRevision(RevisionModel revision);

    /**
     * @param requestModel
     * @return RevisionModel.
     */
    Object searchRevision(RequestModel requestModel);

    /**
     * @param revisionId
     * @return RevisionModel.
     */
    RevisionModel viewRevision(UUID revisionId);

    /**
     * @param revisionId
     */
    void deleteRevisionById(UUID revisionId);
}
