package com.alstom.applicationfactory.dwiservice.instruction.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.instruction.model.EditionControlCommentsModel;
import com.alstom.applicationfactory.dwiservice.instruction.service.EditionControlCommentsService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/editionControlComments/{id}")
@Slf4j
public class EditionControlCommentsController {

    /**
     * EditionControlCommentsService.
     */
    @Autowired
    private EditionControlCommentsService editionControlCommentsService;

    /**
     * @param id
     * @return EditionControlCommentsModel.
     */
    @GetMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public EditionControlCommentsModel getEditionControlComments(@PathVariable final UUID id) {
        log.debug("Entry:EditionControlCommentsController:getEditionControlComments.");
        EditionControlCommentsModel editionCCModel = this.editionControlCommentsService
                .getEditionControlComments(id);
        log.debug("Leave:EditionControlCommentsController:getEditionControlComments.");
        return editionCCModel;
    }

}
