package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.UserSearchQuery;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserSearchQueryModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserSearchQueryRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.UserSearchQueryService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "userSearchQueryService")
@Transactional
@Slf4j
public class UserSearchQueryServiceImpl implements UserSearchQueryService {

    /**
     * UserSearchQueryRepository.
     */
    @Autowired
    private UserSearchQueryRepository userSearchQueryRepo;
    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;

    /**
     * @param email
     * @param screenName
     * @return list of UserSearchQueryModel.
     */
    @Override
    public List<UserSearchQueryModel> listSavedQuery(final String email, final String screenName) {
        log.debug("Entry:UserSearchQueryServiceImpl:listSavedQuery.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            User creator = null;
            try {
                creator = userRepository.findByEmail(email).get(0);
            } catch (NullPointerException ex) {
                log.debug("User not present in the system for the email: " + email);
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.USER,
                        Constants.USER_NOT_PRESENT_FOR_MAIL + email));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            List<UserSearchQueryModel> savedqueryModelList = new ArrayList<>();
            List<UserSearchQuery> savedqueryList = userSearchQueryRepo
                    .findByUserIdAndScreenName(creator.getId(), screenName);
            if (null != savedqueryList && !savedqueryList.isEmpty()) {
                savedqueryModelList = savedqueryList.stream()
                        .map(savedQuery -> mapper.map(savedQuery, UserSearchQueryModel.class))
                        .collect(Collectors.toList());
            }
            log.debug("Leave:UserSearchQueryServiceImpl:listSavedQuery.");
            return savedqueryModelList;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.USER_SEARCH_QUERY_LABEL,
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param id
     */
    @Override
    public void deleteUserQueryById(final UUID id) {
        log.debug("Entry:UserSearchQueryServiceImpl:deleteUserQueryById.");
        try {

            Optional<UserSearchQuery> savedquery = userSearchQueryRepo.findById(id);
            UserSearchQuery savedRecord = new UserSearchQuery();
            if (savedquery.isPresent()) {
                savedRecord = savedquery.get();
            }
            if (Objects.nonNull(savedRecord.getSharedToUsers())
                    && !savedRecord.getSharedToUsers().isEmpty()) {
                deleteRecordForAlreadySharedUsers(savedRecord.getName(),
                        savedRecord.getUser().getId(), savedRecord.getScreenName());
            }
            userSearchQueryRepo.deleteById(id);
            log.debug("Leave:UserSearchQueryServiceImpl:deleteUserQueryById.");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.USER_SEARCH_QUERY_LABEL,
                    Constants.DELETE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param savedSearchId
     * @return UserSearchQueryModel.
     */
    @Override
    public UserSearchQueryModel viewSavedQuery(final UUID savedSearchId) {
        log.debug("Entry:UserSearchQueryServiceImpl:viewSavedQuery.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            UserSearchQueryModel savedqueryModel = null;
            UserSearchQuery savedquery = userSearchQueryRepo.findById(savedSearchId).orElse(null);
            if (null != savedquery) {
                savedqueryModel = mapper.map(savedquery, UserSearchQueryModel.class);
            }
            log.debug("Leave:UserSearchQueryServiceImpl:viewSavedQuery.");
            return savedqueryModel;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.USER_SEARCH_QUERY_LABEL,
                    Constants.VIEW_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param email
     * @param userSearchQueryModel
     * @return UserSearchQueryModel.
     */
    @Override
    public UserSearchQueryModel createSavedSearchQuery(final String email,
            @Valid final UserSearchQueryModel userSearchQueryModel) {
        log.debug("Entry:UserSearchQueryServiceImpl:createSavedSearchQuery.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        UserModel creatorModel = null;
        try {
            User creator = userRepository.findByEmail(email).get(0);
            creatorModel = mapper.map(creator, UserModel.class);
            userSearchQueryModel.setUser(creatorModel);
            userSearchQueryModel.setCreatedBy(email);
            UserSearchQueryModel userSearchCreatedBean = new UserSearchQueryModel();
            UserSearchQuery userSearchQuery = mapper.map(userSearchQueryModel,
                    UserSearchQuery.class);
            List<User> sharedUsers = userSearchQuery.getSharedToUsers();
            List<UserSearchQuery> newSavedQueryList = new ArrayList<>();

            Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
            List<Map<String, Object>> filterConditions = new ArrayList<>();
            filterConditions.add(RequestModifier.getfilterCondition("String", "name",
                    userSearchQueryModel.getName(), "eq"));
            filterConditions.add(RequestModifier.getfilterCondition("UUID", "user.id",
                    userSearchQueryModel.getUser().getId(), "eq"));
            filterConditions.add(RequestModifier.getfilterCondition("String", "screenName",
                    userSearchQueryModel.getScreenName(), "eq"));
            RequestModel requestModel = RequestMapper
                    .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
            long count = this.userSearchQueryRepo.count(requestModel.getFilterSpecification());

            if (count == 0) {

                if (Objects.nonNull(sharedUsers) && !sharedUsers.isEmpty()) {
                    sharedUsers.forEach(user -> {
                        UserSearchQuery savedqueryNew = new UserSearchQuery();
                        savedqueryNew.setScreenName(userSearchQueryModel.getScreenName());
                        savedqueryNew.setName(userSearchQueryModel.getName().concat("_shared"));
                        savedqueryNew.setUser(user);
                        savedqueryNew.setCriteria(userSearchQueryModel.getCriteria());
                        savedqueryNew.setCreatedBy(email);
                        savedqueryNew.setCreatedDate(new Date());
                        savedqueryNew.setSharedByUser(creator);
                        savedqueryNew.setShared(false);
                        savedqueryNew.setDefaultQuery(false);
                        newSavedQueryList.add(savedqueryNew);
                    });
                    if (Objects.nonNull(newSavedQueryList) && !newSavedQueryList.isEmpty()) {
                        List<UserSearchQuery> createdSavedQueryList = userSearchQueryRepo
                                .saveAll(newSavedQueryList);
                    }
                }
                if (userSearchQuery.isDefaultQuery()) {
                    Map<String, Object> request1 = RequestModifier.defaultRequestMapIfEmpty(null);
                    List<Map<String, Object>> filterConditions1 = new ArrayList<>();
                    filterConditions1.add(
                            RequestModifier.getfilterCondition("Boolean", "defaultQuery", true));
                    filterConditions1.add(RequestModifier.getfilterCondition("UUID", "user.id",
                            userSearchQueryModel.getUser().getId(), "eq"));
                    filterConditions1.add(RequestModifier.getfilterCondition("String", "screenName",
                            userSearchQueryModel.getScreenName(), "eq"));
                    RequestModel requestModel1 = RequestMapper.map(
                            RequestModifier.updateRequestMapWithAnd(request1, filterConditions1));
                    List<UserSearchQuery> existingRecord = this.userSearchQueryRepo
                            .findAll(requestModel1.getFilterSpecification());

                    if (Objects.nonNull(existingRecord) && !existingRecord.isEmpty()) {
                        existingRecord.forEach(userQuery -> {
                            userQuery.setDefaultQuery(false);
                            userSearchQueryRepo.save(userQuery);
                        });
                    }

                }
                userSearchQuery = userSearchQueryRepo.save(userSearchQuery);
                userSearchCreatedBean = mapper.map(userSearchQuery, UserSearchQueryModel.class);
            } else {
                log.error(
                        "Record already exists with the same name. Please update existing record.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(
                        new ErrorModel(Constants.USER_SEARCH_QUERY_LABEL, Constants.RECORD_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            log.debug("Leave:UserSearchQueryServiceImpl:createSavedSearchQuery.");
            return userSearchCreatedBean;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.USER_SEARCH_QUERY_LABEL,
                    Constants.CREATE_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param email
     * @param userSearchQueryModel
     * @return UserSearchQueryModel.
     */
    @Override
    public UserSearchQueryModel updateSavedSearchQuery(final String email,
            @Valid final UserSearchQueryModel userSearchQueryModel) {
        log.debug("Entry:UserSearchQueryServiceImpl:updateSavedSearchQuery");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        UserSearchQueryModel searchQueryModel = new UserSearchQueryModel();
        try {
            userSearchQueryModel.setModifiedBy(email);
            UserSearchQuery searchQuery = mapper.map(userSearchQueryModel, UserSearchQuery.class);
            UserSearchQuery searchQueryRecord = userSearchQueryRepo
                    .findById(userSearchQueryModel.getId()).orElse(null);
            List<User> sharedUsers = searchQuery.getSharedToUsers();
            List<UserSearchQuery> newSavedQueryList = new ArrayList<>();
            if (null != searchQueryRecord) {

                if (!searchQueryRecord.isDefaultQuery() && userSearchQueryModel.isDefaultQuery()) {
                    Map<String, Object> request1 = RequestModifier.defaultRequestMapIfEmpty(null);
                    List<Map<String, Object>> filterConditions1 = new ArrayList<>();
                    filterConditions1.add(
                            RequestModifier.getfilterCondition("Boolean", "defaultQuery", true));
                    filterConditions1.add(RequestModifier.getfilterCondition("UUID", "user.id",
                            userSearchQueryModel.getUser().getId(), "eq"));
                    filterConditions1.add(RequestModifier.getfilterCondition("String", "screenName",
                            userSearchQueryModel.getScreenName(), "eq"));
                    RequestModel requestModel1 = RequestMapper.map(
                            RequestModifier.updateRequestMapWithAnd(request1, filterConditions1));
                    List<UserSearchQuery> existingRecord = this.userSearchQueryRepo
                            .findAll(requestModel1.getFilterSpecification());

                    if (Objects.nonNull(existingRecord) && !existingRecord.isEmpty()) {
                        existingRecord.forEach(userQuery -> {
                            userQuery.setDefaultQuery(false);
                            userSearchQueryRepo.save(userQuery);
                        });
                    }
                }

                if (Objects.nonNull(sharedUsers) && !sharedUsers.isEmpty()) {

                    deleteRecordForAlreadySharedUsers(userSearchQueryModel.getName(),
                            userSearchQueryModel.getUser().getId(),
                            userSearchQueryModel.getScreenName());

                    sharedUsers.forEach(user -> {
                        UserSearchQuery savedqueryNew = new UserSearchQuery();
                        savedqueryNew.setScreenName(userSearchQueryModel.getScreenName());
                        savedqueryNew.setName(userSearchQueryModel.getName().concat("_shared"));
                        savedqueryNew.setUser(user);
                        savedqueryNew.setCriteria(userSearchQueryModel.getCriteria());
                        savedqueryNew.setCreatedBy(email);
                        savedqueryNew.setCreatedDate(new Date());
                        savedqueryNew.setSharedByUser(searchQuery.getUser());
                        savedqueryNew.setShared(false);
                        savedqueryNew.setDefaultQuery(false);
                        newSavedQueryList.add(savedqueryNew);
                    });
                    if (Objects.nonNull(newSavedQueryList) && !newSavedQueryList.isEmpty()) {
                        List<UserSearchQuery> createdSavedQueryList = userSearchQueryRepo
                                .saveAll(newSavedQueryList);
                    }
                }

                UserSearchQuery searchQueryResult = userSearchQueryRepo.save(searchQuery);
                searchQueryModel = mapper.map(searchQueryResult, UserSearchQueryModel.class);
                log.debug("Leave:UserSearchQueryServiceImpl:updateSavedSearchQuery.");
            } else {
                log.error("Record does not exists for the Search Query.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.USER_SEARCH_QUERY_LABEL,
                        Constants.RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return searchQueryModel;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.USER_SEARCH_QUERY_LABEL,
                    Constants.UPDATE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param name
     * @param userId
     * @param screenName
     */
    private void deleteRecordForAlreadySharedUsers(final String name, final UUID userId,
            final String screenName) {
        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(
                RequestModifier.getfilterCondition("String", "name", name.concat("_shared"), "eq"));
        filterConditions
                .add(RequestModifier.getfilterCondition("UUID", "sharedByUser.id", userId, "eq"));
        filterConditions
                .add(RequestModifier.getfilterCondition("String", "screenName", screenName, "eq"));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        List<UserSearchQuery> existingRecordList = this.userSearchQueryRepo
                .findAll(requestModel.getFilterSpecification());

        if (Objects.nonNull(existingRecordList) && !existingRecordList.isEmpty()) {
            userSearchQueryRepo.deleteInBatch(existingRecordList);
        }

    }

}
