package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import com.alstom.applicationfactory.dwiservice.masterdata.model.UserSearchQueryModel;

public interface UserSearchQueryService {

    /**
     * @param email
     * @param screenName
     * @return list of UserSearchQueryModel.
     */
    List<UserSearchQueryModel> listSavedQuery(String email, String screenName);

    /**
     * @param id
     */
    void deleteUserQueryById(UUID id);

    /**
     * @param savedSearchId
     * @return UserSearchQueryModel.
     */
    UserSearchQueryModel viewSavedQuery(UUID savedSearchId);

    /**
     * @param email
     * @param userSearchQueryModel
     * @return UserSearchQueryModel.
     */
    UserSearchQueryModel createSavedSearchQuery(String email,
            @Valid UserSearchQueryModel userSearchQueryModel);

    /**
     * @param email
     * @param userSearchQueryModel
     * @return UserSearchQueryModel.
     */
    UserSearchQueryModel updateSavedSearchQuery(String email,
            @Valid UserSearchQueryModel userSearchQueryModel);

}
