package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TemplateModel;

public interface TemplateService {

    /**
     * @param requestModel
     * @return Template.
     */
    Object searchTemplate(RequestModel requestModel);

    /**
     * @param template
     * @return TemplateModel.
     */
    TemplateModel updateTemplate(TemplateModel template);

    /**
     * @param id
     */
    void deleteTemplate(UUID id);

    /**
     * @param template
     * @return TemplateModel.
     */
    TemplateModel saveTemplate(TemplateModel template);
}
