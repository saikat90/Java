package com.alstom.applicationfactory.dwiservice.masterdata.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dwifunctions")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Function implements Serializable {

    /**
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    @Column(unique = true, nullable = false)
    private String dwiFunctionName;

    /**
     */
    private boolean active;

    /**
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     */
    private String createdBy;

    /**
     */
    private String updatedBy;
}
