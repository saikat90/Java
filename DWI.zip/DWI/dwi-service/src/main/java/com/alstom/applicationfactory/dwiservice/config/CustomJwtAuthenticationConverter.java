package com.alstom.applicationfactory.dwiservice.config;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.BearerTokenError;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;

import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor
@Configuration
public class CustomJwtAuthenticationConverter
        implements Converter<Jwt, AbstractAuthenticationToken> {
    /**
     * JwtGrantedAuthoritiesConverter.
     */
    @Setter
    private Converter<Jwt, Collection<GrantedAuthority>> jwtGrantedAuthoritiesConverter = new JwtGrantedAuthoritiesConverter();
    /**
     * Admin service feign client.
     */
    @Autowired
    private AdminServiceClient adminServiceClient;
    /**
     * Authorization config containing property values.
     */
    @Autowired
    private AuthorizationConfig authConfig;

    /**
     * Converts jwt token.
     *
     * @param jwt Jwt token
     * @return JwtAuthenticationToken
     */
    @Override
    public final AbstractAuthenticationToken convert(@NonNull final Jwt jwt) {
        Collection<GrantedAuthority> authorities = this.extractAuthorities(jwt);
        return new JwtAuthenticationToken(jwt, authorities);
    }

    private Collection<GrantedAuthority> extractAuthorities(final Jwt jwt) {
        Collection<String> authorities = (Collection<String>) jwt.getClaims()
                .get(this.authConfig.getAuthoritiesProp());
        String email = (String) jwt.getClaims().get(this.authConfig.getEmailProp());
        if (Objects.isNull(authorities) || authorities.isEmpty()) {
            OAuth2Error invalidToken = new BearerTokenError(Constants.INVALID_TOKEN,
                    HttpStatus.UNAUTHORIZED, Constants.APP_ROLE_EMPTY, null);
            log.error(invalidToken.getDescription());
            throw new OAuth2AuthenticationException(invalidToken, invalidToken.getDescription(),
                    null);
        } else if (Objects.isNull(email) || email.isEmpty()) {
            OAuth2Error invalidToken = new BearerTokenError(Constants.INVALID_TOKEN,
                    HttpStatus.UNAUTHORIZED, Constants.TOKEN_EMAIL_EMPTY, null);
            log.error(invalidToken.getDescription());
            throw new OAuth2AuthenticationException(invalidToken, invalidToken.getDescription(),
                    null);
        } else {
            String appCode = authorities.stream().findFirst().orElse(null);
            List<String> extraAuthorities = (List<String>) this.adminServiceClient
                    .getAuthorities(String.join(Constants.SPACE_DELIMITER,
                            this.authConfig.getTokenType(), jwt.getTokenValue()), appCode, email);
            if (Objects.isNull(extraAuthorities) || extraAuthorities.isEmpty()) {
                OAuth2Error invalidToken = new BearerTokenError(Constants.INVALID_USER,
                        HttpStatus.UNAUTHORIZED,
                        String.format(Constants.USER_NOT_REGISTERED, email), null);
                log.error(invalidToken.getDescription());
                throw new OAuth2AuthenticationException(invalidToken, invalidToken.getDescription(),
                        null);
            } else {
                authorities.addAll(extraAuthorities);
            }
        }
        return authorities.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
    }
}
