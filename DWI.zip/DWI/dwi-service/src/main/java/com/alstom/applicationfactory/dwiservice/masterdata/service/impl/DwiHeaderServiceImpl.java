package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.DwiHeader;
import com.alstom.applicationfactory.dwiservice.masterdata.model.DwiHeaderModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.DwiHeaderRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.DwiHeaderService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "dwiHeaderService")
@Transactional
@Slf4j
public class DwiHeaderServiceImpl implements DwiHeaderService {

    /**
     * DwiHeaderRepository.
     */
    @Autowired
    private DwiHeaderRepository dwiHeaderRepository;

    /**
     * @param request
     * @return findAll.
     */
    @Override
    public Object findAll(final RequestModel request) {

        log.debug("Entry:DwiHeaderServiceImpl:findAll.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            result = mapper.map(
                    this.dwiHeaderRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
        } else {
            result = this.dwiHeaderRepository.findAll(request.getFilterSpecification()).stream()
                    .map(dwiHeader -> mapper.map(dwiHeader, DwiHeaderModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:DwiHeaderServiceImpl:findAll.");
        return result;
    }

    /**
     * @param dwiHeaderModel
     * @return DwiHeaderModel.
     */
    @Override
    public DwiHeaderModel createDwiHeader(final DwiHeaderModel dwiHeaderModel) {
        log.debug("Entry:DwiHeaderServiceImpl:createDwiHeader.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        DwiHeaderModel dwiHeaderCreatedBean = new DwiHeaderModel();
        DwiHeader dwiHeader = mapper.map(dwiHeaderModel, DwiHeader.class);

        try {
            dwiHeader = dwiHeaderRepository.save(dwiHeader);
            dwiHeaderCreatedBean = mapper.map(dwiHeader, DwiHeaderModel.class);
        } catch (Exception e) {
            log.error("Error while creating record for DwiHeader.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(
                    new ErrorModel(Constants.DWI_HEADER_LABEL, Constants.DWI_HEADER_CREATE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:DwiHeaderServiceImpl:createDwiHeader.");
        return dwiHeaderCreatedBean;
    }

    /**
     * @param dwiHeaderModel
     * @return DwiHeaderModel.
     */
    @Override
    public DwiHeaderModel updateDwiHeader(final DwiHeaderModel dwiHeaderModel) {
        log.debug("Entry:DwiHeaderServiceImpl:UpdateDwiHeader.");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        DwiHeaderModel dwiHeaderBean = new DwiHeaderModel();
        try {
            DwiHeader dwiHeader = mapper.map(dwiHeaderModel, DwiHeader.class);
            DwiHeader dwiHeaderRecord = dwiHeaderRepository.findById(dwiHeaderModel.getId())
                    .orElse(null);
            if (null != dwiHeaderRecord) {
                DwiHeader dwiHeaderResult = dwiHeaderRepository.save(dwiHeader);
                dwiHeaderBean = mapper.map(dwiHeaderResult, DwiHeaderModel.class);
                log.debug("Leave:DwiDwiHeaderServiceImpl:UpdateDwiHeader");
            } else {
                log.error("Record does not exists for the DwiHeader.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.DWI_HEADER_LABEL,
                        Constants.DWI_HEADER_RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return dwiHeaderBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.DWI_HEADER_LABEL,
                    Constants.DWI_HEADER_UPDATE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }

    }

    /**
     * @param dwiHeaderId
     * @return DwiHeaderModel.
     */
    @Override
    public DwiHeaderModel viewDwiHeader(final UUID dwiHeaderId) {
        log.debug("Entry:DwiHeaderServiceImpl:ViewDwiHeader.");
        DwiHeader dwiHeader;
        DwiHeaderModel dwiHeaderBean = new DwiHeaderModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            dwiHeader = dwiHeaderRepository.findById(dwiHeaderId).orElse(null);
            if (null != dwiHeader) {
                dwiHeaderBean = mapper.map(dwiHeader, DwiHeaderModel.class);
                log.debug("Leave:DwiHeaderServiceImpl:ViewDwiHeader.");
            }
            return dwiHeaderBean;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.DWI_HEADER_LABEL,
                    Constants.DWI_HEADER_VIEW_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param dwiHeaderId
     */
    @Override
    public void deleteDwiHeaderById(final UUID dwiHeaderId) {
        log.debug("Entry:DwiHeaderServiceImpl:DeleteDwiHeader.");
        try {
            dwiHeaderRepository.deleteById(dwiHeaderId);
            log.debug("Leave:DwiHeaderServiceImpl:DeleteDwiHeader.");
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL, Constants.DELETE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }
}
