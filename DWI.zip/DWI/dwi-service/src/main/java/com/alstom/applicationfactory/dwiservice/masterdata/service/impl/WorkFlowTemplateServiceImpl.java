package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplateDesc;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.WorkFlowTemplateService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "WorkFlowTemplateService")
@Transactional
@Slf4j
public class WorkFlowTemplateServiceImpl implements WorkFlowTemplateService {

    /**
     * WorkFlowTemplateRepository.
     */
    @Autowired
    private WorkFlowTemplateRepository workFlowTemplateRepository;

    /**
     * @param wfTemplateBean
     * @return WorkFlowTemplateModel.
     */
    @Override
    public WorkFlowTemplateModel createWorkFlowTemplate(
            final WorkFlowTemplateModel wfTemplateBean) {

        log.debug("Entry:DwiWorkFlowTemplateServiceImpl:createWorkFlowTemplate.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        WorkFlowTemplate wfTemplate = mapper.map(wfTemplateBean, WorkFlowTemplate.class);

        WorkFlowTemplateModel craetedWorkFlowTemplateModel = new WorkFlowTemplateModel();
        if (!Objects.isNull(wfTemplateBean.getActions())) {
            WorkFlowTemplate finalwfTemplate = wfTemplate;
            List<WorkFlowTemplateDesc> actions = wfTemplateBean.getActions().stream()
                    .map(workFlowTemplateDescModel -> {
                        WorkFlowTemplateDesc action = mapper.map(workFlowTemplateDescModel,
                                WorkFlowTemplateDesc.class);
                        action.setWorkFlowTemplate(finalwfTemplate);
                        return action;
                    }).collect(Collectors.toList());
            wfTemplate.setActions(actions);
        }

        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("String", "workFlowTemplateName",
                wfTemplateBean.getWorkFlowTemplateName(), "eq"));
        filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active", true));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        long count = this.workFlowTemplateRepository.count(requestModel.getFilterSpecification());

        if (count == 0) {
            wfTemplate = workFlowTemplateRepository.save(wfTemplate);
            craetedWorkFlowTemplateModel = mapper.map(wfTemplate, WorkFlowTemplateModel.class);
        } else {
            log.error(
                    "Record already exists for the WorkFlowTemplate. Please update existing value.");
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.WORKFLOW_TEMPLATE_LABEL, Constants.RECORD_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:DwiWorkFlowTemplateServiceImpl:createWorkFlowTemplate.");
        return craetedWorkFlowTemplateModel;
    }

    /**
     * @param wfTemplateModel
     * @return WorkFlowTemplateModel.
     */
    @Override
    public WorkFlowTemplateModel updateWorkFlowTemplate(
            final WorkFlowTemplateModel wfTemplateModel) {
        log.debug("Entry:DwiWorkFlowTemplateServiceImpl:updateWorkFlowTemplate.");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplateModel wfTemplateBean = new WorkFlowTemplateModel();
        try {
            WorkFlowTemplate wfTemplate = mapper.map(wfTemplateModel, WorkFlowTemplate.class);
            WorkFlowTemplate wfTemplateRecord = workFlowTemplateRepository
                    .findById(wfTemplateModel.getId()).orElse(null);
            if (null != wfTemplateRecord) {

                if (!Objects.isNull(wfTemplate.getActions())) {
                    wfTemplate.getActions().forEach(action -> {
                        action.setWorkFlowTemplate(wfTemplate);
                    });
                }

                WorkFlowTemplate wfTemplateResult = workFlowTemplateRepository.save(wfTemplate);
                wfTemplateBean = mapper.map(wfTemplateResult, WorkFlowTemplateModel.class);
                log.debug("Leave:DwiWorkFlowTemplateServiceImpl:updateWorkFlowTemplate.");
            } else {
                log.error("Record does not exists for the WorkFlowTemplate.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.WORKFLOW_TEMPLATE_LABEL,
                        Constants.RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return wfTemplateBean;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.WORKFLOW_TEMPLATE_LABEL,
                    Constants.UPDATE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param request
     * @return searchWorkFlowTemplate.
     */
    @Override
    public Object searchWorkFlowTemplate(final RequestModel request) {
        log.debug("Entry:DwiWorkFlowTemplateServiceImpl:searchWorkFlowTemplate.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(this.workFlowTemplateRepository
                    .findAll(request.getFilterSpecification(), pageable), ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(wfTemplate -> mapper.map(wfTemplate, WorkFlowTemplateModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.workFlowTemplateRepository.findAll(request.getFilterSpecification())
                    .stream().map(wfTemplate -> mapper.map(wfTemplate, WorkFlowTemplateModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:DwiWorkFlowTemplateServiceImpl:searchWorkFlowTemplate.");
        return result;
    }

    /**
     * @param wfTemplateId
     * @return WorkFlowTemplateModel.
     */
    @Override
    public WorkFlowTemplateModel viewWorkFlowTemplate(final UUID wfTemplateId) {
        log.debug("Entry:DwiWorkFlowTemplateServiceImpl:ViewWorkFlowTemplate.");
        WorkFlowTemplate wfTemplate;
        WorkFlowTemplateModel wfTemplateBean = new WorkFlowTemplateModel();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            wfTemplate = workFlowTemplateRepository.findById(wfTemplateId).orElse(null);
            if (null != wfTemplate) {
                wfTemplateBean = mapper.map(wfTemplate, WorkFlowTemplateModel.class);
                log.debug("Leave:DwiWorkFlowTemplateServiceImpl:ViewWorkFlowTemplate.");
            }
            return wfTemplateBean;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.WORKFLOW_TEMPLATE_LABEL,
                    Constants.VIEW_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param wfTemplateId
     */
    @Override
    public void deleteWorkFlowTemplateById(final UUID wfTemplateId) {
        log.debug("Entry:DwiWorkFlowTemplateServiceImpl:DeleteWorkFlowTemplate.");
        try {
            workFlowTemplateRepository.deleteById(wfTemplateId);
            log.debug("Leave:DwiWorkFlowTemplateServiceImpl:DeleteWorkFlowTemplate.");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.WORKFLOW_TEMPLATE_LABEL,
                    Constants.DELETE_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }
}
