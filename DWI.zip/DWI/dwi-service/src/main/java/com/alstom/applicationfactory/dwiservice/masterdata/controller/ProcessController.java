package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProcessRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProcessService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/process")
@Slf4j
public class ProcessController {

    /**
     * ProcessService.
     */
    @Autowired
    private ProcessService processService;

    /**
     * ProcessRepository.
     */
    @Autowired
    private ProcessRepository processRepository;

    /**
     * @param process
     * @return ProcessModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProcessModel createProcess(@RequestBody @Valid final ProcessModel process) {
        log.debug("Entry:DwiProcessController:createProcess.");
        ProcessModel createdProcessModel = processService.createProcess(process);
        log.debug("Leave:DwiProcessController:createProcess.");
        return createdProcessModel;
    }

    /**
     * @param process
     * @return updated ProcessModel.
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProcessModel updateProcess(@RequestBody @Valid final ProcessModel process) {
        log.debug("Entry:ProcessMasterController:updateProcess.");
        ProcessModel updatedProcessModel = processService.updateProcess(process);
        log.debug("Leave:ProcessMasterController:updateProcess.");
        return updatedProcessModel;
    }

    /**
     * @param request
     * @return process object.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchProcess(@RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:DwiProcessController:searchProcess.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = processService.searchProcess(requestModel);
        log.debug("Leave:DwiProcessController:searchProcess.");
        return res;
    }

    /**
     * @return process onject.
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchProcess() {
        log.debug("Entry:DwiProcessController:GetMapping:searchProcess.");
        Object res = processRepository.findAll();
        log.debug("Leave:DwiProcessController:GetMapping:searchProcess.");
        return res;
    }

    /**
     * @param id
     * @return ProcessModel.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProcessModel viewProcess(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiProcessController:viewProcess.");
        ProcessModel processModel = processService.viewProcess(id);
        log.debug("Leave:DwiProcessController:viewProcess.");
        return processModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteProcessById(@PathVariable("id") final UUID id) {
        log.debug("Entry:ProcessMasterController:deleteProcess.");
        this.processService.deleteProcessById(id);
        log.debug("Leave:ProcessMasterController:deleteProcess.");
    }

    /**
     * @param fleetId
     * @param request
     * @return all process for a fleet.
     */
    @PostMapping("/{fleetId}/list")
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public Object getAllProcessForFleet(@PathVariable("fleetId") final UUID fleetId,
            @RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:DwiProcessController:getAllProcessForFleet.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "fleet.id", fleetId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object res = this.processService.searchProcess(requestModel);
        log.debug("Leave:DwiProcessController:getAllProcessForFleet.");
        return res;
    }
}
