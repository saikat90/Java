package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.instruction.entity.Instructions;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsListModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionsRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.AuthorManagementService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "authorManagementService")
@Transactional
@Slf4j
public class AuthorManagementServiceImpl implements AuthorManagementService {

    /**
     * InstructionsRepository.
     */
    @Autowired
    private InstructionsRepository instructionsRepository;

    /**
     * @param request
     * @return searchAuthorManagement.
     */
    @Override
    public Object searchAuthorManagement(final RequestModel request) {
        log.debug("Entry:AuthorManagementServiceImpl:searchAuthorManagement.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.instructionsRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(author -> mapper.map(author, InstructionsModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.instructionsRepository.findAll(request.getFilterSpecification()).stream()
                    .map(author -> mapper.map(author, InstructionsModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:AuthorManagementServiceImpl:searchAuthorManagement.");
        return result;
    }

    /**
     * @param instructionModel
     * @return InstructionsModel.
     */
    @Override
    public InstructionsModel updateAuthorManagement(final InstructionsModel instructionModel) {

        log.debug("Entry:AuthorManagementServiceImpl:updateInstruction.");

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        InstructionsModel instructionBean = new InstructionsModel();
        try {
            Instructions newInstruction = mapper.map(instructionModel, Instructions.class);

            Instructions instructionOldRecord = instructionsRepository
                    .findById(instructionModel.getId()).orElse(null);
            if (null != instructionOldRecord) {

                Instructions instructionResult = instructionsRepository.save(newInstruction);
                instructionBean = mapper.map(instructionResult, InstructionsModel.class);
                log.debug("Leave:AuthorManagementServiceImpl:updateInstruction.");
            } else {
                log.error("Record does not exists for the author Management.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.AUTHOR_MANAGMENT_LABEL,
                        Constants.AUTHOR_MANAGMENT_RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            return instructionBean;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.AUTHOR_MANAGMENT_LABEL,
                    Constants.AUTHOR_MANAGMENT_UPDATE_ERROR);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param id
     * @param userModel
     * @return InstructionsListModel.
     */
    @Override
    public InstructionsListModel updateAuthor(final UUID id, @Valid final UserModel userModel) {
        log.debug("Entry:AuthorManagementServiceImpl:updateAuthor.");
        ModelMapper mapper = new ModelMapper();
        InstructionsListModel instructionModel = new InstructionsListModel();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Instructions instruction = this.instructionsRepository.findById(id).orElse(null);
        if (instruction != null) {
            User newAuthor = mapper.map(userModel, User.class);
            instruction.setAuthor(newAuthor);
            instruction = instructionsRepository.save(instruction);
            instructionModel = mapper.map(instruction, InstructionsListModel.class);
            log.debug("Entry:AuthorManagementServiceImpl:updateAuthor.");
        }
        return instructionModel;
    }

}
