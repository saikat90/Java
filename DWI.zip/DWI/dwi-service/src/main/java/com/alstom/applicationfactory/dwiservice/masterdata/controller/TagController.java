package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ExcelException;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TagModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.TagService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/tag")
@Slf4j
public class TagController {

    /**
     * TagService.
     */
    @Autowired
    private TagService tagService;

    /**
     * @param tag
     * @return TagModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public TagModel createTag(@RequestBody @Valid final TagModel tag) {
        log.debug("Entry:TagController:createTag.");
        TagModel tagModel = tagService.createTag(tag);
        log.debug("Leave:TagController:createTag.");
        return tagModel;
    }

    /**
     * @param process
     * @return TagModel
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public TagModel updateTag(@RequestBody @Valid final TagModel process) {
        log.debug("Entry:TagController:updateTag.");
        TagModel tagModel = tagService.updateTag(process);
        log.debug("Leave:TagController:updateTag.");
        return tagModel;
    }

    /**
     * @param request
     * @return TagModel
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchTag(@RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:TagController:searchTag.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = tagService.searchTag(requestModel);
        log.debug("Leave:TagController:searchTag.");
        return res;
    }

    /**
     * @param id
     * @return TagModel
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public TagModel viewTag(@PathVariable("id") final UUID id) {
        log.debug("Entry:TagController:viewTag.");
        TagModel tagModel = tagService.viewTag(id);
        log.debug("Leave:TagController:viewTag.");
        return tagModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteTag(@PathVariable("id") final UUID id) {
        log.debug("Entry:TagController:deleteTag.");
        tagService.deleteTag(id);
        log.debug("Leave:TagController:deleteTag.");
    }

    /**
     * @param request
     * @return TagModel object
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getAllTag(@RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:TagController:getAllTag.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = tagService.searchTag(requestModel);
        log.debug("Leave:TagController:getAllTag.");
        return res;
    }

    /**
     * @param file
     * @return ExcelException
     */
    @PostMapping("/import")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ExcelException importExcel(@RequestParam("file") final MultipartFile file) {
        log.debug("Entry:DwiInstructionsController:importExcel.");
        return this.tagService.importExcel(file);

    }
}
