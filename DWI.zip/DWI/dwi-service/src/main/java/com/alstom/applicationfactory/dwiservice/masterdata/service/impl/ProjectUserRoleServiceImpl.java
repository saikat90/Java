package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.ProjectUserRole;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectUserRoleModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectUserRoleRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProjectUserRoleService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "projectUserRoleService")
@Transactional
@Slf4j
public class ProjectUserRoleServiceImpl implements ProjectUserRoleService {

    /**
     * ProjectUserRoleRepository.
     */
    @Autowired
    private ProjectUserRoleRepository projUserRoleRepository;

    /**
     * ProjectRepository.
     */
    @Autowired
    private ProjectRepository projRepository;
    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;

    /**
     * @param projId
     * @param userRoleMap
     * @return ProjectUserRoleModel.
     */
    @Override
    public Map<String, List<ProjectUserRoleModel>> userRoleActions(final UUID projId,
            @Valid final Map<String, List<ProjectUserRoleModel>> userRoleMap) {
        log.debug("Entry:DwiProjectUserRoleServiceImpl:userRoleActions.");
        Project project;
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        try {
            project = projRepository.findById(projId).orElse(null);

            if (null != project) {
                List<ProjectUserRoleModel> updateActionBeans = userRoleMap.get("edited");
                List<ProjectUserRoleModel> deleteActionBeans = userRoleMap.get("deleted");
                List<ProjectUserRoleModel> addActionBeans = userRoleMap.get("added");

                List<ProjectUserRole> updatedActions = updateActionBeans.stream()
                        .map(actionBean -> {
                            ProjectUserRole action = mapper.map(actionBean, ProjectUserRole.class);
                            action.setProject(project);
                            return action;
                        }).collect(Collectors.toList());

                if (!updatedActions.isEmpty()) {
                    updateActionBeans = projUserRoleRepository.saveAll(updatedActions).stream()
                            .map(action -> mapper.map(action, ProjectUserRoleModel.class))
                            .collect(Collectors.toList());
                    userRoleMap.put("edited", updateActionBeans);
                }

                List<ProjectUserRole> deletedActions = deleteActionBeans.stream()
                        .map(actionBean -> {
                            ProjectUserRole action = mapper.map(actionBean, ProjectUserRole.class);
                            action.setProject(project);
                            return action;
                        }).collect(Collectors.toList());

                if (!deletedActions.isEmpty()) {
                    deleteActionBeans = deletedActions.stream()
                            .map(action -> mapper.map(action, ProjectUserRoleModel.class))
                            .collect(Collectors.toList());
                    userRoleMap.put("deleted", deleteActionBeans);
                    projUserRoleRepository.deleteInBatch(deletedActions);
                }
                List<ProjectUserRole> addedActions = addActionBeans.stream().map(actionBean -> {
                    ProjectUserRole action = mapper.map(actionBean, ProjectUserRole.class);
                    action.setProject(project);
                    return action;
                }).collect(Collectors.toList());

                if (!addedActions.isEmpty()) {
                    addActionBeans = projUserRoleRepository.saveAll(addedActions).stream()
                            .map(action -> mapper.map(action, ProjectUserRoleModel.class))
                            .collect(Collectors.toList());
                    userRoleMap.put("added", addActionBeans);
                }
            }
            log.debug("Leave:DwiProjectUserRoleServiceImpl:userRoleActions.");
            return userRoleMap;
        } catch (Exception e) {
            List<ErrorModel> errorList = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.PROJECT_USER_ROLE_LABEL,
                    Constants.INTERNAL_ERROR_MSG);
            errorList.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
        }
    }

    /**
     * @param projectId
     * @param request
     * @return searchProjectUserRoles
     */
    @Override
    public Object searchProjectUserRoles(final UUID projectId, final RequestModel request) {
        log.debug("Entry:DwiProjectUserRoleServiceImpl:searchProjectUserRoles.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            result = mapper.map(
                    this.projUserRoleRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
        } else {
            List<ProjectUserRole> userRoles = this.projUserRoleRepository
                    .findAll(request.getFilterSpecification());
            result = userRoles.stream()
                    .map(userRole -> mapper.map(userRole, ProjectUserRoleModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:DwiProjectUserRoleServiceImpl:searchProjectUserRoles.");
        return result;
    }

    /**
     * @param projectId
     * @param role
     * @return UserModel
     */
    @Override
    public List<UserModel> getUsersForRole(final UUID projectId, final String role) {
        log.debug("Entry:DwiProjectUserRoleServiceImpl:getUsersForRole.");
        ModelMapper mapper = new ModelMapper();
        List<ProjectUserRole> projUserRoles = projUserRoleRepository
                .findByProjectIdAndRole(projectId, role);
        List<UserModel> usersModelList = new ArrayList<>();
        if (Objects.nonNull(projUserRoles) && !projUserRoles.isEmpty()) {
            usersModelList = projUserRoles.stream().map(user -> {
                UserModel userrec = mapper.map(user.getUser(), UserModel.class);
                return userrec;
            }).collect(Collectors.toList());
        }
        log.debug("Entry:DwiProjectUserRoleServiceImpl:getUsersForRole.");
        return usersModelList;
    }

    /**
     * @param email
     * @return list of UUID.
     */
    @Override
    public List<UUID> getProjectForUser(final String email) {
        log.debug("Entry:DwiProjectUserRoleServiceImpl:getProjectForUser.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        User user = null;
        try {
            user = userRepository.findByEmail(email).get(0);
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel("User",
                    "User not present in the system for the email: " + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        List<ProjectUserRole> projUserRoles = projUserRoleRepository.findByUserId(user.getId());
        List<UUID> projectIdList = new ArrayList<>();
        if (Objects.nonNull(projUserRoles) && !projUserRoles.isEmpty()) {
            projectIdList = projUserRoles.stream().map(projUser -> {
                UUID projId = projUser.getProject().getId();
                return projId;
            }).collect(Collectors.toList());
        }
        log.debug("Leave:DwiProjectUserRoleServiceImpl:getProjectForUser.");
        return projectIdList;
    }

    /**
     * @param email
     * @return list of ProjectModel.
     */
    @Override
    public List<ProjectModel> getProjectModelForUser(final String email) {
        log.debug("Entry:DwiProjectUserRoleServiceImpl:getProjectModelForUser.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        User user = null;
        try {
            user = userRepository.findByEmail(email).get(0);
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.PROJECT_USER_ROLE_LABEL,
                    Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        List<ProjectUserRole> projUserRoles = projUserRoleRepository.findByUserId(user.getId());
        List<ProjectModel> projectModelList = new ArrayList<>();
        if (Objects.nonNull(projUserRoles) && !projUserRoles.isEmpty()) {
            projectModelList = projUserRoles.stream().map(projUser -> {
                ProjectModel projModel = mapper.map(projUser.getProject(), ProjectModel.class);
                return projModel;
            }).collect(Collectors.toList());
        }
        log.debug("Leave:DwiProjectUserRoleServiceImpl:getProjectModelForUser.");
        return projectModelList;
    }
}
