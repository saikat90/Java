package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.masterdata.model.UserSearchQueryModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.UserSearchQueryService;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/userSearchQuery")
@Slf4j
@RefreshScope
public class UserSearchQueryController {

    /**
     * UserSearchQueryService.
     */
    @Autowired
    private UserSearchQueryService userSearchQueryService;
    /**
     * email address of user.
     */
    @Value("${application.factory.jwt.emailProp}")
    private String emailProp;

    /**
     * @param screenName
     * @param authentication
     * @return list of user search query model.
     */
    @GetMapping("/list/{screen}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public List<UserSearchQueryModel> listSavedQuery(
            @PathVariable("screen") final String screenName, final Authentication authentication) {
        log.debug("Entry:UserSearchQueryController:listSavedQuery.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        List<UserSearchQueryModel> savedQueryModelList = userSearchQueryService
                .listSavedQuery(email, screenName);
        log.debug("Leave:UserSearchQueryController:listSavedQuery.");
        return savedQueryModelList;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteUserQueryById(@PathVariable("id") final UUID id) {
        log.debug("Entry:UserSearchQueryController:deleteUserQueryById.");
        this.userSearchQueryService.deleteUserQueryById(id);
        log.debug("Leave:UserSearchQueryController:deleteUserQueryById.");
    }

    /**
     * @param savedSearchId
     * @return UserSearchQueryModel.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public UserSearchQueryModel viewSavedQuery(@PathVariable("id") final UUID savedSearchId) {
        log.debug("Entry:UserSearchQueryController:viewSavedQuery.");
        UserSearchQueryModel savedQueryModel = userSearchQueryService.viewSavedQuery(savedSearchId);
        log.debug("Leave:UserSearchQueryController:viewSavedQuery.");
        return savedQueryModel;
    }

    /**
     * @param userSearchQueryModel
     * @param authentication
     * @return UserSearchQueryModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public UserSearchQueryModel createSavedSearchQuery(
            @RequestBody @Valid final UserSearchQueryModel userSearchQueryModel,
            final Authentication authentication) {
        log.debug("Entry:UserSearchQueryController:createSavedSearchQuery.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        UserSearchQueryModel savedQueryModel = userSearchQueryService.createSavedSearchQuery(email,
                userSearchQueryModel);
        log.debug("Leave:UserSearchQueryController:createSavedSearchQuery.");
        return savedQueryModel;
    }

    /**
     * @param userSearchQueryModel
     * @param authentication
     * @return UserSearchQueryModel
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public UserSearchQueryModel updateSavedSearchQuery(
            @RequestBody @Valid final UserSearchQueryModel userSearchQueryModel,
            final Authentication authentication) {
        log.debug("Entry:UserSearchQueryController:updateSavedSearchQuery.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        UserSearchQueryModel savedQueryModel = userSearchQueryService.updateSavedSearchQuery(email,
                userSearchQueryModel);
        log.debug("Leave:UserSearchQueryController:updateSavedSearchQuery.");
        return savedQueryModel;
    }
}
