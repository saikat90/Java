package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserSearchQueryModel {

    /**
     */
    private UUID id;

    /**
     */
    private UserModel user;

    /**
     */
    private String name;

    /**
     */
    private String screenName;

    /**
     */
    private String criteria;

    /**
     */
    private boolean defaultQuery;

    /**
     */
    private boolean shared;

    /**
     */
    private UserModel sharedByUser;

    /**
     */
    private List<UserModel> sharedToUsers = Collections.EMPTY_LIST;

    /**
     */
    private Date createdDate;

    /**
     */
    private Date modifiedDate;

    /**
     */
    private String createdBy;

    /**
     */
    private String modifiedBy;

}
