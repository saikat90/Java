package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;

public interface WorkFlowTemplateDescService {

    /**
     * @param wfTemplateId
     * @param actionBeans
     * @return list of WorkFlowTemplateDescModel.
     */
    List<WorkFlowTemplateDescModel> createWorkFlowTemplateDesc(UUID wfTemplateId,
            List<WorkFlowTemplateDescModel> actionBeans);

    /**
     * @param wfTemplateId
     * @param actionMap
     * @return WorkFlowTemplateDescModel.
     */
    Map<String, List<WorkFlowTemplateDescModel>> updateWorkFlowTemplateDesc(UUID wfTemplateId,
            Map<String, List<WorkFlowTemplateDescModel>> actionMap);

    /**
     * @param wfTemplateId
     * @param requestModel
     * @return searchWorkFlowTemplateDesc.
     */
    Object searchWorkFlowTemplateDesc(UUID wfTemplateId, RequestModel requestModel);

    /**
     * @param workFlowTemplateDescId
     * @return WorkFlowTemplateDescModel.
     */
    WorkFlowTemplateDescModel viewWorkFlowTemplateDesc(UUID workFlowTemplateDescId);

    /**
     * @param workFlowTemplateDescId
     */
    void deleteWorkFlowTemplateDescById(UUID workFlowTemplateDescId);
}
