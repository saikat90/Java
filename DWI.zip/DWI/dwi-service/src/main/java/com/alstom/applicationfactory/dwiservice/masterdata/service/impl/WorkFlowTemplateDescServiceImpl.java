package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplateDesc;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateDescRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.WorkFlowTemplateDescService;

import lombok.extern.slf4j.Slf4j;

@Service(value = "workFlowTemplateDescService")
@Transactional
@Slf4j
public class WorkFlowTemplateDescServiceImpl implements WorkFlowTemplateDescService {

    /**
     * WorkFlowTemplateRepository.
     */
    @Autowired
    private WorkFlowTemplateRepository wfTemplateRepository;

    /**
     * WorkFlowTemplateDescRepository.
     */
    @Autowired
    private WorkFlowTemplateDescRepository wfTemplateDescRepository;

    /**
     * @param workFlowTemplateDescId
     * @return WorkFlowTemplateDescModel
     */
    @Override
    public WorkFlowTemplateDescModel viewWorkFlowTemplateDesc(final UUID workFlowTemplateDescId) {
        log.debug("Entry:DwiWorkFlowTemplateDescServiceImpl:viewWorkFlowTemplateDesc.");
        WorkFlowTemplateDesc action;
        WorkFlowTemplateDescModel actionBean = null;
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        try {
            action = wfTemplateDescRepository.findById(workFlowTemplateDescId).orElse(null);
            if (null != action) {
                actionBean = mapper.map(action, WorkFlowTemplateDescModel.class);
                log.debug("Leave:DwiWorkFlowTemplateDescServiceImpl:viewWorkFlowTemplateDesc.");
            }
            return actionBean;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.WORKFLOW_TEMPLATE_DESC_LABEL,
                    Constants.VIEW_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param workFlowTemplateDescId
     */
    @Override
    public void deleteWorkFlowTemplateDescById(final UUID workFlowTemplateDescId) {
        log.debug("Entry:DwiWorkFlowTemplateDescServiceImpl:deleteWorkFlowTemplateDescById.");
        try {
            wfTemplateDescRepository.deleteById(workFlowTemplateDescId);
            log.debug("Leave:DwiWorkFlowTemplateDescServiceImpl:deleteWorkFlowTemplateDescById.");
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.WORKFLOW_TEMPLATE_DESC_LABEL,
                    Constants.DELETE_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param wfTemplateId
     * @param actionBeans
     * @return
     */
    @Override
    public List<WorkFlowTemplateDescModel> createWorkFlowTemplateDesc(final UUID wfTemplateId,
            final List<WorkFlowTemplateDescModel> actionBeans) {
        log.debug("Entry:DwiWorkFlowTemplateDescServiceImpl:createWorkFlowTemplateDesc.");
        WorkFlowTemplate wfTemplate;
        List<WorkFlowTemplateDesc> actions = new ArrayList<>();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        List<WorkFlowTemplateDescModel> workFlowTemplateDescModelList = new ArrayList<WorkFlowTemplateDescModel>();
        try {
            wfTemplate = wfTemplateRepository.findById(wfTemplateId).orElse(null);
            if (null != wfTemplate) {
                actions = actionBeans.stream().map(actionBean -> {
                    WorkFlowTemplateDesc action = mapper.map(actionBean,
                            WorkFlowTemplateDesc.class);
                    action.setWorkFlowTemplate(wfTemplate);
                    return action;
                }).collect(Collectors.toList());
            }
            if (!actions.isEmpty()) {
                actions = wfTemplateDescRepository.saveAll(actions);
                workFlowTemplateDescModelList = actions.stream()
                        .map(action -> mapper.map(action, WorkFlowTemplateDescModel.class))
                        .collect(Collectors.toList());
            } else {
                List<ErrorModel> errorList = new ArrayList<>();
                ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL,
                        Constants.RECORD_NOT_EXISTS);
                errorList.add(errorModel);
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errorList);
            }
            log.debug("Leave:DwiWorkFlowTemplateDescServiceImpl:createWorkFlowTemplateDesc.");
            return workFlowTemplateDescModelList;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.WORKFLOW_TEMPLATE_DESC_LABEL,
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param wfTemplateId
     * @param actionMap
     * @return list of WorkFlowTemplateDescModel
     */
    @Override
    public Map<String, List<WorkFlowTemplateDescModel>> updateWorkFlowTemplateDesc(
            final UUID wfTemplateId, final Map<String, List<WorkFlowTemplateDescModel>> actionMap) {
        log.debug("Entry:DwiWorkFlowTemplateDescServiceImpl:updateWorkFlowTemplateDesc.");
        WorkFlowTemplate wfTemplate;
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        try {
            wfTemplate = wfTemplateRepository.findById(wfTemplateId).orElse(null);

            if (null != wfTemplate) {
                List<WorkFlowTemplateDescModel> updateActionBeans = actionMap.get("edited");
                List<WorkFlowTemplateDescModel> deleteActionBeans = actionMap.get("deleted");
                List<WorkFlowTemplateDescModel> addActionBeans = actionMap.get("added");

                List<WorkFlowTemplateDesc> updatedActions = updateActionBeans.stream()
                        .map(actionBean -> {
                            WorkFlowTemplateDesc action = mapper.map(actionBean,
                                    WorkFlowTemplateDesc.class);
                            action.setWorkFlowTemplate(wfTemplate);
                            return action;
                        }).collect(Collectors.toList());

                if (!updatedActions.isEmpty()) {
                    updateActionBeans = wfTemplateDescRepository.saveAll(updatedActions).stream()
                            .map(action -> mapper.map(action, WorkFlowTemplateDescModel.class))
                            .collect(Collectors.toList());
                    actionMap.put("edited", updateActionBeans);
                }

                List<WorkFlowTemplateDesc> deletedActions = deleteActionBeans.stream()
                        .map(actionBean -> {
                            WorkFlowTemplateDesc action = mapper.map(actionBean,
                                    WorkFlowTemplateDesc.class);
                            action.setWorkFlowTemplate(wfTemplate);
                            return action;
                        }).collect(Collectors.toList());

                if (!deletedActions.isEmpty()) {
                    deleteActionBeans = deletedActions.stream()
                            .map(action -> mapper.map(action, WorkFlowTemplateDescModel.class))
                            .collect(Collectors.toList());
                    actionMap.put("deleted", deleteActionBeans);
                    wfTemplateDescRepository.deleteInBatch(deletedActions);
                }
                List<WorkFlowTemplateDesc> addedActions = addActionBeans.stream()
                        .map(actionBean -> {
                            WorkFlowTemplateDesc action = mapper.map(actionBean,
                                    WorkFlowTemplateDesc.class);
                            action.setWorkFlowTemplate(wfTemplate);
                            return action;
                        }).collect(Collectors.toList());

                if (!addedActions.isEmpty()) {
                    addActionBeans = wfTemplateDescRepository.saveAll(addedActions).stream()
                            .map(action -> mapper.map(action, WorkFlowTemplateDescModel.class))
                            .collect(Collectors.toList());
                    actionMap.put("added", addActionBeans);
                }
            }
            log.debug("Leave:DwiWorkFlowTemplateDescServiceImpl:updateWorkFlowTemplateDesc.");
            return actionMap;
        } catch (Exception e) {
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.WORKFLOW_TEMPLATE_DESC_LABEL,
                    Constants.INTERNAL_ERROR_MSG);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
    }

    /**
     * @param wfTemplateId
     * @param request
     * @return searchWorkFlowTemplateDesc
     */
    @Override
    public Object searchWorkFlowTemplateDesc(final UUID wfTemplateId, final RequestModel request) {
        log.debug("Entry:DwiWorkFlowTemplateDescServiceImpl:searchWorkFlowTemplateDesc.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            result = mapper.map(this.wfTemplateDescRepository
                    .findAll(request.getFilterSpecification(), pageable), ResponseModel.class);
        } else {
            List<WorkFlowTemplateDesc> actions = this.wfTemplateDescRepository
                    .findAll(request.getFilterSpecification());
            result = actions.stream()
                    .map(action -> mapper.map(action, WorkFlowTemplateDescModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Entry:DwiWorkFlowTemplateDescServiceImpl:searchWorkFlowTemplateDesc.");
        return result;
    }

}
