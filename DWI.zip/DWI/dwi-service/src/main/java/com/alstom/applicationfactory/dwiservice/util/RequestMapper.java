package com.alstom.applicationfactory.dwiservice.util;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.data.domain.Sort;

import com.alstom.applicationfactory.dwiservice.common.model.FilterConditionModel;
import com.alstom.applicationfactory.dwiservice.common.model.FilterJoinsModel;
import com.alstom.applicationfactory.dwiservice.common.model.FilterModel;
import com.alstom.applicationfactory.dwiservice.common.model.JoinModel;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;

public class RequestMapper {
    /**
     * @param request
     * @return RequestModel
     */
    public static RequestModel map(final Map<String, Object> request) {
        if (!Objects.isNull(request)) {
            int pageNumber = Objects.isNull(request.get("pageNumber")) ? 0
                    : (int) request.get("pageNumber");
            int pageSize = Objects.isNull(request.get("pageSize")) ? 0
                    : (int) request.get("pageSize");
            boolean isPaged = !Objects.isNull(request.get("isPaged"))
                    && (boolean) request.get("isPaged");
            FilterSpecification filterSpecification = null;
            Sort sort = null;
            if (!Objects.isNull(request.get("filterJoins"))) {
                FilterModel filter = null;
                List<JoinModel> joins = null;
                Map<String, Object> filterJoinsMap = (Map<String, Object>) request
                        .get("filterJoins");
                if (!Objects.isNull(filterJoinsMap.get("filter"))) {
                    Map<String, Object> filterMap = (Map<String, Object>) filterJoinsMap
                            .get("filter");
                    filter = convertToFilterModel(filterMap);
                }
                if (!Objects.isNull(filterJoinsMap.get("joins"))) {
                    joins = ((List<Map>) filterJoinsMap.get("joins")).stream().map(item -> {
                        Map<String, Object> filterMap = Objects.nonNull(item.get("filter"))
                                ? (Map<String, Object>) item.get("filter")
                                : null;
                        return new JoinModel((String) item.get("object"), (String) item.get("type"),
                                Objects.nonNull(filterMap) ? convertToFilterModel(filterMap)
                                        : null);
                    }).collect(Collectors.toList());
                }

                FilterJoinsModel filterJoinModel = new FilterJoinsModel(filter, joins);
                filterSpecification = new FilterSpecification(filterJoinModel);
            }
            if (!Objects.isNull(request.get("sort"))) {
                List<Sort.Order> orders = ((List<Map>) ((Map) request.get("sort")).get("orders"))
                        .stream()
                        .map(order -> new Sort.Order(
                                Sort.Direction.values()[(int) order.get("direction")],
                                order.get("property").toString(),
                                Sort.NullHandling.values()[(int) order.get("nullHandling")]))
                        .collect(Collectors.toList());
                sort = Sort.by(orders);
            } else {
                sort = Sort.unsorted();
            }
            return new RequestModel(pageNumber, pageSize, isPaged, filterSpecification, sort);
        } else {
            RequestModel requestModel = new RequestModel();
            requestModel.setPaged(false);
            return requestModel;
        }
    }

    /**
     * @param filterMap
     * @return FilterModel
     */
    private static FilterModel convertToFilterModel(final Map<String, Object> filterMap) {
        FilterModel filter = null;
        List<FilterConditionModel> filterConditions = null;
        if (Objects.nonNull(filterMap.get("filterConditions"))
                && Objects.nonNull(filterMap.get("condition"))) {
            List<Map> filterConditionsMaps = ((List<Map>) filterMap.get("filterConditions"));
            filterConditions = filterConditionsMaps.stream().map(item -> {
                if (Objects.nonNull(item.get("filter"))) {
                    FilterModel filterModel = convertToFilterModel((Map) item.get("filter"));
                    return new FilterConditionModel(null, null, null, null, filterModel);
                } else {
                    return new FilterConditionModel(item.get("type").toString(),
                            item.get("field").toString(),
                            !Objects.isNull(item.get("operator")) ? item.get("operator").toString()
                                    : null,
                            item.get("data"), null);
                }
            }).collect(Collectors.toList());
            String condtition = (String) filterMap.get("condition");
            filter = new FilterModel(condtition, filterConditions);
        }
        return filter;
    }
}
