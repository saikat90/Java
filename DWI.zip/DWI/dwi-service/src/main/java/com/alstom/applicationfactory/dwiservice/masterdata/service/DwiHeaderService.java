package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.DwiHeaderModel;

public interface DwiHeaderService {

    /**
     * @param dwiHeader
     * @return DwiHeaderModel.
     */
    DwiHeaderModel createDwiHeader(DwiHeaderModel dwiHeader);

    /**
     * @param dwiHeader
     * @return DwiHeaderModel.
     */
    DwiHeaderModel updateDwiHeader(DwiHeaderModel dwiHeader);

    /**
     * @param requestModel
     * @return DwiHeaderModel.
     */
    Object findAll(RequestModel requestModel);

    /**
     * @param dwiHeaderId
     * @return DwiHeaderModel.
     */
    DwiHeaderModel viewDwiHeader(UUID dwiHeaderId);

    /**
     * @param dwiHeaderId
     */
    void deleteDwiHeaderById(UUID dwiHeaderId);
}
