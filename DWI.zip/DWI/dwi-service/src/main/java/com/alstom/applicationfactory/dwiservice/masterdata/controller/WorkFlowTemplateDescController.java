package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.WorkFlowTemplateDescService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/wfTemplates/{wfTemplateId}/wfTemplatActions")
@Slf4j
public class WorkFlowTemplateDescController {

    /**
     * WorkFlowTemplateDescService.
     */
    @Autowired
    private WorkFlowTemplateDescService wfTemplateDescService;

    /**
     * @param wfTemplateId
     * @param actionBeans
     * @return WorkFlowTemplateDescModel.
     */
    @PostMapping
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public List<WorkFlowTemplateDescModel> createWorkFlowTemplateDesc(
            @PathVariable("wfTemplateId") final UUID wfTemplateId,
            @RequestBody @Valid final List<WorkFlowTemplateDescModel> actionBeans) {
        log.debug("Entry:DwiWorkFlowTemplateDescController:createWorkFlowTemplateDesc.");
        List<WorkFlowTemplateDescModel> res = wfTemplateDescService
                .createWorkFlowTemplateDesc(wfTemplateId, actionBeans);
        log.debug("Leave:DwiWorkFlowTemplateDescController:createWorkFlowTemplateDesc.");
        return res;
    }

    /**
     * @param wfTemplateId
     * @param actionMap
     * @return list of WorkFlowTemplateDescModel
     */
    @PutMapping
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public Map<String, List<WorkFlowTemplateDescModel>> updateWorkFlowTemplateDesc(
            @PathVariable("wfTemplateId") final UUID wfTemplateId,
            @RequestBody @Valid final Map<String, List<WorkFlowTemplateDescModel>> actionMap) {
        log.debug("Entry:DwiWorkFlowTemplateDescController:updateWorkFlowTemplateDesc.");
        Map<String, List<WorkFlowTemplateDescModel>> res = wfTemplateDescService
                .updateWorkFlowTemplateDesc(wfTemplateId, actionMap);
        log.debug("Leave:DwiWorkFlowTemplateDescController:updateWorkFlowTemplateDesc.");
        return res;
    }

    /**
     * @param wfTemplateId
     * @param request
     * @return object of work flow template description.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public Object searchWorkFlowTemplateDesc(@PathVariable("wfTemplateId") final UUID wfTemplateId,
            @RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:DwiWorkFlowTemplateDescController:searchWorkFlowTemplateDesc.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(
                RequestModifier.getfilterCondition("UUID", "workFlowTemplate.id", wfTemplateId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object res = wfTemplateDescService.searchWorkFlowTemplateDesc(wfTemplateId, requestModel);
        log.debug("Leave:DwiWorkFlowTemplateDescController:searchWorkFlowTemplateDesc.");
        return res;
    }

    /**
     * @param wfTemplateId
     * @param wfTemplateDescId
     * @return WorkFlowTemplateDescModel.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public WorkFlowTemplateDescModel viewWorkFlowTemplateDesc(
            @PathVariable("wfTemplateId") final UUID wfTemplateId,
            @PathVariable("id") final UUID wfTemplateDescId) {
        log.debug("Entry:DwiWorkFlowTemplateDescController:viewWorkFlowTemplateDesc.");
        WorkFlowTemplateDescModel res = wfTemplateDescService
                .viewWorkFlowTemplateDesc(wfTemplateDescId);
        log.debug("Leave:DwiWorkFlowTemplateDescController:viewWorkFlowTemplateDesc.");
        return res;
    }

    /**
     * @param wfTemplateId
     * @param wfTemplateDescId
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public void deleteWorkFlowTemplateDesc(@PathVariable("wfTemplateId") final UUID wfTemplateId,
            @PathVariable("id") final UUID wfTemplateDescId) {
        log.debug("Entry:DwiWorkFlowTemplateDescController:deleteWorkFlowTemplateDesc.");
        wfTemplateDescService.deleteWorkFlowTemplateDescById(wfTemplateDescId);
        log.debug("Leave:DwiWorkFlowTemplateDescController:deleteWorkFlowTemplateDesc.");
    }

}
