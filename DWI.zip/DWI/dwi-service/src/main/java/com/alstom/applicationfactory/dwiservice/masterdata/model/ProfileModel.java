package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.Set;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProfileModel {
    /**
     */
    private UUID applicationId;
    /**
     */
    private String applicationName;
    /**
     */
    private String applicationCode;
    /**
     */
    private String userName;
    /**
     */
    private String userEmail;
    /**
     */
    private Set<String> permissions;
}
