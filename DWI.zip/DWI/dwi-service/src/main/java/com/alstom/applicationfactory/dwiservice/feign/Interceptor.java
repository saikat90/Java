package com.alstom.applicationfactory.dwiservice.feign;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import feign.RequestInterceptor;
import feign.RequestTemplate;

@RefreshScope
@Component
public class Interceptor implements RequestInterceptor {
    /**
     * Authorization header code used for jwt.
     */
    @Value("${application.factory.jwt.authorizationHeader}")
    private String authorizationHeader;
    /**
     * Token type user for authentication.
     */
    @Value("${application.factory.jwt.tokenType}")
    private String tokenType;

    /**
     * Applies the token information in the out going http header.
     *
     * @param template Rest template used for out going http calls
     */
    @Override
    public void apply(final RequestTemplate template) {
        if (!template.headers().containsKey(this.authorizationHeader)) {
            SecurityContext securityContext = SecurityContextHolder.getContext();
            Authentication authentication = securityContext.getAuthentication();

            if (authentication != null) {
                if (authentication.getDetails() instanceof OAuth2AuthenticationDetails) {
                    OAuth2AuthenticationDetails details = (OAuth2AuthenticationDetails) authentication
                            .getDetails();
                    template.header(this.authorizationHeader,
                            String.join(" ", this.tokenType, details.getTokenValue()));
                } else if (authentication instanceof JwtAuthenticationToken) {
                    JwtAuthenticationToken token = (JwtAuthenticationToken) authentication;
                    template.header(this.authorizationHeader,
                            String.join(" ", this.tokenType, token.getToken().getTokenValue()));
                }
            }
        }
    }
}