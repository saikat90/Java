package com.alstom.applicationfactory.dwiservice.instruction.enums;

public enum Actions {
    /**
     * List of Actions.
     */
    DESIGN, VALIDATE, APPROVED
}
