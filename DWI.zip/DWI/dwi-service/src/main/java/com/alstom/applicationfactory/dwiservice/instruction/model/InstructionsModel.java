package com.alstom.applicationfactory.dwiservice.instruction.model;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TagModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InstructionsModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    private String dwiStatus;

    /**
     */
    private String dwiSubStatus;

    /**
     */
    private Date dwiSubmittedDate;

    /**
     */
    private Date dwiValidatedDate;

    /**
     */
    private Date dwiApprovedDate;

    /**
     */
    private Date dwiRejectedDate;

    /**
     */
    @NotNull(message = "Dwi Number cannot be empty")
    private String dwiNumber;

    /**
     */
    private Integer dwiEdition;

    /**
     */
    private String dwiTitle;

    /**
     */
    private String dwiReference;

    /**
     */
    private ProjectModel project;

    /**
     */
    private String dwiFleet;

    /**
     */
    private ProcessModel process;

    /**
     */
    private RevisionModel revision;

    /**
     */
    private WorkFlowTemplateModel workFlowTemplate;

    /**
     */
    private UserModel author;

    /**
     */
    private UserModel firstValidator;

    /**
     */
    private UserModel approver;

    /**
     */
    private String approverValidatorComments;

    /**
     */
    private Boolean newEditionCreated;

    /**
     */
    private Boolean approvedActiveEdition;

    /**
     */
    private String dwiLongDesc;

    /**
     */
    private byte[] history;

    /**
     */
    private Date createdDate;

    /**
     */
    private Date modifiedDate;

    /**
     */
    private String createdBy;

    /**
     */
    private String modifiedBy;

    /**
     */
    private FleetModel fleet;

    /**
     */
    private byte[] dwiLongDescHeader;

    /**
     */
    private byte[] dwiLongDescComputed;

    /**
     */
    private String dwiStaticLink;

    /**
     */
    private String commentAttachmentId;

    /**
     */
    private List<InstructionWorkFlowDetailsModel> workFlowDetailsList;

    /**
     */
    private EditionControlCommentsModel editionControlComments;

    /**
     */
    private List<UserModel> instructionApproversList;

    /**
     */
    private List<UserModel> instructionValidatorsList;

    /**
     */
    private List<TagModel> instructiontagsList;

    /**
     */
    private List<WorkFlowActionHistoryModel> workFlowActionHistoryList;

    /**
     */
    private List<InstructionAttachmentModel> instructionAttachmentList;

    /**
     * @return
     */
    @Override
    public String toString() {
        return "InstructionsModel [id=" + id + ", version=" + version + ", dwiStatus=" + dwiStatus
                + ", dwiSubStatus=" + dwiSubStatus + ", dwiSubmittedDate=" + dwiSubmittedDate
                + ", dwiValidatedDate=" + dwiValidatedDate + ", dwiApprovedDate=" + dwiApprovedDate
                + ", dwiRejectedDate=" + dwiRejectedDate + ", dwiNumber=" + dwiNumber
                + ", dwiEdition=" + dwiEdition + ", dwiTitle=" + dwiTitle + ", dwiReference="
                + dwiReference + ", project=" + project + ", dwiFleet=" + dwiFleet + ", process="
                + process + ", revision=" + revision + ", workFlowTemplate=" + workFlowTemplate
                + ", author=" + author + ", firstValidator=" + firstValidator + ", approver="
                + approver + ", approverValidatorComments=" + approverValidatorComments
                + ", newEditionCreated=" + newEditionCreated + ", approvedActiveEdition="
                + approvedActiveEdition + ", dwiLongDesc=" + dwiLongDesc + ", history="
                + Arrays.toString(history) + ", createdDate=" + createdDate + ", modifiedDate="
                + modifiedDate + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy
                + ", fleet=" + fleet + ", dwiLongDescHeader=" + Arrays.toString(dwiLongDescHeader)
                + ", dwiLongDescComputed=" + Arrays.toString(dwiLongDescComputed)
                + ", dwiStaticLink=" + dwiStaticLink + ", commentAttachmentId="
                + commentAttachmentId + ", workFlowDetailsList=" + workFlowDetailsList
                + ", editionControlComments=" + editionControlComments
                + ", instructionApproversList=" + instructionApproversList
                + ", instructionValidatorsList=" + instructionValidatorsList
                + ", instructiontagsList=" + instructiontagsList + ", workFlowActionHistoryList="
                + workFlowActionHistoryList + ", instructionAttachmentList="
                + instructionAttachmentList + "]";
    }

}
