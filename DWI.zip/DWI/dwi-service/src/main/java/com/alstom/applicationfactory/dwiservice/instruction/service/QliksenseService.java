package com.alstom.applicationfactory.dwiservice.instruction.service;

public interface QliksenseService {
    /**
     * @return qlik kpi objects.
     */
    Object findAll();
}
