package com.alstom.applicationfactory.dwiservice.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.google.common.collect.ImmutableMap;

public class RequestModifier {
    /**
     * @param requestMap
     * @param filterConditions
     * @return updateRequestMapWithAnd.
     */
    public static Map<String, Object> updateRequestMapWithAnd(final Map<String, Object> requestMap,
            final List<Map<String, Object>> filterConditions) {
        Map<String, Object> filter = (Map) ((Map) requestMap.get("filterJoins")).get("filter");
        if (Objects.nonNull(filter.get("condition"))
                && Objects.nonNull(filter.get("filterConditions"))) {
            if (filter.get("condition").toString().equalsIgnoreCase("and")) {
                List<Map> existingFilterConditions = (List<Map>) filter.get("filterConditions");
                existingFilterConditions.addAll(filterConditions);
                filter.put("filterConditions", existingFilterConditions);
            } else {
                Map<String, Object> filterConditionsBackup = new HashMap<>();
                filterConditionsBackup.put("condition", filter.get("condition"));
                filterConditionsBackup.put("filterConditions", filter.get("filterConditions"));
                Map<String, Object> filterBackup = new HashMap<>();
                filterBackup.put("filter", filterConditionsBackup);
                filterConditions.add(filterBackup);
                filter.put("condition", "and");
                filter.put("filterConditions", filterConditions);
            }
        } else {
            filter.put("condition", "and");
            filter.put("filterConditions", filterConditions);
        }
        return requestMap;
    }

    /**
     * @param requestMap
     * @param filterConditions
     * @param type
     * @return updateRequestMapWithOr.
     */
    public static Map<String, Object> updateRequestMapWithOr(final Map<String, Object> requestMap,
            final List<Map<String, Object>> filterConditions, final String type) {
        Map<String, Object> filter = (Map) ((Map) requestMap.get("filterJoins")).get("filter");
        if (Objects.nonNull(filter.get("condition"))
                && Objects.nonNull(filter.get("filterConditions"))) {
            if (filter.get("condition").toString().equalsIgnoreCase("or")) {
                List<Map> existingFilterConditions = (List<Map>) filter.get("filterConditions");
                existingFilterConditions.addAll(filterConditions);
                filter.put("filterConditions", existingFilterConditions);
            } else {
                Map<String, Object> filterConditionsBackup = new HashMap<>();
                filterConditionsBackup.put("condition", filter.get("condition"));
                filterConditionsBackup.put("filterConditions", filter.get("filterConditions"));
                Map<String, Object> filterBackup = new HashMap<>();
                filterBackup.put("filter", filterConditionsBackup);
                filterConditions.add(filterBackup);
                filter.put("condition", "or");
                filter.put("filterConditions", filterConditions);
            }
        } else {
            filter.put("condition", "or");
            filter.put("filterConditions", filterConditions);
        }
        return requestMap;
    }

    /**
     * @param requestMap
     * @return defaultRequestMapIfEmpty.
     */
    public static Map<String, Object> defaultRequestMapIfEmpty(Map<String, Object> requestMap) {
        if (Objects.isNull(requestMap)) {
            requestMap = new HashMap<>();
        }
        if (Objects.isNull(requestMap.get("filterJoins"))) {
            requestMap.put("filterJoins", new HashMap<>());
        }
        if (Objects.isNull(((Map) requestMap.get("filterJoins")).get("filter"))) {
            ((Map) requestMap.get("filterJoins")).put("filter", new HashMap<>());
        }
        return requestMap;
    }

    /**
     * @param type
     * @param field
     * @param data
     * @param operator
     * @return getfilterCondition.
     */
    public static Map<String, Object> getfilterCondition(final String type, final String field,
            final Object data, final String operator) {
        return ImmutableMap.of("type", type, "field", field, "data", data, "operator", operator);
    }

    /**
     * @param type
     * @param field
     * @param data
     * @return getfilterCondition.
     */
    public static Map<String, Object> getfilterCondition(final String type, final String field,
            final Object data) {
        return ImmutableMap.of("type", type, "field", field, "data", data);
    }

}
