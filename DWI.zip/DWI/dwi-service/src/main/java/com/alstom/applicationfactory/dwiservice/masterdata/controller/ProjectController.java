package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionsService;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProjectService;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProjectUserRoleService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/projects")
@Slf4j
public class ProjectController {
    /**
     * ProjectRepository.
     */
    @Autowired
    private ProjectRepository projectRepository;

    /**
     * ProjectService.
     */
    @Autowired
    private ProjectService projectService;
    /**
     * ProjectUserRoleService.
     */
    @Autowired
    private ProjectUserRoleService projectUserRoleService;
    /**
     * InstructionsService.
     */
    @Autowired
    private InstructionsService instructionService;

    /**
     * email address of the user.
     */
    @Value("${application.factory.jwt.emailProp}")
    private String emailProp;

    /**
     * @return list of all projects.
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object findAll() {
        log.debug("Entry:DwiProjectController:findAll.");
        Object result = this.projectRepository.findAll();
        log.debug("Leave:DwiProjectController:findAll.");
        return result;
    }

    /**
     * @param project
     * @return ProjectModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProjectModel createProject(@RequestBody @Valid final ProjectModel project) {
        log.debug("Entry:DwiProjectController:CreateProject.");
        ProjectModel projectModel = projectService.createProject(project);
        log.debug("Leave:DwiProjectController:CreateProject.");
        return projectModel;
    }

    /**
     * @param project
     * @return ProjectModel.
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProjectModel updateProject(@RequestBody @Valid final ProjectModel project) {
        log.debug("Entry:DwiProjectController:UpdateProject.");
        ProjectModel projectModel = projectService.updateProject(project);
        log.debug("Leave:DwiProjectController:UpdateProject.");
        return projectModel;
    }

    /**
     * @param request
     * @return searched project object.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchProject(@RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:DwiProjectController:SearchProject.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = projectService.searchProject(requestModel);
        log.debug("Leave:DwiProjectController:SearchProject.");
        return res;
    }

    /**
     * @param id
     * @return ProjectModel.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProjectModel viewProject(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiProjectController:ViewProject.");
        ProjectModel projectModel = projectService.viewProject(id);
        log.debug("Leave:DwiProjectController:ViewProject.");
        return projectModel;
    }

    /**
     * @param id
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteProjectById(@PathVariable("id") final UUID id) {
        log.debug("Entry:DwiProjectController:DeleteProject.");
        this.projectService.deleteProjectById(id);
        log.debug("Leave:DwiProjectController:DeleteProject.");
    }

    /**
     * @param projectId
     * @param function
     * @return ProjectModel.
     */
    @PostMapping("/{id}/function")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProjectModel addFunction(@PathVariable("id") final UUID projectId,
            @RequestBody @Valid final FunctionModel function) {

        log.debug("Entry:DwiProjectController:addFunction.");
        ProjectModel projectBean = projectService.addFunction(projectId, function);
        log.debug("Leave:DwiProjectController:addFunction.");
        return projectBean;
    }

    /**
     * @param projectId
     * @param functionId
     * @return ProjectModel.
     */
    @DeleteMapping("/{id}/function/{funcId}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProjectModel deleteFunction(@PathVariable("id") final UUID projectId,
            @PathVariable("funcId") final UUID functionId) {

        log.debug("Entry:DwiProjectController:deleteFunction.");
        ProjectModel projectBean = projectService.deleteFunction(projectId, functionId);
        log.debug("Leave:DwiProjectController:deleteFunction");
        return projectBean;
    }

    /**
     * @param projectId
     * @return ProjectModel.
     */
    @GetMapping("/{id}/list/functions")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getUnassignedFunctions(@PathVariable("id") final UUID projectId) {
        log.debug("Entry:DwiProjectFunctionsController:GetUnassignedFunctions.");
        Object result = projectService.getUnassignedFunctions(projectId);
        log.debug("Leave:DwiProjectFunctionsController:GetUnassignedFunctions.");
        return result;
    }

    /**
     * @return unsigned project objects.
     */
    @GetMapping("/list/unassignedProjects")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getUnassignedProjects() {
        log.debug("Entry:DwiProjectController:GetunassignedProjects.");
        Object result = projectService.getUnassignedProjects();
        log.debug("Leave:DwiProjectController:GetunassignedProjects.");
        return result;
    }

    /**
     * @param request
     * @param authentication
     * @return instructions for that user.
     */
    @PostMapping("/listInstructionForUser")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getInstructionForUser(@RequestBody(required = false) Map<String, Object> request,
            final Authentication authentication) {
        log.debug("Entry:DwiProjectController:getInstructionForUser.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        List<UUID> projectIDs = projectUserRoleService.getProjectForUser(email);
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions
                .add(RequestModifier.getfilterCondition("UUID", "project.id", projectIDs, "in"));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object res = this.instructionService.searchUserInstructions(requestModel);
        log.debug("Leave:DwiProjectController:getInstructionForUser.");
        return res;
    }

    /**
     * @param request
     * @param authentication
     * @return list of project model.
     */
    @PostMapping("/listProjectForUser")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public List<ProjectModel> getProjectModelForUser(
            @RequestBody(required = false) final Map<String, Object> request,
            final Authentication authentication) {
        log.debug("Entry:DwiProjectController:getProjectModelForUser.");
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get(emailProp).toString();
        List<ProjectModel> projectModelList = projectUserRoleService.getProjectModelForUser(email);
        log.debug("Leave:DwiProjectController:getProjectModelForUser.");
        return projectModelList;
    }

    /**
     * @param projectId
     * @return list of all functions for that project.
     */
    @GetMapping("/{id}/listAllfunctions")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getAllFunctionsForProject(@PathVariable("id") final UUID projectId) {
        log.debug("Entry:DwiProjectFunctionsController:GetAllFunctionsForProject.");
        Object result = projectService.getAllFunctionsForProject(projectId);
        log.debug("Leave:DwiProjectFunctionsController:GetAllFunctionsForProject.");
        return result;
    }
}
