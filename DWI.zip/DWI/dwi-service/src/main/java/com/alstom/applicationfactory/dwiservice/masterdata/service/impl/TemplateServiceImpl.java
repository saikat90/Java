package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.common.model.ResponseModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Template;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.TemplateRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.TemplateService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "templateService")
@Transactional
@Slf4j
public class TemplateServiceImpl implements TemplateService {

    /**
     * TemplateRepository.
     */
    @Autowired
    private TemplateRepository templateRepository;
    /**
     * ProjectRepository.
     */
    @Autowired
    private ProjectRepository projectRepository;

    /**
     * @param request
     * @return searchTemplate.
     */
    @Override
    public Object searchTemplate(final RequestModel request) {
        log.debug("Entry:TemplateServiceImpl:searchTemplate.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        Object result = null;
        Pageable pageable;
        if (request.isPaged()) {
            pageable = PageRequest.of(request.getPageNumber(), request.getPageSize(),
                    request.getSort() != null ? request.getSort() : Sort.unsorted());
            ResponseModel response = mapper.map(
                    this.templateRepository.findAll(request.getFilterSpecification(), pageable),
                    ResponseModel.class);
            response.setContent(response.getContent().stream()
                    .map(template -> mapper.map(template, TemplateModel.class))
                    .collect(Collectors.toList()));
            result = response;
        } else {
            result = this.templateRepository.findAll(request.getFilterSpecification()).stream()
                    .map(template -> mapper.map(template, TemplateModel.class))
                    .collect(Collectors.toList());
        }
        log.debug("Leave:TemplateServiceImpl:searchTemplate.");
        return result;
    }

    /**
     * @param templateModel
     * @return TemplateModel.
     */
    @Override
    public TemplateModel saveTemplate(final TemplateModel templateModel) {
        log.debug("Entry:TemplateServiceImpl:saveTemplate.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        List<ErrorModel> errors = new ArrayList<>();

        TemplateModel createdTemplateModel = new TemplateModel();

        if (templateModel.getContent() == null && templateModel.getProject() == null) {
            log.error("Template content and project is mandatory for a template.");
            errors.add(new ErrorModel(Constants.TEMPLATE_LABEL, Constants.TEMPLATE_MANDATORY));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }

        List<Template> templateList = getDuplicateFleet(templateModel);
        if (!templateList.isEmpty()) {
            Template template = templateList.get(0);
            errors.add(new ErrorModel(Constants.TEMPLATE_LABEL, Constants.RECORD_EXISTS));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        try {
            Template templateObj = mapper.map(templateModel, Template.class);
            Project proj = projectRepository.findById(templateObj.getProject().getId())
                    .orElse(null);
            templateObj.setProject(proj);

            Template template = this.templateRepository.save(templateObj);
            createdTemplateModel = mapper.map(template, TemplateModel.class);
        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
            errors.add(new ErrorModel(Constants.TEMPLATE_LABEL, Constants.CREATE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:TemplateServiceImpl:saveTemplate.");
        return createdTemplateModel;
    }

    /**
     * @param template
     * @return list of Template.
     */
    private List<Template> getDuplicateFleet(final TemplateModel template) {
        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(
                RequestModifier.getfilterCondition("String", "title", template.getTitle(), "eq"));
        filterConditions.add(RequestModifier.getfilterCondition("Boolean", "active", true));

        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        List<Template> templateList = templateRepository
                .findAll(requestModel.getFilterSpecification());
        return templateList;
    }

    /**
     * @param templateModel
     * @return TemplateModel
     */
    @Override
    public TemplateModel updateTemplate(final TemplateModel templateModel) {
        log.debug("Entry:TemplateServiceImpl:updateTemplate.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        TemplateModel updatedTemplateModel = new TemplateModel();
        try {
            if (templateModel.getContent() == null && templateModel.getProject() == null) {
                log.error("Template content and project is mandatory for a template.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.TEMPLATE_LABEL, Constants.TEMPLATE_MANDATORY));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            }
            Template templateRequest = mapper.map(templateModel, Template.class);

            if (null != templateRequest) {
                Template template = this.templateRepository.save(templateRequest);
                updatedTemplateModel = mapper.map(template, TemplateModel.class);
            }

        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.TEMPLATE_LABEL,
                    Constants.UPDATE_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.INTERNAL_ERROR, errorModels);
        }
        log.debug("Leave:TemplateServiceImpl:updateTemplate.");
        return updatedTemplateModel;
    }

    /**
     * @param id
     */
    @Override
    public void deleteTemplate(final UUID id) {
        log.debug("Entry:TemplateServiceImpl:deleteTemplate.");
        try {
            Template template = templateRepository.findById(id).orElse(null);
            if (Objects.isNull(template)) {
                log.error("No template present.");
                List<ErrorModel> errors = new ArrayList<>();
                errors.add(new ErrorModel(Constants.TEMPLATE_LABEL, Constants.RECORD_NOT_EXISTS));
                throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
            } else {
                templateRepository.delete(template);
            }
        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.TEMPLATE_LABEL, Constants.DELETE_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        log.debug("Leave:TemplateServiceImpl:deleteTemplate.");
    }
}
