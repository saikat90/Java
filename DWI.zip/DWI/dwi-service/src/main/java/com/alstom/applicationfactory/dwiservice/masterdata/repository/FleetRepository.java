package com.alstom.applicationfactory.dwiservice.masterdata.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;

@Repository
public interface FleetRepository
        extends JpaRepositoryImplementation<Fleet, UUID>, JpaSpecificationExecutor<Fleet> {
    /**
     * @param name
     * @return list of fleet by name.
     */
    List<Fleet> findByFleetName(String name);

    /**
     * @param name
     * @param id
     * @return list of fleet by name & project id.
     */
    List<Fleet> findByFleetNameAndProjectId(String name, UUID id);
}
