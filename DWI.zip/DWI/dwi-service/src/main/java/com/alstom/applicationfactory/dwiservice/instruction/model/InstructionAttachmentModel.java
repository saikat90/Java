package com.alstom.applicationfactory.dwiservice.instruction.model;

import java.util.Date;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InstructionAttachmentModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    private String dwiFormId;

    /**
     */
    private String attachmentText;

    /**
     */
    private String attachedFileName;

    /**
     */
    private Boolean uploadSuccesfull;

    /**
     */
    private Date createdDate;

    /**
     */
    private Date modifiedDate;

    /**
     */
    private String createdBy;

    /**
     */
    private String modifiedBy;

    /**
     */
    @JsonIgnore
    private InstructionsModel instructions;
}
