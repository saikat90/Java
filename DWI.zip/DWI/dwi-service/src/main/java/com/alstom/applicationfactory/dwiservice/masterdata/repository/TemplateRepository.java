package com.alstom.applicationfactory.dwiservice.masterdata.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.Template;

@Repository
public interface TemplateRepository
        extends JpaRepositoryImplementation<Template, UUID>, JpaSpecificationExecutor<Template> {

}
