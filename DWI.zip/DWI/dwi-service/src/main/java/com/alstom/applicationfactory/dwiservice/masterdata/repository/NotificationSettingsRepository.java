package com.alstom.applicationfactory.dwiservice.masterdata.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.NotificationSettings;

@Repository
public interface NotificationSettingsRepository extends JpaRepository<NotificationSettings, UUID> {

}
