package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationModel {
    /**
     */
    private UUID id;
    /**
     */
    private String name;
    /**
     */
    private String code;
    /**
     */
    private boolean verified;
    /**
     */
    private boolean deleted;
    /**
     */
    private boolean allowAllUsers;

}
