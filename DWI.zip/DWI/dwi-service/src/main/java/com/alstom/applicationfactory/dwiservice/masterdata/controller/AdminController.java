package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProfileModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.AdminService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class AdminController {

    /**
     * AdminService.
     */
    @Autowired
    private AdminService adminService;

    /**
     * @param id
     * @return ApplicationModel.
     */
    @GetMapping("/applications/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ApplicationModel findById(@PathVariable final String id) {
        log.debug("Entry:AdminController:findById.");
        ApplicationModel applicationModel = this.adminService.findById(id);
        log.debug("Leave:AdminController:findById.");
        return applicationModel;
    }

    /**
     * @param code
     * @param authentication
     * @return ProfileModel.
     */
    @GetMapping("/applications/{code}/profile")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public ProfileModel getProfile(@PathVariable final String code,
            final Authentication authentication) {
        log.debug("Entry:AdminController:getProfile.");
        ProfileModel profileModel = this.adminService.getProfile(code, authentication);
        log.debug("Leave:AdminController:getProfile.");
        return profileModel;
    }

    /**
     * @param email
     * @return email model.
     */
    @PutMapping("/emails")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object updateEmail(@RequestBody final Object email) {
        log.debug("Entry:AdminController:updateEmail");
        Object emailModel = this.adminService.updateEmail(email);
        log.debug("Leave:AdminController:updateEmail");
        return emailModel;
    }

    /**
     * @param id
     * @param request
     * @return email model list.
     */
    @PostMapping("/emails/{id}/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object findEmailByApplicationId(@PathVariable final String id,
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:AdminController:findEmailByApplicationId.");
        Object emailModelList = this.adminService.findEmailByApplicationId(id, request);
        log.debug("Leave:AdminController:findEmailByApplicationId.");
        return emailModelList;
    }

    /**
     * @param id
     * @param request
     * @return application model list.
     */
    @PostMapping("/application-roles/application/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object findRolesByApplicationId(@PathVariable final String id,
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:AdminController:findRolesByApplicationId.");
        Object applicationRoleModelList = this.adminService.findRolesByApplicationId(id, request);
        log.debug("Leave:AdminController:findRolesByApplicationId.");
        return applicationRoleModelList;
    }

    /**
     * @param request
     * @return user model list.
     */
    @PostMapping("/users/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object findAllUsers(@RequestBody final Map<String, Object> request) {
        log.debug("Entry:AdminController:findAllUsers.");
        Object userModelList = this.adminService.findAllUsers(request);
        log.debug("Leave:AdminController:findAllUsers.");
        return userModelList;
    }

    /**
     * @param users
     * @return user model list.
     */
    @PostMapping("/users/all")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public List<UserModel> saveAllUsers(@RequestBody @Valid final List<UserModel> users) {
        log.debug("Entry:AdminController:saveAllUsers.");
        List<UserModel> userModelList = this.adminService.saveAllUsers(users);
        log.debug("Leave:AdminController:saveAllUsers.");
        return userModelList;
    }

    /**
     * @param id
     * @param request
     * @return user model list.
     */
    @PostMapping("/users/{id}/unmapped-users")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object findUnmappedApplicationRoleUsers(@PathVariable final String id,
            @RequestBody final Map<String, Object> request) {
        log.debug("Entry:AdminController:findUnmappedApplicationRoleUsers.");
        Object userModelList = this.adminService.findUnmappedApplicationRoleUsers(id, request);
        log.debug("Leave:AdminController:findUnmappedApplicationRoleUsers.");
        return userModelList;
    }

    /**
     * @param applicationId
     * @param roleCode
     * @param request
     * @return user model list.
     */
    @PostMapping("/application-role-users/application/{applicationId}/role/{roleCode}/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object findRoleUsers(@PathVariable final String applicationId,
            @PathVariable final String roleCode, @RequestBody final Map<String, Object> request) {
        log.debug("Entry:AdminController:findRoleUsers.");
        Object userModelList = this.adminService.findRoleUsers(applicationId, roleCode, request);
        log.debug("Leave:AdminController:findRoleUsers.");
        return userModelList;
    }

    /**
     * @param appRoleId
     * @param request
     * @return application role user model list.
     */
    @PostMapping("/application-role-users/application-role/{appRoleId}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object findUsersByApplicationRole(@PathVariable final String appRoleId,
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:AdminController:findUsersByApplicationRole.");
        Object applicationRoleUserModelList = this.adminService
                .findUsersByApplicationRole(appRoleId, request);
        log.debug("Leave:AdminController:findUsersByApplicationRole.");
        return applicationRoleUserModelList;
    }

    /**
     * @param applicationRoleUsers
     * @return application role user model list.
     */
    @PostMapping("/application-role-users/all")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object saveUsersForRole(@RequestBody final Object applicationRoleUsers) {
        log.debug("Entry:AdminController:saveUsersForRole.");
        Object applicationRoleUserModelList = this.adminService
                .saveUsersForRole(applicationRoleUsers);
        log.debug("Leave:AdminController:saveUsersForRole.");
        return applicationRoleUserModelList;
    }

    /**
     * @param applicationRoleUsers
     * @return application role user model list.
     */
    @PutMapping("/application-role-users/all")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object updateUsersForRole(@RequestBody final Object applicationRoleUsers) {
        log.debug("Entry:AdminController:updateUsersForRole.");
        Object applicationRoleUserModelList = this.adminService
                .updateUsersForRole(applicationRoleUsers);
        log.debug("Leave:AdminController:updateUsersForRole.");
        return applicationRoleUserModelList;
    }

    /**
     * @param appId
     * @param applicationRoleUserId
     * @param request
     * @return application role user model list.
     */
    @PostMapping("/rights/{appId}/user/{applicationRoleUserId}/unmapped")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object getUnmappedRightsForApplicationRoleUser(@PathVariable final String appId,
            @PathVariable final String applicationRoleUserId,
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:AdminController:getUnmappedRightsForApplicationRoleUser.");
        Object result = this.adminService.getUnmappedRightsForApplicationRoleUser(appId,
                applicationRoleUserId, request);
        log.debug("Leave:AdminController:getUnmappedRightsForApplicationRoleUser.");
        return result;
    }

    /**
     * @param applicationRoleUserRightsModels
     * @return object of saved application role rights.
     */
    @PostMapping("/application-role-user-rights")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object saveApplicationRoleRights(
            @RequestBody final Object applicationRoleUserRightsModels) {
        log.debug("Entry:AdminController:saveApplicationRoleRights.");
        Object result = this.adminService
                .saveApplicationRoleRights(applicationRoleUserRightsModels);
        log.debug("Leave:AdminController:saveApplicationRoleRights.");
        return result;
    }

    /**
     * @param applicationRoleUserRightsModels
     * @return object of updated application role rights.
     */
    @PutMapping("/application-role-user-rights")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object updateApplicationRoleRights(
            @RequestBody final Object applicationRoleUserRightsModels) {
        log.debug("Entry:AdminController:updateApplicationRoleRights.");
        Object result = this.adminService
                .updateApplicationRoleRights(applicationRoleUserRightsModels);
        log.debug("Leave:AdminController:updateApplicationRoleRights.");
        return result;
    }

    /**
     * @param appRoleUserId
     * @param request
     * @return list of applicatin role user rights.
     */
    @PostMapping("/application-role-user-rights/{appRoleUserId}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object listApplicationRoleUserRights(@PathVariable final String appRoleUserId,
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:AdminController:listApplicationRoleUserRights.");
        Object result = this.adminService.listApplicationRoleUserRights(appRoleUserId, request);
        log.debug("Leave:AdminController:listApplicationRoleUserRights.");
        return result;
    }

}
