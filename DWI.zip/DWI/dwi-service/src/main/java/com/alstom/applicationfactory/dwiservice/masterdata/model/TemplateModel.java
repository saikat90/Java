package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TemplateModel {

    /**
     */
    private UUID id;
    /**
     */
    private Integer version;
    /**
     */
    @NotNull(message = "Title name should not be empty")
    private String title;
    /**
     */
    private boolean active;
    /**
     */
    @NotNull(message = "DWI TEMPLATE DESCRIPTION  name should not be empty")
    private String dwiTemplateDescription;
    /**
     */
    private String content;
    /**
     */
    private ProjectModel project;
}
