package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DwiHeaderModel {

    /**
     */
    private UUID id;

    /**
     */
    @NotNull(message = "Version should not be empty")
    private Integer version;

    /**
     */
    private String content;

    /**
     */
    private ProjectModel project;
}
