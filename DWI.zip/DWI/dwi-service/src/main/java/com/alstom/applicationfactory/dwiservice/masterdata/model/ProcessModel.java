package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProcessModel {

    /**
     */
    private UUID id;
    /**
     */
    private Integer version;
    /**
     */
    @NotNull(message = "Process name should not be empty")
    private String processName;
    /**
     */
    @NotNull(message = "Fleet should not be empty")
    private FleetModel fleet;
    /**
     */
    private boolean active;
    /**
     */
    private Date createdDate;
    /**
     */
    private Date modifiedDate;
    /**
     */
    private String createdBy;
    /**
     */
    private String modifiedBy;

}
