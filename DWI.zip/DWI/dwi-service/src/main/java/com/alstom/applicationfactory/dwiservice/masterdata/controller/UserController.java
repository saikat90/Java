package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;

@RestController
@RequestMapping("/users")
public class UserController {
    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;

    /**
     * @return list of user objets.
     */
    @GetMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object findAll() {
        return this.userRepository.findAll();
    }
}
