package com.alstom.applicationfactory.dwiservice.instruction.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.instruction.service.FileManagerService;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/rte/image")
@Slf4j
@RefreshScope
public class FileManagerController {

    /**
     * FileManagerService.
     */
    @Autowired
    private FileManagerService fileManagerService;

    /**
     * @param imageSource
     * @param response
     * @throws IOException
     */
    @GetMapping("/fileManager/**")
    public void getImage(@RequestParam("path") final String imageSource,
            final HttpServletResponse response) throws IOException {
        log.debug("Entry:FileManagerController:getImage.");
        response.setContentType("APPLICATION/OCTET-STREAM");
        response.getOutputStream().write(fileManagerService.getImage(imageSource));
        response.getOutputStream().close();
        log.debug("Leave:FileManagerController:getImage.");
    }

}
