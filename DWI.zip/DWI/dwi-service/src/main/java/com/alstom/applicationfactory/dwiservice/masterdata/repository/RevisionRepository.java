package com.alstom.applicationfactory.dwiservice.masterdata.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;

@Repository
public interface RevisionRepository
        extends JpaRepository<Revision, UUID>, JpaSpecificationExecutor<Revision> {

    /**
     * @param name
     * @return list of revision by name.
     */
    List<Revision> findByRevisionName(String name);

    /**
     * @param name
     * @param id
     * @return list of revision by name & process id.
     */
    List<Revision> findByRevisionNameAndProcessId(String name, UUID id);
}
