package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailModel {

    /**
     * list of mail recipients.
     */
    @NotNull(message = "Email recipients should not be empty")
    @Size(min = 1, message = "Email recipients should not be empty")
    private List<String> recipients;

    /**
     * subject of the mail.
     */
    @NotNull(message = "Email subject should not be empty")
    @Size(min = 1, max = Constants.FIVE_HUNDERD, message = "Subject should be 1-500 characters")
    private String subject;

    /**
     * body of the mail.
     */
    @NotNull(message = "Email body should not be empty")
    @Size(min = 1, max = Constants.FIVE_THOUSAND, message = "Body should be 1-5000 characters")
    private String body;

}
