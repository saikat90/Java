package com.alstom.applicationfactory.dwiservice.instruction.service;

import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.exception.ExcelException;

public interface InstructionExcelService {

    /**
     * @param file
     * @param email
     * @return ExcelException.
     */
    ExcelException importExcel(MultipartFile file, String email);
}
