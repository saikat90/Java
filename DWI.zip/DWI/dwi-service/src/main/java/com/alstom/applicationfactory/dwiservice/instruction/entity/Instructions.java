package com.alstom.applicationfactory.dwiservice.instruction.entity;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Tag;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dwinstructions", uniqueConstraints = @UniqueConstraint(columnNames = { "dwi_number",
        "dwi_edition" }))
public class Instructions {

    /**
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     */
    @Column(name = "dwi_status", length = Constants.TWENTY, nullable = false)
    private String dwiStatus;

    /**
     */
    @Column(name = "dwi_sub_status", length = Constants.ELEVEN, nullable = false)
    private String dwiSubStatus;

    /**
     */
    @Column(name = "dwi_submitted_date")
    private Date dwiSubmittedDate;

    /**
     */
    @Column(name = "dwi_validated_date")
    private Date dwiValidatedDate;

    /**
     */
    @Column(name = "dwi_approved_date")
    private Date dwiApprovedDate;

    /**
     */
    @Column(name = "dwi_rejected_date")
    private Date dwiRejectedDate;

    /**
     */
    @Column(nullable = false, name = "dwi_number", length = Constants.FIFTY)
    private String dwiNumber;

    /**
     */
    @Column(nullable = false, name = "dwi_edition")
    private Integer dwiEdition;

    /**
     */
    @Column(name = "dwi_title")
    private String dwiTitle;

    /**
     */
    @Column(name = "dwi_reference")
    private String dwiReference;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_project_id")
    private Project project;

    /**
     */
    @Column(name = "dwi_fleet", length = Constants.FIVE_HUNDERD)
    private String dwiFleet;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_process_id")
    private Process process;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_revision_id")
    private Revision revision;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_work_flow_template_id")
    private WorkFlowTemplate workFlowTemplate;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_author_id")
    private User author;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_first_validator_id")
    private User firstValidator;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_approver_id")
    private User approver;

    /**
     */
    @Column(name = "approver_validator_comments", length = Constants.FIVE_HUNDERD)
    private String approverValidatorComments;

    /**
     */
    @Column(name = "new_edition_created", nullable = false)
    private Boolean newEditionCreated;

    /**
     */
    @Column(name = "approved_active_edition", nullable = false)
    private Boolean approvedActiveEdition;

    // @Lob
    /**
     */
    @Column(columnDefinition = "TEXT", name = "dwi_long_desc")
    private String dwiLongDesc;

    // @Lob
    /**
     */
    private byte[] history;

    /**
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     */
    @Column(name = "updated_by")
    private String modifiedBy;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_fleet_id")
    private Fleet fleet;

    /**
     */
    @Column(name = "dwi_long_desc_header")
    private byte[] dwiLongDescHeader;

    /**
     */
    @Column(name = "dwi_long_desc_computed")
    private byte[] dwiLongDescComputed;

    /**
     */
    @Column(name = "dwi_static_link", length = Constants.TWO_THOUSAND)
    private String dwiStaticLink;

    /**
     */
    @Column(name = "comment_attachement_id")
    private String commentAttachmentId;

    /**
     */
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "instructions", cascade = CascadeType.ALL)
    private List<InstructionWorkFlowDetails> workFlowDetailsList;

    /**
     */
    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "instructions", cascade = CascadeType.ALL)
    private EditionControlComments editionControlComments;

    /**
     */
    @ManyToMany
    @CollectionTable(name = "dwinstructions_dwi_list_of_approver")
    private List<User> instructionApproversList = Collections.emptyList();

    /**
     */
    @ManyToMany
    @CollectionTable(name = "dwinstructions_dwi_list_of_validators")
    private List<User> instructionValidatorsList = Collections.emptyList();

    /**
     */
    @ManyToMany
    @CollectionTable(name = "dwinstructions_set_of_dwitags")
    private List<Tag> instructiontagsList = Collections.emptyList();

    /**
     */
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "wfhInstructions", cascade = CascadeType.ALL)
    private List<WorkFlowActionHistory> workFlowActionHistoryList;

    /**
     */
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "instructions", cascade = CascadeType.ALL)
    private List<InstructionAttachment> instructionAttachmentList;
}
