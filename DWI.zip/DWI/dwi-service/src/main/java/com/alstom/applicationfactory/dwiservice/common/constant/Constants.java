package com.alstom.applicationfactory.dwiservice.common.constant;

public final class Constants {
    /**
     * Default Constrctor.
     */
    private Constants() {
    }

    /**
     * Constant. - Auto Reminder Validation.
     */
    public static final String AUTO_REMINDER_VALIDATION = "AUTO_REMINDER_VALIDATION";
    /**
     * Constant. - Auto Reminder Approval.
     */
    public static final String AUTO_REMINDER_APPROVAL = "AUTO_REMINDER_APPROVAL";
    /**
     * Constant. - Rejected By Validator.
     */
    public static final String REJECTED_BY_VALIDATOR = "Rejected by Validator";
    /**
     * Constant. - Rejected By Validato.
     */
    public static final String REJECTED_BY_APPROVER = "Rejected by Approver";
    /**
     * Constant. - Created.
     */
    public static final String CREATED = "Created";
    /**
     * Constant. - Modified.
     */
    public static final String MODIFIED = "Modified";
    /**
     * Constant. - New Version.
     */
    public static final String NEW_VERSION_CREATED = "New Version Created";
    /**
     * Constant. - DWI Number.
     */
    public static final String DWI_NUMBER_PREFIX = "DWI";
    /**
     * Constant. - DWI Number Delimiter.
     */
    public static final String DWI_NUMBER_DELIMITER = "_";
    /**
     * Constant. - Add Comments.
     */
    public static final String ADDCOMMENTS = "ADDCOMMENTS";

    /**
     * Field Constant - Project.
     */
    public static final String FIELD_PROJECT = "Project";
    /**
     * Field Constant - Email.
     */
    public static final String FIELD_EMAIL = "Email";

    /**
     * Message Constant - Email Recipient.
     */
    public static final String MSG_EMAIL_RECIPIENT_ARE_NOT_ADDED = "Email recipients are not added";
    /**
     * Message Constant - Master data down.
     */
    public static final String MSG_MASTER_DATA_SERVICE_DOWN = "Master data service down";
    /**
     * Message Constant - Error.
     */
    public static final String ERROR_LABEL = "ERROR";
    /**
     * Message Constant - 406.
     */
    public static final int ERROR_CODE_406 = 406;
    /**
     * Message Constant - 405.
     */
    public static final int ERROR_CODE_405 = 405;
    /**
     * Message Constant - Internal Error Msg.
     */
    public static final String INTERNAL_ERROR_MSG = "not able to perform this operation";
    /**
     * Message Constant - 500.
     */
    public static final Integer INTERNAL_ERROR = 500;
    /**
     * Message Constant - Object Created.
     */
    public static final String OBJ_CREATED = "Object created";
    /**
     * Message Constant - Object Modified.
     */
    public static final String OBJ_MODIFIED = "Object modified";
    /**
     * Message Constant - Info Delimiter.
     */
    public static final String INFO_DELIMITER = " - ";
    /**
     * Message Constant - New Line.
     */
    public static final String INFO_NEWLINE = "\n";
    /**
     * Message Constant - Info Submit.
     */
    public static final String INFO_SUBMIT = "Object Status changed from DRAFT to SUBMITTED";
    /**
     * Message Constant - Info Validate.
     */
    public static final String INFO_VALIDATE = "Object Status changed from SUBMITTED to VALIDATED";
    /**
     * Message Constant - Info Approve.
     */
    public static final String INFO_APPROVE = "Object Status changed from VALIDATED to APPROVED";
    /**
     * Message Constant - Info Reject.
     */
    public static final String INFO_REJECT = "Object Status set to REJECTED";
    /**
     * Message Constant - Info Import.
     */
    public static final String INFO_IMPORT = "Object Status changed from IMPORTED to IMPORT_SUBMITTED";
    /**
     * Message Constant - Attach added.
     */
    public static final String ATTACH_ADDED = "Attachment Added";
    /**
     * Message Constant - Object Imported.
     */
    public static final String OBJ_IMPORTED = "Object Imported";
    /**
     * Message Constant - Comments Added.
     */
    public static final String COMMENTS_ADDED = "Comments Added";
    /**
     * Message Constant - Static Link.
     */
    public static final String STATIC_LINK_ADD = "Static link is set to";

    /**
     * Message Constant - Excel Error.
     */
    public static final String EXCEL_ERROR = "Excel not in correct format";
    /**
     * Constant - Excel Error 404.
     */
    public static final int ERROR_CODE_404 = 404;

    /**
     * Constant - Email Server down.
     */
    public static final String EMAIL_SERVER_DOWN = "Email Server down";

    /**
     * Constant - UUID Pattern.
     */
    public static final String UUID_PATTERN = "([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})-([0-9A-Fa-f]{4})-([0-9A-Fa-f]{4})-([0-9A-Fa-f]{4})-([0-9A-Fa-f]{12})";
    /**
     * Constant - Unauthorized.
     */
    public static final String UNAUTHORIZED = "Unauthorized";
    /**
     * Constant - Unauthorized Msg.
     */
    public static final String UNAUTHORIZED_MSG = "Unauthorized to access this!";
    /**
     * Constant - Resource.
     */
    public static final String RESOURCE = "Resource";
    /**
     * Constant - Resource Msg.
     */
    public static final String RESOURCE_MSG = "Resource not found!";
    /**
     * Constant - Request.
     */
    public static final String REQUEST = "Request";
    /**
     * Constant - Bad Request.
     */
    public static final String REQUEST_MSG = "Bad Request!";
    /**
     * Constant - Media Type.
     */
    public static final String MEDIA_TYPE = "Media Type";
    /**
     * Constant - Media Type Msg.
     */
    public static final String MEDIA_TYPE_MSG = "Unsupported Media Type!";
    /**
     * Constant - Server Error.
     */
    public static final String SERVER_ERROR = "Server Error";
    /**
     * Constant - Hystrix error.
     */
    public static final String HYSTRIX_ERROR = "Hystrix error. Please contact application factory admin";
    /**
     * Constant - Data Access Issue.
     */
    public static final String DATA_ACCESS_ISSUE = "Data access issue. Please contact application factory admin";
    /**
     * Constant.
     */
    public static final String DATA_ERROR = "Data error";
    /**
     * Constant.
     */
    public static final String DATA_ERROR_MSG = "Input data format is wrong";
    /**
     * Constant.
     */
    public static final String MAPPING_ERROR = "Mapping error";
    /**
     * Constant.
     */
    public static final String MAPPING_ERROR_MSG = "Data mapping error";
    /**
     * Constant.
     */
    public static final String FIELD_NULL = "Field Null";
    /**
     * Constant.
     */
    public static final String FIELD_NULL_MSG = "Data field is empty";
    /**
     * Constant.
     */
    public static final String DATA_EXITS = "Data already exist error";
    /**
     * Constant.
     */
    public static final String DATA_CONVERT_ERROR = "Data not able to convert error";
    /**
     * Constant.
     */
    public static final String DATA_VIOLATION = "Data constraint violation error";
    /**
     * Constant.
     */
    public static final String FACTORY_ADMIN_MSG = "Please contact application factory admin";
    /**
     * Constant.
     */
    public static final String INSTRUCTION = "Instruction";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_PARSE_ERROR = "Could not parse work instruction values. Please try again!";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_ATTACH_ERROR = "Instruction Attachment";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_ATTACH_ERROR_MSG = "Could not parse work instruction attachment values. Please try again!";
    /**
     * Constant.
     */
    public static final String ATTACHMENT_READ_ERROR = "Error in reading attachment file.";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_VIEW_ERROR = "Error in viewing Instructionst";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_ATTACHMENT = "Instruction Attachment";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_ATTACHMENT_CREATE_ERROR = "Error while creating record for InstructionAttachment";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_ATTACHMENT_DELETE_ERROR = "Error while Deleting attachments";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_ATTACHMENT_VIEW_ERROR = "Error while fetching attachments";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_ATTACHMENT_READ_ERROR = "Error while reading attachments";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_ATTACHMENT_EMPTY = "Attached file is empty";
    /**
     * Constant.
     */
    public static final String APPROVER = "Approver";
    /**
     * Constant.
     */
    public static final String AUTHOR = "Author";
    /**
     * Constant.
     */
    public static final String VALIDATOR = "Validator";
    /**
     * Constant.
     */
    public static final String USER = "User";
    /**
     * Constant.
     */
    public static final String USER_NOT_PRESENT_FOR_MAIL = "User not present in the system for the email: ";
    /**
     * Constant.
     */
    public static final String UPLOAD_ERROR = "Error while performing upload";
    /**
     * Constant.
     */
    public static final String ATTACHMENT_COPY_ERROR = "Error while performing upload";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_IMPORT_ERROR = "Error while performing instruction import";
    /**
     * Constant.
     */
    public static final String INSTRUCTION_DOWNLOAD_ERROR = "Error while downloading instruction";
    /**
     * Constant.
     */
    public static final String WORK_INSTRUCTIONS_NOT_AVAILABLE = "Work Instruction not available in the application";
    /**
     * Constant.
     */
    public static final String VALIDATION = "Validation";
    /**
     * Constant.
     */
    public static final String WORKFLOW_VALIDATOR_ERROR = "User not specified as validator in workflow";
    /**
     * Constant.
     */
    public static final String WORK_INSTRUCTION_ALREADY_APPROVED = "User already approved the work instruction";
    /**
     * Constant.
     */
    public static final String RTEMEDIA_ERROR = "Error while fetching RTE media Image.";
    /**
     * Constant.
     */
    public static final String RTEMEDIA_SAVE_ERROR = "Unable to save new RTEMedia";

    /**
     * Constant.
     */
    public static final String AUTHOR_MANAGMENT_LABEL = "AuthorManagement";
    /**
     * Constant.
     */
    public static final String AUTHOR_MANAGMENT_RECORD_NOT_EXISTS = "Record does not exists for the author Management.";
    /**
     * Constant.
     */
    public static final String AUTHOR_MANAGMENT_UPDATE_ERROR = "Unable to update author Management";

    /**
     * Constant.
     */
    public static final String DWI_HEADER_LABEL = "DwiHeader";
    /**
     * Constant.
     */
    public static final String DWI_HEADER_RECORD_NOT_EXISTS = "Record does not exists for the DwiHeader.";
    /**
     * Constant.
     */
    public static final String DWI_HEADER_CREATE_ERROR = "Error while creating record for DwiHeader";
    /**
     * Constant.
     */
    public static final String DWI_HEADER_UPDATE_ERROR = "Unable to update DwiHeader";
    /**
     * Constant.
     */
    public static final String DWI_HEADER_VIEW_ERROR = "Unable to view DwiHeader";

    /**
     * Constant.
     */
    public static final String FLEET_LABEL = "Fleet";
    /**
     * Constant.
     */
    public static final String FUNCTION_LABEL = "Function";
    /**
     * Constant.
     */
    public static final String PROCESS_LABEL = "Process";
    /**
     * Constant.
     */
    public static final String PROJECT_LABEL = "Project";
    /**
     * Constant.
     */
    public static final String REVISION_LABEL = "Revision";
    /**
     * Constant.
     */
    public static final String PROJECT_USER_ROLE_LABEL = "Project User Role";
    /**
     * Constant.
     */
    public static final String NOTIFICATION_SETTINGS_LABEL = "NotificationSettings";
    /**
     * Constant.
     */
    public static final String TAGS_LABEL = "Tags";
    /**
     * Constant.
     */
    public static final String TEMPLATE_LABEL = "Template";
    /**
     * Constant.
     */
    public static final String USER_SEARCH_QUERY_LABEL = "User Search Query";
    /**
     * Constant.
     */
    public static final String WORKFLOW_TEMPLATE_LABEL = "WorkFlowTemplate";
    /**
     * Constant.
     */
    public static final String WORKFLOW_TEMPLATE_DESC_LABEL = "WorkFlowTemplateDesc";
    /**
     * Constant.
     */
    public static final String NOTIFICATION_SETTINGS_FOUND_MANY = "Multiple settings found. Only one settings is allowed. Please remove others";

    /**
     * Constant.
     */
    public static final String SELECT_PROJECT_ERROR = "Please select Project";
    /**
     * Constant.
     */
    public static final String SELECT_FLEET_ERROR = "Please select Fleet";
    /**
     * Constant.
     */
    public static final String SELECT_PROCESS_ERROR = "Please select Process";
    /**
     * Constant.
     */
    public static final String RECORD_NOT_EXISTS = "Record does not exists";
    /**
     * Constant.
     */
    public static final String RECORD_EXISTS = "Record already exists";
    /**
     * Constant.
     */
    public static final String CREATE_ERROR = "Error while creating record";
    /**
     * Constant.
     */
    public static final String UPDATE_ERROR = "Unable to update record";
    /**
     * Constant.
     */
    public static final String VIEW_ERROR = "Unable to view record";
    /**
     * Constant.
     */
    public static final String DELETE_ERROR = "Error occurred while performing delete";
    /**
     * Constant.
     */
    public static final String MANDATORY = "Mandatory field. Please select";
    /**
     * Constant.
     */
    public static final String TEMPLATE_MANDATORY = "Content and project is mandatory for a template";

    /**
     * invalid token constant.
     */
    public static final String INVALID_TOKEN = "invalid_token";
    /**
     * invalid user constant.
     */
    public static final String INVALID_USER = "invalid_user";
    /**
     * app role empty constant.
     */
    public static final String APP_ROLE_EMPTY = "App Roles property is empty in the authentication token";
    /**
     * email empty in token constant.
     */
    public static final String TOKEN_EMAIL_EMPTY = "Preferred username (Email) property is empty in the authentication token";
    /**
     * space delimiter constant.
     */
    public static final String SPACE_DELIMITER = " ";
    /**
     * user not registered in app constant.
     */
    public static final String USER_NOT_REGISTERED = "User (%s) is not registered for the application. Please contact application admin";
    /**
     * Actuator security config order.
     */
    public static final int ACTUATOR_ORDER = 1;
    /**
     * QlikSense security config order.
     */
    public static final int QLIK_SENSE_ORDER = 2;
    /**
     * Image security config order.
     */
    public static final int IMAGE_ORDER = 3;
    /**
     * API security config order.
     */
    public static final int API_ORDER = 4;
    /**
     * Content security policy used for http security configuration.
     */
    public static final String CONTENT_SECURITY_POLICY = "script-src 'self'";
    /**
     * actuator endpoints constant.
     */
    public static final String ACTUATOR_ENPOINTS = "/actuator/**";
    /**
     * qliksense endpoints constant.
     */
    public static final String QLIK_SENSE_ENPOINTS = "/qliksense/**";
    /**
     * rte media endpoints constant.
     */
    public static final String RTE_MEDIA_ENPOINTS = "/rte/image/**";

    /**
     * Number Constant 0.
     */
    public static final int ZERO = 0;
    /**
     * Number Constant 0.
     */
    public static final int ONE = 1;
    /**
     * Number Constant 0.
     */
    public static final int TWO = 2;
    /**
     * Number Constant 0.
     */
    public static final int THREE = 3;
    /**
     * Number Constant 0.
     */
    public static final int FOUR = 4;
    /**
     * Number Constant 0.
     */
    public static final int FIVE = 5;
    /**
     * Number Constant 0.
     */
    public static final int SIX = 6;
    /**
     * Number Constant 0.
     */
    public static final int SEVEN = 7;
    /**
     * Number Constant 0.
     */
    public static final int EIGHT = 8;
    /**
     * Number Constant 0.
     */
    public static final int NINE = 9;
    /**
     * Number Constant 10.
     */
    public static final int TEN = 10;
    /**
     * Number Constant 10.
     */
    public static final int ELEVEN = 11;
    /**
     * Number Constant 0.
     */
    public static final int TWELVE = 12;
    /**
     * Number Constant 0.
     */
    public static final int THIRTEEN = 13;
    /**
     * Number Constant 0.
     */
    public static final int FOURTEEN = 14;
    /**
     * Number Constant 0.
     */
    public static final int FIFTEEN = 15;
    /**
     * Number Constant 0.
     */
    public static final int SIXTEEN = 16;
    /**
     * Number Constant 0.
     */
    public static final int SEVENTEEN = 17;
    /**
     * Number Constant 20.
     */
    public static final int TWENTY = 20;
    /**
     * Number Constant 25.
     */
    public static final int TWENTY_FIVE = 25;
    /**
     * Number Constant 20.
     */
    public static final int THIRTY = 30;
    /**
     * Number Constant 36.
     */
    public static final int THIRTY_SIX = 36;
    /**
     * Number Constant 50.
     */
    public static final int FIFTY = 50;
    /**
     * Number Constant 100.
     */
    public static final int HUNDRED = 100;
    /**
     * Number Constant 200.
     */
    public static final int TWO_HUNDRED = 200;
    /**
     * Number Constant 250.
     */
    public static final int TWO_HUNDRED_FIFTY = 250;
    /**
     * Number Constant 250.
     */
    public static final int TWO_HUNDRED_FIFTY_FIVE = 255;
    /**
     * Number Constant 500.
     */
    public static final int FIVE_HUNDERD = 500;
    /**
     * Number Constant 2000.
     */
    public static final int TWO_THOUSAND = 2000;
    /**
     * Number Constant 5000.
     */
    public static final int FIVE_THOUSAND = 5000;
    /**
     * Number Constant 2000.
     */
    public static final int INST_BYTE_LENGTH = 10000000;
    /**
     * Number Constant 2000.
     */
    public static final int BYTE_1024 = 1024;
    /**
     * Number Constant 2000.
     */
    public static final int LENGTH_4096 = 4096;
}
