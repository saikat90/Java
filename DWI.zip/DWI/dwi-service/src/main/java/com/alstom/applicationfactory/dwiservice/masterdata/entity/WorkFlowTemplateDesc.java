package com.alstom.applicationfactory.dwiservice.masterdata.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dwiwork_flow_template_desc")
public class WorkFlowTemplateDesc {

    /**
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     */
    @Column(nullable = false, length = Constants.EIGHT, name = "dwi_actions_enum")
    private String dwiActions;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(nullable = false, referencedColumnName = "id", name = "dwi_functions_id")
    private Function function;

    /**
     */
    @Column(length = Constants.TWO_HUNDRED, name = "name")
    private String name;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_validator_approver_id")
    private User validateApproveUser;

    /**
     */
    @Column(length = Constants.TWO_HUNDRED, name = "comments")
    private String comments;

    /**
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_work_flow_template_desc_dwiwork_flow_template_id")
    private WorkFlowTemplate workFlowTemplate;

    /**
     */
    @Column(name = "dwiwork_flow_template_dwi_work_flow_template_desc_seq", length = Constants.ELEVEN)
    private Integer wfTemplateDescSeq;

}
