package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.exception.ExcelException;
import com.alstom.applicationfactory.dwiservice.instruction.entity.Instructions;
import com.alstom.applicationfactory.dwiservice.instruction.enums.Status;
import com.alstom.applicationfactory.dwiservice.instruction.enums.SubStatus;
import com.alstom.applicationfactory.dwiservice.instruction.model.EditionControlCommentsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionWorkFlowDetailsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.WorkFlowActionHistoryModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionExcelService;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionsService;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.FleetRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProcessRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.RevisionRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateRepository;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Service(value = "instructionExcelService")
@Transactional
@Slf4j
@RefreshScope
public class InstructionExcelServiceImpl implements InstructionExcelService {

    /**
     * content types of excel.
     */
    private static final List<String> contentTypes = Arrays.asList("application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/csv");

    /**
     * ProjectRepository.
     */
    @Autowired
    private ProjectRepository projectRepository;
    /**
     * ProcessRepository.
     */
    @Autowired
    private ProcessRepository processRepository;
    /**
     * FleetRepository.
     */
    @Autowired
    private FleetRepository fleetRepository;
    /**
     * RevisionRepository.
     */
    @Autowired
    private RevisionRepository revisionRepository;
    /**
     * InstructionsRepository.
     */
    @Autowired
    private InstructionsRepository instructionsRepository;
    /**
     * InstructionsService.
     */
    @Autowired
    private InstructionsService instructionService;
    /**
     * UserRepository.
     */
    @Autowired
    private UserRepository userRepository;
    /**
     * WorkFlowTemplateRepository.
     */
    @Autowired
    private WorkFlowTemplateRepository wfTemplateRepository;
    /**
     * date format.
     */
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * @param file
     * @param email
     * @return ExcelException.
     */
    @Override
    public ExcelException importExcel(final MultipartFile file, final String email) {
        log.debug("Entry:DwiInstructionsServiceImpl:importExcel.");

        InstructionsModel instructionModel = new InstructionsModel();

        ModelMapper mapper = new ModelMapper();
        ExcelException excelException = new ExcelException();
        List<String> listError = new ArrayList<String>();
        User user = null;
        UserModel userModel = null;
        String userName = null;

        try {
            user = userRepository.findByEmail(email).get(0);
            userName = user.getFirstName().concat(" ").concat(user.getLastName());
        } catch (NullPointerException ex) {
            log.debug("User not present in the system for the email: " + email);
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(
                    new ErrorModel(Constants.AUTHOR, Constants.USER_NOT_PRESENT_FOR_MAIL + email));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_406, errors);
        }
        userModel = mapper.map(user, UserModel.class);

        try {

            Sheet sheet = null;
            InstructionsModel insModel = null;
            InputStream inputStream = file.getInputStream();

            String fileContentType = file.getContentType();

            if (fileContentType.equals("application/vnd.ms-excel")) {
                HSSFWorkbook wb = new HSSFWorkbook(inputStream);
                sheet = wb.getSheetAt(0);
                // Excel computaion(.xls)
                excelException = populateExcel(sheet, userModel);

            } else if (fileContentType
                    .equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                XSSFWorkbook wb = new XSSFWorkbook(inputStream);
                sheet = wb.getSheetAt(0);
                // Excel computation(.xlsx)
                excelException = populateExcel(sheet, userModel);

            } else if (fileContentType.equals("text/csv")) {
                // CSV computation
                excelException = PopulateCSV(inputStream, userModel);
            } else {
                listError.add("Please upload file in (xls/xlsx/csv) format ");
                excelException.setErrorDescription(listError);
            }

            log.debug("Leave:DwiInstructionsServiceImpl:importExcel.");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL,
                    Constants.INSTRUCTION_IMPORT_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errorModels);
        }

        return excelException;

    }

    /**
     * @param classType
     * @return long.
     */
    public Long checkExistingData(final Object classType) {
        Map<String, Object> request = RequestModifier.defaultRequestMapIfEmpty(null);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        long count = 0L;

        if (classType instanceof ProjectModel) {

            ProjectModel projectModel = (ProjectModel) classType;
            filterConditions.add(RequestModifier.getfilterCondition("String", "projName",
                    projectModel.getProjName(), "eq"));
            RequestModel requestModel = RequestMapper
                    .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
            count = projectRepository.count(requestModel.getFilterSpecification());

        } else if (classType instanceof FleetModel) {

            FleetModel fleetModel = (FleetModel) classType;
            filterConditions.add(RequestModifier.getfilterCondition("String", "fleetName",
                    fleetModel.getFleetName(), "eq"));
            RequestModel requestModel = RequestMapper
                    .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
            count = fleetRepository.count(requestModel.getFilterSpecification());

        } else if (classType instanceof ProcessModel) {

            ProcessModel processModel = (ProcessModel) classType;
            filterConditions.add(RequestModifier.getfilterCondition("String", "processName",
                    processModel.getProcessName(), "eq"));
            RequestModel requestModel = RequestMapper
                    .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
            count = processRepository.count(requestModel.getFilterSpecification());

        } else if (classType instanceof RevisionModel) {

            RevisionModel revisionModel = (RevisionModel) classType;
            filterConditions.add(RequestModifier.getfilterCondition("String", "revisionName",
                    revisionModel.getRevisionName(), "eq"));
            RequestModel requestModel = RequestMapper
                    .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
            count = revisionRepository.count(requestModel.getFilterSpecification());

        } else if (classType instanceof InstructionsModel) {
            InstructionsModel instructionsModel = (InstructionsModel) classType;
            Instructions ins = instructionsRepository.findByDwiNumberAndDwiEdition(
                    instructionsModel.getDwiNumber(), instructionsModel.getDwiEdition());
            if (ins != null) {
                count = 1;
            }
        }

        return count;
    }

    /**
     * @param sheet
     * @param userModel
     * @return ExcelException.
     */
    public ExcelException populateExcel(final Sheet sheet, final UserModel userModel) {
        int rowCount = 3, successRowCount = 0, failureRowCount = 0, blank = 0;
        List<String> listError = new ArrayList<String>();
        ModelMapper mapper = new ModelMapper();
        InstructionsModel insModel = null;
        List<InstructionsModel> listInstructionModel = new ArrayList<InstructionsModel>();

        log.debug("Number of rows in excel sheet : " + sheet.getPhysicalNumberOfRows());
        if (sheet.getPhysicalNumberOfRows() < 11) {
            for (Row row : sheet) // iteration over row using for each loop
            {
                long count = 0L;
                boolean failure = false;
                int j = 0;
                insModel = new InstructionsModel();
                InstructionsModel instModelDemo = new InstructionsModel();

                if (row.getRowNum() == 0 || row.getRowNum() == 1) {
                    continue;
                }
                blank = 0;

                for (Cell cell : row) // iteration over cell using for each loop
                {
                    blank = 1;
                    switch (cell.getCellType()) {
                    case BLANK:
                        failure = true;
                        if (j == 0) {
                            listError.add("DWI Number is Blank for Row " + rowCount);
                        } else if (j == 1) {
                            listError.add("Edition is Blank for Row " + rowCount);
                        } else if (j == 2) {
                            listError.add("Title is Blank for Row " + rowCount);
                        } else if (j == 3) {
                            listError.add("Reference is Blank for Row " + rowCount);
                        } else if (j == 4) {
                            listError.add("Project is Blank for Row " + rowCount);
                        } else if (j == 5) {
                            listError.add("Fleet is Blank for Row " + rowCount);
                        } else if (j == 6) {
                            listError.add("Process is Blank for Row " + rowCount);
                        } else if (j == 7) {
                            listError.add("Revision is Blank for Row " + rowCount);
                        }
                        break;
                    case NUMERIC: // field that represents numeric cell type
                        // getting the value of the cell as a number
                        log.debug(cell.getNumericCellValue() + "\t\t");
                        if (j == 1) {
                            if (cell.getNumericCellValue() != 0.0d) {
                                instModelDemo.setDwiEdition((int) cell.getNumericCellValue());
                                count = checkExistingData(instModelDemo);
                                if (count == 0) {
                                    insModel.setDwiEdition(instModelDemo.getDwiEdition());
                                    insModel.setDwiNumber(instModelDemo.getDwiNumber());
                                } else {
                                    failure = true;
                                    listError.add("dwinstructions - " + instModelDemo.getDwiNumber()
                                            + " With Edition " + instModelDemo.getDwiEdition()
                                            + " is already present in dwinstructions db ");
                                }

                            }
                        }

                        break;
                    case STRING: // field that represents string cell type
                        // getting the value of the cell as a string
                        log.debug(cell.getStringCellValue() + "\t\t");
                        if (j == 0) {
                            if (!cell.getStringCellValue().isBlank()) {
                                instModelDemo.setDwiNumber(cell.getStringCellValue());
                            }
                        } else if (j == 2) {
                            if (!cell.getStringCellValue().isBlank()) {
                                insModel.setDwiTitle(cell.getStringCellValue());
                            }
                        } else if (j == 3) {
                            if (!cell.getStringCellValue().isBlank()) {
                                insModel.setDwiReference(cell.getStringCellValue());
                            }
                        } else if (j == 4) {
                            if (!cell.getStringCellValue().isBlank()) {
                                ProjectModel proj = new ProjectModel();
                                proj.setProjName(cell.getStringCellValue());
                                count = checkExistingData(proj);

                                if (count == 0) {
                                    failure = true;
                                    listError.add("Project - " + proj.getProjName()
                                            + " is not in the Master Data ");
                                } else {
                                    List<Project> pro = projectRepository
                                            .findByProjName(proj.getProjName());
                                    if (pro != null && pro.size() != 0) {
                                        proj = mapper.map(pro.get(0), ProjectModel.class);
                                        insModel.setProject(proj);
                                    }
                                }
                            }

                        } else if (j == 5) {
                            if (!cell.getStringCellValue().isBlank()) {
                                FleetModel fleet = new FleetModel();
                                fleet.setFleetName(cell.getStringCellValue());
                                count = checkExistingData(fleet);
                                if (count == 0) {
                                    failure = true;
                                    listError.add("Fleet - " + fleet.getFleetName()
                                            + " is not in the Master Data ");
                                } else if (failure != true && insModel.getProject() != null) {
                                    List<Fleet> fleetList = fleetRepository
                                            .findByFleetNameAndProjectId(cell.getStringCellValue(),
                                                    insModel.getProject().getId());

                                    if (fleetList != null && fleetList.size() != 0) {
                                        List<Fleet> f = fleetRepository
                                                .findByFleetName(fleet.getFleetName());
                                        fleet = mapper.map(f.get(0), FleetModel.class);
                                        insModel.setFleet(fleet);
                                    } else {
                                        failure = true;
                                        listError.add("Fleet - " + fleet.getFleetName()
                                                + " is not associated with Project - "
                                                + insModel.getProject().getProjName());
                                    }
                                }
                            }
                        } else if (j == 6) {
                            if (!cell.getStringCellValue().isBlank()) {
                                ProcessModel process = new ProcessModel();
                                process.setProcessName(cell.getStringCellValue());
                                count = checkExistingData(process);
                                if (count == 0) {
                                    failure = true;
                                    listError.add("Process - " + process.getProcessName()
                                            + " is not in the Master Data ");
                                } else if (failure != true) {
                                    List<Process> listProcess = processRepository
                                            .findByProcessNameAndFleetId(cell.getStringCellValue(),
                                                    insModel.getFleet().getId());

                                    if (listProcess != null && listProcess.size() != 0) {
                                        List<Process> pr = processRepository
                                                .findByProcessName(process.getProcessName());
                                        process = mapper.map(pr.get(0), ProcessModel.class);
                                        insModel.setProcess(process);
                                    } else {
                                        failure = true;
                                        listError.add("Process - " + process.getProcessName()
                                                + " is not associated with Fleet - "
                                                + insModel.getFleet().getFleetName());
                                    }
                                }
                            }
                        } else if (j == 7) {
                            if (!cell.getStringCellValue().isBlank()) {
                                RevisionModel revision = new RevisionModel();
                                revision.setRevisionName(cell.getStringCellValue());
                                count = checkExistingData(revision);
                                if (count == 0) {
                                    failure = true;
                                    listError.add(revision.getRevisionName()
                                            + " is not in the Master Data ");
                                } else if (failure != true) {

                                    List<Revision> listRevision = revisionRepository
                                            .findByRevisionNameAndProcessId(
                                                    cell.getStringCellValue(),
                                                    insModel.getProcess().getId());

                                    if (listRevision != null && listRevision.size() != 0) {
                                        List<Revision> rev = revisionRepository
                                                .findByRevisionName(revision.getRevisionName());
                                        revision = mapper.map(rev.get(0), RevisionModel.class);
                                        insModel.setRevision(revision);
                                    } else {
                                        failure = true;
                                        listError.add("Revision - " + revision.getRevisionName()
                                                + " is not associated with Process - "
                                                + insModel.getProcess().getProcessName());
                                    }
                                }
                            }

                        } else if (j == 8) {
                            insModel.setDwiLongDesc(cell.getStringCellValue());
                        } else if (j == 9) {
                            EditionControlCommentsModel edc = new EditionControlCommentsModel();
                            edc.setDwiEdition(insModel.getDwiEdition());
                            edc.setDwiNumber(insModel.getDwiNumber());
                            edc.setSubmittedDate(new Date());
                            edc.setComments(cell.getStringCellValue());
                            edc.setVersion(0);
                            edc.setUser(userModel);
                            insModel.setEditionControlComments(edc);

                        }

                        break;
                    default:
                        break;
                    }

                    j++;
                }

                if (blank == 1) {
                    if (failure == false) {
                        successRowCount++;
                        insModel.setAuthor(userModel);
                        listInstructionModel.add(insModel);
                    } else {
                        failureRowCount++;
                    }
                } else {
                    listError.add("In Row - " + rowCount + " errorneous blank cell is there");
                }

                rowCount++;
            }

            // save it in DB
            List<InstructionsModel> newInstructionModelList = new ArrayList<InstructionsModel>();
            for (InstructionsModel instructionsModel : listInstructionModel) {
                newInstructionModelList.add(createImportInstruction(instructionsModel));
            }

        } else {
            listError.add("Unable to import data as number of rows are greater than 10 ");
        }

        return new ExcelException(successRowCount, failureRowCount, listError);
    }

    /**
     * @param inputStream
     * @param userModel
     * @return
     */
    public ExcelException PopulateCSV(final InputStream inputStream, final UserModel userModel) {
        int rowCount = 3, successRowCount = 0, failureRowCount = 0;
        ModelMapper mapper = new ModelMapper();
        InstructionsModel insModel = null;
        List<String> listError = new ArrayList<String>();
        List<InstructionsModel> listInstructionModel = new ArrayList<InstructionsModel>();

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));

            String line = "";

            while ((line = br.readLine()) != null) {
                InstructionsModel instModelDemo = new InstructionsModel();
                long countDup = 0L;
                boolean failure = true;
                String[] data = line.split(",");
                insModel = new InstructionsModel();

                // call Method
                if (!data[0].isBlank()) {
                    // InstructionsModel instModel = new InstructionsModel();
                    instModelDemo.setDwiNumber(data[0]);

                } else {
                    failure = true;
                    listError.add("DWI Number is Blank for Row in csv" + rowCount);
                }

                if (!data[1].isBlank()) {
                    instModelDemo.setDwiEdition(Integer.parseInt(data[1]));
                    countDup = checkExistingData(instModelDemo);
                    if (countDup == 0) {
                        insModel.setDwiEdition(instModelDemo.getDwiEdition());
                        insModel.setDwiNumber(instModelDemo.getDwiNumber());
                    } else {
                        failure = true;
                        listError.add("dwinstructions - " + instModelDemo.getDwiNumber()
                                + " With Edition " + instModelDemo.getDwiEdition()
                                + " is already present in dwinstructions db ");
                    }
                } else {
                    failure = true;
                    listError.add("Edition is Blank for Row in csv" + rowCount);
                }

                if (!data[2].isBlank()) {
                    insModel.setDwiTitle(data[2]);
                } else {
                    failure = true;
                    listError.add("Title is Blank for Row in csv" + rowCount);
                }

                if (!data[3].isBlank()) {
                    insModel.setDwiReference(data[3]);
                } else {
                    failure = true;
                    listError.add("Reference is Blank for Row in csv" + rowCount);
                }

                if (!data[4].isBlank()) {
                    ProjectModel proj = new ProjectModel();
                    proj.setProjName(data[4]);
                    countDup = checkExistingData(proj);

                    if (countDup == 0) {
                        failure = true;
                        listError.add(
                                "Project - " + proj.getProjName() + " is not in the Master Data ");
                    } else {
                        List<Project> pro = projectRepository.findByProjName(proj.getProjName());
                        if (pro != null && pro.size() != 0) {
                            proj = mapper.map(pro.get(0), ProjectModel.class);
                            insModel.setProject(proj);
                        }
                    }
                } else {
                    failure = true;
                    listError.add("Project is Blank for Row in csv" + rowCount);
                }

                if (!data[5].isBlank()) {
                    FleetModel fleet = new FleetModel();
                    fleet.setFleetName(data[5]);
                    countDup = checkExistingData(fleet);
                    if (countDup == 0) {
                        failure = true;
                        listError.add(
                                "Fleet - " + fleet.getFleetName() + " is not in the Master Data ");
                    } else if (failure != true && insModel.getProject() != null) {
                        List<Fleet> fleetList = fleetRepository.findByFleetNameAndProjectId(data[5],
                                insModel.getProject().getId());

                        if (fleetList != null && fleetList.size() != 0) {
                            List<Fleet> f = fleetRepository.findByFleetName(fleet.getFleetName());
                            fleet = mapper.map(f.get(0), FleetModel.class);
                            insModel.setFleet(fleet);
                        } else {
                            failure = true;
                            listError.add("Fleet - " + fleet.getFleetName()
                                    + " is not associated with Project - "
                                    + insModel.getProject().getProjName());
                        }
                    }
                } else {
                    failure = true;
                    listError.add("Fleet is Blank for Row " + rowCount);
                }

                if (!data[6].isBlank()) {
                    ProcessModel process = new ProcessModel();
                    process.setProcessName(data[6]);
                    countDup = checkExistingData(process);
                    if (countDup == 0) {
                        failure = true;
                        listError.add("Process - " + process.getProcessName()
                                + " is not in the Master Data ");
                    } else if (failure != true) {
                        List<Process> listProcess = processRepository
                                .findByProcessNameAndFleetId(data[6], insModel.getFleet().getId());

                        if (listProcess != null && listProcess.size() != 0) {
                            List<Process> pr = processRepository
                                    .findByProcessName(process.getProcessName());
                            process = mapper.map(pr.get(0), ProcessModel.class);
                            insModel.setProcess(process);
                        } else {
                            failure = true;
                            listError.add("Process - " + process.getProcessName()
                                    + " is not associated with Fleet - "
                                    + insModel.getFleet().getFleetName());
                        }
                    }
                } else {
                    failure = true;
                    listError.add("Process is Blank for Row " + rowCount);
                }

                if (!data[7].isBlank()) {
                    RevisionModel revision = new RevisionModel();
                    revision.setRevisionName(data[7]);
                    countDup = checkExistingData(revision);
                    if (countDup == 0) {
                        failure = true;
                        listError.add("Revision - " + revision.getRevisionName()
                                + " is not in the Master Data ");
                    } else if (failure != true) {

                        List<Revision> listRevision = revisionRepository
                                .findByRevisionNameAndProcessId(data[7],
                                        insModel.getProcess().getId());

                        if (listRevision != null && listRevision.size() != 0) {
                            List<Revision> rev = revisionRepository
                                    .findByRevisionName(revision.getRevisionName());
                            revision = mapper.map(rev.get(0), RevisionModel.class);
                            insModel.setRevision(revision);
                        } else {
                            failure = true;
                            listError.add("Revision - " + revision.getRevisionName()
                                    + " is not associated with Process - "
                                    + insModel.getProcess().getProcessName());
                        }
                    }
                } else {
                    failure = true;
                    listError.add("Revision is Blank for Row " + rowCount);
                }

                insModel.setDwiLongDesc(data[8]);

                EditionControlCommentsModel edc = new EditionControlCommentsModel();
                edc.setDwiEdition(insModel.getDwiEdition());
                edc.setDwiNumber(insModel.getDwiNumber());
                edc.setSubmittedDate(new Date());
                edc.setComments(data[9]);
                edc.setVersion(0);
                edc.setUser(userModel);
                insModel.setEditionControlComments(edc);

                if (failure == false) {
                    successRowCount++;
                    insModel.setAuthor(userModel);
                    listInstructionModel.add(insModel);
                } else {
                    failureRowCount++;
                }

                rowCount++;
            }

            // save it in DB
            List<InstructionsModel> newInstructionModelList = new ArrayList<InstructionsModel>();
            for (InstructionsModel instructionsModel : listInstructionModel) {
                newInstructionModelList.add(createImportInstruction(instructionsModel));
            }

        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            List<ErrorModel> errorModels = new ArrayList<>();
            ErrorModel errorModel = new ErrorModel(Constants.ERROR_LABEL,
                    Constants.INSTRUCTION_IMPORT_ERROR);
            errorModels.add(errorModel);
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errorModels);
        }

        return new ExcelException(successRowCount, failureRowCount, listError);

    }

    /**
     * @param instructionModel
     * @return
     */
    public InstructionsModel createImportInstruction(InstructionsModel instructionModel) {
        log.debug("Entry:DwiInstructionExcelServiceImpl:createImportInstruction.");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        List<InstructionWorkFlowDetailsModel> workFlowDetailsModelsList = new ArrayList<>();
        List<WorkFlowActionHistoryModel> wfHistoryModelList = new ArrayList<>();
        byte[] history = new byte[Constants.INST_BYTE_LENGTH];

        if (instructionModel != null) {
            UserModel creatorModel = instructionModel.getAuthor();
            String creatorUserName = creatorModel.getFirstName().concat(" ")
                    .concat(creatorModel.getLastName());
            WorkFlowActionHistoryModel wfHistoryModel = new WorkFlowActionHistoryModel();
            wfHistoryModel.setVersion(0);
            wfHistoryModel.setWfhActionDate(new Date());
            wfHistoryModel.setWfhUser(creatorModel);
            wfHistoryModel.setWfhUserName(creatorUserName);
            wfHistoryModel.setWfhUserComments(instructionModel.getApproverValidatorComments());
            wfHistoryModel.setWfhdepartment(creatorModel.getDepartment());
            wfHistoryModel.setWfhOperation(Constants.CREATED);

            List<WorkFlowTemplate> wfTemplateList = wfTemplateRepository
                    .findByProjectId(instructionModel.getProject().getId());
            WorkFlowTemplate wfTemplate = wfTemplateList.get(0);
            WorkFlowTemplateModel wfTemplateModel = mapper.map(wfTemplate,
                    WorkFlowTemplateModel.class);
            instructionModel.setWorkFlowTemplate(wfTemplateModel);

            List<WorkFlowTemplateDescModel> workFlowTempDescList = instructionModel
                    .getWorkFlowTemplate().getActions();
            workFlowTempDescList.forEach(item -> {
                InstructionWorkFlowDetailsModel wfDetailModel = new InstructionWorkFlowDetailsModel();
                wfDetailModel.setVersion(0);
                wfDetailModel.setDwiActions(item.getDwiActions());
                wfDetailModel.setFunction(item.getFunction());
                wfDetailModel.setName(item.getName());
                wfDetailModel.setApproverOrValidatorUser(item.getValidateApproveUser());
                wfDetailModel.setApprovedRejectDate(null);
                wfDetailModel.setApproverAction(null);
                wfDetailModel.setWfTemplateDescSeq(item.getWfTemplateDescSeq());
                workFlowDetailsModelsList.add(wfDetailModel);
            });

            String his = dateFormat.format(new Date()).concat(Constants.INFO_DELIMITER)
                    .concat(creatorUserName).concat(Constants.INFO_DELIMITER)
                    .concat(Constants.OBJ_IMPORTED);
            history = his.getBytes();
            instructionModel.setHistory(history);
            wfHistoryModelList.add(wfHistoryModel);
            instructionModel.setWorkFlowActionHistoryList(wfHistoryModelList);
            instructionModel.setWorkFlowDetailsList(workFlowDetailsModelsList);
            instructionModel.setInstructionAttachmentList(null);

            instructionModel.setCreatedDate(new Date());
            instructionModel.setCreatedBy(creatorModel.getEmployeeId());
            instructionModel.setFirstValidator(null);
            instructionModel.setApprover(null);
            instructionModel.setDwiSubStatus(SubStatus.NEW.toString());
            instructionModel.setDwiStatus(Status.IMPORTED.toString());
            instructionModel.setApproverValidatorComments(null);
            instructionModel.setVersion(0);
            instructionModel.setApprovedActiveEdition(false);
            instructionModel.setNewEditionCreated(false);

            Instructions instruction = mapper.map(instructionModel, Instructions.class);

            if (Objects.nonNull(instruction.getWorkFlowActionHistoryList())
                    && !instruction.getWorkFlowActionHistoryList().isEmpty()) {
                Instructions finalInstruction = instruction;
                instruction.getWorkFlowActionHistoryList()
                        .forEach(item -> item.setWfhInstructions(finalInstruction));
            }

            if (Objects.nonNull(instruction.getEditionControlComments())) {
                Instructions finalInstruction = instruction;
                instruction.getEditionControlComments().setInstructions(finalInstruction);
            }

            if (instruction.getInstructiontagsList().isEmpty()) {
                instruction.setInstructiontagsList(null);
            }

            if (Objects.nonNull(instruction.getWorkFlowDetailsList())
                    && !instruction.getWorkFlowDetailsList().isEmpty()) {
                Instructions finalInstruction = instruction;
                instruction.getWorkFlowDetailsList()
                        .forEach(item -> item.setInstructions(finalInstruction));
            }

            if (instruction.getInstructionApproversList().isEmpty()) {
                instruction.setInstructionApproversList(null);
            }
            if (instruction.getInstructionValidatorsList().isEmpty()) {
                instruction.setInstructionValidatorsList(null);
            }

            if (Objects.nonNull(instruction.getInstructionAttachmentList())
                    && !instruction.getInstructionAttachmentList().isEmpty()) {
                Instructions finalInstruction = instruction;
                instruction.getInstructionAttachmentList()
                        .forEach(item -> item.setInstructions(finalInstruction));
            }
            instruction = this.instructionsRepository.save(instruction);
            instructionModel = mapper.map(instruction, InstructionsModel.class);

            log.debug("Leave:DwiInstructionExcelServiceImpl:createImportInstruction.");
        }
        return instructionModel;
    }
}
