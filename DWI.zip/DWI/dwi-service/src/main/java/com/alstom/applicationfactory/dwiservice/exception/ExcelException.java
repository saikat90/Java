package com.alstom.applicationfactory.dwiservice.exception;

import java.util.List;

import lombok.Data;

@Data
public class ExcelException {
    /**
     * success row count.
     */
    private int successRowCount;
    /**
     * failure row count.
     */
    private int failureRowCount;
    /**
     * error description.
     */
    private List<String> errorDescription;

    /**
     * Excel Exception.
     */
    public ExcelException() {

    }

    /**
     * @param errorDesc
     */
    public ExcelException(final List<String> errorDesc) {
        super();
        this.errorDescription = errorDesc;
    }

    /**
     * @param succRowCount
     * @param failRowCount
     * @param errorDesc
     */
    public ExcelException(final int succRowCount, final int failRowCount,
            final List<String> errorDesc) {
        super();
        this.successRowCount = succRowCount;
        this.failureRowCount = failRowCount;
        this.errorDescription = errorDesc;
    }

}
