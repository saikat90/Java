package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.UUID;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationSettingsModel {
    /**
     */
    private UUID id;
    /**
     */
    @Min(value = 1, message = "Verification auto-reminder waiting period minimum value should be 1")
    @NotNull(message = "Verification auto-reminder waiting period should not be empty")
    private int verificationAutoReminderWaitingPeriod;
    /**
     */
    @Min(value = 1, message = "Approval auto-reminder waiting period minimum value should be 1")
    @NotNull(message = "Approval auto-reminder waiting period should not be empty")
    private int approvalAutoReminderWaitingPeriod;
}
