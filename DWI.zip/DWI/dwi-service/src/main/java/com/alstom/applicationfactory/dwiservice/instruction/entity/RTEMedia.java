package com.alstom.applicationfactory.dwiservice.instruction.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "rtemedia")
public class RTEMedia {

    /**
     */
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    private UUID id;

    /**
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     */
    @Column(name = "name", length = Constants.TWO_HUNDRED_FIFTY_FIVE)
    private String name;

    /**
     */
    @Column(name = "content")
    private byte[] content;

}
