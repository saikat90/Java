package com.alstom.applicationfactory.dwiservice.instruction.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Function;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dwinstructions_work_flow_details")
public class InstructionWorkFlowDetails {

    /**
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     */
    @Column(nullable = false, name = "version")
    private Integer version;

    /**
     */
    @Column(length = Constants.EIGHT, name = "dwi_actions_enum")
    private String dwiActions;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_funtions_id")
    private Function function;

    /**
     */
    @Column(length = Constants.TWO_HUNDRED, name = "name")
    private String name;

    /**
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dwi_validator_approver_id")
    private User approverOrValidatorUser;

    /**
     */
    @Column(name = "approved_reject_date")
    private Date approvedRejectDate;

    /**
     */
    @Column(name = "approver_action", length = Constants.HUNDRED)
    private String approverAction;

    /**
     */
    @Column(length = Constants.TWO_HUNDRED, name = "signature_comments")
    private String signatureComments;

    /**
     */
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(referencedColumnName = "id", name = "dw_instructions_id")
    private Instructions instructions;

    /**
     */
    @Column(name = "dwinstructions_dwi_work_flow_details_seq")
    private Integer wfTemplateDescSeq;

}
