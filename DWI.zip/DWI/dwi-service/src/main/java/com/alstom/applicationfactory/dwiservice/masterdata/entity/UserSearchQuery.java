package com.alstom.applicationfactory.dwiservice.masterdata.entity;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_search_query")
public class UserSearchQuery {

    /**
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(nullable = false, referencedColumnName = "id", name = "dwi_user_id")
    private User user;

    /**
     */
    @Column(nullable = false)
    private String name;

    /**
     */
    @Column(nullable = false)
    private String screenName;

    /**
     */
    @Column(length = Constants.LENGTH_4096, nullable = false)
    private String criteria;

    /**
     */
    @Column(name = "default_query")
    private boolean defaultQuery;

    /**
     */
    @Column(name = "shared")
    private boolean shared;

    /**
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(nullable = false, referencedColumnName = "id", name = "shared_by_user_id")
    private User sharedByUser;

    /**
     */
    @ManyToMany
    @CollectionTable(name = "user_search_query_shared_users")
    private List<User> sharedToUsers = Collections.EMPTY_LIST;

    /**
     */
    @Column(name = "create_timestamp")
    private Date createdDate;

    /**
     */
    @Column(name = "last_update_timestamp")
    private Date modifiedDate;

    /**
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     */
    @Column(name = "updated_by")
    private String modifiedBy;
}
