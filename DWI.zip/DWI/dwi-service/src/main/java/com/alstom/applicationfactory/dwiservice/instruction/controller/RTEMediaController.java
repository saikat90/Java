package com.alstom.applicationfactory.dwiservice.instruction.controller;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alstom.applicationfactory.dwiservice.instruction.model.RTEMediaModel;
import com.alstom.applicationfactory.dwiservice.instruction.service.RTEMediaService;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/rte")
@Slf4j
@RefreshScope
public class RTEMediaController {

    /**
     * RTEMediaService.
     */
    @Autowired
    private RTEMediaService rteMediaService;

    /**
     * @param id
     * @param response
     * @throws IOException
     */
    @GetMapping("/image/{id}")
    public void getImage(@PathVariable("id") final UUID id, final HttpServletResponse response)
            throws IOException {
        log.debug("Entry:RTEMediaController:getImage.");
        RTEMediaModel rteMediaModel = rteMediaService.getImage(id);
        response.setContentType("APPLICATION/OCTET-STREAM");
        response.getOutputStream().write(rteMediaModel.getContent());
        response.getOutputStream().close();
        log.debug("Leave:RTEMediaController:getImage.");
    }

    /**
     * @param file
     * @return location of the uploaded image.
     */
    @PostMapping("/image/")
    public String uploadImage(@RequestParam("file") final MultipartFile file) {
        log.debug("Entry:RTEMediaController:uploadImage.");
        RTEMediaModel rteModel = rteMediaService.uploadImage(file);

        String url = rteModel.getId().toString();

        return "{\"location\":\"" + url + "\"}";
    }

    /**
     * @param id
     */
    @DeleteMapping("/image/{id}")
    public void deleteImageById(@PathVariable("id") final UUID id) {
        log.debug("Entry:RTEMediaController:deleteImage.");
        this.rteMediaService.deleteImageById(id);
        log.debug("Leave:RTEMediaController:deleteImage.");
    }

}
