package com.alstom.applicationfactory.dwiservice.instruction.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.instruction.entity.Instructions;

@Repository
public interface InstructionsRepository
        extends JpaRepository<Instructions, UUID>, JpaSpecificationExecutor<Instructions> {
    /**
     * @param dwiNumber
     * @param dwiEdition
     * @return Instructions
     */
    Instructions findByDwiNumberAndDwiEdition(String dwiNumber, int dwiEdition);

    /**
     * @return list of qlik kpi data.
     */
    @Query(value = "select inst.dwi_number,inst.dwi_edition,inst.approved_active_edition,inst.dwi_reference,inst.dwi_status,"
            + " (select proj.dwi_project_name from dwiproject proj where proj.id = inst.dwi_project_id ),"
            + " (select usr.first_name ||' '|| usr.last_name from dwiproject proj,af_user usr  "
            + "	where proj.id = inst.dwi_project_id and proj.project_manager_id = usr.id) as project_manager_name,"
            + " (select author.first_name from af_user author "
            + "	where author.id = inst.dwi_author_id ) as author_first_nmame,"
            + "	(select author.last_name from af_user author "
            + "	where author.id = inst.dwi_author_id ) as author_last_nmame,"
            + " (select fleet.dwi_fleet_name  from dwifleet fleet where fleet.id = inst.dwi_fleet_id ),"
            + " (select revision.dwi_revision_name  from dwirevision revision where revision.id = inst.dwi_revision_id ),"
            + " (select process.dwi_process_name from dwiprocess process where process.id = inst.dwi_process_id ),"
            + " (select author.first_name from af_user author "
            + "	where author.id = dur.dwi_user_id ) as user_first_nmame,"
            + " (select author.last_name from af_user author "
            + "	where author.id = dur.dwi_user_id ) as user_last_nmame,"
            + " dur.role as user_role_name" + " from dwinstructions inst,dwiproject_user_role dur "
            + " where " + " inst.dwi_project_id = dur.dwi_project_id", nativeQuery = true)
    List<Object[]> findAllQliksenseData();
}
