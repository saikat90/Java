package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;

public interface ProjectService {

    /**
     * @param project
     * @return ProjectModel.
     */
    ProjectModel createProject(ProjectModel project);

    /**
     * @param project
     * @return ProjectModel.
     */
    ProjectModel updateProject(ProjectModel project);

    /**
     * @param requestModel
     * @return ProjectModel.
     */
    Object searchProject(RequestModel requestModel);

    /**
     * @param projectId
     * @return ProjectModel.
     */
    ProjectModel viewProject(UUID projectId);

    /**
     * @param projectId
     */
    void deleteProjectById(UUID projectId);

    /**
     * @param projectId
     * @return GetUnassignedFunctions
     */
    Object getUnassignedFunctions(UUID projectId);

    /**
     * @param projectId
     * @param functionId
     * @return ProjectModel.
     */
    ProjectModel deleteFunction(UUID projectId, UUID functionId);

    /**
     * @return GetUnassignedProjects
     */
    Object getUnassignedProjects();

    /**
     * @param projectId
     * @param functionModel
     * @return ProjectModel.
     */
    ProjectModel addFunction(UUID projectId, FunctionModel functionModel);

    /**
     * @param projectId
     * @return getAllFunctionsForProject
     */
    Object getAllFunctionsForProject(UUID projectId);
}
