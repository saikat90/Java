package com.alstom.applicationfactory.dwiservice.instruction.model;

import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InstructionWorkFlowDetailsModel {

    /**
     */
    private UUID id;

    /**
     */
    private Integer version;

    /**
     */
    private String dwiActions;

    /**
     */
    private FunctionModel function;

    /**
     */
    private String name;

    /**
     */
    @NotNull(message = "Validator / Approver is mandatory")
    private UserModel approverOrValidatorUser;

    /**
     */
    private Date approvedRejectDate;

    /**
     */
    private String approverAction;

    /**
     */
    private String signatureComments;

    /**
     */
    @JsonIgnore
    private InstructionsModel instructions;

    /**
     */
    private Integer wfTemplateDescSeq;
}
