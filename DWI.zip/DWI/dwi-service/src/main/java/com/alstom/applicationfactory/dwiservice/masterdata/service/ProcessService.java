package com.alstom.applicationfactory.dwiservice.masterdata.service;

import java.util.UUID;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;

public interface ProcessService {
    /**
     * @param process
     * @return ProcessModel.
     */
    ProcessModel createProcess(ProcessModel process);

    /**
     * @param process
     * @return ProcessModel.
     */
    ProcessModel updateProcess(ProcessModel process);

    /**
     * @param requestModel
     * @return ProcessModel.
     */
    Object searchProcess(RequestModel requestModel);

    /**
     * @param processId
     * @return ProcessModel.
     */
    ProcessModel viewProcess(UUID processId);

    /**
     * @param processId
     */
    void deleteProcessById(UUID processId);
}
