package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.WorkFlowTemplateService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;

import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("/wfTemplates")
@Slf4j
public class WorkFlowTemplateController {

    /**
     * WorkFlowTemplateService.
     */
    @Autowired
    private WorkFlowTemplateService wfTemplateService;

    /**
     * @param wfTemplate
     * @return WorkFlowTemplateModel.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public WorkFlowTemplateModel createWorkFlowTemplate(
            @RequestBody @Valid final WorkFlowTemplateModel wfTemplate) {
        log.debug("Entry:DwiWorkFlowTemplateController:createWorkFlowTemplate.");
        WorkFlowTemplateModel wfTemplateModel = wfTemplateService
                .createWorkFlowTemplate(wfTemplate);
        log.debug("Leave:DwiWorkFlowTemplateController:createWorkFlowTemplate.");
        return wfTemplateModel;
    }

    /**
     * @param wfTemplate
     * @return WorkFlowTemplateModel.
     */
    @PutMapping
    @PreAuthorize("hasAuthority('APP_DWI')")
    public WorkFlowTemplateModel updateWorkFlowTemplate(
            @RequestBody @Valid final WorkFlowTemplateModel wfTemplate) {
        log.debug("Entry:DwiWorkFlowTemplateController:updateWorkFlowTemplate.");
        WorkFlowTemplateModel wfTemplateModel = wfTemplateService
                .updateWorkFlowTemplate(wfTemplate);
        log.debug("Leave:DwiWorkFlowTemplateController:updateWorkFlowTemplate.");
        return wfTemplateModel;
    }

    /**
     * @param request
     * @return object of workflow template.
     */
    @PostMapping("/list")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public Object searchWorkFlowTemplate(
            @RequestBody(required = false) final Map<String, Object> request) {
        log.debug("Entry:DwiWorkFlowTemplateController:searchWorkFlowTemplate.");
        RequestModel requestModel = RequestMapper.map(request);
        Object res = wfTemplateService.searchWorkFlowTemplate(requestModel);
        log.debug("Leave:DwiWorkFlowTemplateController:searchWorkFlowTemplate.");
        return res;
    }

    /**
     * @param wfTemplateId
     * @return WorkFlowTemplateModel
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public WorkFlowTemplateModel viewWorkFlowTemplate(@PathVariable("id") final UUID wfTemplateId) {
        log.debug("Entry:DwiWorkFlowTemplateController:viewWorkFlowTemplate.");
        WorkFlowTemplateModel wfTemplateModel = wfTemplateService
                .viewWorkFlowTemplate(wfTemplateId);
        log.debug("Leave:DwiWorkFlowTemplateController:viewWorkFlowTemplate.");
        return wfTemplateModel;
    }

    /**
     * @param wfTemplateId
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('APP_DWI')")
    public void deleteWorkFlowTemplate(@PathVariable("id") final UUID wfTemplateId) {
        log.debug("Entry:DwiWorkFlowTemplateController:deleteWorkFlowTemplate.");
        wfTemplateService.deleteWorkFlowTemplateById(wfTemplateId);
        log.debug("Leave:DwiWorkFlowTemplateController:deleteWorkFlowTemplate.");
    }

    /**
     * @param projectId
     * @param request
     * @return list of all work flow template for project
     */
    @PostMapping("/{projectId}/list")
    @PreAuthorize("hasAnyAuthority('APP_DWI')")
    public Object getAllWorkFlowTemplateForProject(@PathVariable("projectId") final UUID projectId,
            @RequestBody(required = false) Map<String, Object> request) {
        log.debug("Entry:DwiWorkFlowTemplateController:getAllWorkFlowTemplateForProject.");
        request = RequestModifier.defaultRequestMapIfEmpty(request);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "project.id", projectId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request, filterConditions));
        Object res = this.wfTemplateService.searchWorkFlowTemplate(requestModel);
        log.debug("Leave:DwiWorkFlowTemplateController:getAllWorkFlowTemplateForProject.");
        return res;
    }
}
