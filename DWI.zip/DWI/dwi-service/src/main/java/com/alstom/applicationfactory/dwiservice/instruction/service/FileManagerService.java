package com.alstom.applicationfactory.dwiservice.instruction.service;

public interface FileManagerService {

    /**
     * @param imageSource
     * @return array of bytes of image.
     */
    byte[] getImage(String imageSource);

}
