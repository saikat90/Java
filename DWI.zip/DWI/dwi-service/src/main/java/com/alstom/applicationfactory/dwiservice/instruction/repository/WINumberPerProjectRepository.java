package com.alstom.applicationfactory.dwiservice.instruction.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.alstom.applicationfactory.dwiservice.instruction.entity.WINumberPerProject;

@Repository
public interface WINumberPerProjectRepository
        extends JpaRepositoryImplementation<WINumberPerProject, UUID> {
    /**
     * @param id
     * @return WINumberPerProject.
     */
    WINumberPerProject findByProjectId(UUID id);
}
