package com.alstom.applicationfactory.dwiservice.feign.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient("ldap-service")
public interface LdapServiceClient {

    /**
     * @param request
     * @return user objects.
     */
    @PostMapping("/users/search")
    Object findUsers(@RequestBody(required = false) Map<String, String> request);
}
