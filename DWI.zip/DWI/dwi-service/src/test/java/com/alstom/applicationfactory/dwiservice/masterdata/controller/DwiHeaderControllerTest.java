package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.DwiHeader;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.DwiHeaderModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.DwiHeaderRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.DwiHeaderService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(controllers = DwiHeaderController.class)
class DwiHeaderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DwiHeaderService dwiHeaderService;

    @MockBean
    private DwiHeaderRepository dwiHeaderRepository;

    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private WebApplicationContext context;

    ObjectMapper objMapper = new ObjectMapper();

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
            "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
    Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", user, true, new Date(), null, "test", null, null, null);

    /**
     * @throws Exception
     */
    @BeforeEach
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testSearchAllDwiHeader() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        String returnedObjAsString = "{\"pageNumber\":0,\"pageSize\":10,\"totalElements\":13,\"totalPages\":2,\"content\":[{\"id\":\"040aa608-86a1-5794-3526-74694840aaaf\",\"version\":0,\"content\":\"<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>\",\"project\":{\"id\":\"9a6901ec-26ae-8e40-eca6-6cd81de2ef57\",\"version\":8,\"projName\":\"Test Project\",\"projectManager\":{\"id\":\"54c22bf5-dd12-9a00-7f1c-933bb85a5b2d\",\"employeeId\":\"100769630\",\"firstName\":\"Shanmugam\",\"lastName\":\"RAJ\",\"email\":\"shanmugam.raj@alstomgroup.com\",\"department\":\"IS&T Project CoE\"},\"active\":true,\"createdDate\":\"2019-08-12T00:00:00.000+0000\",\"modifiedDate\":\"2019-08-12T00:00:00.000+0000\",\"createdBy\":\"100769630\",\"modifiedBy\":\"dev\",\"projFunctions\":[]}},{\"id\":\"0e364d23-ee8b-c0f4-f75d-f4eac4bef403\",\"version\":0,\"content\":\"<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>TEST DWI Header</div>\\n</body>\\n</html>\",\"project\":{\"id\":\"ca42d3ca-8f92-b244-e3ca-1a47ea34676f\",\"version\":10,\"projName\":\"METROREX\",\"projectManager\":{\"id\":\"a60510f2-c2a2-e76b-714b-d8844e035926\",\"employeeId\":\"9827\",\"firstName\":\"Mihaela\",\"lastName\":\"ZANFIR\",\"email\":\"mihaela.zanfir@alstomgroup.com\",\"department\":\"IND\"},\"active\":true,\"createdDate\":\"2019-08-12T00:00:00.000+0000\",\"modifiedDate\":\"2019-08-12T00:00:00.000+0000\",\"createdBy\":\"240619\",\"modifiedBy\":\"dev\",\"projFunctions\":[]}}]}";

        Object obj = returnedObjAsString;
        RequestModel requestModel = RequestMapper.map(request1);
        when(dwiHeaderService.findAll(requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders.post("/dwiHeader/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testGetAllDwiHeader() throws Exception {
        DwiHeader dwiHeader_1 = new DwiHeader(
                UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"), 0,
                "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>",
                project);

        DwiHeader dwiHeader_2 = new DwiHeader(
                UUID.fromString("0e364d23-ee8b-c0f4-f75d-f4eac4bef403"), 0,
                "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>TEST DWI Header</div>\\n</body>\\n</html>",
                project);

        List<DwiHeader> dwiHeaderModelList = new ArrayList<>();
        dwiHeaderModelList.add(dwiHeader_1);
        dwiHeaderModelList.add(dwiHeader_2);

        RequestBuilder request = MockMvcRequestBuilders.get("/dwiHeader/list")
                .accept(MediaType.APPLICATION_JSON);

        when(dwiHeaderRepository.findAll()).thenReturn(dwiHeaderModelList);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testCreateDwiHeader() throws Exception {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        ProjectModel projectModel = mapper.map(project, ProjectModel.class);

        DwiHeaderModel dwiHeaderModel = new DwiHeaderModel(null, 0,
                "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>",
                projectModel);

        DwiHeaderModel createdDwiHeaderModel = new DwiHeaderModel(
                UUID.fromString("440cd709-6f33-0d82-fa94-74e10069f469"), 0,
                "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>",
                projectModel);

        String json = objMapper.writeValueAsString(dwiHeaderModel);

        when(dwiHeaderService.createDwiHeader(dwiHeaderModel)).thenReturn(createdDwiHeaderModel);

        RequestBuilder request = MockMvcRequestBuilders.post("/dwiHeader")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());

    }

    /**
     * @throws Exception
     */
    @Test
    void testUpdateDwiHeader() throws Exception {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        ProjectModel projectModel = mapper.map(project, ProjectModel.class);

        DwiHeaderModel updatedDwiHeaderModel = new DwiHeaderModel(null, 0,
                "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>Content Updated</div>\\n</body>\\n</html>",
                projectModel);
        String json = objMapper.writeValueAsString(updatedDwiHeaderModel);

        when(dwiHeaderService.updateDwiHeader(updatedDwiHeaderModel))
                .thenReturn(updatedDwiHeaderModel);

        RequestBuilder request = MockMvcRequestBuilders.put("/dwiHeader")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());

    }

    /**
     * @throws Exception
     */
    @Test
    void testViewDwiHeader() throws Exception {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        ProjectModel projectModel = mapper.map(project, ProjectModel.class);

        DwiHeaderModel createdDwiHeaderModel = new DwiHeaderModel(
                UUID.fromString("440cd709-6f33-0d82-fa94-74e10069f469"), 0,
                "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>",
                projectModel);
        when(dwiHeaderService
                .viewDwiHeader(UUID.fromString("440cd709-6f33-0d82-fa94-74e10069f469")))
                        .thenReturn(createdDwiHeaderModel);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/dwiHeader/21ebfe8f-dbc6-2271-db80-3c0534288771")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteDwiHeaderById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/dwiHeader/440cd709-6f33-0d82-fa94-74e10069f469")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

}
