package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Tag;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TagModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.TagRepository;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class TagServiceImplTest {

    @InjectMocks
    TagServiceImpl tagService;
    @Mock
    private TagRepository tagRepository;
    ObjectMapper objMapper = new ObjectMapper();

    TagModel tagModel = new TagModel(null, 0, "cleaning");
    TagModel createdTagModel = new TagModel(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
    TagModel updatedTagModel = new TagModel(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0,
            "cleaning-Test");

    /**
     * testCreateTag
     */
    @Test
    void testCreateTag() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Tag tag = mapper.map(tagModel, Tag.class);
        Tag createdtag = mapper.map(createdTagModel, Tag.class);
        when(tagRepository.save(tag)).thenReturn(createdtag);
        assertThat(tagService.createTag(tagModel)).isEqualTo(createdTagModel);
    }

    @Test
    void testCreateTagForNullTags() {
        tagModel.setDwTags(null);
        assertThrows(ApplicationFactoryException.class, () -> tagService.createTag(tagModel), "");
    }

    @Test
    void testCreateTagForRecordExists() {
        when(tagRepository.count(Mockito.any(FilterSpecification.class))).thenReturn((long) 1);
        assertThrows(ApplicationFactoryException.class, () -> tagService.createTag(tagModel), "");
    }

    @Test
    void testUpdateTag() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Tag createdtag = mapper.map(createdTagModel, Tag.class);
        Tag updatedTag = mapper.map(updatedTagModel, Tag.class);
        when(tagRepository.findById(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0")))
                .thenReturn(Optional.of(createdtag));
        when(tagRepository.save(updatedTag)).thenReturn(updatedTag);
        TagModel updatedTagModel = mapper.map(updatedTag, TagModel.class);
        assertThat(tagService.updateTag(updatedTagModel)).isEqualTo(updatedTagModel);
    }

    @Test
    void testUpdateTagForNullTags() {
        updatedTagModel.setDwTags(null);
        assertThrows(ApplicationFactoryException.class, () -> tagService.updateTag(updatedTagModel), "");
    }

    @Test
    void testUpdateTagForRecordNotExist() {
        assertThrows(ApplicationFactoryException.class, () -> tagService.updateTag(updatedTagModel), "");
    }

    @Test
    void testSearchTag() {
        Tag tag = new Tag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
        Tag tag1 = new Tag(UUID.fromString("03f9480a-496d-199c-7e4f-265112fdfe88"), 0, "GIDS");
        List<Tag> tagList = new ArrayList<>();
        tagList.add(tag);
        tagList.add(tag1);

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        RequestModel requestModel = RequestMapper.map(request1);

        when(tagRepository.findAll(requestModel.getFilterSpecification())).thenReturn(tagList);
        Object obj1 = tagService.searchTag(requestModel);
        assertThat((tagList.size() == '2'));
    }

    /**
     * testViewTag
     */
    @Test
    void testViewTag() {

        Tag tag = new Tag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        TagModel tagModel = mapper.map(tag, TagModel.class);

        when(tagRepository.findById(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0")))
                .thenReturn(Optional.of(tag));

        assertThat(tagService.viewTag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"))).isEqualTo(tagModel);
    }

    @Test
    void testViewTagForCatch() {
        when(tagRepository.findById(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> tagService.viewTag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0")), "");
    }

    @Test
    void testDeleteTag() {
        Tag tag = new Tag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        when(tagRepository.findById(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0")))
                .thenReturn(Optional.of(tag));

        tagService.deleteTag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"));
        verify(tagRepository).delete(tag);
    }

    @Test
    void testDeleteTagForCatch() {
        Tag tag = new Tag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
        when(tagRepository.findById(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0")))
                .thenReturn(Optional.of(tag));
        doThrow(ApplicationFactoryException.class).when(tagRepository).delete(tag);
        assertThrows(ApplicationFactoryException.class,
                () -> tagService.deleteTag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0")), "");
    }
}
