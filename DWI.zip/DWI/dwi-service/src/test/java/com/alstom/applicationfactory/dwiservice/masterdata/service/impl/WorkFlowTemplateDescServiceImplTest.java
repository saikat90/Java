package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplateDesc;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateDescRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateRepository;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class WorkFlowTemplateDescServiceImplTest {

    @Mock
    private WorkFlowTemplateRepository wfTemplateRepository;
    @Mock
    private WorkFlowTemplateDescRepository wfTemplateDescRepository;
    @InjectMocks
    WorkFlowTemplateDescServiceImpl wfTemplateDescService;
    ObjectMapper objMapper = new ObjectMapper();

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
    ProjectModel project = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
            userModel, true, new Date(), null, "test", null, null, null);
    FunctionModel functionModel = new FunctionModel(UUID.fromString("bdcfdbfe-5be2-0b90-3746-74846e35eab7"), 2,
            "Project Manager", true, new Date(), null, "test", null);
    WorkFlowTemplateModel createdwfTemplate = new WorkFlowTemplateModel(
            UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, project, new Date(), null, "test",
            null, null);
    WorkFlowTemplateDescModel wfTemplatedesc = new WorkFlowTemplateDescModel(null, 0, "APPROVED", functionModel,
            "Roberto", userModel, null, createdwfTemplate, 1);

    WorkFlowTemplateDescModel createdwfTemplatedesc = new WorkFlowTemplateDescModel(
            UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"), 0, "APPROVED", functionModel, "Roberto", userModel,
            null, createdwfTemplate, 1);

    WorkFlowTemplateDescModel createdwfTemplatedesc1 = new WorkFlowTemplateDescModel(
            UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"), 0, "APPROVED", functionModel, "TestName",
            userModel, null, createdwfTemplate, 2);

    WorkFlowTemplateDescModel updatedwfTemplatedesc = new WorkFlowTemplateDescModel(
            UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"), 0, "APPROVED", functionModel, "Roberto Test",
            userModel, null, createdwfTemplate, 1);

    WorkFlowTemplateDescModel deletedwfTemplatedesc = new WorkFlowTemplateDescModel(
            UUID.fromString("3a2a3008-3a9a-1a96-2e0e-24eb62532c90"), 0, "DESIGN", functionModel, "test-action",
            userModel, null, createdwfTemplate, 1);

    WorkFlowTemplateDescModel updatedwfTemplatedesc1 = new WorkFlowTemplateDescModel(
            UUID.fromString("3a2a3008-3a9a-1a96-2e0e-24eb62532c90"), 0, "DESIGN", functionModel, "test-action_2",
            userModel, null, createdwfTemplate, 1);

    /**
     * testViewWorkFlowTemplateDesc
     */
    @Test
    void testViewWorkFlowTemplateDesc() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        WorkFlowTemplateDesc wfAction = mapper.map(createdwfTemplatedesc, WorkFlowTemplateDesc.class);
        when(wfTemplateDescRepository.findById(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c")))
                .thenReturn(Optional.of(wfAction));
        WorkFlowTemplateDescModel expectedWfDescModel = mapper.map(wfAction, WorkFlowTemplateDescModel.class);
        assertThat(
                wfTemplateDescService.viewWorkFlowTemplateDesc(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c")))
                        .isEqualTo(expectedWfDescModel);
    }

    @Test
    void testViewWorkFlowTemplateDescForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        when(wfTemplateDescRepository.findById(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class, () -> wfTemplateDescService
                .viewWorkFlowTemplateDesc(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c")), "");
    }

    @Test
    void testDeleteWorkFlowTemplateDescById() {
        wfTemplateDescService.deleteWorkFlowTemplateDescById(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"));
        verify(wfTemplateDescRepository).deleteById(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"));
    }

    @Test
    void testDeleteWorkFlowTemplateDescByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(wfTemplateDescRepository)
                .deleteById(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"));
        assertThrows(ApplicationFactoryException.class, () -> wfTemplateDescService
                .deleteWorkFlowTemplateDescById(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c")), "");
    }

    @Test
    void testCreateWorkFlowTemplateDesc() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UUID uuid = UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150");
        WorkFlowTemplateDesc wfAction = mapper.map(wfTemplatedesc, WorkFlowTemplateDesc.class);
        WorkFlowTemplateDesc wfCreatedAction = mapper.map(createdwfTemplatedesc, WorkFlowTemplateDesc.class);
        List<WorkFlowTemplateDescModel> actions = new ArrayList<>();
        actions.add(wfTemplatedesc);
        List<WorkFlowTemplateDescModel> createdactions = new ArrayList<>();
        actions.add(createdwfTemplatedesc);

        List<WorkFlowTemplateDesc> actions1 = new ArrayList<>();
        actions1.add(wfAction);
        List<WorkFlowTemplateDesc> actions2 = new ArrayList<>();
        actions1.add(wfCreatedAction);

        WorkFlowTemplate wfTemplate = mapper.map(createdwfTemplate, WorkFlowTemplate.class);
        when(wfTemplateRepository.findById(uuid)).thenReturn(Optional.of(wfTemplate));
        when(wfTemplateDescRepository.saveAll(actions1)).thenReturn(actions2);
        assertThat(wfTemplateDescService.createWorkFlowTemplateDesc(uuid, actions)).isEqualTo(createdactions);
    }

    @Test
    void testCreateWorkFlowTemplateDescForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UUID uuid = UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150");
        List<WorkFlowTemplateDescModel> actions = new ArrayList<>();
        actions.add(wfTemplatedesc);
        actions.add(createdwfTemplatedesc);

        when(wfTemplateRepository.findById(uuid)).thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> wfTemplateDescService.createWorkFlowTemplateDesc(uuid, actions), "");
    }

    @Test
    void testUpdateWorkFlowTemplateDescForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UUID uuid = UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150");

        List<WorkFlowTemplateDescModel> updatedactionsList = new ArrayList<>();
        updatedactionsList.add(updatedwfTemplatedesc);

        List<WorkFlowTemplateDescModel> deletedactionsList = new ArrayList<>();
        Map<String, List<WorkFlowTemplateDescModel>> mapactions = new HashMap<String, List<WorkFlowTemplateDescModel>>();
        mapactions.put("edited", updatedactionsList);
        mapactions.put("added", deletedactionsList);
        mapactions.put("deleted", deletedactionsList);

        when(wfTemplateRepository.findById(uuid)).thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> wfTemplateDescService.updateWorkFlowTemplateDesc(uuid, mapactions), "");
    }

    @Test
    void testUpdateWorkFlowTemplateDesc() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UUID uuid = UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150");
        WorkFlowTemplate wfTemplate = mapper.map(createdwfTemplate, WorkFlowTemplate.class);
        when(wfTemplateRepository.findById(uuid)).thenReturn(Optional.of(wfTemplate));

        List<WorkFlowTemplateDescModel> updatedactionsList = new ArrayList<>();
        updatedactionsList.add(updatedwfTemplatedesc);

        List<WorkFlowTemplateDescModel> deletedactionsList = new ArrayList<>();
        Map<String, List<WorkFlowTemplateDescModel>> mapactions = new HashMap<String, List<WorkFlowTemplateDescModel>>();
        mapactions.put("edited", updatedactionsList);
        mapactions.put("added", deletedactionsList);
        mapactions.put("deleted", deletedactionsList);

        WorkFlowTemplateDesc wfupdatedAction = mapper.map(updatedwfTemplatedesc, WorkFlowTemplateDesc.class);

        List<WorkFlowTemplateDesc> updatedActions = updatedactionsList.stream().map(actionBean -> {
            WorkFlowTemplateDesc action = mapper.map(actionBean, WorkFlowTemplateDesc.class);
            action.setWorkFlowTemplate(wfTemplate);
            return action;
        }).collect(Collectors.toList());

        when(wfTemplateDescRepository.saveAll(updatedActions)).thenReturn(updatedActions);

        WorkFlowTemplateDescModel ExpwfupdatedAction = mapper.map(wfupdatedAction, WorkFlowTemplateDescModel.class);

        List<WorkFlowTemplateDescModel> expupdatedactionsList = new ArrayList<>();
        expupdatedactionsList.add(ExpwfupdatedAction);

        Map<String, List<WorkFlowTemplateDescModel>> expmapactions = new HashMap<String, List<WorkFlowTemplateDescModel>>();
        expmapactions.put("edited", expupdatedactionsList);
        expmapactions.put("added", deletedactionsList);
        expmapactions.put("deleted", deletedactionsList);
        Map<String, List<WorkFlowTemplateDescModel>> newlist = wfTemplateDescService.updateWorkFlowTemplateDesc(uuid,
                mapactions);
        assertThat(wfTemplateDescService.updateWorkFlowTemplateDesc(uuid, mapactions)).isEqualTo(expmapactions);
    }

    /**
     * testSearchWorkFlowTemplateDesc
     */
    @Test
    void testSearchWorkFlowTemplateDesc() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplateDesc wfAction = mapper.map(createdwfTemplatedesc, WorkFlowTemplateDesc.class);
        WorkFlowTemplateDesc wfAction1 = mapper.map(createdwfTemplatedesc1, WorkFlowTemplateDesc.class);
        List<WorkFlowTemplateDesc> actionList = new ArrayList<>();
        actionList.add(wfAction);
        actionList.add(wfAction1);

        UUID uuid = UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150");

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        RequestModel requestModel = RequestMapper.map(request1);
        when(wfTemplateDescRepository.findAll(requestModel.getFilterSpecification())).thenReturn(actionList);
        Object obj1 = wfTemplateDescService.searchWorkFlowTemplateDesc(uuid, requestModel);
        assertThat((actionList.size() == '2'));
    }

}
