package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.WorkFlowTemplateService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(WorkFlowTemplateController.class)
class WorkFlowTemplateControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private WebApplicationContext context;
    @MockBean
    private WorkFlowTemplateService wfTemplateService;
    @MockBean
    private RequestModel requestModel;

    ObjectMapper mapper = new ObjectMapper();

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");
    Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
            true, new Date(), null, "test", null, null, null);

    WorkFlowTemplate wfTemplate = new WorkFlowTemplate(null, 0, "N1", true, project, new Date(), null, "test", null,
            null);
    WorkFlowTemplate createdwfTemplate = new WorkFlowTemplate(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"),
            0, "N1", true, project, new Date(), null, "test", null, null);
    WorkFlowTemplate updatedwfTemplate = new WorkFlowTemplate(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"),
            0, "N1-Test", true, project, new Date(), null, "test", null, null);

    /**
     * setup method
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV")).thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testCreateWorkFlowTemplate() throws Exception {
        ModelMapper mapper1 = new ModelMapper();
        mapper1.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplateModel wfTemplateModel = mapper1.map(wfTemplate, WorkFlowTemplateModel.class);
        WorkFlowTemplateModel createdwfTemplateModel = mapper1.map(createdwfTemplate, WorkFlowTemplateModel.class);
        String json = mapper.writeValueAsString(wfTemplateModel);
        when(wfTemplateService.createWorkFlowTemplate(wfTemplateModel)).thenReturn(createdwfTemplateModel);
        RequestBuilder request = MockMvcRequestBuilders.post("/wfTemplates").accept(MediaType.APPLICATION_JSON)
                .content(json).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testUpdateWorkFlowTemplate() throws Exception {
        ModelMapper mapper1 = new ModelMapper();
        mapper1.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplateModel updatedwfTemplateModel = mapper1.map(updatedwfTemplate, WorkFlowTemplateModel.class);
        String json = mapper.writeValueAsString(updatedwfTemplateModel);
        when(wfTemplateService.updateWorkFlowTemplate(updatedwfTemplateModel)).thenReturn(updatedwfTemplateModel);
        RequestBuilder request = MockMvcRequestBuilders.put("/wfTemplates").accept(MediaType.APPLICATION_JSON)
                .content(json).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testSearchWorkFlowTemplate() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        String returnObject = "{\r\n" + "  \"pageNumber\": 0,\r\n" + "  \"pageSize\": 10,\r\n"
                + "  \"totalElements\": 2,\r\n" + "  \"totalPages\": 1,\r\n" + "  \"content\": [\r\n" + "    {\r\n"
                + "      \"id\": \"59441f6c-723b-4462-98aa-b49d912b1150\",\r\n" + "      \"version\": 0,\r\n"
                + "      \"workFlowTemplateName\": \"N1\",\r\n" + "      \"active\": true,\r\n"
                + "      \"project\": {\r\n" + "        \"id\": \"6472e71d-f87f-4116-b5e6-b63e306b7b09\",\r\n"
                + "        \"version\": 0,\r\n" + "        \"projName\": \"PRJ2\",\r\n"
                + "        \"projectManager\": {\r\n"
                + "          \"id\": \"d5f931b0-a8bb-4d04-9aa8-6e6711fb8b59\",\r\n"
                + "          \"employeeId\": \"42370\",\r\n" + "          \"firstName\": \"Olivier\",\r\n"
                + "          \"lastName\": \"ATLAS\",\r\n"
                + "          \"email\": \"olivier.atlas@alstomgroup.com\",\r\n" + "          \"department\": \"OP\"\r\n"
                + "        },\r\n" + "        \"active\": true,\r\n"
                + "        \"createdDate\": \"2020-05-15T14:05:23.166+0000\",\r\n"
                + "        \"modifiedDate\": null,\r\n" + "        \"createdBy\": null,\r\n"
                + "        \"modifiedBy\": null,\r\n" + "        \"projFunctions\": [\r\n" + "          {\r\n"
                + "            \"id\": \"1716c8c4-4ea6-d0fb-8133-f479868b007e\",\r\n"
                + "            \"version\": 0,\r\n" + "            \"dwiFunctionName\": \"EHS\",\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2018-08-16T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2018-08-16T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"178049\",\r\n" + "            \"updatedBy\": null\r\n"
                + "          },\r\n" + "          {\r\n"
                + "            \"id\": \"0e3b39d7-7bcc-d0f4-6621-cfc02c669b2f\",\r\n"
                + "            \"version\": 0,\r\n" + "            \"dwiFunctionName\": \"Project Assistance\",\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2018-08-16T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2018-08-16T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"178049\",\r\n" + "            \"updatedBy\": null\r\n"
                + "          }\r\n" + "        ],\r\n" + "        \"projectUserRoles\": []\r\n" + "      },\r\n"
                + "      \"createdDate\": \"2020-05-21T05:47:12.297+0000\",\r\n" + "      \"modifiedDate\": null,\r\n"
                + "      \"createdBy\": null,\r\n" + "      \"modifiedBy\": null,\r\n" + "      \"actions\": []\r\n"
                + "    },\r\n" + "    {\r\n" + "      \"id\": \"0c6ce614-347e-455f-b2b3-7286a5cb0c4c\",\r\n"
                + "      \"version\": 0,\r\n" + "      \"workFlowTemplateName\": \"N1-Test\",\r\n"
                + "      \"active\": true,\r\n" + "      \"project\": {\r\n"
                + "        \"id\": \"6472e71d-f87f-4116-b5e6-b63e306b7b09\",\r\n" + "        \"version\": 0,\r\n"
                + "        \"projName\": \"PRJ2\",\r\n" + "        \"projectManager\": {\r\n"
                + "          \"id\": \"d5f931b0-a8bb-4d04-9aa8-6e6711fb8b59\",\r\n"
                + "          \"employeeId\": \"42370\",\r\n" + "          \"firstName\": \"Olivier\",\r\n"
                + "          \"lastName\": \"ATLAS\",\r\n"
                + "          \"email\": \"olivier.atlas@alstomgroup.com\",\r\n" + "          \"department\": \"OP\"\r\n"
                + "        },\r\n" + "        \"active\": true,\r\n"
                + "        \"createdDate\": \"2020-05-15T14:05:23.166+0000\",\r\n"
                + "        \"modifiedDate\": null,\r\n" + "        \"createdBy\": null,\r\n"
                + "        \"modifiedBy\": null,\r\n" + "        \"projFunctions\": [],\r\n"
                + "        \"projectUserRoles\": []\r\n" + "      },\r\n"
                + "      \"createdDate\": \"2020-05-21T05:47:12.297+0000\",\r\n" + "      \"modifiedDate\": null,\r\n"
                + "      \"createdBy\": null,\r\n" + "      \"modifiedBy\": null,\r\n" + "      \"actions\": []\r\n"
                + "    }]\r\n" + "}";

        Object obj = returnObject;
        RequestModel requestModel = RequestMapper.map(request1);
        when(wfTemplateService.searchWorkFlowTemplate(requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders.post("/wfTemplates/list").accept(MediaType.APPLICATION_JSON)
                .content(json).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testViewWorkFlowTemplate() throws Exception {
        ModelMapper mapper1 = new ModelMapper();
        mapper1.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplateModel createdwfTemplateModel = mapper1.map(createdwfTemplate, WorkFlowTemplateModel.class);
        when(wfTemplateService.viewWorkFlowTemplate(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150")))
                .thenReturn(createdwfTemplateModel);
        RequestBuilder request = MockMvcRequestBuilders.get("/wfTemplates/59441f6c-723b-4462-98aa-b49d912b1150")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteWorkFlowTemplate() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.delete("/wfTemplates/59441f6c-723b-4462-98aa-b49d912b1150")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testGetAllWorkFlowTemplateForProject() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        UUID ProjectId = UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150");
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        String returnObject = "{\r\n" + "  \"pageNumber\": 0,\r\n" + "  \"pageSize\": 10,\r\n"
                + "  \"totalElements\": 1,\r\n" + "  \"totalPages\": 1,\r\n" + "  \"content\": [\r\n" + "    {\r\n"
                + "      \"id\": \"0c6ce614-347e-455f-b2b3-7286a5cb0c4c\",\r\n" + "      \"version\": 0,\r\n"
                + "      \"workFlowTemplateName\": \"N1-Test\",\r\n" + "      \"active\": true,\r\n"
                + "      \"project\": {\r\n" + "        \"id\": \"59441f6c-723b-4462-98aa-b49d912b1150\",\r\n"
                + "        \"version\": 0,\r\n" + "        \"projName\": \"PRJ2\",\r\n"
                + "        \"projectManager\": {\r\n"
                + "          \"id\": \"d5f931b0-a8bb-4d04-9aa8-6e6711fb8b59\",\r\n"
                + "          \"employeeId\": \"42370\",\r\n" + "          \"firstName\": \"Olivier\",\r\n"
                + "          \"lastName\": \"ATLAS\",\r\n"
                + "          \"email\": \"olivier.atlas@alstomgroup.com\",\r\n" + "          \"department\": \"OP\"\r\n"
                + "        },\r\n" + "        \"active\": true,\r\n"
                + "        \"createdDate\": \"2020-05-15T14:05:23.166+0000\",\r\n"
                + "        \"modifiedDate\": null,\r\n" + "        \"createdBy\": null,\r\n"
                + "        \"modifiedBy\": null,\r\n" + "        \"projFunctions\": [],\r\n"
                + "        \"projectUserRoles\": []\r\n" + "      },\r\n"
                + "      \"createdDate\": \"2020-05-21T05:47:12.297+0000\",\r\n" + "      \"modifiedDate\": null,\r\n"
                + "      \"createdBy\": null,\r\n" + "      \"modifiedBy\": null,\r\n" + "      \"actions\": []\r\n"
                + "    }]\r\n" + "}";
        Object obj = returnObject;
        request1 = RequestModifier.defaultRequestMapIfEmpty(request1);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "project.id", ProjectId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request1, filterConditions));
        when(wfTemplateService.searchWorkFlowTemplate(requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders.post("/wfTemplates/59441f6c-723b-4462-98aa-b49d912b1150/list")
                .accept(MediaType.APPLICATION_JSON).content(json).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }
}
