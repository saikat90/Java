/**
 */
package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionAttachment;
import com.alstom.applicationfactory.dwiservice.instruction.entity.Instructions;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionAttachmentRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author 100769630
 */
@ExtendWith(MockitoExtension.class)
class InstructionAttachmentServiceImplTest {

    @Mock
    private InstructionAttachmentRepository instructionAttachmentRepository;
    @Mock
    private UserRepository userRepository;
    @InjectMocks
    private InstructionAttachmentServiceImpl instructionAttachmentServiceImpl;

    ObjectMapper objMapper = new ObjectMapper();

    UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    User userObj = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", userModel, true, new Date(), new Date(), "test", "userb", null, null);

    Project projectObj = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
            userObj, true, new Date(), new Date(), "test", "userb", null, null);

    FleetModel fleetModel = new FleetModel(UUID.fromString("05d559bc-f1ed-7c21-2a39-a4f5d5c2421f"), 0, "Test Fleet",
            projectModel, true, new Date(), new Date(), "usera", "userb");

    Fleet fleetObj = new Fleet(UUID.fromString("05d559bc-f1ed-7c21-2a39-a4f5d5c2421f"), 0, "Test Fleet", projectObj,
            true, new Date(), new Date(), "usera", "userb");

    ProcessModel processModel = new ProcessModel(UUID.fromString("064841a5-98d7-9b1c-2da8-abdb4a5aff24"), 0,
            "Test Process", fleetModel, true, new Date(), new Date(), "test", "userb");

    Process processObj = new Process(UUID.fromString("064841a5-98d7-9b1c-2da8-abdb4a5aff24"), 0, "Test Process", true,
            new Date(), new Date(), "test", "userb", fleetObj);

    RevisionModel revisionModel = new RevisionModel(UUID.fromString("04a62e8f-a6b7-d69b-0238-55d4c7e594fa"), 0,
            "Test Revision", true, new Date(), new Date(), "test", "userb", processModel);

    Revision revisionObj = new Revision(UUID.fromString("04a62e8f-a6b7-d69b-0238-55d4c7e594fa"), 0, "Test Revision",
            true, new Date(), null, "test", null, processObj);

    WorkFlowTemplateModel createdwfTemplate = new WorkFlowTemplateModel(
            UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, projectModel, new Date(),
            new Date(), "test", "userb", null);

    WorkFlowTemplate createdwfTemplateObj = new WorkFlowTemplate(
            UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, projectObj, new Date(), new Date(),
            "test", "userb", null);

    InstructionsModel instructionsModel = new InstructionsModel(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
            0, "APPROVED", "NEW", new Date(), new Date(), new Date(), null, "OTT-LRV-MTN50-WMS-004", 1, "OperatingáUWL",
            "OTT-LRV-MTN50-WMS-004", projectModel, "testFleet", processModel, revisionModel, createdwfTemplate,
            userModel, userModel, userModel, "Approved", false, false, "pdf import", null, new Date(), new Date(),
            "user.ar@alstomgroup.com", "user.b.ar@alstomgroup.com", fleetModel, null, null, null, null, null, null,
            null, null, null, null, null);

    Instructions instructionsObj = new Instructions(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), 0,
            "APPROVED", "NEW", new Date(), new Date(), new Date(), null, "OTT-LRV-MTN50-WMS-004", 1, "OperatingáUWL",
            "OTT-LRV-MTN50-WMS-004", projectObj, "testFleet", processObj, revisionObj, createdwfTemplateObj, userObj,
            userObj, userObj, "Approved", false, false, "pdf import", null, new Date(), new Date(),
            "user.ar@alstomgroup.com", "user.b.ar@alstomgroup.com", fleetObj, null, null, null, null, null, null, null,
            null, null, null, null);

    InstructionAttachmentModel newInstructionAttachmentModel = new InstructionAttachmentModel(null, 0, "testdwiFormId",
            "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test", instructionsModel);

    InstructionAttachmentModel createdInstructionAttachmentModel = new InstructionAttachmentModel(uuid, 0,
            "testdwiFormId", "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test",
            instructionsModel);

    InstructionAttachment createdInstructionAttachmentObj = new InstructionAttachment(uuid, 0, "testdwiFormId",
            "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test", instructionsObj);

    @Test
    public void init() {
        userModel.toString();
        userModel.hashCode();
        userObj.toString();
        userObj.hashCode();
        userModel.equals(userObj);
        projectModel.toString();
        projectModel.hashCode();
        projectObj.toString();
        projectObj.hashCode();
        projectModel.equals(processObj);
        fleetModel.toString();
        fleetModel.hashCode();
        fleetObj.toString();
        fleetObj.hashCode();
        fleetModel.equals(fleetObj);
        processModel.toString();
        processModel.hashCode();
        processObj.toString();
        processObj.hashCode();
        processModel.equals(processObj);
        revisionModel.toString();
        revisionModel.hashCode();
        revisionObj.toString();
        revisionObj.hashCode();
        revisionModel.equals(revisionObj);
        createdwfTemplate.toString();
        createdwfTemplate.hashCode();
        createdwfTemplateObj.toString();
        createdwfTemplateObj.hashCode();
        createdwfTemplate.equals(createdwfTemplateObj);
        instructionsModel.toString();
        instructionsModel.hashCode();
        instructionsObj.toString();
        instructionsObj.hashCode();
        instructionsModel.equals(instructionsObj);
        createdInstructionAttachmentModel.toString();
        createdInstructionAttachmentModel.hashCode();
        createdInstructionAttachmentObj.toString();
        createdInstructionAttachmentObj.hashCode();
        createdInstructionAttachmentObj.equals(createdInstructionAttachmentObj);
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionAttachmentServiceImpl#createDwiAttachment(com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel)}.
     */
    @Test
    void testCreateDwiAttachment() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        InstructionAttachment instructionAttachment = mapper.map(newInstructionAttachmentModel,
                InstructionAttachment.class);
        InstructionAttachment createdInstructionAttachment = mapper.map(createdInstructionAttachmentModel,
                InstructionAttachment.class);

        when(instructionAttachmentRepository.save(instructionAttachment)).thenReturn(createdInstructionAttachment);

        assertThat(instructionAttachmentServiceImpl.createDwiAttachment(newInstructionAttachmentModel).getId())
                .isEqualTo(createdInstructionAttachmentModel.getId());
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionAttachmentServiceImpl#deleteInstructionAttachmentById(java.util.UUID)}.
     */
    @Test
    void testDeleteInstructionAttachmentById() {
        instructionAttachmentServiceImpl.deleteInstructionAttachmentById(uuid);
        verify(instructionAttachmentRepository).deleteById(uuid);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionAttachmentServiceImpl#downloadDwiAttachment(java.util.UUID)}.
     */
    @Test
    void testDownloadDwiAttachment() {
        Assertions.assertTrue(true);

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionAttachmentServiceImpl#uploadAttachment(org.springframework.web.multipart.MultipartFile, java.lang.String)}.
     */
    @Test
    void testUploadAttachment() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionAttachmentServiceImpl#getFilePath(java.lang.String)}.
     */
    @Test
    void testGetFilePath() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionAttachmentServiceImpl#viewInstructionAttachment(java.util.UUID)}.
     */
    @Test
    void testViewInstructionAttachment() {
        when(instructionAttachmentRepository.findById(uuid)).thenReturn(Optional.of(createdInstructionAttachmentObj));
        assertThat(instructionAttachmentServiceImpl.viewInstructionAttachment(uuid).getId())
                .isEqualTo(createdInstructionAttachmentModel.getId());
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionAttachmentServiceImpl#copyInstructionAttachmentById(java.util.UUID, java.util.UUID)}.
     */
    @Test
    void testCopyInstructionAttachmentById() {
        Assertions.assertTrue(true);
    }

}
