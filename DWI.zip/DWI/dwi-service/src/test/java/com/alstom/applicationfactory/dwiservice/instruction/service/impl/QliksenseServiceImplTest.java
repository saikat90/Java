/**
 */
package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionsRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author 100769630.
 */
@ExtendWith(MockitoExtension.class)
class QliksenseServiceImplTest {

    @Mock
    private InstructionsRepository instructionsRepository;

    @InjectMocks
    QliksenseServiceImpl qliksenseServiceImpl;

    ObjectMapper objMapper = new ObjectMapper();

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.QliksenseServiceImpl#findAll()}.
     */
    @Test
    void testFindAll() {
        List<Object[]> listObject = new ArrayList<>();

        Object[] strObj1 = { "DWI_PRASA X'Trapolis Mega_28", "1", true, "", "DRAFT", "PRASA X'Trapolis Mega",
                "Lethabo RIBA", "Mukovhe", "RATSHISUKA", "3kV BL 10.1", "Test Revision", "Test Process", "Sekwati",
                "RAMONYAI", "WORKER" };

        Object[] strObj2 = { "DWI_PRASA X'Trapolis Mega_28", "1", true, "", "DRAFT", "PRASA X'Trapolis Mega",
                "Lethabo RIBA", "Mukovhe", "RATSHISUKA", "3kV BL 10.1", "Test Revision", "Test Process", "Thabiso",
                "MASHABA", "WORKER" };
        listObject.add(strObj1);
        listObject.add(strObj2);
        when(instructionsRepository.findAllQliksenseData()).thenReturn(listObject);

        List<Object[]> instructionsQliksenseModelList = (List<Object[]>) qliksenseServiceImpl.findAll();

        assertThat(instructionsQliksenseModelList.size()).isEqualTo(listObject.size());
    }

}
