package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.WorkFlowTemplateDescService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(WorkFlowTemplateDescController.class)
class WorkFlowTemplateDescControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private WebApplicationContext context;
    @MockBean
    private WorkFlowTemplateDescService wfTemplateDescService;
    @MockBean
    private RequestModel requestModel;

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
    ProjectModel project = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
            userModel, true, new Date(), null, "test", null, null, null);
    FunctionModel functionModel = new FunctionModel(UUID.fromString("bdcfdbfe-5be2-0b90-3746-74846e35eab7"), 2,
            "Project Manager", true, new Date(), null, "test", null);
    WorkFlowTemplateModel createdwfTemplate = new WorkFlowTemplateModel(
            UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, project, new Date(), null, "test",
            null, null);
    WorkFlowTemplateDescModel wfTemplatedesc = new WorkFlowTemplateDescModel(null, 0, "APPROVED", functionModel,
            "Roberto", userModel, null, createdwfTemplate, 1);

    WorkFlowTemplateDescModel createdwfTemplatedesc = new WorkFlowTemplateDescModel(
            UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"), 0, "APPROVED", functionModel, "Roberto", userModel,
            null, createdwfTemplate, 1);

    WorkFlowTemplateDescModel updatedwfTemplatedesc = new WorkFlowTemplateDescModel(
            UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"), 0, "APPROVED", functionModel, "Roberto Test",
            userModel, null, createdwfTemplate, 1);

    WorkFlowTemplateDescModel deletedwfTemplatedesc = new WorkFlowTemplateDescModel(
            UUID.fromString("3a2a3008-3a9a-1a96-2e0e-24eb62532c90"), 0, "DESIGN", functionModel, "test-action",
            userModel, null, createdwfTemplate, 1);

    ObjectMapper mapper = new ObjectMapper();

    /**
     * setup method
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV")).thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testCreateWorkFlowTemplateDesc() throws Exception {
        // String json = mapper.writeValueAsString(wfTemplatedesc);
        List<WorkFlowTemplateDescModel> actionsList = new ArrayList<>();
        actionsList.add(wfTemplatedesc);
        String json = mapper.writeValueAsString(actionsList);
        List<WorkFlowTemplateDescModel> createdactionsList = new ArrayList<>();
        actionsList.add(createdwfTemplatedesc);
        when(wfTemplateDescService.createWorkFlowTemplateDesc(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"),
                actionsList)).thenReturn(createdactionsList);
        RequestBuilder request = MockMvcRequestBuilders
                .post("/wfTemplates/59441f6c-723b-4462-98aa-b49d912b1150/wfTemplatActions")
                .accept(MediaType.APPLICATION_JSON).content(json).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testUpdateWorkFlowTemplateDesc() throws Exception {
        List<WorkFlowTemplateDescModel> updatedactionsList = new ArrayList<>();
        updatedactionsList.add(updatedwfTemplatedesc);
        List<WorkFlowTemplateDescModel> deletedactionsList = new ArrayList<>();
        deletedactionsList.add(deletedwfTemplatedesc);
        Map<String, List<WorkFlowTemplateDescModel>> mapactions = new HashMap<String, List<WorkFlowTemplateDescModel>>();
        mapactions.put("edited", updatedactionsList);
        mapactions.put("added", null);
        mapactions.put("deleted", deletedactionsList);

        String json = mapper.writeValueAsString(mapactions);
        when(wfTemplateDescService.updateWorkFlowTemplateDesc(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"),
                mapactions)).thenReturn(mapactions);
        RequestBuilder request = MockMvcRequestBuilders
                .put("/wfTemplates/59441f6c-723b-4462-98aa-b49d912b1150/wfTemplatActions")
                .accept(MediaType.APPLICATION_JSON).content(json).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testSearchWorkFlowTemplateDesc() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        UUID workflowId = UUID.fromString("49ea4dfd-2e38-2bc6-89ab-e3167de5e77f");
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        String returnObject = "{\r\n" + "  \"pageNumber\": 0,\r\n" + "  \"pageSize\": 10,\r\n"
                + "  \"totalElements\": 20,\r\n" + "  \"totalPages\": 2,\r\n" + "  \"content\": [\r\n" + "    {\r\n"
                + "      \"id\": \"49ea4dfd-2e38-2bc6-89ab-e3167de5e77f\",\r\n" + "      \"version\": 6,\r\n"
                + "      \"workFlowTemplateName\": \"ATK_KZ8A/KZ4A Alstom Traction 31Y Workflow\",\r\n"
                + "      \"active\": true,\r\n" + "      \"project\": {\r\n"
                + "        \"id\": \"2d9876f4-195b-7c29-a71c-b24ab7647a4d\",\r\n" + "        \"version\": 2,\r\n"
                + "        \"projName\": \"ATK_KZ8A/KZ4A Alstom Traction 31Y\",\r\n"
                + "        \"projectManager\": {\r\n"
                + "          \"id\": \"f6817874-e4d9-8b7c-5a1d-ecf370ce4d7a\",\r\n"
                + "          \"employeeId\": \"415128\",\r\n" + "          \"firstName\": \"Dauren\",\r\n"
                + "          \"lastName\": \"KASSYMOV\",\r\n"
                + "          \"email\": \"dauren.kassymov@alstomgroup.com\",\r\n"
                + "          \"department\": \"WCA - Indus\"\r\n" + "        },\r\n" + "        \"active\": false,\r\n"
                + "        \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "        \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "        \"createdBy\": \"415128\",\r\n" + "        \"modifiedBy\": \"dev\",\r\n"
                + "        \"projFunctions\": [],\r\n" + "        \"projectUserRoles\": [\r\n" + "          {\r\n"
                + "            \"id\": \"6def4180-7501-e01e-8ce0-8d587fc8edae\",\r\n" + "            \"user\": {\r\n"
                + "              \"id\": \"ffffc8ff-4e42-0d80-09d4-4ec547285b26\",\r\n"
                + "              \"employeeId\": \"427521\",\r\n" + "              \"firstName\": \"Michael\",\r\n"
                + "              \"lastName\": \"HAULER\",\r\n"
                + "              \"email\": \"michael.hauler@alstomgroup.com\",\r\n"
                + "              \"department\": \"Eng. Trains\"\r\n" + "            },\r\n"
                + "            \"role\": \"VALIDATOR\"\r\n" + "          }\r\n" + "        ]\r\n" + "      },\r\n"
                + "      \"createdDate\": \"2019-04-04T00:00:00.000+0000\",\r\n"
                + "      \"modifiedDate\": \"2019-04-04T00:00:00.000+0000\",\r\n"
                + "      \"createdBy\": \"415128\",\r\n" + "      \"modifiedBy\": \"415128\",\r\n"
                + "      \"actions\": [\r\n" + "        {\r\n"
                + "          \"id\": \"17f5b01f-9ffd-2c2e-dea3-d9bfe3070756\",\r\n" + "          \"version\": 0,\r\n"
                + "          \"dwiActions\": \"VALIDATE\",\r\n" + "          \"function\": {\r\n"
                + "            \"id\": \"2b436a97-af2b-debc-c080-3297fe81ba70\",\r\n"
                + "            \"version\": 2,\r\n" + "            \"dwiFunctionName\": \"Operation Manager\",\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2018-08-16T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2018-08-16T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"178049\",\r\n" + "            \"updatedBy\": \"100017412\"\r\n"
                + "          },\r\n" + "          \"name\": \"Rustem ABDRASSILOV\",\r\n"
                + "          \"validateApproveUser\": {\r\n"
                + "            \"id\": \"7c69e2a9-1345-9158-f97a-1d10422c6ab1\",\r\n"
                + "            \"employeeId\": \"409098\",\r\n" + "            \"firstName\": \"Rustem\",\r\n"
                + "            \"lastName\": \"ABDRASSILOV\",\r\n"
                + "            \"email\": \"rustem.abdrassilov@alstomgroup.com\",\r\n"
                + "            \"department\": \"WCA - Indus\"\r\n" + "          },\r\n"
                + "          \"comments\": \"Services Production Manager\",\r\n"
                + "          \"wfTemplateDescSeq\": 4\r\n" + "        },\r\n" + "        {\r\n"
                + "          \"id\": \"8c3bc7db-d156-1740-ee86-6562d2c4887f\",\r\n" + "          \"version\": 0,\r\n"
                + "          \"dwiActions\": \"DESIGN\",\r\n" + "          \"function\": {\r\n"
                + "            \"id\": \"e2340596-0809-27ca-84c3-f41f38a74698\",\r\n"
                + "            \"version\": 2,\r\n" + "            \"dwiFunctionName\": \"Industrial\",\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2018-08-16T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2018-08-16T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"105890\",\r\n" + "            \"updatedBy\": \"100017412\"\r\n"
                + "          },\r\n" + "          \"name\": \"Anuar SAPIYEV\",\r\n"
                + "          \"validateApproveUser\": {\r\n"
                + "            \"id\": \"3378ca6d-55ec-c870-088c-7a9301359311\",\r\n"
                + "            \"employeeId\": \"420130\",\r\n" + "            \"firstName\": \"Anuar\",\r\n"
                + "            \"lastName\": \"SAPIYEV\",\r\n"
                + "            \"email\": \"anuar.sapiyev@alstomgroup.com\",\r\n"
                + "            \"department\": \"WCA - Indus\"\r\n" + "          },\r\n"
                + "          \"comments\": \"Industrial Engineer\",\r\n" + "          \"wfTemplateDescSeq\": 1\r\n"
                + "        }\r\n" + "      ]\r\n" + "    }]\r\n" + "}";

        Object obj = returnObject;
        request1 = RequestModifier.defaultRequestMapIfEmpty(request1);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "workFlowTemplate.id", workflowId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request1, filterConditions));
        when(wfTemplateDescService.searchWorkFlowTemplateDesc(UUID.fromString("49ea4dfd-2e38-2bc6-89ab-e3167de5e77f"),
                requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders
                .post("/wfTemplates/49ea4dfd-2e38-2bc6-89ab-e3167de5e77f/wfTemplatActions/list")
                .accept(MediaType.APPLICATION_JSON).content(json).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testViewWorkFlowTemplateDesc() throws Exception {
        when(wfTemplateDescService.viewWorkFlowTemplateDesc(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c")))
                .thenReturn(createdwfTemplatedesc);
        RequestBuilder request = MockMvcRequestBuilders.get(
                "/wfTemplates/59441f6c-723b-4462-98aa-b49d912b1150/wfTemplatActions/03711a0a-c42f-8c28-82e8-cd0d7ce0003c")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteWorkFlowTemplateDesc() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders.delete(
                "/wfTemplates/59441f6c-723b-4462-98aa-b49d912b1150/wfTemplatActions/03711a0a-c42f-8c28-82e8-cd0d7ce0003c")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
    }

}
