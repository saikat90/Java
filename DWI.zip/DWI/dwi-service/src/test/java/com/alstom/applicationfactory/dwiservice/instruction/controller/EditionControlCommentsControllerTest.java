package com.alstom.applicationfactory.dwiservice.instruction.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.instruction.model.EditionControlCommentsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.service.EditionControlCommentsService;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(EditionControlCommentsController.class)
class EditionControlCommentsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EditionControlCommentsService editionCCService;

    @Autowired
    private WebApplicationContext context;

    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;

    ObjectMapper mapper = new ObjectMapper();

    /**
     * setup Method
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testGetEditionControlComments() throws Exception {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
                "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel projectModel = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userModel, true, new Date(), null, "test", null, null, null);

        FleetModel fleetModel = new FleetModel(
                UUID.fromString("05d559bc-f1ed-7c21-2a39-a4f5d5c2421f"), 0, "Test Fleet",
                projectModel, true, new Date(), new Date(), null, null);

        ProcessModel processModel = new ProcessModel(
                UUID.fromString("064841a5-98d7-9b1c-2da8-abdb4a5aff24"), 0, "Test Process",
                fleetModel, true, new Date(), null, "test", null);

        RevisionModel revisionModel = new RevisionModel(
                UUID.fromString("04a62e8f-a6b7-d69b-0238-55d4c7e594fa"), 0, "Test Revision", true,
                new Date(), null, "test", null, processModel);

        InstructionsModel instructionsModel = new InstructionsModel(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), 0, "APPROVED", "NEW",
                new Date(), new Date(), new Date(), null, "OTT-LRV-MTN50-WMS-004", 1,
                "OperatingáUWL", "OTT-LRV-MTN50-WMS-004", projectModel, null, processModel,
                revisionModel, null, userModel, userModel, userModel, "Approved", false, false,
                "pdf import", null, new Date(), null, "user.ar@alstomgroup.com", null, fleetModel,
                null, null, null, null, null, null, null, null, null, null, null);

        EditionControlCommentsModel editionControlCommentsModel = new EditionControlCommentsModel(
                UUID.fromString("5e645231-7b33-73ad-0ca0-8b5e49aac5b2"), 0, instructionsModel,
                "OTT-LRV-MTN50-WMS-004", 1, userModel, new Date(), null);

        when(editionCCService
                .getEditionControlComments(UUID.fromString("5e645231-7b33-73ad-0ca0-8b5e49aac5b2")))
                        .thenReturn(editionControlCommentsModel);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/editionControlComments/5e645231-7b33-73ad-0ca0-8b5e49aac5b2")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

}
