/**
 */
package com.alstom.applicationfactory.dwiservice.masterdata.model;

import java.util.UUID;

import org.junit.jupiter.api.Test;

/**
 * @author 100769630
 */
class ApplicationModelTest {

    UUID uuid = UUID.fromString("f0ce5c29-9385-4853-9483-ecd1e74062e7");
    String name = "Digital Work Instructions";
    String code = "APP_DWI";
    boolean verified = true;
    boolean deleted = false;
    boolean allowAllUsers = false;

    /**
     * @return ApplicationModel
     */
    public ApplicationModel crateTestSuite() {
        return new ApplicationModel();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#hashCode()}.
     */
    @Test
    void testHashCode() {
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();

        applictionModel.hashCode();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#getId()}.
     */
    @Test
    void testGetId() {
        ApplicationModel applictionModel = null;
        applictionModel = crateTestSuite();
        uuid = applictionModel.getId();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#getName()}.
     */
    @Test
    void testGetName() {

        ApplicationModel applictionModel = null;
        applictionModel = crateTestSuite();
        name = applictionModel.getName();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#getCode()}.
     */
    @Test
    void testGetCode() {
        String code = "";
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();
        code = applictionModel.getCode();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#isVerified()}.
     */
    @Test
    void testIsVerified() {
        boolean verified;
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();
        verified = applictionModel.isVerified();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#isDeleted()}.
     */
    @Test
    void testIsDeleted() {
        boolean deleted;
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();
        deleted = applictionModel.isDeleted();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#isAllowAllUsers()}.
     */
    @Test
    void testIsAllowAllUsers() {
        boolean allowAllUsers;
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();
        allowAllUsers = applictionModel.isAllowAllUsers();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#setId(UUID)}.
     */
    @Test
    void testSetId() {
        ApplicationModel applictionModel = new ApplicationModel();
        applictionModel.setId(uuid);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#setName(String)}.
     */
    @Test
    void testSetName() {
        ApplicationModel applictionModel = new ApplicationModel();
        applictionModel.setName("Digital Work Instructions");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#setCode(String)}.
     */
    @Test
    void testSetCode() {
        ApplicationModel applictionModel = new ApplicationModel();
        applictionModel.setCode("APP_DWI");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#setVerified(boolean)}.
     */
    @Test
    void testSetVerified() {
        ApplicationModel applictionModel = new ApplicationModel();
        applictionModel.setVerified(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#setDeleted(boolean)}.
     */
    @Test
    void testSetDeleted() {
        ApplicationModel applictionModel = new ApplicationModel();
        applictionModel.setDeleted(false);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#setAllowAllUsers(boolean)}.
     */
    @Test
    void testSetAllowAllUsers() {
        ApplicationModel applictionModel = new ApplicationModel();
        applictionModel.setAllowAllUsers(false);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#equals(java.lang.Object)}.
     */
    @Test
    void testEqualsObject() {
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();

        ApplicationModel applictionModel_2 = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);

        ApplicationModel applictionModel_3 = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                true, false);

        applictionModel.equals(applictionModel_2);
        applictionModel.equals(applictionModel_3);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#canEqual(java.lang.Object)}.
     */
    @Test
    void testCanEqual() {
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();

        ApplicationModel applictionModel_2 = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                true, false);

        applictionModel.canEqual(applictionModel_2);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#toString()}.
     */
    @Test
    void testToString() {
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();

        applictionModel.toString();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#ApplicationModel()}.
     */
    @Test
    void testApplicationModel() {
        ApplicationModel applictionModel = null;
        applictionModel = crateTestSuite();
        uuid = applictionModel.getId();
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.masterdata.model.ApplicationModel#ApplicationModel(UUID, String, String, boolean, boolean, boolean)}.
     */
    @Test
    void testApplicationModelUUIDStringStringBooleanBooleanBoolean() {
        ApplicationModel applictionModel = new ApplicationModel(uuid, "Digital Work Instructions", "APP_DWI", true,
                false, false);
        applictionModel = crateTestSuite();
        uuid = applictionModel.getId();
    }

}
