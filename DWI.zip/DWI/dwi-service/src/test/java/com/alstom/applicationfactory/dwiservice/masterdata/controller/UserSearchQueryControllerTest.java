package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.Jwt.Builder;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserSearchQueryModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.UserSearchQueryService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
@WebMvcTest(UserSearchQueryController.class)
class UserSearchQueryControllerTest {

    MockMvc mockMvc;
    @Autowired
    private WebApplicationContext context;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @MockBean
    private UserSearchQueryService userSearchQueryService;
    @MockBean
    private RequestModel requestModel;
    @MockBean
    private Authentication authentication;
    @MockBean
    private Jwt jwt;
    @MockBean
    private EmailServiceClient emailServiceClient;

    ObjectMapper mapper = new ObjectMapper();

    UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
    UserModel userObject2 = new UserModel(UUID.fromString("54c22bf5-dd12-9a00-7f1c-933bb85a5b2d"),
            "100769630", "User B", "LastName", "user.b@alstomgroup.com", "IS&T Project CoE");
    UserSearchQueryModel searchQuerycreateModel = new UserSearchQueryModel(null, userObject1,
            "Test Project", "Work Instructions",
            "{\\\"\"filter\\\"\":{\\\"\"condition\\\"\":\\\"\"and\\\"\",\\\"\"filterConditions\\\"\":[{\\\"\"type\\\"\":\\\"\"String\\\"\",\\\"\"field\\\"\":\\\"\"dwiStatus\\\"\",\\\"\"data\\\"\":\\\"\"Draft\\\"\"}]}}",
            false, false, null, null, new Date(), null, "user.ar@alstomgroup.com", null);
    UserSearchQueryModel searchQueryModel = new UserSearchQueryModel(
            UUID.fromString("bad9fc58-d983-487f-90ae-2a42059fe1e4"), userObject1, "Test Project",
            "Work Instructions",
            "{\\\"\"filter\\\"\":{\\\"\"condition\\\"\":\\\"\"and\\\"\",\\\"\"filterConditions\\\"\":[{\\\"\"type\\\"\":\\\"\"String\\\"\",\\\"\"field\\\"\":\\\"\"dwiStatus\\\"\",\\\"\"data\\\"\":\\\"\"Draft\\\"\"}]}}",
            false, false, null, null, new Date(), null, "user.ar@alstomgroup.com", null);
    UserSearchQueryModel searchQueryUpdatedModel = new UserSearchQueryModel(
            UUID.fromString("bad9fc58-d983-487f-90ae-2a42059fe1e4"), userObject1, "Test Project1",
            "Work Instructions",
            "{\\\"\"filter\\\"\":{\\\"\"condition\\\"\":\\\"\"and\\\"\",\\\"\"filterConditions\\\"\":[{\\\"\"type\\\"\":\\\"\"String\\\"\",\\\"\"field\\\"\":\\\"\"dwiStatus\\\"\",\\\"\"data\\\"\":\\\"\"Draft\\\"\"}]}}",
            false, false, null, null, new Date(), new Date(), "user.ar@alstomgroup.com",
            "user.ar@alstomgroup.com");

    /**
     * @author 100769630
     */
    public static class MockSecurityContext implements SecurityContext {

        private static final long serialVersionUID = -1386535243513362694L;

        private Authentication authentication;

        public MockSecurityContext(Authentication authentication) {
            this.authentication = authentication;
        }

        @Override
        public Authentication getAuthentication() {
            return this.authentication;
        }

        @Override
        public void setAuthentication(Authentication authentication) {
            this.authentication = authentication;
        }
    }

    /**
     * @throws Exception
     */
    @BeforeEach
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Disabled
    @Test
    void testListSavedQuery() throws Exception {

        HttpHeaders httpHeader = new HttpHeaders();
        httpHeader.put("Content-Type", Arrays.asList("application/json"));
        httpHeader.put("Authorization", Arrays.asList("Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSU"));

        Authentication auth = Mockito.mock(Authentication.class);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
                new MockSecurityContext(auth));

        Map<String, Object> claims = new HashMap<>();
        claims.put("preferred_username", "user.ar@alstomgroup.com");

        String dummyString = "{sub=GaniNUFjL_1MkL2mMsxunYYSHzlXdyv8cOeh9TzStFs, ver=2.0, aio=AVQAq/8PAAAAqFfOTp2S9elSe5C1I1rguL4e2kgg9tCWpX8zRl3w//ODzoNeod4xkerBzainTWV7EN0aboWDV7iwjiZGBEhq71EXJL0u2cjmIkuY2sQFlt0=, roles=[\"APP_DWI\",\"ROLE_AUTHOR\",\"ROLE_ADM\",\"ROLE_VALIDATOR\",\"ROLE_APPROVER\"], iss=https://login.microsoftonline.com/0d993ad3-fa73-421a-b129-1fe5590103f3/v2.0, oid=b6819d4f-9a5c-4336-aa3f-61ff8a55bc9f, preferred_username=shanmugam.raj@alstomgroup.com, uti=lhou8HGkz06pWi2pVogZAA, nonce=0fd1800a-d6c7-4db0-acf4-de33c2109aa4, tid=0d993ad3-fa73-421a-b129-1fe5590103f3, aud=[2e6af6b9-f1ca-4d9f-a70a-b1aae6423775], nbf=2020-06-07T11:55:32Z, rh=0.AR8A0zqZDXP6GkKxKR_lWQED87n2ai7K8Z9NpwqxquZCN3UfAJ8., name=RAJ Shanmugam -EXT, exp=2040-06-07T13:00:32Z, iat=2020-06-07T11:55:32Z}";

        Builder jwt = Jwt.withTokenValue(dummyString);
        jwt.claim("preferred_username", "user.ar@alstomgroup.com");
        jwt.header("authentication", auth);

        Jwt jwtObject = jwt.build();

        String email = claims.get("preferred_username").toString();

        // when(authentication.getCredentials()).thenReturn(jwtObject);

        when(((Jwt) authentication.getCredentials()).getClaims()).thenReturn(claims);
        String screenName = "Work Instructions";
        List<UserSearchQueryModel> usersearchModelList = new ArrayList<>();
        usersearchModelList.add(searchQueryModel);
        when(userSearchQueryService.listSavedQuery(email, screenName))
                .thenReturn(usersearchModelList);
        RequestBuilder request = MockMvcRequestBuilders
                .get("/userSearchQuery/list/Work Instructions").accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Disabled
    @Test
    void testListQuery() throws Exception {

        Authentication auth = Mockito.mock(Authentication.class);

        // Authentication authentication = getAuthentication((WithMockAuthentication)
        // auth);
        String dummyString = "{sub=GaniNUFjL_1MkL2mMsxunYYSHzlXdyv8cOeh9TzStFs, ver=2.0, aio=AVQAq/8PAAAAqFfOTp2S9elSe5C1I1rguL4e2kgg9tCWpX8zRl3w//ODzoNeod4xkerBzainTWV7EN0aboWDV7iwjiZGBEhq71EXJL0u2cjmIkuY2sQFlt0=, roles=[\"APP_DWI\",\"ROLE_AUTHOR\",\"ROLE_ADM\",\"ROLE_VALIDATOR\",\"ROLE_APPROVER\"], iss=https://login.microsoftonline.com/0d993ad3-fa73-421a-b129-1fe5590103f3/v2.0, oid=b6819d4f-9a5c-4336-aa3f-61ff8a55bc9f, preferred_username=shanmugam.raj@alstomgroup.com, uti=lhou8HGkz06pWi2pVogZAA, nonce=0fd1800a-d6c7-4db0-acf4-de33c2109aa4, tid=0d993ad3-fa73-421a-b129-1fe5590103f3, aud=[2e6af6b9-f1ca-4d9f-a70a-b1aae6423775], nbf=2020-06-07T11:55:32Z, rh=0.AR8A0zqZDXP6GkKxKR_lWQED87n2ai7K8Z9NpwqxquZCN3UfAJ8., name=RAJ Shanmugam -EXT, exp=2040-06-07T13:00:32Z, iat=2020-06-07T11:55:32Z}";
        Builder jwt = Jwt.withTokenValue(dummyString);
        jwt.claim("preferred_username", "user.ar@alstomgroup.com");
        jwt.header("authentication", auth);

        Jwt jwtObject = jwt.build();
        String json = mapper.writeValueAsString(authentication);

        String screenName = "Work Instructions";
        String email = "test@email.com";
        List<UserSearchQueryModel> usersearchModelList = new ArrayList<>();
        usersearchModelList.add(searchQueryModel);
        when(userSearchQueryService.listSavedQuery(email, screenName))
                .thenReturn(usersearchModelList);
        RequestBuilder request = MockMvcRequestBuilders
                .get("/userSearchQuery/list/Work Instructions").accept(MediaType.APPLICATION_JSON)
                .content(json);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteUserQueryById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/userSearchQuery/bad9fc58-d983-487f-90ae-2a42059fe1e4")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testViewSavedQuery() throws Exception {
        when(userSearchQueryService
                .viewSavedQuery(UUID.fromString("bad9fc58-d983-487f-90ae-2a42059fe1e4")))
                        .thenReturn(searchQueryModel);
        RequestBuilder request = MockMvcRequestBuilders
                .get("/userSearchQuery/bad9fc58-d983-487f-90ae-2a42059fe1e4")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Disabled
    @Test
    void testCreateSavedSearchQuery() throws Exception {

        String json = mapper.writeValueAsString(searchQuerycreateModel);
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get("preferred_username").toString();
        when(userSearchQueryService.createSavedSearchQuery(email, searchQuerycreateModel))
                .thenReturn(searchQueryModel);
        RequestBuilder request = MockMvcRequestBuilders.post("/userSearchQuery")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Disabled
    @Test
    void testUpdateSavedSearchQuery() throws Exception {
        String json = mapper.writeValueAsString(searchQueryUpdatedModel);
        Map<String, Object> claims = ((Jwt) authentication.getCredentials()).getClaims();
        String email = claims.get("preferred_username").toString();
        when(userSearchQueryService.updateSavedSearchQuery(email, searchQueryUpdatedModel))
                .thenReturn(searchQueryUpdatedModel);
        RequestBuilder request = MockMvcRequestBuilders.put("/userSearchQuery")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }
}
