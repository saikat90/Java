/**
 */
package com.alstom.applicationfactory.dwiservice.instruction.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.instruction.service.QliksenseService;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author 100769630.
 */
@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(QlikSenseController.class)
class QlikSenseControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private QliksenseService qliksenseService;

    @Autowired
    private WebApplicationContext context;

    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;

    ObjectMapper mapper = new ObjectMapper();

    /**
     * @throws java.lang.Exception.
     */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * Test method for.
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.QlikSenseController#findAll()}.
     * 
     * @throws Exception
     */
    @Test
    void testFindAll() throws Exception {

        List<Object[]> listObject = new ArrayList<>();

        Object[] strObj1 = { "DWI_PRASA X'Trapolis Mega_28", "1", true, "", "DRAFT",
                "PRASA X'Trapolis Mega", "Lethabo RIBA", "Mukovhe", "RATSHISUKA", "3kV BL 10.1",
                "Test Revision", "Test Process", "Sekwati", "RAMONYAI", "WORKER" };

        Object[] strObj2 = { "DWI_PRASA X'Trapolis Mega_28", "1", true, "", "DRAFT",
                "PRASA X'Trapolis Mega", "Lethabo RIBA", "Mukovhe", "RATSHISUKA", "3kV BL 10.1",
                "Test Revision", "Test Process", "Thabiso", "MASHABA", "WORKER" };
        listObject.add(strObj1);
        listObject.add(strObj2);

        when(qliksenseService.findAll()).thenReturn(listObject);

        RequestBuilder request = MockMvcRequestBuilders.get("/qliksense/instructions/kpi")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

}
