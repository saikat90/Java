package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TagModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.TagService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(TagController.class)
class TagControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private WebApplicationContext context;
    @MockBean
    private RequestModel requestModel;
    @MockBean
    private TagService tagService;

    ObjectMapper mapper = new ObjectMapper();

    TagModel tagModel = new TagModel(null, 0, "cleaning");
    TagModel createdTagModel = new TagModel(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"),
            0, "cleaning");
    TagModel updatedTagModel = new TagModel(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"),
            0, "cleaning-Test");

    /**
     * setup
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testCreateTag() throws Exception {
        String json = mapper.writeValueAsString(tagModel);
        when(tagService.createTag(tagModel)).thenReturn(createdTagModel);
        RequestBuilder request = MockMvcRequestBuilders.post("/tag")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testUpdateTag() throws Exception {
        String json = mapper.writeValueAsString(updatedTagModel);
        when(tagService.updateTag(updatedTagModel)).thenReturn(updatedTagModel);
        RequestBuilder request = MockMvcRequestBuilders.put("/tag")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testSearchTag() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);
        String returnObject = "{\r\n" + "    \"pageNumber\": 0,\r\n" + "    \"pageSize\": 10,\r\n"
                + "    \"totalElements\": 2,\r\n" + "    \"totalPages\": 1,\r\n"
                + "    \"content\": [\r\n" + "        {\r\n"
                + "            \"id\": \"0040bee5-d3c9-9d09-b3c3-78f4965139e0\",\r\n"
                + "            \"version\": 0,\r\n" + "            \"dwTags\": \"cleaning\"\r\n"
                + "        },\r\n" + "        {\r\n"
                + "            \"id\": \"03f9480a-496d-199c-7e4f-265112fdfe88\",\r\n"
                + "            \"version\": 0,\r\n" + "            \"dwTags\": \"GIDS\"\r\n"
                + "        }]\r\n" + "}";

        Object obj = returnObject;

        when(tagService.searchTag(requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders.post("/tag/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testViewTag() throws Exception {
        when(tagService.viewTag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0")))
                .thenReturn(createdTagModel);
        RequestBuilder request = MockMvcRequestBuilders
                .get("/tag/0040bee5-d3c9-9d09-b3c3-78f4965139e0")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteTag() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/tag/0040bee5-d3c9-9d09-b3c3-78f4965139e0")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }
}
