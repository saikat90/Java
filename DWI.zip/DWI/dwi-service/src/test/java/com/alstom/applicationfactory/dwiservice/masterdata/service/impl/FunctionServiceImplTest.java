package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Function;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.FunctionRepository;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class FunctionServiceImplTest {

    @InjectMocks
    FunctionServiceImpl functionService;
    @Mock
    private FunctionRepository functionRepository;
    ObjectMapper objMapper = new ObjectMapper();

    FunctionModel functionModel = new FunctionModel(null, 1, "Test Function 1", true, new Date(), null, "system", null);

    FunctionModel createdFunctionModel = new FunctionModel(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771"), 1,
            "Test Function 1", true, new Date(), null, "system", null);

    FunctionModel updatedFunctionModel = new FunctionModel(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771"), 1,
            "Test Function 1", false, new Date(), null, "system", null);

    /**
     * testCreateFunction
     */
    @Test
    void testCreateFunction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Function func = mapper.map(functionModel, Function.class);
        Function createdFunc = mapper.map(createdFunctionModel, Function.class);
        when(functionRepository.save(func)).thenReturn(createdFunc);
        FunctionModel expectedFunctionModel = mapper.map(createdFunc, FunctionModel.class);
        assertThat(functionService.createFunction(functionModel)).isEqualTo(expectedFunctionModel);
    }

    @Test
    void testCreateFunctionForRecordExist() {
        when(functionRepository.count(Mockito.any(FilterSpecification.class))).thenReturn((long) 1);
        assertThrows(ApplicationFactoryException.class, () -> functionService.createFunction(functionModel), "");
    }

    @Test
    void testUpdateFunction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Function createdFunc = mapper.map(createdFunctionModel, Function.class);
        Function updatedFunc = mapper.map(updatedFunctionModel, Function.class);
        when(functionRepository.findById(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771")))
                .thenReturn(Optional.of(createdFunc));
        when(functionRepository.save(updatedFunc)).thenReturn(updatedFunc);
        assertThat(functionService.updateFunction(updatedFunctionModel)).isEqualTo(updatedFunctionModel);
    }

    @Test
    void testUpdateFunctionForElseCondition() {
        assertThrows(ApplicationFactoryException.class, () -> functionService.updateFunction(updatedFunctionModel), "");
    }

    @Test
    void testFindAll() {
        Function function1 = new Function(UUID.fromString("04d25e51-147d-4c4d-9029-b90ca4f5203c"), 1, "Test Function 1",
                true, new Date(), null, "system", null);

        Function function2 = new Function(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771"), 0, "Test Function 2",
                true, new Date(), null, "system", null);

        List<Function> functionList = new ArrayList<>();
        functionList.add(function1);
        functionList.add(function2);

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        RequestModel requestModel = RequestMapper.map(request1);

        when(functionRepository.findAll(requestModel.getFilterSpecification())).thenReturn(functionList);
        Object obj1 = functionService.findAll(requestModel);
        assertThat((functionList.size() == '2'));
    }

    /**
     * testViewFunction
     */
    @Test
    void testViewFunction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Function createdFunc = mapper.map(createdFunctionModel, Function.class);
        when(functionRepository.findById(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771")))
                .thenReturn(Optional.of(createdFunc));

        assertThat(functionService.viewFunction(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771")))
                .isEqualTo(createdFunctionModel);
    }

    /**
     * testDeleteFunctionById
     */
    @Test
    void testDeleteFunctionById() {
        functionService.deleteFunctionById(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771"));
        verify(functionRepository).deleteById(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771"));
    }

    @Test
    void testDeleteFunctionByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(functionRepository)
                .deleteById(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771"));
        assertThrows(ApplicationFactoryException.class,
                () -> functionService.deleteFunctionById(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771")), "");
    }

}
