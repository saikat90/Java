package com.alstom.applicationfactory.dwiservice.instruction.controller;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.fail;

class InstructionsControllerIT {

	@Disabled
	@Test
	void testSearchInstruction() {
		fail("Not yet implemented");
	}

	@Disabled
	@Test
	void testViewInstruction() {
		fail("Not yet implemented");
	}

}
