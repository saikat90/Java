package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProcessRepository;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class ProcessServiceImplTest {

    @InjectMocks
    ProcessServiceImpl processService;
    @Mock
    private ProcessRepository processRepository;
    ObjectMapper objMapper = new ObjectMapper();

    UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
            "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", userObject1, true, new Date(), null, "test", null, null, null);

    FleetModel fleetModel = new FleetModel(UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3"), 0, "Test Fleet",
            projectModel, true, new Date(), null, "test", null);

    ProcessModel processModel = new ProcessModel(null, 0, "Test Process", fleetModel, true, new Date(), null, "test",
            null);

    ProcessModel createdProcessModel = new ProcessModel(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"), 0,
            "Test Process", fleetModel, true, new Date(), null, "test", null);
    ProcessModel updatedProcessModel = new ProcessModel(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"), 0,
            "Test Process", fleetModel, false, new Date(), null, "test", null);

    /**
     * testCreateProcess
     */
    @Test
    void testCreateProcess() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Process process = mapper.map(processModel, Process.class);
        Process createdprocess = mapper.map(createdProcessModel, Process.class);
        when(processRepository.save(process)).thenReturn(createdprocess);
        ProcessModel expectedProcessModel = mapper.map(createdprocess, ProcessModel.class);
        assertThat(processService.createProcess(processModel)).isEqualTo(expectedProcessModel);
    }

    @Test
    void testCreateProcessForEmptyFleet() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        processModel.setFleet(null);
        assertThrows(ApplicationFactoryException.class, () -> processService.createProcess(processModel), "");
    }

    @Test
    void testCreateProcessForRecordExists() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        when(processRepository.count(Mockito.any(FilterSpecification.class))).thenReturn((long) 1);
        assertThrows(ApplicationFactoryException.class, () -> processService.createProcess(processModel), "");
    }

    @Test
    void testUpdateProcess() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Process updatedprocess = mapper.map(updatedProcessModel, Process.class);
        Process createdprocess = mapper.map(createdProcessModel, Process.class);
        when(processRepository.findById(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")))
                .thenReturn(Optional.of(createdprocess));
        when(processRepository.save(updatedprocess)).thenReturn(updatedprocess);
        ProcessModel updatedprocessModel = mapper.map(updatedprocess, ProcessModel.class);
        assertThat(processService.updateProcess(updatedprocessModel)).isEqualTo(updatedprocessModel);
    }

    @Test
    void testUpdateProcessForElseCondition() {
        assertThrows(ApplicationFactoryException.class, () -> processService.updateProcess(updatedProcessModel), "");
    }

    @Test
    void testSearchProcess() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
                "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
                true, new Date(), null, "test", null, null, null);
        Fleet fleet = new Fleet(UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3"), 0, "Test Fleet", project, true,
                new Date(), null, "test", null);

        Process process = new Process(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"), 0, "Test Process", true,
                new Date(), null, "test", null, fleet);

        Process process1 = new Process(UUID.fromString("01007d1e-8842-e4c1-b22b-3d43aa9dd80d"), 0, "Test Process1",
                true, new Date(), null, "test", null, fleet);

        List<Process> processList = new ArrayList<>();
        processList.add(process);
        processList.add(process1);

        Object obj = processList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":false,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);

        when(processRepository.findAll(requestModel.getFilterSpecification())).thenReturn(processList);

        Object obj1 = processService.searchProcess(requestModel);

        int len = obj1.toString().length();

        assertThat((processList.size() == '2'));
    }

    /**
     * testViewProcess
     */
    @Test
    void testViewProcess() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
                "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
                true, new Date(), null, "test", null, null, null);
        Fleet fleet = new Fleet(UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3"), 0, "Test Fleet", project, true,
                new Date(), null, "test", null);
        Process process = new Process(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"), 0, "Test Process", true,
                new Date(), null, "test", null, fleet);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        ProcessModel processModel = mapper.map(process, ProcessModel.class);

        when(processRepository.findById(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")))
                .thenReturn(Optional.of(process));

        assertThat(processService.viewProcess(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")))
                .isEqualTo(processModel);
    }

    @Test
    void testViewProcessForCatch() {
        when(processRepository.findById(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> processService.viewProcess(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")), "");
    }

    @Test
    void testDeleteProcessById() {
        processService.deleteProcessById(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"));
        verify(processRepository).deleteById(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"));
    }

    @Test
    void testDeleteProcessByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(processRepository)
                .deleteById(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"));
        assertThrows(ApplicationFactoryException.class,
                () -> processService.deleteProcessById(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")), "");
    }

}
