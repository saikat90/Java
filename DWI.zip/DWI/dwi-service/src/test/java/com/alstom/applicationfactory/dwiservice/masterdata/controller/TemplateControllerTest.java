package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Template;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.service.TemplateService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(TemplateController.class)
class TemplateControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private WebApplicationContext context;
    @MockBean
    private TemplateService templateService;
    @MockBean
    private RequestModel requestModel;
    @MockBean
    private Authentication authentication;

    ObjectMapper mapper = new ObjectMapper();

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
            "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", user, true, new Date(), null, "test", null, null, null);

    Template template1 = new Template(null, 0, "Ottawa_Completion", true, "Work Procedure",
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"margin: 12.0pt 0cm 12.0pt 28.8pt;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Completion</span></h2>\\n<div>\\n<ol>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Ensure nothing is left in the site (for e.g. tools, cloth, paper sheets etc.)</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">On completion of the task, inform the Operations desk and ensure the system is operational.</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Complete all the documentation needed to report the task as completed.</span></li>\\n</ol>\\n</div>\\n</div>\\n</div>\\n</body>\\n</html>",
            project);

    Template createdtemplate = new Template(UUID.fromString("06ef2eb2-36c5-a4f4-b1aa-c9a1902a61c3"),
            0, "Ottawa_Completion", true, "Work Procedure",
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"margin: 12.0pt 0cm 12.0pt 28.8pt;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Completion</span></h2>\\n<div>\\n<ol>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Ensure nothing is left in the site (for e.g. tools, cloth, paper sheets etc.)</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">On completion of the task, inform the Operations desk and ensure the system is operational.</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Complete all the documentation needed to report the task as completed.</span></li>\\n</ol>\\n</div>\\n</div>\\n</div>\\n</body>\\n</html>",
            project);

    Template updatedTemplate = new Template(UUID.fromString("087daf8d-ae19-15e3-b0c9-0765f9a20455"),
            0, "Test Title", true, "Test Description_1",
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"padding-left: 30px;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Environmental Considerations</span></h2>\\n<table style=\\\"border-color: #000000;\\\" border=\\\"1\\\" width=\\\"100%\\\">\\n<tbody>\\n<tr style=\\\"height: 46px;\\\">\\n<td style=\\\"width: 35.0133%; border-color: #4f81bd; border-style: solid; border-width: 1pt 1pt 2.25pt; border-image: none 100% / 1 / 0 stretch; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"166\\\">\\n<p style=\\\"tab-stops: 60.75pt;\\\"><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Aspect</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 26.8852%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"154\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Impact</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 10.1174%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"97\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Rating</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 26.3926%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"212\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Mitigation Measure</span></strong></span></p>\\n</td>\\n</tr>\\n<tr style=\\\"height: 10px;\\\">\\n<td style=\\\"width: 35.0133%; border-color: currentcolor #4f81bd #4f81bd currentcolor; border-style: none solid solid none; border-width: medium 1pt 1pt medium; padding: 0cm 5.4pt; height: 99px;\\\" width=\\\"186\\\">&nbsp;</td>\\n<td style=\\\"width: 26.8852%; height: 99px;\\\">&nbsp;</td>\\n<td style=\\\"width: 10.1174%; height: 99px;\\\">&nbsp;</td>\\n<td style=\\\"width: 26.3926%; height: 99px;\\\">&nbsp;</td>\\n</tr>\\n</tbody>\\n</table>\\n</div>\\n</div>\\n</body>\\n</html>",
            project);

    /**
     * setup method
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testSearchTemplates() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        String returnObject = "{\r\n" + "  \"pageNumber\": 0,\r\n" + "  \"pageSize\": 10,\r\n"
                + "  \"totalElements\": 2,\r\n" + "  \"totalPages\": 1,\r\n"
                + "  \"content\": [\r\n" + "    {\r\n"
                + "      \"id\": \"06ef2eb2-36c5-a4f4-b1aa-c9a1902a61c3\",\r\n"
                + "      \"version\": 1,\r\n" + "      \"title\": \"Ottawa_Completion\",\r\n"
                + "      \"active\": true,\r\n"
                + "      \"dwiTemplateDescription\": \"Work Procedure\",\r\n"
                + "      \"content\": \"<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"margin: 12.0pt 0cm 12.0pt 28.8pt;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Completion</span></h2>\\n<div>\\n<ol>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Ensure nothing is left in the site (for e.g. tools, cloth, paper sheets etc.)</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">On completion of the task, inform the Operations desk and ensure the system is operational.</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Complete all the documentation needed to report the task as completed.</span></li>\\n</ol>\\n</div>\\n</div>\\n</div>\\n</body>\\n</html>\",\r\n"
                + "      \"project\": {\r\n"
                + "        \"id\": \"cbbb230f-b31d-d380-00ac-3a9488876b65\",\r\n"
                + "        \"version\": 0,\r\n"
                + "        \"projName\": \"Ottawa_MTN_Vehicle\",\r\n"
                + "        \"projectManager\": {\r\n"
                + "          \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "          \"employeeId\": \"23139\",\r\n"
                + "          \"firstName\": \"Alban\",\r\n"
                + "          \"lastName\": \"HOUSSIN\",\r\n"
                + "          \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "          \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "        },\r\n" + "        \"active\": true,\r\n"
                + "        \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "        \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "        \"createdBy\": \"413316\",\r\n" + "        \"modifiedBy\": null,\r\n"
                + "        \"projFunctions\": [],\r\n" + "        \"projectUserRoles\": []\r\n"
                + "      }\r\n" + "    },\r\n" + "	{\r\n"
                + "      \"id\": \"0930828c-ebc9-895d-fdbe-c93c022243a5\",\r\n"
                + "      \"version\": 0,\r\n" + "      \"title\": \"Ottawa_Materials & Tools\",\r\n"
                + "      \"active\": true,\r\n"
                + "      \"dwiTemplateDescription\": \"Materials & tools\",\r\n"
                + "      \"content\": \"<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<table style=\\\"width: 100%;\\\" border=\\\"1\\\"><caption><strong style=\\\"font-size: 18px;\\\">Materials &amp; Tools</strong></caption>\\n<tbody>\\n<tr style=\\\"background-color: #96d7fa;\\\">\\n<td style=\\\"width: 63.2462%; text-align: center;\\\"><strong>Description</strong></td>\\n<td style=\\\"width: 15.9181%; text-align: center;\\\"><strong>Quantity</strong></td>\\n<td style=\\\"width: 16.3872%; text-align: center;\\\"><strong>Calibration Required?<br /></strong></td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n<tr>\\n<td style=\\\"text-align: left; width: 63.2462%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 15.9181%;\\\">&nbsp;</td>\\n<td style=\\\"text-align: center; width: 16.3872%;\\\">&nbsp;</td>\\n</tr>\\n</tbody>\\n</table>\\n</div>\\n<div>&nbsp;</div>\\n</div>\\n</body>\\n</html>\",\r\n"
                + "      \"project\": {\r\n"
                + "        \"id\": \"394a6ba2-0988-17b3-560a-bc6e25a5776b\",\r\n"
                + "        \"version\": 0,\r\n"
                + "        \"projName\": \"Ottawa_MTN_Railsystem\",\r\n"
                + "        \"projectManager\": {\r\n"
                + "          \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "          \"employeeId\": \"23139\",\r\n"
                + "          \"firstName\": \"Alban\",\r\n"
                + "          \"lastName\": \"HOUSSIN\",\r\n"
                + "          \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "          \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "        },\r\n" + "        \"active\": true,\r\n"
                + "        \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "        \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "        \"createdBy\": \"413316\",\r\n" + "        \"modifiedBy\": null,\r\n"
                + "        \"projFunctions\": [],\r\n" + "        \"projectUserRoles\": []\r\n"
                + "      }\r\n" + "    }]\r\n" + "}";

        Object obj = returnObject;
        RequestModel requestModel = RequestMapper.map(request1);
        when(templateService.searchTemplate(requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders.post("/template/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testCreateTemplateModel() throws Exception {
        ModelMapper mapper1 = new ModelMapper();
        mapper1.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        TemplateModel templateModel = mapper1.map(template1, TemplateModel.class);
        TemplateModel createdTemplateModel = mapper1.map(createdtemplate, TemplateModel.class);
        String json = mapper.writeValueAsString(templateModel);
        when(templateService.saveTemplate(templateModel)).thenReturn(createdTemplateModel);
        RequestBuilder request = MockMvcRequestBuilders.post("/template")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testUpdateTemplate() throws Exception {
        ModelMapper mapper1 = new ModelMapper();
        mapper1.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());
        TemplateModel updatedTemplateModel = mapper1.map(updatedTemplate, TemplateModel.class);
        String json = mapper.writeValueAsString(updatedTemplateModel);
        when(templateService.updateTemplate(updatedTemplateModel)).thenReturn(updatedTemplateModel);
        RequestBuilder request = MockMvcRequestBuilders.put("/template")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteTemplate() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/template/087daf8d-ae19-15e3-b0c9-0765f9a20455")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testGetAllTemplateForProject() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        UUID projectId = UUID.fromString("cbbb230f-b31d-d380-00ac-3a9488876b65");
        String returnObject = "{\r\n"
                + "      \"id\": \"06ef2eb2-36c5-a4f4-b1aa-c9a1902a61c3\",\r\n"
                + "      \"version\": 1,\r\n" + "      \"title\": \"Ottawa_Completion\",\r\n"
                + "      \"active\": true,\r\n"
                + "      \"dwiTemplateDescription\": \"Work Procedure\",\r\n"
                + "      \"content\": \"<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"margin: 12.0pt 0cm 12.0pt 28.8pt;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Completion</span></h2>\\n<div>\\n<ol>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Ensure nothing is left in the site (for e.g. tools, cloth, paper sheets etc.)</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">On completion of the task, inform the Operations desk and ensure the system is operational.</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Complete all the documentation needed to report the task as completed.</span></li>\\n</ol>\\n</div>\\n</div>\\n</div>\\n</body>\\n</html>\",\r\n"
                + "      \"project\": {\r\n"
                + "        \"id\": \"cbbb230f-b31d-d380-00ac-3a9488876b65\",\r\n"
                + "        \"version\": 0,\r\n"
                + "        \"projName\": \"Ottawa_MTN_Vehicle\",\r\n"
                + "        \"projectManager\": {\r\n"
                + "          \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "          \"employeeId\": \"23139\",\r\n"
                + "          \"firstName\": \"Alban\",\r\n"
                + "          \"lastName\": \"HOUSSIN\",\r\n"
                + "          \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "          \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "        },\r\n" + "        \"active\": true,\r\n"
                + "        \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "        \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "        \"createdBy\": \"413316\",\r\n" + "        \"modifiedBy\": null,\r\n"
                + "        \"projFunctions\": [],\r\n" + "        \"projectUserRoles\": []\r\n"
                + "      }\r\n" + "    }";

        Object obj = returnObject;
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        request1 = RequestModifier.defaultRequestMapIfEmpty(request1);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "project.id", projectId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request1, filterConditions));
        when(templateService.searchTemplate(requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders
                .post("/template/cbbb230f-b31d-d380-00ac-3a9488876b65/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }
}
