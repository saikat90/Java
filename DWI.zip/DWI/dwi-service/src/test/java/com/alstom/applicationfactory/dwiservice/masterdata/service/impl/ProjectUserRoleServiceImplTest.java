package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.ProjectUserRole;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectUserRoleModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectUserRoleRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class ProjectUserRoleServiceImplTest {

    @InjectMocks
    ProjectUserRoleServiceImpl projUserRoleService;
    @Mock
    private ProjectRepository projRepository;
    @Mock
    private ProjectUserRoleRepository projUserRoleRepository;
    @Mock
    private UserRepository userRepository;
    ObjectMapper objMapper = new ObjectMapper();

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    UserModel userModel1 = new UserModel(UUID.fromString("1dfb6de1-dd86-49e6-a7eb-ee9515842bb5"), "100773831", "User B",
            "LastName", "user.bb@alstomgroup.com", "IS&T Project CoE");

    ProjectModel project = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
            userModel, true, new Date(), null, "test", null, null, null);

    ProjectUserRoleModel projUserRole = new ProjectUserRoleModel(null, userModel, "VALIDATOR", project);

    ProjectUserRoleModel addProjUserRole = new ProjectUserRoleModel(null, userModel, "VALIDATOR", project);
    ProjectUserRoleModel addedProjUserRole = new ProjectUserRoleModel(
            UUID.fromString("34fe9f7c-edaf-4686-87da-9c65fefe6707"), userModel, "VALIDATOR", project);
    ProjectUserRoleModel updatedProjUserRole = new ProjectUserRoleModel(
            UUID.fromString("e66815e4-b88e-43a4-b032-a2d444b4e436"), userModel1, "AUTHER", project);
    ProjectUserRoleModel addProjUserRole1 = new ProjectUserRoleModel(
            UUID.fromString("34fe2e7c-edaf-4686-87da-9c65fefe6707"), userModel, "AUTHER", project);

    /**
     * testUserRoleActions
     */
    @Test
    void testUserRoleActions() {
        List<ProjectUserRoleModel> updatedactionsList = new ArrayList<>();
        updatedactionsList.add(updatedProjUserRole);
        List<ProjectUserRoleModel> addedactionsList = new ArrayList<>();
        addedactionsList.add(addProjUserRole);
        List<ProjectUserRoleModel> addedFinalactionsList = new ArrayList<>();
        addedFinalactionsList.add(addedProjUserRole);
        List<ProjectUserRoleModel> deletedFinalactionsList = new ArrayList<>();
        Map<String, List<ProjectUserRoleModel>> mapactions = new HashMap<String, List<ProjectUserRoleModel>>();
        mapactions.put("edited", updatedactionsList);
        mapactions.put("added", addedactionsList);
        mapactions.put("deleted", deletedFinalactionsList);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UUID uuid = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");
        Project project_1 = mapper.map(project, Project.class);
        when(projRepository.findById(uuid)).thenReturn(Optional.of(project_1));

        ProjectUserRole finaladdedAction = mapper.map(addedProjUserRole, ProjectUserRole.class);

        List<ProjectUserRole> actions3 = new ArrayList<>();
        actions3.add(finaladdedAction);

        List<ProjectUserRole> updatedActions = updatedactionsList.stream().map(actionBean -> {
            ProjectUserRole action = mapper.map(actionBean, ProjectUserRole.class);
            action.setProject(project_1);
            return action;
        }).collect(Collectors.toList());

        List<ProjectUserRole> addedActions = addedactionsList.stream().map(actionBean -> {
            ProjectUserRole action = mapper.map(actionBean, ProjectUserRole.class);
            action.setProject(project_1);
            return action;
        }).collect(Collectors.toList());

        when(projUserRoleRepository.saveAll(updatedActions)).thenReturn(updatedActions);
        when(projUserRoleRepository.saveAll(addedActions)).thenReturn(actions3);
        ProjectUserRoleModel expupdatedActionModel = mapper.map(updatedActions.get(0), ProjectUserRoleModel.class);
        ProjectUserRoleModel expaddedActionModel = mapper.map(finaladdedAction, ProjectUserRoleModel.class);
        Map<String, List<ProjectUserRoleModel>> mapactionsExpected = new HashMap<String, List<ProjectUserRoleModel>>();
        List<ProjectUserRoleModel> ExpupdatedactionsList = new ArrayList<>();
        ExpupdatedactionsList.add(expupdatedActionModel);
        List<ProjectUserRoleModel> ExpaddedactionsList = new ArrayList<>();
        ExpaddedactionsList.add(expaddedActionModel);
        mapactionsExpected.put("edited", ExpupdatedactionsList);
        mapactionsExpected.put("added", ExpaddedactionsList);
        mapactionsExpected.put("deleted", deletedFinalactionsList);
        assertThat(projUserRoleService.userRoleActions(uuid, mapactions)).isEqualTo(mapactionsExpected);

    }

    @Test
    void testUserRoleActionsForCatch() {
        List<ProjectUserRoleModel> updatedactionsList = new ArrayList<>();
        updatedactionsList.add(updatedProjUserRole);
        List<ProjectUserRoleModel> addedactionsList = new ArrayList<>();
        addedactionsList.add(addProjUserRole);
        List<ProjectUserRoleModel> addedFinalactionsList = new ArrayList<>();
        addedFinalactionsList.add(addedProjUserRole);
        List<ProjectUserRoleModel> deletedFinalactionsList = new ArrayList<>();
        Map<String, List<ProjectUserRoleModel>> mapactions = new HashMap<String, List<ProjectUserRoleModel>>();
        mapactions.put("edited", updatedactionsList);
        mapactions.put("added", addedactionsList);
        mapactions.put("deleted", deletedFinalactionsList);

        UUID uuid = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");

        when(projRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class, () -> projUserRoleService.userRoleActions(uuid, mapactions),
                "");
    }

    @Test
    void testSearchProjectUserRoles() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        ProjectUserRole projUserRole = mapper.map(addedProjUserRole, ProjectUserRole.class);
        ProjectUserRole projUserRole1 = mapper.map(addProjUserRole1, ProjectUserRole.class);

        List<ProjectUserRole> actions1 = new ArrayList<>();
        actions1.add(projUserRole);
        actions1.add(projUserRole1);

        UUID uuid = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        RequestModel requestModel = RequestMapper.map(request1);
        when(projUserRoleRepository.findAll(requestModel.getFilterSpecification())).thenReturn(actions1);
        Object obj1 = projUserRoleService.searchProjectUserRoles(uuid, requestModel);
        assertThat((actions1.size() == '2'));

    }

    /**
     * testGetUsersForRole
     */
    @Test
    void testGetUsersForRole() {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        ProjectUserRole projUserRole = mapper.map(updatedProjUserRole, ProjectUserRole.class);
        ProjectUserRole projUserRole1 = mapper.map(addProjUserRole1, ProjectUserRole.class);

        List<ProjectUserRole> actions1 = new ArrayList<>();
        actions1.add(projUserRole);
        actions1.add(projUserRole1);

        UUID projectId = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");
        String role = "AUTHER";
        List<UserModel> userModelList = new ArrayList<>();
        userModelList.add(userModel);
        userModelList.add(userModel1);
        when(projUserRoleRepository.findByProjectIdAndRole(projectId, role)).thenReturn(actions1);
        List<UserModel> userModelListNew = projUserRoleService.getUsersForRole(projectId, role);
        assertThat((userModelList.size() == userModelListNew.size()));

    }

    /**
     * testGetProjectForUser
     */
    @Test
    void testGetProjectForUser() {
        UUID projectId = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");
        List<UUID> projectIdList = new ArrayList<>();
        projectIdList.add(projectId);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        User user = mapper.map(userModel, User.class);
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);

        ProjectUserRole projUserRole = mapper.map(addedProjUserRole, ProjectUserRole.class);
        ProjectUserRole projUserRole1 = mapper.map(addProjUserRole1, ProjectUserRole.class);
        List<ProjectUserRole> actions1 = new ArrayList<>();
        actions1.add(projUserRole);
        actions1.add(projUserRole1);

        when(projUserRoleRepository.findByUserId(user.getId())).thenReturn(actions1);

        List<UUID> projectIdListNew = projUserRoleService.getProjectForUser("user.ar@alstomgroup.com");
        assertThat((projectIdList.size() == projectIdListNew.size()));
    }

    @Test
    void testGetProjectForUserNullCase() {
        String email = "user.ar@alstomgroup.com";
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> projUserRoleService.getProjectForUser("user.ar@alstomgroup.com"), "");
    }

    @Test
    void testGetProjectModelForUserNullCase() {
        String email = "user.ar@alstomgroup.com";
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> projUserRoleService.getProjectModelForUser("user.ar@alstomgroup.com"), "");
    }

    @Test
    void testGetProjectModelForUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        User user = mapper.map(userModel, User.class);
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);

        ProjectUserRole projUserRole = mapper.map(addedProjUserRole, ProjectUserRole.class);
        ProjectUserRole projUserRole1 = mapper.map(addProjUserRole1, ProjectUserRole.class);
        List<ProjectUserRole> actions1 = new ArrayList<>();
        actions1.add(projUserRole);
        actions1.add(projUserRole1);

        List<ProjectModel> projectModelList = new ArrayList<>();
        projectModelList.add(project);

        when(projUserRoleRepository.findByUserId(user.getId())).thenReturn(actions1);

        List<ProjectModel> projectModelListNew = projUserRoleService.getProjectModelForUser("user.ar@alstomgroup.com");
        assertThat((projectModelList.size() == projectModelListNew.size()));
    }

}
