package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.instruction.entity.EditionControlComments;
import com.alstom.applicationfactory.dwiservice.instruction.entity.Instructions;
import com.alstom.applicationfactory.dwiservice.instruction.model.EditionControlCommentsModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.EditionControlCommentsRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class EditionControlCommentsServiceImplTest {

    @Mock
    private EditionControlCommentsRepository editionCCRespository;

    @InjectMocks
    EditionControlCommentsServiceImpl editionControlCommentsServiceImpl;

    ObjectMapper objMapper = new ObjectMapper();

    UUID uuid = UUID.fromString("5e645231-7b33-73ad-0ca0-8b5e49aac5b2");

    /**
     * testGetEditionControlComments
     */
    @Test
    void testGetEditionControlComments() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
                "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
                true, new Date(), null, "test", null, null, null);

        Fleet fleet = new Fleet(UUID.fromString("05d559bc-f1ed-7c21-2a39-a4f5d5c2421f"), 0, "Test Fleet", project, true,
                new Date(), new Date(), null, null);

        Process process = new Process(UUID.fromString("064841a5-98d7-9b1c-2da8-abdb4a5aff24"), 0, "Test Process", true,
                new Date(), null, "user.ar@alstomgroup.com", null, fleet);

        Revision revision = new Revision(UUID.fromString("04a62e8f-a6b7-d69b-0238-55d4c7e594fa"), 0, "Test Revision",
                true, new Date(), null, "test", null, process);

        Instructions instructions = new Instructions(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), 0,
                "APPROVED", "NEW", new Date(), new Date(), new Date(), null, "OTT-LRV-MTN50-WMS-004", 1,
                "OperatingáUWL", "OTT-LRV-MTN50-WMS-004", project, null, process, revision, null, user, user, user,
                "Approved", false, false, "pdf import", null, new Date(), null, "user.ar@alstomgroup.com", null, fleet,
                null, null, null, null, null, null, null, null, null, null, null);

        EditionControlComments editionControlComments = new EditionControlComments(
                UUID.fromString("5e645231-7b33-73ad-0ca0-8b5e49aac5b2"), 0, instructions, "OTT-LRV-MTN50-WMS-004", 1,
                user, new Date(), null);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        EditionControlCommentsModel expectedEditionControlCommentsModel = mapper.map(editionControlComments,
                EditionControlCommentsModel.class);

        List<EditionControlComments> expectedObject = new ArrayList<>();

        expectedObject.add(editionControlComments);

        when(editionCCRespository.findByInstructionsId(uuid)).thenReturn(expectedObject);

        assertThat(editionControlCommentsServiceImpl.getEditionControlComments(uuid))
                .isEqualTo(expectedEditionControlCommentsModel);

    }

}
