/**
 */
package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.alstom.applicationfactory.dwiservice.instruction.entity.EditionControlComments;
import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionAttachment;
import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionWorkFlowDetails;
import com.alstom.applicationfactory.dwiservice.instruction.entity.Instructions;
import com.alstom.applicationfactory.dwiservice.instruction.entity.RTEMedia;
import com.alstom.applicationfactory.dwiservice.instruction.entity.WINumberPerProject;
import com.alstom.applicationfactory.dwiservice.instruction.entity.WorkFlowActionHistory;
import com.alstom.applicationfactory.dwiservice.instruction.model.EditionControlCommentsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionWorkFlowDetailsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsListModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsQliksenseModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.RTEMediaModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.WINumberPerProjectModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.WorkFlowActionHistoryModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.DwiHeader;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Function;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.NotificationSettings;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.ProjectUserRole;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Tag;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Template;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.UserSearchQuery;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplateDesc;
import com.alstom.applicationfactory.dwiservice.masterdata.model.DwiHeaderModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.EmailModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.NotificationSettingsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProfileModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectUserRoleModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TagModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserSearchQueryModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;

/**
 * @author 100769630
 */
@ExtendWith(MockitoExtension.class)
class EnityModelTest {

    UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");

    byte byteArray[] = { 20, 10, 30, 5 };

    Object obj = new Object();

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    User userObj = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", userModel, true, new Date(), new Date(), "test", "userb", null, null);

    Project projectObj = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
            userObj, true, new Date(), new Date(), "test", "userb", null, null);

    FleetModel fleetModel = new FleetModel(UUID.fromString("05d559bc-f1ed-7c21-2a39-a4f5d5c2421f"), 0, "Test Fleet",
            projectModel, true, new Date(), new Date(), "usera", "userb");

    Fleet fleetObj = new Fleet(UUID.fromString("05d559bc-f1ed-7c21-2a39-a4f5d5c2421f"), 0, "Test Fleet", projectObj,
            true, new Date(), new Date(), "usera", "userb");

    ProcessModel processModel = new ProcessModel(UUID.fromString("064841a5-98d7-9b1c-2da8-abdb4a5aff24"), 0,
            "Test Process", fleetModel, true, new Date(), new Date(), "test", "userb");

    Process processObj = new Process(UUID.fromString("064841a5-98d7-9b1c-2da8-abdb4a5aff24"), 0, "Test Process", true,
            new Date(), new Date(), "test", "userb", fleetObj);

    RevisionModel revisionModel = new RevisionModel(UUID.fromString("04a62e8f-a6b7-d69b-0238-55d4c7e594fa"), 0,
            "Test Revision", true, new Date(), new Date(), "test", "userb", processModel);

    Revision revisionObj = new Revision(UUID.fromString("04a62e8f-a6b7-d69b-0238-55d4c7e594fa"), 0, "Test Revision",
            true, new Date(), null, "test", null, processObj);

    FunctionModel functionModel = new FunctionModel(UUID.fromString("0e3b39d7-7bcc-d0f4-6621-cfc02c669b2f"), 0,
            "test Function Name", true, new Date(), new Date(), "usera", "userb");

    Function functionObj = new Function(UUID.fromString("0e3b39d7-7bcc-d0f4-6621-cfc02c669b2f"), 0,
            "test Function Name", true, new Date(), new Date(), "usera", "userb");

    WorkFlowTemplateModel createdwfTemplate = new WorkFlowTemplateModel(
            UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, projectModel, new Date(),
            new Date(), "test", "userb", null);

    WorkFlowTemplate createdwfTemplateObj = new WorkFlowTemplate(
            UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, projectObj, new Date(), new Date(),
            "test", "userb", null);

    WorkFlowTemplateDescModel workFlowTemplateDescModel = new WorkFlowTemplateDescModel(
            UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"), 0, "APPROVED", functionModel, "Dauren", userModel,
            "Test Comments", createdwfTemplate, 0);

    WorkFlowTemplateDesc workFlowTemplateDescObj = new WorkFlowTemplateDesc(
            UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"), 0, "APPROVED", functionObj, "Dauren", userObj,
            "Test Comments", createdwfTemplateObj, 0);

    InstructionsModel instructionsModel = new InstructionsModel(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
            0, "APPROVED", "NEW", new Date(), new Date(), new Date(), new Date(), "OTT-LRV-MTN50-WMS-004", 1,
            "OperatingáUWL", "OTT-LRV-MTN50-WMS-004", projectModel, "testFleet", processModel, revisionModel,
            createdwfTemplate, userModel, userModel, userModel, "Approved", false, false, "pdf import", byteArray,
            new Date(), new Date(), "user.ar@alstomgroup.com", "user.b.ar@alstomgroup.com", fleetModel, byteArray,
            byteArray, "http://test.com", "test commentAttachmentId", null, null, null, null, null, null, null);

    Instructions instructionsObj = new Instructions(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), 0,
            "APPROVED", "NEW", new Date(), new Date(), new Date(), new Date(), "OTT-LRV-MTN50-WMS-004", 1,
            "OperatingáUWL", "OTT-LRV-MTN50-WMS-004", projectObj, "testFleet", processObj, revisionObj,
            createdwfTemplateObj, userObj, userObj, userObj, "Approved", false, false, "pdf import", byteArray,
            new Date(), new Date(), "user.ar@alstomgroup.com", "user.b.ar@alstomgroup.com", fleetObj, byteArray,
            byteArray, "http://test.com", "test commentAttachmentId", null, null, null, null, null, null, null);

    InstructionAttachmentModel newInstructionAttachmentModel = new InstructionAttachmentModel(null, 0, "testdwiFormId",
            "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test", instructionsModel);

    InstructionAttachmentModel createdInstructionAttachmentModel = new InstructionAttachmentModel(uuid, 0,
            "testdwiFormId", "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test",
            instructionsModel);

    InstructionAttachment createdInstructionAttachmentObj = new InstructionAttachment(uuid, 0, "testdwiFormId",
            "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test", instructionsObj);

    DwiHeaderModel dwiHeaderModel = new DwiHeaderModel(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"), 0,
            "Test Content", projectModel);

    DwiHeader dwiHeaderObj = new DwiHeader(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"), 0, "Test Content",
            projectObj);

    NotificationSettingsModel notificationSettingsModel = new NotificationSettingsModel(
            UUID.fromString("0506ed93-f217-c58d-e3a8-c659276839e2"), 1, 1);

    NotificationSettings notificationSettingsObj = new NotificationSettings(
            UUID.fromString("0506ed93-f217-c58d-e3a8-c659276839e2"), 1, 1);

    ProjectUserRoleModel projectUserRoleModel = new ProjectUserRoleModel(
            UUID.fromString("7d1255b4-2a84-72ba-03ff-3febb7aa5ea0"), userModel, "VALIDATOR", projectModel);

    ProjectUserRole projectUserObj = new ProjectUserRole(UUID.fromString("7d1255b4-2a84-72ba-03ff-3febb7aa5ea0"),
            userObj, "VALIDATOR", projectObj);

    TagModel tagModel = new TagModel(UUID.fromString("0bd4a196-a236-9a90-0d0a-4d602d975783"), 0, "GDS");

    Tag tagObj = new Tag(UUID.fromString("0bd4a196-a236-9a90-0d0a-4d602d975783"), 0, "GDS");

    TemplateModel templateModel = new TemplateModel(UUID.fromString("0930828c-ebc9-895d-fdbe-c93c022243a5"), 0,
            "Test Template", true, "Test Tempalte Desc", "test content", projectModel);

    Template templateObj = new Template(UUID.fromString("0930828c-ebc9-895d-fdbe-c93c022243a5"), 0, "Test Template",
            true, "Test Tempalte Desc", "test content", projectObj);

    UserSearchQueryModel userSearchQueryModel = new UserSearchQueryModel(
            UUID.fromString("9d13fae8-5971-415b-b380-4235dd3db055"), userModel, "Test Query", "Project",
            "Test Data  Updated", true, false, userModel, null, new Date(), new Date(), "usera", "userb");

    UserSearchQuery userSearchQueryObj = new UserSearchQuery(UUID.fromString("9d13fae8-5971-415b-b380-4235dd3db055"),
            userObj, "Test Query", "Project", "Test Data  Updated", true, false, userObj, null, new Date(), new Date(),
            "usera", "userb");

    EditionControlCommentsModel editionControlCommentsModel = new EditionControlCommentsModel(
            UUID.fromString("5e645231-7b33-73ad-0ca0-8b5e49aac5b2"), 0, instructionsModel, "OTT-LRV-MTN50-WMS-004", 1,
            userModel, new Date(), "Test Comment");

    EditionControlComments editionControlComments = new EditionControlComments(
            UUID.fromString("5e645231-7b33-73ad-0ca0-8b5e49aac5b2"), 0, instructionsObj, "OTT-LRV-MTN50-WMS-004", 1,
            userObj, new Date(), "Test Comment");

    InstructionsQliksenseModel instructionsQliksenseModel = new InstructionsQliksenseModel("Test DWI Number", 1, true,
            "Test Reference", "DRAFT", "Test Project", "Test Project Manager", "Author First Name", "Author last Name",
            "Test Fleet Name", "Test Process Name", "Test Revision Name", "user first name", "user last name",
            "WORKER");

    InstructionsQliksenseModel instructionsQliksenseModel2 = new InstructionsQliksenseModel("Test DWI Number2", 1,
            false, "Test Reference", "DRAFT", "Test Project", "Test Project Manager", "Author First Name",
            "Author last Name", "Test Fleet Name", "Test Process Name", "Test Revision Name", "user first name",
            "user last name", "WORKER");

    InstructionsListModel instructionsListModel = new InstructionsListModel(
            UUID.fromString("6e645231-7b33-73ad-0ca0-8b5e49aac5b2"), 1, "DRAFT", "DWI_Number_1", 1, "DWI Title",
            "DWI Ref", projectModel, processModel, revisionModel, userModel, fleetModel, "http://test.com", new Date());

    InstructionsListModel instructionsListModel2 = new InstructionsListModel(
            UUID.fromString("7e645231-7b33-73ad-0ca0-8b5e49aac5b2"), 1, "DRAFT", "DWI_Number_1", 1, "DWI Title",
            "DWI Ref", projectModel, processModel, revisionModel, userModel, fleetModel, "http://test.com", new Date());

    InstructionWorkFlowDetailsModel instructionWorkFlowDetailsModel = new InstructionWorkFlowDetailsModel(
            UUID.fromString("1be35875-c83a-446f-9611-971aea753740"), 0, "DESIGN", functionModel, "Designer", userModel,
            new Date(), "Validated", "Test Comments", instructionsModel, 0);

    InstructionWorkFlowDetails instructionWorkFlowDetailsObj = new InstructionWorkFlowDetails(
            UUID.fromString("1be35875-c83a-446f-9611-971aea753740"), 0, "DESIGN", functionObj, "Designer", userObj,
            new Date(), "Validated", "Test Comments", instructionsObj, 0);

    WorkFlowActionHistory workFlowActionHistoryObj = new WorkFlowActionHistory(
            UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), 0, new Date(), "IS&T Project CoE", userObj,
            "User A", "Created", "Test Comments", instructionsObj, 1, createdInstructionAttachmentObj);

    WorkFlowActionHistoryModel workFlowActionHistoryModel = new WorkFlowActionHistoryModel(
            UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), 0, new Date(), "IS&T Project CoE", userModel,
            "User A", "Created", "Test Comments", instructionsModel, 1, createdInstructionAttachmentModel);

    WINumberPerProjectModel wiNumberPerProjectModel = new WINumberPerProjectModel(
            UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), 1, "1", projectModel);

    WINumberPerProject wiNumberPerProjectObj = new WINumberPerProject(
            UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), 1, "1", projectObj);

    RTEMediaModel rTEMediaModel = new RTEMediaModel(UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), 1,
            "Test Upload", byteArray);

    RTEMedia rTEMediaObj = new RTEMedia(UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), 1, "Test Upload",
            byteArray);

    ProfileModel profileModel = new ProfileModel(UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"),
            "Digital Work Instruction", "APP_DWI", "test", "test@alstomgroup.com", null);

    EmailModel emailModel = new EmailModel(Arrays.asList(new String[] { "APPROVER", "VALIDATOR" }), "Test Subject",
            "Test Body");

    @Test
    void testEntiyAndModel() {
        userModel.toString();
        userModel.hashCode();
        userObj.toString();
        userObj.hashCode();
        userModel.equals(userModel);
        userModel.equals(null);
        userObj.equals(userObj);
        userObj.equals(null);

        projectModel.toString();
        projectModel.hashCode();
        projectObj.toString();
        projectObj.hashCode();
        projectModel.equals(projectModel);
        projectModel.equals(null);
        projectObj.equals(projectObj);
        projectObj.equals(null);

        fleetModel.toString();
        fleetModel.hashCode();
        fleetObj.toString();
        fleetObj.hashCode();
        fleetModel.equals(fleetModel);
        fleetModel.equals(null);
        fleetObj.equals(fleetObj);
        fleetObj.equals(null);

        processModel.toString();
        processModel.hashCode();
        processObj.toString();
        processObj.hashCode();
        processModel.equals(processModel);
        processModel.equals(null);
        processObj.equals(processObj);
        processObj.equals(null);

        revisionModel.toString();
        revisionModel.hashCode();
        revisionObj.toString();
        revisionObj.hashCode();
        revisionObj.equals(revisionObj);
        revisionObj.equals(null);
        revisionObj.equals(revisionObj);
        revisionObj.equals(null);

        functionModel.toString();
        functionModel.hashCode();
        functionObj.toString();
        functionObj.hashCode();
        functionObj.equals(functionObj);
        functionObj.equals(null);
        functionModel.equals(functionModel);
        functionModel.equals(null);

        createdwfTemplate.toString();
        createdwfTemplate.hashCode();
        createdwfTemplateObj.toString();
        createdwfTemplateObj.hashCode();
        createdwfTemplate.equals(createdwfTemplate);
        createdwfTemplate.equals(null);
        createdwfTemplateObj.equals(createdwfTemplateObj);
        createdwfTemplateObj.equals(null);

        workFlowTemplateDescModel.toString();
        workFlowTemplateDescModel.hashCode();
        workFlowTemplateDescObj.toString();
        workFlowTemplateDescObj.hashCode();
        workFlowTemplateDescModel.equals(workFlowTemplateDescModel);
        workFlowTemplateDescModel.equals(null);
        workFlowTemplateDescObj.equals(workFlowTemplateDescObj);
        workFlowTemplateDescObj.equals(null);

        instructionsModel.toString();
        instructionsModel.hashCode();
        instructionsObj.toString();
        instructionsObj.hashCode();
        instructionsModel.equals(instructionsModel);
        instructionsModel.equals(null);
        instructionsObj.equals(instructionsObj);
        instructionsObj.equals(null);

        createdInstructionAttachmentModel.toString();
        createdInstructionAttachmentModel.hashCode();
        createdInstructionAttachmentObj.toString();
        createdInstructionAttachmentObj.hashCode();
        createdInstructionAttachmentModel.equals(createdInstructionAttachmentModel);
        createdInstructionAttachmentModel.equals(null);
        createdInstructionAttachmentObj.equals(createdInstructionAttachmentObj);
        createdInstructionAttachmentObj.equals(null);

        dwiHeaderModel.toString();
        dwiHeaderModel.hashCode();
        dwiHeaderObj.toString();
        dwiHeaderObj.hashCode();
        dwiHeaderModel.equals(dwiHeaderModel);
        dwiHeaderModel.equals(null);
        dwiHeaderObj.equals(dwiHeaderObj);
        dwiHeaderObj.equals(null);

        notificationSettingsModel.toString();
        notificationSettingsModel.hashCode();
        notificationSettingsObj.toString();
        notificationSettingsObj.hashCode();
        notificationSettingsModel.equals(notificationSettingsModel);
        notificationSettingsModel.equals(null);
        notificationSettingsObj.equals(notificationSettingsObj);
        notificationSettingsObj.equals(null);

        projectUserRoleModel.toString();
        projectUserRoleModel.hashCode();
        projectUserObj.toString();
        projectUserObj.hashCode();
        projectUserRoleModel.equals(projectUserRoleModel);
        projectUserRoleModel.equals(null);
        projectUserObj.equals(projectUserObj);
        projectUserObj.equals(null);

        tagModel.toString();
        tagModel.hashCode();
        tagObj.toString();
        tagObj.hashCode();
        tagModel.equals(tagModel);
        tagModel.equals(null);
        tagObj.equals(tagObj);
        tagObj.equals(null);

        templateModel.toString();
        templateModel.hashCode();
        templateObj.toString();
        templateObj.hashCode();
        templateModel.equals(templateModel);
        templateModel.equals(null);
        templateObj.equals(templateObj);
        templateObj.equals(null);

        userSearchQueryModel.toString();
        userSearchQueryModel.hashCode();
        userSearchQueryObj.toString();
        userSearchQueryObj.hashCode();
        userSearchQueryModel.equals(userSearchQueryModel);
        userSearchQueryModel.equals(null);
        userSearchQueryObj.equals(userSearchQueryObj);
        userSearchQueryObj.equals(null);

        editionControlCommentsModel.toString();
        editionControlCommentsModel.hashCode();
        editionControlComments.toString();
        editionControlComments.hashCode();
        editionControlCommentsModel.equals(editionControlCommentsModel);
        editionControlCommentsModel.equals(null);
        editionControlComments.equals(editionControlComments);
        editionControlComments.equals(null);

        instructionsQliksenseModel.toString();
        instructionsQliksenseModel.hashCode();
        instructionsQliksenseModel.equals(instructionsQliksenseModel);
        instructionsQliksenseModel.equals(null);

        instructionsListModel.toString();
        instructionsListModel.hashCode();
        instructionsListModel.equals(instructionsListModel);
        instructionsListModel.equals(null);

        instructionWorkFlowDetailsObj.toString();
        instructionWorkFlowDetailsObj.hashCode();
        instructionWorkFlowDetailsModel.toString();
        instructionWorkFlowDetailsModel.hashCode();
        instructionWorkFlowDetailsObj.equals(instructionWorkFlowDetailsObj);
        instructionWorkFlowDetailsObj.equals(null);
        instructionWorkFlowDetailsModel.equals(instructionWorkFlowDetailsModel);
        instructionWorkFlowDetailsModel.equals(null);

        workFlowActionHistoryObj.toString();
        workFlowActionHistoryObj.hashCode();
        workFlowActionHistoryModel.toString();
        workFlowActionHistoryModel.hashCode();
        workFlowActionHistoryObj.equals(workFlowActionHistoryObj);
        workFlowActionHistoryObj.equals(null);
        workFlowActionHistoryModel.equals(workFlowActionHistoryModel);
        workFlowActionHistoryModel.equals(null);

        wiNumberPerProjectModel.toString();
        wiNumberPerProjectModel.hashCode();
        wiNumberPerProjectObj.toString();
        wiNumberPerProjectObj.hashCode();
        wiNumberPerProjectModel.equals(wiNumberPerProjectModel);
        wiNumberPerProjectModel.equals(null);
        wiNumberPerProjectObj.equals(wiNumberPerProjectObj);
        wiNumberPerProjectObj.equals(null);

        rTEMediaModel.toString();
        rTEMediaModel.hashCode();
        rTEMediaObj.toString();
        rTEMediaObj.hashCode();
        rTEMediaModel.equals(rTEMediaModel);
        rTEMediaModel.equals(null);
        rTEMediaObj.equals(rTEMediaObj);
        rTEMediaObj.equals(null);

        profileModel.toString();
        profileModel.hashCode();
        profileModel.equals(obj);
        profileModel.equals(profileModel);
        profileModel.equals(null);

        emailModel.toString();
        emailModel.hashCode();
        emailModel.equals(obj);
        emailModel.equals(emailModel);
        emailModel.equals(null);

        Assertions.assertTrue(true);
    }

}
