package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateDescModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateRepository;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class WorkFlowTemplateServiceImplTest {

    @InjectMocks
    WorkFlowTemplateServiceImpl wfTemplateService;
    @Mock
    private WorkFlowTemplateRepository workFlowTemplateRepository;
    ObjectMapper objMapper = new ObjectMapper();

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");
    Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
            true, new Date(), null, "test", null, null, null);

    WorkFlowTemplate wfTemplate = new WorkFlowTemplate(null, 0, "N1", true, project, new Date(), null, "test", null,
            null);
    WorkFlowTemplate createdwfTemplate = new WorkFlowTemplate(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"),
            0, "N1", true, project, new Date(), null, "test", null, null);
    WorkFlowTemplate updatedwfTemplate = new WorkFlowTemplate(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"),
            0, "N1-Test", true, project, new Date(), null, "test", null, null);
    WorkFlowTemplate createdwfTemplate1 = new WorkFlowTemplate(UUID.fromString("0c6ce614-347e-455f-b2b3-7286a5cb0c4c"),
            0, "N5", true, project, new Date(), null, "test", null, null);

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
    ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", userModel, true, new Date(), null, "test", null, null, null);

    WorkFlowTemplateModel wfTemplateModel = new WorkFlowTemplateModel(null, 0, "N1", true, projectModel, new Date(),
            null, "test", null, null);
    WorkFlowTemplateModel createdwfTemplateModel = new WorkFlowTemplateModel(
            UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, projectModel, new Date(), null,
            "test", null, null);
    WorkFlowTemplateModel updatedwfTemplateModel = new WorkFlowTemplateModel(
            UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1-Test", true, projectModel, new Date(), null,
            "test", null, null);
    FunctionModel functionModel = new FunctionModel(UUID.fromString("bdcfdbfe-5be2-0b90-3746-74846e35eab7"), 2,
            "Project Manager", true, new Date(), null, "test", null);
    WorkFlowTemplateDescModel createdwfTemplatedesc = new WorkFlowTemplateDescModel(
            UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"), 0, "APPROVED", functionModel, "Roberto", userModel,
            null, createdwfTemplateModel, 1);

    /**
     * testCreateWorkFlowTemplate
     */
    @Test
    void testCreateWorkFlowTemplate() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplate wfTemplate_1 = mapper.map(wfTemplateModel, WorkFlowTemplate.class);
        WorkFlowTemplate createdwfTemplate_1 = mapper.map(createdwfTemplateModel, WorkFlowTemplate.class);
        when(workFlowTemplateRepository.save(wfTemplate_1)).thenReturn(createdwfTemplate_1);
        WorkFlowTemplateModel expectedwfTemplateModel = mapper.map(createdwfTemplate_1, WorkFlowTemplateModel.class);
        assertThat(wfTemplateService.createWorkFlowTemplate(wfTemplateModel)).isEqualTo(expectedwfTemplateModel);
    }

    @Test
    void testCreateWorkFlowTemplateForRecordExist() {
        List<WorkFlowTemplateDescModel> actions = new ArrayList<>();
        actions.add(createdwfTemplatedesc);
        wfTemplateModel.setActions(actions);
        when(workFlowTemplateRepository.count(Mockito.any(FilterSpecification.class))).thenReturn((long) 1);
        assertThrows(ApplicationFactoryException.class, () -> wfTemplateService.createWorkFlowTemplate(wfTemplateModel),
                "");
    }

    @Test
    void testUpdateWorkFlowTemplate() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<WorkFlowTemplateDescModel> actions = new ArrayList<>();
        actions.add(createdwfTemplatedesc);
        createdwfTemplateModel.setActions(actions);
        WorkFlowTemplate createdwfTemplate_1 = mapper.map(createdwfTemplateModel, WorkFlowTemplate.class);
        WorkFlowTemplate updatedwfTemplate_1 = mapper.map(updatedwfTemplateModel, WorkFlowTemplate.class);
        when(workFlowTemplateRepository.findById(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150")))
                .thenReturn(Optional.of(createdwfTemplate_1));
        when(workFlowTemplateRepository.save(updatedwfTemplate_1)).thenReturn(updatedwfTemplate_1);
        WorkFlowTemplateModel expectedwfTemplateModel = mapper.map(updatedwfTemplate_1, WorkFlowTemplateModel.class);
        assertThat(wfTemplateService.updateWorkFlowTemplate(updatedwfTemplateModel)).isEqualTo(expectedwfTemplateModel);
    }

    @Test
    void testUpdateWorkFlowTemplateForRecordNotExist() {
        assertThrows(ApplicationFactoryException.class,
                () -> wfTemplateService.updateWorkFlowTemplate(updatedwfTemplateModel), "");
    }

    @Test
    void testSearchWorkFlowTemplate() {
        List<WorkFlowTemplate> wftemplateList = new ArrayList<>();
        wftemplateList.add(createdwfTemplate);
        wftemplateList.add(createdwfTemplate1);

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        RequestModel requestModel = RequestMapper.map(request1);

        when(workFlowTemplateRepository.findAll(requestModel.getFilterSpecification())).thenReturn(wftemplateList);
        Object obj1 = wfTemplateService.searchWorkFlowTemplate(requestModel);
        assertThat((wftemplateList.size() == '2'));
    }

    /**
     * testViewWorkFlowTemplate
     */
    @Test
    void testViewWorkFlowTemplate() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplateModel createdwfTemplateModel = mapper.map(createdwfTemplate, WorkFlowTemplateModel.class);
        when(workFlowTemplateRepository.findById(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150")))
                .thenReturn(Optional.of(createdwfTemplate));
        assertThat(wfTemplateService.viewWorkFlowTemplate(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150")))
                .isEqualTo(createdwfTemplateModel);

    }

    @Test
    void testViewWorkFlowTemplateForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplateModel createdwfTemplateModel = mapper.map(createdwfTemplate, WorkFlowTemplateModel.class);
        when(workFlowTemplateRepository.findById(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> wfTemplateService.viewWorkFlowTemplate(UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150")),
                "");
    }

    @Test
    void testDeleteWorkFlowTemplateById() {
        wfTemplateService.deleteWorkFlowTemplateById(UUID.fromString("0c6ce614-347e-455f-b2b3-7286a5cb0c4c"));
        verify(workFlowTemplateRepository).deleteById(UUID.fromString("0c6ce614-347e-455f-b2b3-7286a5cb0c4c"));
    }

    @Test
    void testDeleteWorkFlowTemplateByIdForCatch() {

        doThrow(ApplicationFactoryException.class).when(workFlowTemplateRepository)
                .deleteById(UUID.fromString("0c6ce614-347e-455f-b2b3-7286a5cb0c4c"));
        assertThrows(ApplicationFactoryException.class, () -> wfTemplateService
                .deleteWorkFlowTemplateById(UUID.fromString("0c6ce614-347e-455f-b2b3-7286a5cb0c4c")), "");
    }

}
