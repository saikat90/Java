/**
 */
package com.alstom.applicationfactory.dwiservice.instruction.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionAttachmentService;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author 100769630.
 */
@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
@WebMvcTest(InstructionAttachmentController.class)
class InstructionAttachmentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;

    @Autowired
    private WebApplicationContext context;

    ObjectMapper mapper = new ObjectMapper();

    @MockBean
    private EmailServiceClient emailServiceClient;

    @MockBean
    private InstructionAttachmentService instructionAttachmentService;

    UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", userModel, true, new Date(), null, "test", null, null, null);

    FleetModel fleetModel = new FleetModel(UUID.fromString("05d559bc-f1ed-7c21-2a39-a4f5d5c2421f"), 0, "Test Fleet",
            projectModel, true, new Date(), new Date(), null, null);

    ProcessModel processModel = new ProcessModel(UUID.fromString("064841a5-98d7-9b1c-2da8-abdb4a5aff24"), 0,
            "Test Process", fleetModel, true, new Date(), null, "test", null);

    RevisionModel revisionModel = new RevisionModel(UUID.fromString("04a62e8f-a6b7-d69b-0238-55d4c7e594fa"), 0,
            "Test Revision", true, new Date(), null, "test", null, processModel);

    InstructionsModel instructionsModel = new InstructionsModel(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
            0, "APPROVED", "NEW", new Date(), new Date(), new Date(), null, "OTT-LRV-MTN50-WMS-004", 1, "OperatingáUWL",
            "OTT-LRV-MTN50-WMS-004", projectModel, null, processModel, revisionModel, null, userModel, userModel,
            userModel, "Approved", false, false, "pdf import", null, new Date(), null, "user.ar@alstomgroup.com", null,
            fleetModel, null, null, null, null, null, null, null, null, null, null, null);

    InstructionAttachmentModel instructionAttachmentModel = new InstructionAttachmentModel(uuid, 0, null, null,
            "Dummy.pdf", true, new Date(), null, "100769630", null, instructionsModel);

    private Path workingDir;

    /**
     * init method for file
     */
    @BeforeEach
    public void init() {
        this.workingDir = Path.of("", "src/test/resources");
    }

    /**
     * @throws java.lang.Exception
     */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");
        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV")).thenReturn(null);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionAttachmentController#uploadAttachment(org.springframework.web.multipart.MultipartFile, java.lang.String)}.
     * 
     * @throws Exception
     */
    @Test
    void testUploadAttachment() throws Exception {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        MockMultipartFile file = new MockMultipartFile("file", "hello.txt", MediaType.TEXT_PLAIN_VALUE,
                "Hello, World!".getBytes());

        String userEmail = "test@alstomgroup.com";
        when(instructionAttachmentService.uploadAttachment(file, userEmail)).thenReturn(instructionAttachmentModel);

        MvcResult result = mockMvc.perform(
                multipart("/instructionAttachment/upload").file(file).param("userEmail", "test@alstomgroup.com"))
                .andDo(print()).andExpect(status().isOk()).andReturn();

        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionAttachmentController#downloadDwiAttachment(java.util.UUID, javax.servlet.http.HttpServletResponse)}.
     * 
     * @throws Exception
     */
    @Test
    void testDownloadDwiAttachment() throws Exception {
        File file;
        Path downloadPath = this.workingDir.resolve("Warning_Sign.png");

        file = new File(downloadPath.toUri());

        byte[] expected_file = readFileToByteArray(file);

        when(instructionAttachmentService.downloadDwiAttachment(uuid)).thenReturn(file);
        when(instructionAttachmentService.readFileToByteArray(file)).thenReturn(expected_file);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/instructionAttachment/005a6076-6001-f39d-6de7-ee13fc92c33b").accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionAttachmentController#deleteInstructionAttachmentById(java.util.UUID)}.
     * 
     * @throws Exception
     */
    @Test
    void testDeleteInstructionAttachmentById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/instructionAttachment/005a6076-6001-f39d-6de7-ee13fc92c33b")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Disabled
    @Test
    public void downloadDwiAttachmentWithException() throws Exception {
        File file;
        Path downloadPath = this.workingDir.resolve("Warning_Sign_not.png");

        file = new File(downloadPath.toUri());

        when(instructionAttachmentService.downloadDwiAttachment(uuid)).thenReturn(file);
        // when(instructionAttachmentService.readFileToByteArray(file)).thenThrow(IOException.class);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/instructionAttachment/005a6076-6001-f39d-6de7-ee13fc92c33b").accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.IMAGE_PNG);

        MvcResult result = mockMvc.perform(request).andReturn();

        System.out.println(result.getResponse().getContentAsString());
        // assertThrows(IOException.class, () -> result.getResponse().getErrorMessage(),
        // "File not found");
        // assertThrows(expectedType, executable);
        /*
         * Throwable thrown = assertThrows(IOException.class, () -> {
         * instructionAttachmentService.readFileToByteArray(file); });
         */

        // Throwable thrown = assertThrows(IOException.class, () ->
        // instructionAttachmentService.readFileToByteArray(file),
        // "File not found");

        // assertThrows(IOException.class, () ->
        // instructionAttachmentService.readFileToByteArray(file), "File not found");
        // assertEquals("File not found", thrown.getMessage());
    }

    /**
     * @param file
     * @return
     */
    private static byte[] readFileToByteArray(File file) {
        FileInputStream fis = null;
        // Creating a byte array using the length of the file
        // file.length returns long which is cast to int
        byte[] bArray = new byte[(int) file.length()];
        try {
            fis = new FileInputStream(file);
            int count = fis.read(bArray);
        } catch (IOException e) {
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.ERROR_LABEL, Constants.ATTACHMENT_READ_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errors);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                }
            }
        }
        return bArray;
    }

}
