/**
 * 
 */
package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.dwiservice.instruction.entity.EditionControlComments;
import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionAttachment;
import com.alstom.applicationfactory.dwiservice.instruction.entity.InstructionWorkFlowDetails;
import com.alstom.applicationfactory.dwiservice.instruction.entity.Instructions;
import com.alstom.applicationfactory.dwiservice.instruction.entity.WINumberPerProject;
import com.alstom.applicationfactory.dwiservice.instruction.entity.WorkFlowActionHistory;
import com.alstom.applicationfactory.dwiservice.instruction.enums.Status;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel;
import com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel;
import com.alstom.applicationfactory.dwiservice.instruction.repository.EditionControlCommentsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionAttachmentRepository;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionWorkFlowDetailsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.repository.InstructionsRepository;
import com.alstom.applicationfactory.dwiservice.instruction.repository.WINumberPerProjectRepository;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionAttachmentService;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.DwiHeader;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Function;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Tag;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplateDesc;
import com.alstom.applicationfactory.dwiservice.masterdata.model.EmailModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.NotificationSettingsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.DwiHeaderRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.UserRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.NotificationSettingsService;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author shalini.jayakumar
 *
 */
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@ExtendWith(MockitoExtension.class)
class InstructionsServiceImplTest {

    @Mock
    private InstructionsRepository instructionsRepository;
    @Mock
    private NotificationSettingsService settingsService;
    @Mock
    private EmailServiceClient emailServiceClient;
    @Mock
    private AdminServiceClient adminServiceClient;
    @Mock
    private UserRepository userRepository;
    @Mock
    private EditionControlCommentsRepository editionCCRepository;
    @Mock
    private WINumberPerProjectRepository wiNumberPerProjectRepository;
    @Mock
    private InstructionAttachmentRepository instructionAttachmentRepository;
    @Mock
    private InstructionWorkFlowDetailsRepository InstructionWFDetailsRepository;
    @Mock
    private DwiHeaderRepository dwiHeaderRepository;
    @Mock
    private InstructionAttachmentService instructionAttachmentService;
    @InjectMocks
    InstructionsServiceImpl instructionService;

    ObjectMapper objMapper = new ObjectMapper();

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");
    User user2 = new User(UUID.fromString("54c22bf5-dd12-9a00-7f1c-933bb85a5b2d"), "100769630", "User B", "LastName",
            "user.b@alstomgroup.com", "IS&T Project CoE");

    Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
            true, new Date(), null, "test", null, null, null);

    Fleet fleet = new Fleet(UUID.fromString("05d559bc-f1ed-7c21-2a39-a4f5d5c2421f"), 0, "Test Fleet", project, true,
            new Date(), new Date(), null, null);

    Process process = new Process(UUID.fromString("064841a5-98d7-9b1c-2da8-abdb4a5aff24"), 0, "Test Process", true,
            new Date(), null, "user.ar@alstomgroup.com", null, fleet);

    Revision revision = new Revision(UUID.fromString("04a62e8f-a6b7-d69b-0238-55d4c7e594fa"), 0, "Test Revision", true,
            new Date(), null, "test", null, process);

    Function function = new Function(UUID.fromString("21ebfe8f-dbc6-2271-db80-3c0534288771"), 1, "Test Function 1",
            true, new Date(), null, "system", null);

    Instructions instructions1 = new Instructions(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), 0,
            "APPROVED", "NEW", new Date(), new Date(), new Date(), null, "OTT-LRV-MTN50-WMS-004", 1, "OperatingáUWL",
            "OTT-LRV-MTN50-WMS-004", project, null, process, revision, null, user, user, user, "Approved", false, false,
            "pdf import", null, new Date(), null, "user.ar@alstomgroup.com", null, fleet, null, null, null, null, null,
            null, null, null, null, null, null);

    Instructions instructions = new Instructions(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), 0,
            "SUBMITTED", "NEW", new Date(), new Date(), new Date(), null, "OTT-LRV-MTN50-WMS-004", 1, "OperatingáUWL",
            "OTT-LRV-MTN50-WMS-004", project, null, process, revision, null, user, user, user, "Approved", false, false,
            "pdf import", null, new Date(), null, "user.ar@alstomgroup.com", null, fleet, null, null, null, null, null,
            null, null, null, null, null, null);

    Instructions instructions2 = new Instructions(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb93"), 0,
            "APPROVED", "NEW_VERSION", new Date(), new Date(), new Date(), null, "OTT-LRV-MTN50-WMS-004", 2,
            "OperatingáUWL", "OTT-LRV-MTN50-WMS-005", project, null, process, revision, null, user, user, user,
            "Approved", false, false, "pdf import Test", null, new Date(), null, "user.ar@alstomgroup.com", null, fleet,
            null, null, null, null, null, null, null, null, null, null, null);

    Instructions instructionsDraft = new Instructions(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), 0,
            "DRAFT", "NEW", new Date(), new Date(), new Date(), null, "DWI-Test Project-1", 1, "OperatingáUWL",
            "OTT-LRV-MTN50-WMS-004", project, null, process, revision, null, user, user, user, "Approved", false, false,
            "pdf import", null, new Date(), null, "user.ar@alstomgroup.com", null, fleet, null, null, null, null, null,
            null, null, null, null, null, null);

    Instructions createInstruction = new Instructions(null, 0, "DRAFT", "NEW", new Date(), new Date(), new Date(), null,
            null, 1, "OperatingáUWL", "OTT-LRV-MTN50-WMS-004", project, null, process, revision, null, user, user, user,
            "Approved", false, false, "pdf import", null, new Date(), null, "user.ar@alstomgroup.com", null, fleet,
            null, null, null, null, null, null, null, null, null, null, null);

    InstructionWorkFlowDetails wfdetail1 = new InstructionWorkFlowDetails(
            UUID.fromString("1be35875-c83a-446f-9611-971aea753740"), 0, "DESIGN", function, "Designer", user, null,
            null, null, instructions, 0);
    InstructionWorkFlowDetails wfdetail2 = new InstructionWorkFlowDetails(
            UUID.fromString("199788db-81f7-4e12-a82b-f7a7c69fbc80"), 0, "VALIDATE", function, "Validator", user, null,
            null, null, instructions, 1);
    InstructionWorkFlowDetails wfdetail3 = new InstructionWorkFlowDetails(
            UUID.fromString("d8eb8b1d-42b7-49d5-a281-56676cf0c333"), 0, "APPROVED", function, "Approver", user, null,
            null, null, instructions, 2);
    InstructionWorkFlowDetails wfdetail4 = new InstructionWorkFlowDetails(
            UUID.fromString("d8eb8b1d-42b7-49d5-a281-56676cf0c330"), 0, "VALIDATE", function, "Validator", user, null,
            "VALIDATED", null, instructions, 3);
    InstructionWorkFlowDetails wfdetail5 = new InstructionWorkFlowDetails(
            UUID.fromString("d8eb8b1d-42b7-49d5-a281-56676cf0c330"), 0, "VALIDATE", function, "Validator", user2, null,
            null, null, instructions, 3);
    InstructionWorkFlowDetails wfdetail6 = new InstructionWorkFlowDetails(
            UUID.fromString("d8eb8b1d-42b7-49d5-a281-56676cf0c333"), 0, "APPROVED", function, "Approver", user, null,
            "APPROVED", null, instructions, 2);
    InstructionWorkFlowDetails wfdetail7 = new InstructionWorkFlowDetails(
            UUID.fromString("d8eb8b1d-42b7-49d5-a281-56676cf0c333"), 0, "APPROVED", function, "Approver", user2, null,
            null, null, instructions, 2);

    WorkFlowActionHistory wfhistory1 = new WorkFlowActionHistory(
            UUID.fromString("3c6f533c-be7f-48ac-9a43-31956b77f3a7"), 0, new Date(), "IS&T Project CoE", user, "User A",
            "Created", null, instructions, null, null);

    DwiHeader dwiHeader1 = new DwiHeader(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"), 0,
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>", project);

    EditionControlComments ecc = new EditionControlComments(UUID.fromString("5e645231-7b33-73ad-0ca0-8b5e49aac5b2"), 0,
            instructions, "OTT-LRV-MTN50-WMS-004", 1, user, new Date(), "Test");

    List<String> recipients = Arrays.asList("CREATOR", "APPROVER", "VALIDATOR", "AUTHOR");
    EmailModel email = new EmailModel(recipients, "{$dwinstructions.dwiNumber}",
            "{$dwinstructions.dwiNumber}.{$dwinstructions.dwiEdition} , {$dwinstructions.dwiProject}, {$dwinstructions.dwiProcess}"
                    + "{$dwinstructions.dwiRevision}, {$dwinstructions.dwiTitle}, {$dwinstructions.dwiAuthor}, {$dwinstructions.approverValidatorComments} ");

    InstructionAttachment insAttach = new InstructionAttachment(UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b"),
            0, "testdwiFormId", "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test",
            instructions);

    @BeforeEach
    public void init() {
        ReflectionTestUtils.setField(instructionService, "wiSubmitted", "INSTRUCTION_SUBMITTED");
        ReflectionTestUtils.setField(instructionService, "wiValidated", "INSTRUCTION_VALIDATED");
        ReflectionTestUtils.setField(instructionService, "wiApproved", "INSTRUCTION_APPROVED");
        ReflectionTestUtils.setField(instructionService, "wiRejected", "INSTRUCTION_REJECTED");
        ReflectionTestUtils.setField(instructionService, "wiAddComments", "INSTRUCTION_ADDCOMMENTS");
        ReflectionTestUtils.setField(instructionService, "wiAutoreminderValidation",
                "INSTRUCTION_VALIDATION_AUTOREMINDER");
        ReflectionTestUtils.setField(instructionService, "wiAutoreminderValidation",
                "INSTRUCTION_APPROVAL_AUTOREMINDER");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#searchInstructions(com.alstom.applicationfactory.dwiservice.common.model.RequestModel)}.
     */

    @Test
    void testSearchInstructions() {
        List<Instructions> instructionList = new ArrayList<>();
        instructionList.add(instructions);
        instructionList.add(instructions2);

        Object obj = instructionList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":false,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);
        when(instructionsRepository.findAll(requestModel.getFilterSpecification())).thenReturn(instructionList);
        Object obj1 = instructionService.searchInstructions(requestModel);
        int len = obj1.toString().length();
        assertThat((instructionList.size() == '2'));
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#saveasDraftInstruction(com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testSaveasDraftInstructionForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        InstructionsModel insModel = mapper.map(instructionsDraft, InstructionsModel.class);
        String email = "user.ar@alstomgroup.com";
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.saveasDraftInstruction(insModel, "Test Comments", "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#saveasDraftInstruction(com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testSaveasDraftInstructionForFirstSave() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplate createdwfTemplate = new WorkFlowTemplate(
                UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, project, new Date(), null,
                "test", null, null);
        WorkFlowTemplateDesc action1 = new WorkFlowTemplateDesc(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"),
                0, "APPROVED", function, "Roberto Test", user, null, createdwfTemplate, 1);

        WorkFlowTemplateDesc action2 = new WorkFlowTemplateDesc(UUID.fromString("3a2a3008-3a9a-1a96-2e0e-24eb62532c90"),
                0, "VALIDATE", function, "test-action", user, null, createdwfTemplate, 1);
        List<WorkFlowTemplateDesc> actions = new ArrayList<>();
        actions.add(action1);
        actions.add(action2);
        createdwfTemplate.setActions(actions);
        createInstruction.setWorkFlowTemplate(createdwfTemplate);
        List<Tag> taglist = new ArrayList<>();
        List<InstructionAttachment> attachlist = new ArrayList<>();
        UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");
        Tag createdtag = new Tag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
        InstructionAttachment createdInstructionAttach = new InstructionAttachment(uuid, 0, "testdwiFormId",
                "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test", instructions);
        taglist.add(createdtag);
        attachlist.add(createdInstructionAttach);
        createInstruction.setInstructiontagsList(taglist);
        createInstruction.setInstructionAttachmentList(attachlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        createInstruction.setWorkFlowActionHistoryList(wfhistoryList);
        String email = "user.ar@alstomgroup.com";
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        createInstruction.setHistory(newHistory);
        InstructionsModel insModel = mapper.map(createInstruction, InstructionsModel.class);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructionsDraft);
        InstructionsModel savedInstructionModel = instructionService.saveasDraftInstruction(insModel, "Test Comments",
                "user.ar@alstomgroup.com");
        assertThat(instructionsDraft.getDwiStatus()).isEqualTo("DRAFT");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#saveasDraftInstruction(com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testSaveasDraftInstructionForFirstSave1() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplate createdwfTemplate = new WorkFlowTemplate(
                UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, project, new Date(), null,
                "test", null, null);
        WorkFlowTemplateDesc action1 = new WorkFlowTemplateDesc(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"),
                0, "APPROVED", function, "Roberto Test", user, null, createdwfTemplate, 1);

        WorkFlowTemplateDesc action2 = new WorkFlowTemplateDesc(UUID.fromString("3a2a3008-3a9a-1a96-2e0e-24eb62532c90"),
                0, "VALIDATE", function, "test-action", user, null, createdwfTemplate, 1);
        List<WorkFlowTemplateDesc> actions = new ArrayList<>();
        actions.add(action1);
        actions.add(action2);
        createdwfTemplate.setActions(actions);
        createInstruction.setWorkFlowTemplate(createdwfTemplate);
        List<Tag> taglist = new ArrayList<>();
        List<InstructionAttachment> attachlist = new ArrayList<>();
        UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");
        Tag createdtag = new Tag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
        InstructionAttachment createdInstructionAttach = new InstructionAttachment(uuid, 0, "testdwiFormId",
                "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test", instructions);
        WINumberPerProject wientry = new WINumberPerProject(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e5"), 0,
                "1", project);
        taglist.add(createdtag);
        attachlist.add(createdInstructionAttach);
        createInstruction.setInstructiontagsList(taglist);
        createInstruction.setInstructionAttachmentList(attachlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        createInstruction.setWorkFlowActionHistoryList(wfhistoryList);
        InstructionsModel insModel = mapper.map(createInstruction, InstructionsModel.class);
        String email = "user.ar@alstomgroup.com";
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        createInstruction.setHistory(newHistory);
        insModel.setHistory(newHistory);

        when(wiNumberPerProjectRepository.findByProjectId(project.getId())).thenReturn(wientry);
        int incrementedNumber = Integer.valueOf(wientry.getGeneratedNumber()) + 1;
        String incrementNumber = String.valueOf(incrementedNumber);
        wientry.setGeneratedNumber(incrementNumber);
        wientry.setVersion(Integer.valueOf(incrementNumber));
        wientry.setProject(project);

        when(wiNumberPerProjectRepository.save(wientry)).thenReturn(wientry);
        insModel = mapper.map(createInstruction, InstructionsModel.class);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructionsDraft);
        InstructionsModel savedInstructionModel = instructionService.saveasDraftInstruction(insModel, "Test Comments",
                "user.ar@alstomgroup.com");
        assertThat(instructionsDraft.getDwiNumber()).isEqualTo("DWI-Test Project-1");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#saveasDraftInstruction(com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testSaveasDraftInstructionForSave() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        WorkFlowTemplate createdwfTemplate = new WorkFlowTemplate(
                UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1", true, project, new Date(), null,
                "test", null, null);
        WorkFlowTemplateDesc action1 = new WorkFlowTemplateDesc(UUID.fromString("03711a0a-c42f-8c28-82e8-cd0d7ce0003c"),
                0, "APPROVED", function, "Roberto Test", user, null, createdwfTemplate, 1);

        WorkFlowTemplateDesc action2 = new WorkFlowTemplateDesc(UUID.fromString("3a2a3008-3a9a-1a96-2e0e-24eb62532c90"),
                0, "VALIDATE", function, "test-action", user, null, createdwfTemplate, 1);
        List<WorkFlowTemplateDesc> actions = new ArrayList<>();
        actions.add(action1);
        actions.add(action2);
        createdwfTemplate.setActions(actions);
        instructionsDraft.setWorkFlowTemplate(createdwfTemplate);
        List<Tag> taglist = new ArrayList<>();
        List<InstructionAttachment> attachlist = new ArrayList<>();
        UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");
        Tag createdtag = new Tag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
        InstructionAttachment createdInstructionAttach = new InstructionAttachment(uuid, 0, "testdwiFormId",
                "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test", instructions);
        taglist.add(createdtag);
        attachlist.add(createdInstructionAttach);
        instructionsDraft.setInstructiontagsList(taglist);
        instructionsDraft.setInstructionAttachmentList(attachlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructionsDraft.setWorkFlowActionHistoryList(wfhistoryList);
        String email = "user.ar@alstomgroup.com";
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructionsDraft.setHistory(newHistory);
        List<EditionControlComments> editionCCList = new ArrayList<>();
        editionCCList.add(ecc);
        when(editionCCRepository.findByInstructionsId(instructions.getId())).thenReturn(editionCCList);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        InstructionsModel insModel = mapper.map(instructionsDraft, InstructionsModel.class);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructionsDraft);
        InstructionsModel savedInstructionModel = instructionService.saveasDraftInstruction(insModel, "Test Comments",
                "user.ar@alstomgroup.com");
        assertThat(instructionsDraft.getDwiStatus()).isEqualTo("DRAFT");
        assertThat(instructionsDraft.getDwiNumber()).isEqualTo("DWI-Test Project-1");

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#submitInstruction(com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testSubmitInstructionForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        InstructionsModel insModel = mapper.map(instructionsDraft, InstructionsModel.class);
        String email = "user.ar@alstomgroup.com";
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.submitInstruction(insModel, "Test Comments", "user.ar@alstomgroup.com"), "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#submitInstruction(com.alstom.applicationfactory.dwiservice.instruction.model.InstructionsModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testSubmitInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        InstructionsModel insModel = new InstructionsModel();
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        instructionsDraft.setWorkFlowDetailsList(wfDetailsList);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructionsDraft.setWorkFlowActionHistoryList(wfhistoryList);
        List<EditionControlComments> editionCCList = new ArrayList<>();
        editionCCList.add(ecc);
        when(editionCCRepository.findByInstructionsId(instructions.getId())).thenReturn(editionCCList);
        instructionsDraft.setEditionControlComments(ecc);
        insModel = mapper.map(instructionsDraft, InstructionsModel.class);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructionsDraft.setHistory(newHistory);
        insModel.setHistory(newHistory);
        insModel = mapper.map(instructionsDraft, InstructionsModel.class);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        // when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        instructionService.submitInstruction(insModel, "Test Comments", "user.ar@alstomgroup.com");
        assertThat(instructions.getDwiStatus()).isEqualTo("SUBMITTED");

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#viewInstruction(java.util.UUID)}.
     */

    @Test
    void testViewInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        InstructionsModel insModel = mapper.map(instructions, InstructionsModel.class);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        assertThat(instructionService.viewInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .isEqualTo(insModel);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#viewInstruction(java.util.UUID)}.
     */

    @Test
    void testViewInstructionForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.viewInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")), "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#deleteInstructionById(java.util.UUID)}.
     */

    @Test
    void testDeleteInstructionById() {
        instructionService.deleteInstructionById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"));
        verify(instructionsRepository).deleteById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"));
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#deleteInstructionById(java.util.UUID)}.
     */

    @Test
    void testDeleteInstructionByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(instructionsRepository)
                .deleteById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"));
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.deleteInstructionById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstruction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionForNullInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.validateInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        "Test Comments", "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstruction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        String email = "user.ar@alstomgroup.com";
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.validateInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        "Test Comments", "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstruction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionForNotNullInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        // when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        InstructionsModel instructionmodel = instructionService.validateInstruction(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "user.ar@alstomgroup.com");
        assertThat(instructionmodel.getDwiStatus()).isEqualTo("VALIDATED");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstruction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstructionForNullInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.approveInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        "Test Comments", "http://test", "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstruction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstructionForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        String email = "user.ar@alstomgroup.com";
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.approveInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        "Test Comments", "http://test", "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstruction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail4);
        wfDetailsList.add(wfdetail3);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        List<DwiHeader> dwiHeaderList = new ArrayList<>();
        dwiHeaderList.add(dwiHeader1);
        when(dwiHeaderRepository.findByProjectId(project.getId())).thenReturn(dwiHeaderList);
        instructions.setEditionControlComments(ecc);
        instructions.setDwiLongDescComputed(null);
        when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        InstructionsModel instructionmodel = instructionService.approveInstruction(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "http://test",
                "user.ar@alstomgroup.com");
        assertThat(instructionmodel.getDwiStatus()).isEqualTo("APPROVED");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#archiveInstruction(java.util.UUID)}.
     */

    @Test
    void testArchiveInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb93")))
                .thenReturn(Optional.of(instructions2));
        when(instructionsRepository.findByDwiNumberAndDwiEdition(instructions2.getDwiNumber(), 1))
                .thenReturn(instructions);
        instructions.setDwiStatus(Status.ARCHIVED.toString());
        instructions.setApprovedActiveEdition(false);
        when(instructionsRepository.save(instructions)).thenReturn(instructions);
        instructionService.archiveInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb93"));
        assertEquals(instructions.getDwiStatus(), Status.ARCHIVED.toString());

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#rejectInstruction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testRejectInstructionForNullInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.rejectInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        "Test Comments", "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#rejectInstruction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testRejectInstructionForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        String email = "user.ar@alstomgroup.com";
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.rejectInstruction(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        "Test Comments", "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#rejectInstruction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testRejectInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        InstructionsModel instructionmodel = instructionService.rejectInstruction(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "user.ar@alstomgroup.com");
        assertThat(instructionmodel.getDwiStatus()).isEqualTo("REJECTED");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#instructionAutoReminder()}.
     */

    @Test
    void testInstructionAutoReminder() {
        NotificationSettingsModel createdSettingsModel = new NotificationSettingsModel(
                UUID.fromString("03f9480a-496d-199c-7e4f-265112fdfe88"), 2, 2);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        instructions2.setWorkFlowDetailsList(wfDetailsList);
        List<Instructions> instructionList = new ArrayList<>();
        instructionList.add(instructions);
        instructionList.add(instructions2);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        when(settingsService.getSettings()).thenReturn(createdSettingsModel);
        when(instructionsRepository.findAll(Mockito.any(FilterSpecification.class))).thenReturn(instructionList);
        when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        instructionService.instructionAutoReminder();

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#instructionAutoReminder()}.
     */

    @Test
    void testInstructionAutoReminderForNullRecipients() {
        NotificationSettingsModel createdSettingsModel = new NotificationSettingsModel(
                UUID.fromString("03f9480a-496d-199c-7e4f-265112fdfe88"), 2, 2);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        instructions.setAuthor(null);
        instructions.setFirstValidator(null);
        instructions.setApprover(null);
        List<Instructions> instructionList = new ArrayList<>();
        instructionList.add(instructions);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        when(settingsService.getSettings()).thenReturn(createdSettingsModel);
        when(instructionsRepository.findAll(Mockito.any(FilterSpecification.class))).thenReturn(instructionList);
        // when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        instructionService.instructionAutoReminder();

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#createNewVersion(java.util.UUID, java.lang.String)}.
     */

    @Test
    void testCreateNewVersion() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<Tag> taglist = new ArrayList<>();
        List<InstructionAttachment> attachlist = new ArrayList<>();
        UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");
        Tag createdtag = new Tag(UUID.fromString("0040bee5-d3c9-9d09-b3c3-78f4965139e0"), 0, "cleaning");
        InstructionAttachment createdInstructionAttach = new InstructionAttachment(uuid, 0, "testdwiFormId",
                "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test", instructions);
        taglist.add(createdtag);
        attachlist.add(createdInstructionAttach);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        instructions.setInstructiontagsList(taglist);
        instructions.setInstructionAttachmentList(attachlist);
        instructions.setEditionControlComments(ecc);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        instructions.setNewEditionCreated(true);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();

        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        InstructionsModel instructionmodel = instructionService
                .createNewVersion(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "user.ar@alstomgroup.com");
        assertThat(instructionmodel.getDwiSubStatus()).isEqualTo("NEW");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#createNewVersion(java.util.UUID, java.lang.String)}.
     */

    @Test
    void testCreateNewVersionForNullInstruction() {
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        assertThrows(ApplicationFactoryException.class, () -> instructionService
                .createNewVersion(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#createNewVersion(java.util.UUID, java.lang.String)}.
     */

    @Test
    void testCreateNewVersionForNullUser() {
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class, () -> instructionService
                .createNewVersion(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#copyAttachment(java.util.UUID)}.
     */

    @Test
    void testCopyAttachmentForNullInstruction() {
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.copyAttachment(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")), "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#copyAttachment(java.util.UUID)}.
     */

    @Test
    void testCopyAttachment() {

        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb93")))
                .thenReturn(Optional.of(instructions2));

        when(instructionsRepository.findByDwiNumberAndDwiEdition(instructions2.getDwiNumber(),
                (instructions2.getDwiEdition() - 1))).thenReturn(instructions);
        instructionAttachmentService.copyInstructionAttachmentById(instructions.getId(), instructions2.getId());
        instructionService.copyAttachment(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb93"));
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#addComments(java.util.UUID, com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testAddComments() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");
        String comments = "Test Comments";
        InstructionsModel insModel = mapper.map(instructions, InstructionsModel.class);
        InstructionAttachmentModel createdInstructionAttachmentModel = new InstructionAttachmentModel(uuid, 0,
                "testdwiFormId", "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test",
                insModel);
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        InstructionsModel instructionmodel = instructionService.addComments(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), createdInstructionAttachmentModel, comments,
                "user.ar@alstomgroup.com");
        assertThat(instructionmodel.getApproverValidatorComments()).isEqualTo(comments);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#addComments(java.util.UUID, com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testAddCommentsForNullInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");
        InstructionsModel insModel = mapper.map(instructions, InstructionsModel.class);
        InstructionAttachmentModel createdInstructionAttachmentModel = new InstructionAttachmentModel(uuid, 0,
                "testdwiFormId", "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test",
                insModel);

        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.addComments(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        createdInstructionAttachmentModel, "Test Comments", "user.ar@alstomgroup.com"),
                "");

    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#addComments(java.util.UUID, com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel, java.lang.String, java.lang.String)}.
     */

    @Test
    void testAddCommentsForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UUID uuid = UUID.fromString("005a6076-6001-f39d-6de7-ee13fc92c33b");
        InstructionsModel insModel = mapper.map(instructions, InstructionsModel.class);
        InstructionAttachmentModel createdInstructionAttachmentModel = new InstructionAttachmentModel(uuid, 0,
                "testdwiFormId", "testattachmentText", "Dummy.pdf", true, new Date(), new Date(), "100769630", "test",
                insModel);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.addComments(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        createdInstructionAttachmentModel, "Test Comments", "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#viewPreviousVersion(java.util.UUID, java.lang.String)}.
     */

    @Test
    void testViewPreviousVersionForNullInstruction() {
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.viewPreviousVersion(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#viewPreviousVersion(java.util.UUID, java.lang.String)}.
     */

    @Test
    void testViewPreviousVersionForNullUser() {
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenThrow(NullPointerException.class);

        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.viewPreviousVersion(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#viewPreviousVersion(java.util.UUID, java.lang.String)}.
     */

    @Test
    void testViewPreviousVersion() {
        Assertions.assertTrue(true);
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb93")))
                .thenReturn(Optional.of(instructions2));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        when(instructionsRepository.findByDwiNumberAndDwiEdition(instructions2.getDwiNumber(), 1))
                .thenReturn(instructions);
        InstructionsModel insModel = instructionService.viewPreviousVersion(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb93"), "user.ar@alstomgroup.com");

        assertEquals(insModel.getDwiNumber(), instructions2.getDwiNumber());
        assertEquals(insModel.getDwiEdition(), (instructions2.getDwiEdition() - 1));
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstructionByAction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionByActionForNullInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.validateInstructionByAction(
                        UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments",
                        "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstructionByAction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionByActionForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        String email = "user.ar@alstomgroup.com";
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.validateInstructionByAction(
                        UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments",
                        "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstructionByAction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionByActionForUserValidatedInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        wfDetailsList.add(wfdetail4);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.validateInstructionByAction(
                        UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments",
                        "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstructionByAction(java.util.UUID, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionByActionForUserUnauthorizedInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user2);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        wfDetailsList.add(wfdetail4);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.b@alstomgroup.com")).thenReturn(userlist);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.validateInstructionByAction(
                        UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments",
                        "user.b@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstructionByAction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionByActionForOneValidatorInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user2);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail2);
        wfDetailsList.add(wfdetail3);
        wfDetailsList.add(wfdetail5);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.b@alstomgroup.com")).thenReturn(userlist);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        // when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        InstructionsModel instructionmodel = instructionService.validateInstructionByAction(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "user.b@alstomgroup.com");
        assertThat(instructionmodel.getDwiStatus()).isEqualTo("SUBMITTED");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#validateInstructionByAction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testValidateInstructionByAction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user2);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail3);
        wfDetailsList.add(wfdetail4);
        wfDetailsList.add(wfdetail5);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.b@alstomgroup.com")).thenReturn(userlist);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        InstructionsModel instructionmodel = instructionService.validateInstructionByAction(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "user.b@alstomgroup.com");
        assertThat(instructionmodel.getDwiStatus()).isEqualTo("VALIDATED");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstructionByAction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstructionByActionForNullInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.approveInstructionByAction(
                        UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "http://test",
                        "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstructionByAction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstructionByActionForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        String email = "user.ar@alstomgroup.com";
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.approveInstructionByAction(
                        UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "http://test",
                        "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstructionByAction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstructionByActionForUserApprovedInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail4);
        wfDetailsList.add(wfdetail6);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.approveInstructionByAction(
                        UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "http://test",
                        "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstructionByAction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstructionByActionForUserUnauthorizedInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user2);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail4);
        wfDetailsList.add(wfdetail6);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.b@alstomgroup.com")).thenReturn(userlist);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.approveInstructionByAction(
                        UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "http://test",
                        "user.b@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstructionByAction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstructionByActionForOneApproverInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail4);
        wfDetailsList.add(wfdetail3);
        wfDetailsList.add(wfdetail7);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        // when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        InstructionsModel instructionmodel = instructionService.approveInstructionByAction(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "http://test",
                "user.ar@alstomgroup.com");
        assertThat(instructionmodel.getDwiStatus()).isEqualTo("VALIDATED");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#approveInstructionByAction(java.util.UUID, java.lang.String, java.lang.String, java.lang.String)}.
     */

    @Test
    void testApproveInstructionByAction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        List<InstructionWorkFlowDetails> wfDetailsList = new ArrayList<>();
        wfDetailsList.add(wfdetail1);
        wfDetailsList.add(wfdetail4);
        wfDetailsList.add(wfdetail3);
        instructions.setWorkFlowDetailsList(wfDetailsList);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        String history = "Object Created.";
        byte[] newHistory = history.getBytes();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.writeBytes(newHistory);
        newHistory = os.toByteArray();
        instructions.setHistory(newHistory);
        when(adminServiceClient.getEmail(Mockito.anyString())).thenReturn(email);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        InstructionsModel instructionmodel = instructionService.approveInstructionByAction(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), "Test Comments", "http://test",
                "user.ar@alstomgroup.com");
        assertThat(instructionmodel.getDwiStatus()).isEqualTo("APPROVED");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#addAttachment(java.util.UUID, com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel, java.lang.String)}.
     */

    @Test
    void testAddAttachmentForNullUser() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        InstructionAttachmentModel insAttachModel = mapper.map(insAttach, InstructionAttachmentModel.class);
        String email = "user.ar@alstomgroup.com";
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        when(userRepository.findByEmail(email)).thenThrow(NullPointerException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.addAttachment(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        insAttachModel, "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#addAttachment(java.util.UUID, com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel, java.lang.String)}.
     */

    @Test
    void testAddAttachment() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        InstructionAttachmentModel insAttachModel = mapper.map(insAttach, InstructionAttachmentModel.class);
        when(instructionsRepository.findById(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83")))
                .thenReturn(Optional.of(instructions));
        List<User> userlist = new ArrayList<>();
        userlist.add(user);
        when(userRepository.findByEmail("user.ar@alstomgroup.com")).thenReturn(userlist);
        List<WorkFlowActionHistory> wfhistoryList = new ArrayList<>();
        wfhistoryList.add(wfhistory1);
        instructions.setWorkFlowActionHistoryList(wfhistoryList);
        when(instructionsRepository.save(Mockito.any(Instructions.class))).thenReturn(instructions);
        InstructionsModel instructionmodel = instructionService.addAttachment(
                UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"), insAttachModel, "user.ar@alstomgroup.com");
        assertNotNull(instructionmodel.getInstructionAttachmentList());
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#addAttachment(java.util.UUID, com.alstom.applicationfactory.dwiservice.instruction.model.InstructionAttachmentModel, java.lang.String)}.
     */

    @Test
    void testAddAttachmentForNullInstruction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        InstructionAttachmentModel insAttachModel = mapper.map(insAttach, InstructionAttachmentModel.class);
        assertThrows(ApplicationFactoryException.class,
                () -> instructionService.addAttachment(UUID.fromString("dd16e8dc-842d-7440-fed3-dd671833bb83"),
                        insAttachModel, "user.ar@alstomgroup.com"),
                "");
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.service.impl.InstructionsServiceImpl#searchUserInstructions(com.alstom.applicationfactory.dwiservice.common.model.RequestModel)}.
     */

    @Test
    void testSearchUserInstructions() {
        List<Instructions> instructionList = new ArrayList<>();
        instructionList.add(instructions);
        instructionList.add(instructions2);

        Object obj = instructionList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":false,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);
        when(instructionsRepository.findAll(requestModel.getFilterSpecification())).thenReturn(instructionList);
        Object obj1 = instructionService.searchUserInstructions(requestModel);
        int len = obj1.toString().length();
        assertThat((instructionList.size() == '2'));
    }

}
