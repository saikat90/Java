package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.NotificationSettings;
import com.alstom.applicationfactory.dwiservice.masterdata.model.NotificationSettingsModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.NotificationSettingsRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class NotificationSettingsServiceImplTest {

    @InjectMocks
    NotificationSettingsServiceImpl notificationService;
    @Mock
    private NotificationSettingsRepository settingsRepository;

    ObjectMapper objMapper = new ObjectMapper();

    NotificationSettingsModel settingsModel = new NotificationSettingsModel(null, 2, 2);
    NotificationSettingsModel createdSettingsModel = new NotificationSettingsModel(
            UUID.fromString("03f9480a-496d-199c-7e4f-265112fdfe88"), 2, 2);
    NotificationSettingsModel updatedSettingsModel = new NotificationSettingsModel(
            UUID.fromString("03f9480a-496d-199c-7e4f-265112fdfe88"), 2, 4);

    /**
     * testUpdateSettings
     */
    @Test
    void testUpdateSettings() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        NotificationSettings updateNotificationSettings = mapper.map(updatedSettingsModel, NotificationSettings.class);
        NotificationSettings createNotificationSettings = mapper.map(createdSettingsModel, NotificationSettings.class);
        when(settingsRepository.count()).thenReturn((long) 1);
        when(settingsRepository.findById(createdSettingsModel.getId()))
                .thenReturn(Optional.of(createNotificationSettings));
        when(settingsRepository.save(updateNotificationSettings)).thenReturn(updateNotificationSettings);
        assertThat(notificationService.updateSettings(updatedSettingsModel)).isEqualTo(updatedSettingsModel);
    }

    @Test
    void testUpdateSettingsForElseIfCondition() {
        assertThrows(ApplicationFactoryException.class, () -> notificationService.updateSettings(updatedSettingsModel),
                "");
    }

    @Test
    void testUpdateSettingsForElseCondition() {
        when(settingsRepository.count()).thenReturn((long) 1);
        assertThrows(ApplicationFactoryException.class, () -> notificationService.updateSettings(updatedSettingsModel),
                "");
    }

    @Test
    void testSaveSettings() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        NotificationSettings notificationSettings = mapper.map(settingsModel, NotificationSettings.class);
        NotificationSettings createNotificationSettings = mapper.map(createdSettingsModel, NotificationSettings.class);
        when(settingsRepository.count()).thenReturn((long) 0);
        when(settingsRepository.save(notificationSettings)).thenReturn(createNotificationSettings);
        assertThat(notificationService.saveSettings(settingsModel)).isEqualTo(createdSettingsModel);
    }

    @Test
    void testSaveSettingsForElseCondition() {
        when(settingsRepository.count()).thenReturn((long) 1);
        assertThrows(ApplicationFactoryException.class, () -> notificationService.saveSettings(settingsModel), "");
    }

    @Test
    void testGetSettings() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        NotificationSettings createNotificationSettings = mapper.map(createdSettingsModel, NotificationSettings.class);
        when(settingsRepository.count()).thenReturn((long) 1);
        List<NotificationSettings> notificationlist = new ArrayList<>();
        notificationlist.add(createNotificationSettings);
        when(settingsRepository.findAll()).thenReturn(notificationlist);
        assertThat(notificationService.getSettings()).isEqualTo(createdSettingsModel);
    }

    @Test
    void testGetSettingsForElseCondition() {
        when(settingsRepository.count()).thenReturn((long) 2);
        assertThrows(ApplicationFactoryException.class, () -> notificationService.getSettings(), "");
    }

}
