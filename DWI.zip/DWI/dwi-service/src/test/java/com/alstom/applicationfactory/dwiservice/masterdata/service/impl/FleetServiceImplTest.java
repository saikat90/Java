package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.FleetRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class FleetServiceImplTest {

    @Mock
    private FleetRepository fleetRepository;

    @Mock
    private ProjectRepository projectRepository;

    @InjectMocks
    FleetServiceImpl fleetServiceImpl;

    ObjectMapper objMapper = new ObjectMapper();

    UUID uuid = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");

    /**
     * testSaveFleet
     */
    @Test
    void testSaveFleet() {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
                "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel projectModel = new ProjectModel(UUID.fromString("ba454e26-8528-48db-9a6c-1a3384979793"), 0,
                "Test Project", userObject1, true, new Date(), null, "test", null, null, null);

        FleetModel fleetModel = new FleetModel(null, 0, "Test Fleet", projectModel, true, new Date(), new Date(), null,
                null);

        Fleet fleet = mapper.map(fleetModel, Fleet.class);

        Project project = mapper.map(projectModel, Project.class);

        Fleet createdFleet = new Fleet(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Fleet",
                project, true, new Date(), new Date(), null, null);

        FleetModel expectedFleetModel = new FleetModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
                "Test Fleet", projectModel, true, new Date(), new Date(), null, null);

        when(projectRepository.findById(fleet.getProject().getId())).thenReturn(Optional.of(project));

        fleet.setProject(project);

        when(fleetRepository.save(fleet)).thenReturn(createdFleet);

        assertThat(fleetServiceImpl.saveFleet(fleetModel).getId()).isEqualTo(expectedFleetModel.getId());

    }

    @Test
    void testSaveFleetForNullProject() {
        FleetModel fleetModel = new FleetModel(null, 0, "Test Fleet", null, true, new Date(), new Date(), null, null);
        assertThrows(ApplicationFactoryException.class, () -> fleetServiceImpl.saveFleet(fleetModel), "");
    }

    @Test
    void testSaveFleetForRecordAlreadyExists() {
        List<Fleet> fleetList = new ArrayList<>();
        UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
                "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel projectModel = new ProjectModel(UUID.fromString("ba454e26-8528-48db-9a6c-1a3384979793"), 0,
                "Test Project", userObject1, true, new Date(), null, "test", null, null, null);
        FleetModel fleetModel = new FleetModel(null, 0, "Test Fleet", projectModel, true, new Date(), new Date(), null,
                null);
        when(fleetRepository.findAll(Mockito.any(FilterSpecification.class))).thenReturn(fleetList);
        assertThrows(ApplicationFactoryException.class, () -> fleetServiceImpl.saveFleet(fleetModel), "");
    }

    @Test
    void testUpdateFleetForNullProject() {
        FleetModel updatedFleetModel = new FleetModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
                "Test Fleet1", null, true, new Date(), new Date(), null, null);
        assertThrows(ApplicationFactoryException.class, () -> fleetServiceImpl.updateFleet(updatedFleetModel), "");
    }

    @Test
    void testUpdateFleet() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
                "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea81"), 0,
                "Test Project", userObject1, true, new Date(), null, "test", null, null, null);

        FleetModel createdFleetModel = new FleetModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
                "Test Fleet", projectModel, true, new Date(), new Date(), null, null);

        FleetModel updatedFleetModel = new FleetModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
                "Test Fleet1", projectModel, true, new Date(), new Date(), null, null);

        Fleet updatedNewFleet = mapper.map(updatedFleetModel, Fleet.class);
        FleetModel updatedNewFleetModel = mapper.map(updatedNewFleet, FleetModel.class);
        when(fleetRepository.save(updatedNewFleet)).thenReturn(updatedNewFleet);
        assertThat(fleetServiceImpl.updateFleet(updatedFleetModel)).isEqualTo(updatedNewFleetModel);
    }

    /**
     * testSearchFleet
     */
    @Test
    void testSearchFleet() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
                "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea81"), 0, "Test Project", user,
                true, new Date(), null, "test", null, null, null);

        Fleet fleet = new Fleet(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Fleet", project, true,
                new Date(), new Date(), null, null);

        Fleet fleetOject2 = new Fleet(UUID.fromString("394a6ba2-0988-17b3-560a-bc6e25a5776b"), 0, "Test Fleet", project,
                true, new Date(), new Date(), null, null);

        List<Fleet> fleetList = new ArrayList<>();
        fleetList.add(fleet);
        fleetList.add(fleetOject2);

        Object obj = fleetList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);

        when(fleetRepository.findAll(requestModel.getFilterSpecification())).thenReturn(fleetList);

        fleetList = (List<Fleet>) fleetServiceImpl.searchFleet(requestModel);

        assertThat((fleetList.size() == '2'));
    }

    /**
     * testViewFleet
     */
    @Test
    void testViewFleet() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
                "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea81"), 0, "Test Project", user,
                true, new Date(), null, "test", null, null, null);

        Fleet fleet = new Fleet(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Fleet", project, true,
                new Date(), new Date(), null, null);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        FleetModel fleetModel = mapper.map(fleet, FleetModel.class);

        when(fleetRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(fleet));

        assertThat(fleetServiceImpl.viewFleet(uuid)).isEqualTo(fleetModel);

    }

    @Test
    void testViewFleetForCatch() {
        when(fleetRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> fleetServiceImpl.viewFleet(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")), "");

    }

    @Test
    void testDeleteFleetById() {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
                "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea81"), 0,
                "Test Project", userObject1, true, new Date(), null, "test", null, null, null);

        FleetModel createdFleetModel = new FleetModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
                "Test Fleet", projectModel, true, new Date(), new Date(), null, null);

        Fleet alreadySavedFleet = mapper.map(createdFleetModel, Fleet.class);

        when(fleetRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(alreadySavedFleet));
        fleetServiceImpl.deleteFleet(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"));
        verify(fleetRepository).delete(alreadySavedFleet);
    }

    @Test
    void testDeleteFleetByIdForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
                "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea81"), 0,
                "Test Project", userObject1, true, new Date(), null, "test", null, null, null);
        FleetModel createdFleetModel = new FleetModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
                "Test Fleet", projectModel, true, new Date(), new Date(), null, null);

        Fleet alreadySavedFleet = mapper.map(createdFleetModel, Fleet.class);
        when(fleetRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(alreadySavedFleet));
        doThrow(ApplicationFactoryException.class).when(fleetRepository).delete(alreadySavedFleet);
        assertThrows(ApplicationFactoryException.class,
                () -> fleetServiceImpl.deleteFleet(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")), "");
    }

}
