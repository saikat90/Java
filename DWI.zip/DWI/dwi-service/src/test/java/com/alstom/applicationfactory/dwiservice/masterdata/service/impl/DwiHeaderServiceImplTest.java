package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.DwiHeader;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.DwiHeaderModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.DwiHeaderRepository;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class DwiHeaderServiceImplTest {

    @InjectMocks
    DwiHeaderServiceImpl dwiHeaderService;
    @Mock
    private DwiHeaderRepository dwiHeaderRepository;
    ObjectMapper objMapper = new ObjectMapper();

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");
    Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
            true, new Date(), null, "test", null, null, null);
    DwiHeader dwiHeader = new DwiHeader(null, 0,
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>", project);
    DwiHeader dwiHeader_1 = new DwiHeader(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"), 0,
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>", project);
    DwiHeader dwiHeader_3 = new DwiHeader(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"), 0,
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test___Test</div>\\n</body>\\n</html>",
            project);

    DwiHeader dwiHeader_2 = new DwiHeader(UUID.fromString("0e364d23-ee8b-c0f4-f75d-f4eac4bef403"), 0,
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>TEST DWI Header</div>\\n</body>\\n</html>",
            project);

    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", userModel, true, new Date(), null, "test", null, null, null);

    DwiHeaderModel updatedDWIHeaderModel = new DwiHeaderModel(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"),
            0, "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test___Test</div>\\n</body>\\n</html>",
            projectModel);
    DwiHeaderModel dwiHeaderModel = new DwiHeaderModel(null, 0,
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>", projectModel);
    DwiHeaderModel createddwiHeaderModel = new DwiHeaderModel(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"),
            0, "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>test</div>\\n</body>\\n</html>",
            projectModel);

    /**
     * testFindAll
     */
    @Test
    void testFindAll() {
        List<DwiHeader> dwiHeaderModelList = new ArrayList<>();
        dwiHeaderModelList.add(dwiHeader_1);
        dwiHeaderModelList.add(dwiHeader_2);

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        RequestModel requestModel = RequestMapper.map(request1);

        when(dwiHeaderRepository.findAll(requestModel.getFilterSpecification())).thenReturn(dwiHeaderModelList);
        Object obj1 = dwiHeaderService.findAll(requestModel);
        assertThat((dwiHeaderModelList.size() == '2'));
    }

    /**
     * testCreateDwiHeader
     */
    @Test
    void testCreateDwiHeader() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        DwiHeader dwiheader = mapper.map(dwiHeaderModel, DwiHeader.class);
        DwiHeader dwiheadercreated = mapper.map(createddwiHeaderModel, DwiHeader.class);
        when(dwiHeaderRepository.save(dwiheader)).thenReturn(dwiheadercreated);
        DwiHeaderModel expecteddwiheaderModel = mapper.map(dwiheadercreated, DwiHeaderModel.class);
        assertThat(dwiHeaderService.createDwiHeader(dwiHeaderModel)).isEqualTo(expecteddwiheaderModel);
    }

    @Test
    void testCreateDwiHeaderForCatch() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        DwiHeader dwiheader = mapper.map(dwiHeaderModel, DwiHeader.class);
        when(dwiHeaderRepository.save(dwiheader)).thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class, () -> dwiHeaderService.createDwiHeader(dwiHeaderModel), "");
    }

    @Test
    void testUpdateDwiHeader() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        DwiHeader updateddwiheader = mapper.map(updatedDWIHeaderModel, DwiHeader.class);
        DwiHeaderModel expecteddwiheaderModel = mapper.map(updateddwiheader, DwiHeaderModel.class);
        when(dwiHeaderRepository.findById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf")))
                .thenReturn(Optional.of(dwiHeader_1));
        when(dwiHeaderRepository.save(updateddwiheader)).thenReturn(updateddwiheader);
        assertThat(dwiHeaderService.updateDwiHeader(updatedDWIHeaderModel)).isEqualTo(expecteddwiheaderModel);
    }

    @Test
    void testUpdateDwiHeaderForElse() {
        assertThrows(ApplicationFactoryException.class, () -> dwiHeaderService.updateDwiHeader(updatedDWIHeaderModel),
                "");
    }

    @Test
    void testViewDwiHeader() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        DwiHeaderModel createddwiheaderModel = mapper.map(dwiHeader_1, DwiHeaderModel.class);
        when(dwiHeaderRepository.findById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf")))
                .thenReturn(Optional.of(dwiHeader_1));
        assertThat(dwiHeaderService.viewDwiHeader(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf")))
                .isEqualTo(createddwiheaderModel);
    }

    @Test
    void testViewDwiHeaderForCatch() {
        when(dwiHeaderRepository.findById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> dwiHeaderService.viewDwiHeader(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf")), "");
    }

    @Test
    void testDeleteDwiHeaderById() {
        dwiHeaderService.deleteDwiHeaderById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"));
        verify(dwiHeaderRepository).deleteById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"));
    }

    @Test
    void testDeleteDwiHeaderByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(dwiHeaderRepository)
                .deleteById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf"));
        assertThrows(ApplicationFactoryException.class,
                () -> dwiHeaderService.deleteDwiHeaderById(UUID.fromString("040aa608-86a1-5794-3526-74694840aaaf")),
                "");
    }

}
