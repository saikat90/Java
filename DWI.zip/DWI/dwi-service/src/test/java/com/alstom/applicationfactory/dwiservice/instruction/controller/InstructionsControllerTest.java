/**
 */
package com.alstom.applicationfactory.dwiservice.instruction.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.feign.client.EmailServiceClient;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionsService;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author 100769630.
 */
@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
@WebMvcTest(InstructionsController.class)
class InstructionsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;

    @Autowired
    private WebApplicationContext context;

    ObjectMapper mapper = new ObjectMapper();

    @MockBean
    private EmailServiceClient emailServiceClient;

    @MockBean
    private InstructionsService instructionsService;

    /**
     * @throws java.lang.Exception
     */
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");
        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV")).thenReturn(null);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#searchInstruction(java.util.Map)}.
     */
    @Test
    void testSearchInstruction() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#saveasDraftInstruction(java.lang.String, java.lang.String, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testSaveasDraftInstruction() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#submitInstruction(java.lang.String, java.lang.String, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testSubmitInstruction() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#viewInstruction(java.util.UUID)}.
     */
    @Test
    void testViewInstruction() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#deleteInstructionById(java.util.UUID)}.
     */
    @Test
    void testDeleteInstructionById() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#validateInstruction(java.util.UUID, java.lang.String, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testValidateInstruction() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#approveInstruction(java.util.UUID, java.lang.String, java.lang.String, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testApproveInstruction() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#archiveInstruction(java.util.UUID)}.
     */
    @Test
    void testArchiveInstruction() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#rejectInstruction(java.util.UUID, java.lang.String, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testRejectInstruction() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#createNewVersion(java.util.UUID, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testCreateNewVersion() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#copyAttachment(java.util.UUID)}.
     */
    @Test
    void testCopyAttachment() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#instructionAutoReminder()}.
     */
    @Test
    void testInstructionAutoReminder() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#addComments(java.util.UUID, java.lang.String, java.lang.String, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testAddComments() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#viewPreviousVersion(java.util.UUID, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testViewPreviousVersion() {
        Assertions.assertTrue(true);
    }

    /**
     * Test method for
     * {@link com.alstom.applicationfactory.dwiservice.instruction.controller.InstructionsController#addAttachment(java.util.UUID, java.lang.String, org.springframework.security.core.Authentication)}.
     */
    @Test
    void testAddAttachment() {
        Assertions.assertTrue(true);
    }

}
