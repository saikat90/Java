package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Fleet;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Process;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Revision;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.RevisionRepository;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class RevisionServiceImplTest {

    @InjectMocks
    RevisionServiceImpl revisionService;
    @Mock
    private RevisionRepository revisionRepository;
    ObjectMapper objMapper = new ObjectMapper();

    UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
            "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", userObject1, true, new Date(), null, "test", null, null, null);

    FleetModel fleetModel = new FleetModel(UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3"), 0, "Test Fleet",
            projectModel, true, new Date(), null, "test", null);

    ProcessModel processModel = new ProcessModel(null, 0, "Test Process", fleetModel, true, new Date(), null, "test",
            null);

    RevisionModel revisionModel = new RevisionModel(null, 0, "Test Revision", true, new Date(), null, "test", null,
            processModel);
    RevisionModel createdRevisionModel = new RevisionModel(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"), 0,
            "Test Revision", true, new Date(), null, "test", null, processModel);
    RevisionModel updatedRevisionModel = new RevisionModel(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"), 0,
            "Test Revision", false, new Date(), null, "test", null, processModel);

    /**
     * testCreateRevision
     */
    @Test
    void testCreateRevision() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Revision revision = mapper.map(revisionModel, Revision.class);
        Revision createdrevision = mapper.map(createdRevisionModel, Revision.class);
        when(revisionRepository.save(revision)).thenReturn(createdrevision);
        RevisionModel expectedRevisionModel = mapper.map(createdrevision, RevisionModel.class);
        assertThat(revisionService.createRevision(revisionModel)).isEqualTo(expectedRevisionModel);
    }

    @Test
    void testCreateRevisionForNullProess() {
        revisionModel.setProcess(null);
        assertThrows(ApplicationFactoryException.class, () -> revisionService.createRevision(revisionModel), "");

    }

    @Test
    void testCreateRevisionForRecordExist() {
        when(revisionRepository.count(Mockito.any(FilterSpecification.class))).thenReturn((long) 1);
        assertThrows(ApplicationFactoryException.class, () -> revisionService.createRevision(revisionModel), "");
    }

    @Test
    void testUpdateRevision() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Revision updatedRevision = mapper.map(updatedRevisionModel, Revision.class);
        Revision createdrevision = mapper.map(createdRevisionModel, Revision.class);
        when(revisionRepository.findById(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb")))
                .thenReturn(Optional.of(createdrevision));
        when(revisionRepository.save(updatedRevision)).thenReturn(updatedRevision);
        RevisionModel updatedRevisionModel = mapper.map(updatedRevision, RevisionModel.class);
        assertThat(revisionService.updateRevision(updatedRevisionModel)).isEqualTo(updatedRevisionModel);
    }

    @Test
    void testUpdateRevisionForNullProcess() {
        updatedRevisionModel.setProcess(null);
        assertThrows(ApplicationFactoryException.class, () -> revisionService.updateRevision(updatedRevisionModel), "");
    }

    @Test
    void testUpdateRevisionForRecordNotExist() {
        assertThrows(ApplicationFactoryException.class, () -> revisionService.updateRevision(updatedRevisionModel), "");
    }

    @Test
    void testSearchRevision() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
                "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
                true, new Date(), null, "test", null, null, null);
        Fleet fleet = new Fleet(UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3"), 0, "Test Fleet", project, true,
                new Date(), null, "test", null);

        Process process = new Process(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"), 0, "Test Process", true,
                new Date(), null, "test", null, fleet);
        Revision revision = new Revision(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"), 0, "Test Revision",
                true, new Date(), null, "test", null, process);

        Revision revision1 = new Revision(UUID.fromString("023724d2-3416-02d9-63e1-c19fbf8850a7"), 0, "Test Revision1",
                false, new Date(), null, "test", null, process);

        List<Revision> revisionList = new ArrayList<>();
        revisionList.add(revision);
        revisionList.add(revision1);

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        RequestModel requestModel = RequestMapper.map(request1);

        when(revisionRepository.findAll(requestModel.getFilterSpecification())).thenReturn(revisionList);

        Object obj1 = revisionService.searchRevision(requestModel);
        assertThat((revisionList.size() == '2'));
    }

    /**
     * testViewRevision
     */
    @Test
    void testViewRevision() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
                "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
                true, new Date(), null, "test", null, null, null);
        Fleet fleet = new Fleet(UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3"), 0, "Test Fleet", project, true,
                new Date(), null, "test", null);
        Process process = new Process(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"), 0, "Test Process", true,
                new Date(), null, "test", null, fleet);
        Revision revision = new Revision(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"), 0, "Test Revision",
                true, new Date(), null, "test", null, process);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());

        RevisionModel revisionModel = mapper.map(revision, RevisionModel.class);

        when(revisionRepository.findById(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb")))
                .thenReturn(Optional.of(revision));

        assertThat(revisionService.viewRevision(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb")))
                .isEqualTo(revisionModel);
    }

    @Test
    void testViewRevisionForCatch() {
        when(revisionRepository.findById(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> revisionService.viewRevision(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb")), "");
    }

    @Test
    void testDeleteRevisionById() {
        revisionService.deleteRevisionById(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"));
        verify(revisionRepository).deleteById(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"));
    }

    @Test
    void testDeleteRevisionByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(revisionRepository)
                .deleteById(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"));
        assertThrows(ApplicationFactoryException.class,
                () -> revisionService.deleteRevisionById(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb")), "");
    }

}
