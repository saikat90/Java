package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProcessRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProcessService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(ProcessController.class)
class ProcessControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private WebApplicationContext context;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @MockBean
    private ProcessService processService;
    @MockBean
    private ProcessRepository processRepository;
    @MockBean
    private RequestModel requestModel;

    ObjectMapper mapper = new ObjectMapper();

    UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(
            UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", userObject1,
            true, new Date(), null, "test", null, null, null);

    FleetModel fleetModel = new FleetModel(UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3"),
            0, "Test Fleet", projectModel, true, new Date(), null, "test", null);

    ProcessModel processModel = new ProcessModel(null, 0, "Test Process", fleetModel, true,
            new Date(), null, "test", null);

    ProcessModel createdProcessModel = new ProcessModel(
            UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"), 0, "Test Process", fleetModel,
            true, new Date(), null, "test", null);
    ProcessModel updatedProcessModel = new ProcessModel(
            UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e"), 0, "Test Process", fleetModel,
            false, new Date(), null, "test", null);

    /**
     * setup
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testCreateProcess() throws Exception {
        String json = mapper.writeValueAsString(processModel);
        when(processService.createProcess(processModel)).thenReturn(createdProcessModel);
        RequestBuilder request = MockMvcRequestBuilders.post("/process")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testUpdateProcess() throws Exception {
        String json = mapper.writeValueAsString(updatedProcessModel);
        when(processService.updateProcess(updatedProcessModel)).thenReturn(updatedProcessModel);
        RequestBuilder request = MockMvcRequestBuilders.put("/process")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testSearchProcess() throws Exception {

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);
        String returnObject = "{\r\n" + "    \"pageNumber\": 0,\r\n" + "    \"pageSize\": 10,\r\n"
                + "    \"totalElements\": 85,\r\n" + "    \"totalPages\": 9,\r\n"
                + "    \"content\": [\r\n" + "        {\r\n"
                + "            \"id\": \"008a4bc1-8e2c-addf-a640-b6aaf4de4f3e\",\r\n"
                + "            \"version\": 0,\r\n"
                + "            \"processName\": \"Preventive-MTN10\",\r\n"
                + "            \"fleet\": {\r\n"
                + "                \"id\": \"a59cb76c-2d66-5d28-dd77-d252db143ba3\",\r\n"
                + "                \"version\": 0,\r\n"
                + "                \"fleetName\": \"Others\",\r\n"
                + "                \"project\": {\r\n"
                + "                    \"id\": \"394a6ba2-0988-17b3-560a-bc6e25a5776b\",\r\n"
                + "                    \"version\": 0,\r\n"
                + "                    \"projName\": \"Ottawa_MTN_Railsystem\",\r\n"
                + "                    \"projectManager\": {\r\n"
                + "                        \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "                        \"employeeId\": \"23139\",\r\n"
                + "                        \"firstName\": \"Alban\",\r\n"
                + "                        \"lastName\": \"HOUSSIN\",\r\n"
                + "                        \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "                        \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "                    },\r\n" + "                    \"active\": true,\r\n"
                + "                    \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                    \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                    \"createdBy\": \"413316\",\r\n"
                + "                    \"modifiedBy\": null,\r\n"
                + "                    \"projFunctions\": [],\r\n"
                + "                    \"projectUserRoles\": []\r\n" + "                },\r\n"
                + "                \"active\": true,\r\n"
                + "                \"createdDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                \"modifiedDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                \"createdBy\": \"413316\",\r\n"
                + "                \"modifiedBy\": null\r\n" + "            },\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"9827\",\r\n"
                + "            \"modifiedBy\": null\r\n" + "        },\r\n" + "        {\r\n"
                + "            \"id\": \"01007d1e-8842-e4c1-b22b-3d43aa9dd80d\",\r\n"
                + "            \"version\": 0,\r\n"
                + "            \"processName\": \"Special Processes-MTN40\",\r\n"
                + "            \"fleet\": {\r\n"
                + "                \"id\": \"a59cb76c-2d66-5d28-dd77-d252db143ba3\",\r\n"
                + "                \"version\": 0,\r\n"
                + "                \"fleetName\": \"Others\",\r\n"
                + "                \"project\": {\r\n"
                + "                    \"id\": \"394a6ba2-0988-17b3-560a-bc6e25a5776b\",\r\n"
                + "                    \"version\": 0,\r\n"
                + "                    \"projName\": \"Ottawa_MTN_Railsystem\",\r\n"
                + "                    \"projectManager\": {\r\n"
                + "                        \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "                        \"employeeId\": \"23139\",\r\n"
                + "                        \"firstName\": \"Alban\",\r\n"
                + "                        \"lastName\": \"HOUSSIN\",\r\n"
                + "                        \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "                        \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "                    },\r\n" + "                    \"active\": true,\r\n"
                + "                    \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                    \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                    \"createdBy\": \"413316\",\r\n"
                + "                    \"modifiedBy\": null,\r\n"
                + "                    \"projFunctions\": [],\r\n"
                + "                    \"projectUserRoles\": []\r\n" + "                },\r\n"
                + "                \"active\": true,\r\n"
                + "                \"createdDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                \"modifiedDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                \"createdBy\": \"413316\",\r\n"
                + "                \"modifiedBy\": null\r\n" + "            },\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"9827\",\r\n"
                + "            \"modifiedBy\": null\r\n" + "        }]\r\n" + "}";
        Object obj = returnObject;
        when(processService.searchProcess(requestModel)).thenReturn(updatedProcessModel);
        RequestBuilder request = MockMvcRequestBuilders.post("/process/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testViewProcess() throws Exception {
        when(processService.viewProcess(UUID.fromString("008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")))
                .thenReturn(createdProcessModel);
        RequestBuilder request = MockMvcRequestBuilders
                .get("/process/008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteProcessById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/process/008a4bc1-8e2c-addf-a640-b6aaf4de4f3e")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testGetAllProcessForFleet() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        UUID fleetId = UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3");
        String returnObject = "{\r\n" + "    \"pageNumber\": 0,\r\n" + "    \"pageSize\": 10,\r\n"
                + "    \"totalElements\": 85,\r\n" + "    \"totalPages\": 9,\r\n"
                + "    \"content\": [\r\n" + "        {\r\n"
                + "            \"id\": \"008a4bc1-8e2c-addf-a640-b6aaf4de4f3e\",\r\n"
                + "            \"version\": 0,\r\n"
                + "            \"processName\": \"Preventive-MTN10\",\r\n"
                + "            \"fleet\": {\r\n"
                + "                \"id\": \"a59cb76c-2d66-5d28-dd77-d252db143ba3\",\r\n"
                + "                \"version\": 0,\r\n"
                + "                \"fleetName\": \"Others\",\r\n"
                + "                \"project\": {\r\n"
                + "                    \"id\": \"394a6ba2-0988-17b3-560a-bc6e25a5776b\",\r\n"
                + "                    \"version\": 0,\r\n"
                + "                    \"projName\": \"Ottawa_MTN_Railsystem\",\r\n"
                + "                    \"projectManager\": {\r\n"
                + "                        \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "                        \"employeeId\": \"23139\",\r\n"
                + "                        \"firstName\": \"Alban\",\r\n"
                + "                        \"lastName\": \"HOUSSIN\",\r\n"
                + "                        \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "                        \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "                    },\r\n" + "                    \"active\": true,\r\n"
                + "                    \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                    \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                    \"createdBy\": \"413316\",\r\n"
                + "                    \"modifiedBy\": null,\r\n"
                + "                    \"projFunctions\": [],\r\n"
                + "                    \"projectUserRoles\": []\r\n" + "                },\r\n"
                + "                \"active\": true,\r\n"
                + "                \"createdDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                \"modifiedDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                \"createdBy\": \"413316\",\r\n"
                + "                \"modifiedBy\": null\r\n" + "            },\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"9827\",\r\n"
                + "            \"modifiedBy\": null\r\n" + "        },\r\n" + "        {\r\n"
                + "            \"id\": \"01007d1e-8842-e4c1-b22b-3d43aa9dd80d\",\r\n"
                + "            \"version\": 0,\r\n"
                + "            \"processName\": \"Special Processes-MTN40\",\r\n"
                + "            \"fleet\": {\r\n"
                + "                \"id\": \"a59cb76c-2d66-5d28-dd77-d252db143ba3\",\r\n"
                + "                \"version\": 0,\r\n"
                + "                \"fleetName\": \"Others\",\r\n"
                + "                \"project\": {\r\n"
                + "                    \"id\": \"394a6ba2-0988-17b3-560a-bc6e25a5776b\",\r\n"
                + "                    \"version\": 0,\r\n"
                + "                    \"projName\": \"Ottawa_MTN_Railsystem\",\r\n"
                + "                    \"projectManager\": {\r\n"
                + "                        \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "                        \"employeeId\": \"23139\",\r\n"
                + "                        \"firstName\": \"Alban\",\r\n"
                + "                        \"lastName\": \"HOUSSIN\",\r\n"
                + "                        \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "                        \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "                    },\r\n" + "                    \"active\": true,\r\n"
                + "                    \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                    \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                    \"createdBy\": \"413316\",\r\n"
                + "                    \"modifiedBy\": null,\r\n"
                + "                    \"projFunctions\": [],\r\n"
                + "                    \"projectUserRoles\": []\r\n" + "                },\r\n"
                + "                \"active\": true,\r\n"
                + "                \"createdDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                \"modifiedDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                \"createdBy\": \"413316\",\r\n"
                + "                \"modifiedBy\": null\r\n" + "            },\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"9827\",\r\n"
                + "            \"modifiedBy\": null\r\n" + "        }]\r\n" + "}";

        Object obj = returnObject;
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        request1 = RequestModifier.defaultRequestMapIfEmpty(request1);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "fleet.id", fleetId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request1, filterConditions));
        when(processService.searchProcess(requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders
                .post("/process/a59cb76c-2d66-5d28-dd77-d252db143ba3/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }
}
