package com.alstom.applicationfactory.dwiservice.instruction.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;

@TestPropertySource(locations = "classpath:application-test.properties")
@ExtendWith(MockitoExtension.class)
class FileManagerServiceImplTest {

    @InjectMocks
    FileManagerServiceImpl fileManagerServiceImpl;

    private Path workingDir;

    /**
     * init method
     */
    @BeforeEach
    public void init() {
        this.workingDir = Path.of("", "src/test/resources");
    }

    /**
     * testGetImage method for upload attachments
     */
    @Disabled
    @Test
    void testGetImage() {
        File file;
        Path downloadPath = this.workingDir.resolve("Warning_Sign.png");

        file = new File(downloadPath.toUri());

        byte[] expected_file = readFileToByteArray(file);

        ReflectionTestUtils.setField(fileManagerServiceImpl, "filePath", "src\\test\\resources\\");

        // assertThat(fileManagerServiceImpl.getImage("/Warning_Sign.png")).isEqualTo(expected_file);
        Assertions.assertTrue(true);

    }

    /**
     * @param file
     * @return
     */
    private static byte[] readFileToByteArray(File file) {
        FileInputStream fis = null;
        // Creating a byte array using the length of the file
        // file.length returns long which is cast to int
        byte[] bArray = new byte[(int) file.length()];
        try {
            fis = new FileInputStream(file);
            int count = fis.read(bArray);
        } catch (IOException e) {
            List<ErrorModel> errors = new ArrayList<>();
            errors.add(new ErrorModel(Constants.ERROR_LABEL, Constants.ATTACHMENT_READ_ERROR));
            throw new ApplicationFactoryException(Constants.ERROR_CODE_404, errors);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                }
            }
        }
        return bArray;
    }

}
