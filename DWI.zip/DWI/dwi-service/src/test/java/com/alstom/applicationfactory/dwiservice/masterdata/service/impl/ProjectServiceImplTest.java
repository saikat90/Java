package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.exception.ErrorModel;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Function;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.WorkFlowTemplate;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectUserRoleModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.WorkFlowTemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.FunctionRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.WorkFlowTemplateRepository;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class ProjectServiceImplTest {

    @InjectMocks
    ProjectServiceImpl projectService;

    @Mock
    private ProjectRepository projectRepository;

    @Mock
    private WorkFlowTemplateRepository wfTemplateRepository;

    @Mock
    private FunctionRepository functionRepository;

    ObjectMapper objMapper = new ObjectMapper();

    UUID uuid = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");

    /**
     * testCreateProjectForCount
     */
    @Test
    void testCreateProjectForCount() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel projectModel = new ProjectModel(null, 0, "Test Project", userObject1, true,
                new Date(), null, "test", null, null, null);

        Project project = mapper.map(projectModel, Project.class);

        User user = mapper.map(userObject1, User.class);

        Project createdProject = new Project(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
                true, new Date(), null, "test", null, null, null);

        ProjectModel expectedProjectModel = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null, null, null);

        when(projectRepository.save(project)).thenReturn(createdProject);

        assertThat(projectService.createProject(projectModel).getId())
                .isEqualTo(expectedProjectModel.getId());

    }

    /**
     * testCreateProjectForElseCount
     */
    @Test
    void testCreateProjectForElseCount() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel projectModel = new ProjectModel(null, 0, "Test Project", userObject1, true,
                new Date(), null, "test", null, null, null);
        ProjectUserRoleModel projUserRole = new ProjectUserRoleModel(null, userObject1, "VALIDATOR",
                projectModel);

        List<ProjectUserRoleModel> projUserRoleList = new ArrayList<>();
        projUserRoleList.add(projUserRole);

        projectModel.setProjectUserRoles(projUserRoleList);
        when(projectRepository.count(Mockito.any(FilterSpecification.class))).thenReturn((long) 1);
        assertThrows(ApplicationFactoryException.class,
                () -> projectService.createProject(projectModel), "");
    }

    /**
     * testUpdateProjectForProjectRecord
     */
    @Test
    void testUpdateProjectForProjectRecord() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel createdProjectModel = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null, null, null);

        ProjectUserRoleModel projUserRole = new ProjectUserRoleModel(null, userObject1, "VALIDATOR",
                createdProjectModel);

        List<ProjectUserRoleModel> projUserRoleList = new ArrayList<>();
        projUserRoleList.add(projUserRole);

        createdProjectModel.setProjectUserRoles(projUserRoleList);

        ProjectModel passedProjectModel = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), new Date(), "test", "modified", null, null);

        Project alreadySavedProject = mapper.map(createdProjectModel, Project.class);
        Project updatedproject = mapper.map(passedProjectModel, Project.class);

        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(alreadySavedProject));

        when(projectRepository.save(updatedproject)).thenReturn(updatedproject);

        ProjectModel updatedprojectModel = mapper.map(updatedproject, ProjectModel.class);

        assertThat(projectService.updateProject(passedProjectModel)).isEqualTo(updatedprojectModel);
    }

    /**
     * testUpdateProjectForElseProjectRecord
     */
    @Test
    void testUpdateProjectForElseProjectRecord() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel passedProjectModel = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), new Date(), "test", "modified", null, null);

        List<ErrorModel> errorList = new ArrayList<>();
        ErrorModel errorModel = new ErrorModel("Project", "Unable to update Project");
        errorList.add(errorModel);

        assertThrows(ApplicationFactoryException.class,
                () -> projectService.updateProject(passedProjectModel), "");

    }

    /**
     * testSearchProject
     */
    @Test
    void testSearchProject() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
                "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
                "Test Project", user, true, new Date(), null, "test", null, null, null);

        Project projectOject2 = new Project(UUID.fromString("394a6ba2-0988-17b3-560a-bc6e25a5776b"),
                0, "Ottawa_MTN_Railsystem", user, true, new Date(), null, "415128", "dev", null,
                null);

        List<Project> projList = new ArrayList<>();
        projList.add(project);
        projList.add(projectOject2);

        Object obj = projList;

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);

        when(projectRepository.findAll(requestModel.getFilterSpecification())).thenReturn(projList);

        projList = (List<Project>) projectService.searchProject(requestModel);

        assertThat((projList.size() == '2'));
    }

    /**
     * testViewProject
     */
    @Test
    void testViewProject() {
        User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182",
                "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
                "Test Project", user, true, new Date(), null, "test", null, null, null);

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        ProjectModel projectModel = mapper.map(project, ProjectModel.class);

        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(project));

        assertThat(projectService.viewProject(uuid)).isEqualTo(projectModel);

    }

    @Test
    void testViewProjectForCatch() {
        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class, () -> projectService
                .viewProject(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")), "");

    }

    @Test
    void testDeleteProjectById() {
        projectService.deleteProjectById(uuid);
        verify(projectRepository, times(1)).deleteById(uuid);
    }

    @Test
    void testDeleteProjectByIdForCatch() {
        doThrow(ApplicationFactoryException.class).when(projectRepository)
                .deleteById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"));
        assertThrows(ApplicationFactoryException.class,
                () -> projectService
                        .deleteProjectById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")),
                "");
    }

    @Test
    void testAddFunction() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel createdProjectModel = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null, null, null);

        FunctionModel createfunctionModel = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b0181"), 0, "EHS_1", true,
                new Date(), null, "system", null);

        FunctionModel functionModel = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e"), 0, "EHS", true, new Date(),
                null, "system", null);

        ProjectModel projectModelWithFunction = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null,
                Arrays.asList(createfunctionModel), null);

        ProjectModel createdprojectModelWithFunction = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null,
                Arrays.asList(createfunctionModel, functionModel), null);

        Project alreadySavedProject = mapper.map(createdProjectModel, Project.class);
        Project projectWithFunction = mapper.map(projectModelWithFunction, Project.class);
        Project createdprojectWithFunction = mapper.map(createdprojectModelWithFunction,
                Project.class);

        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(projectWithFunction));

        when(projectRepository.save(projectWithFunction)).thenReturn(createdprojectWithFunction);

        ProjectModel updatedprojectModel = mapper.map(createdprojectWithFunction,
                ProjectModel.class);

        assertThat(projectService.addFunction(uuid, functionModel)).isEqualTo(updatedprojectModel);
    }

    @Test
    void testAddFunctionForCatch() {
        FunctionModel functionModel = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e"), 0, "EHS", true, new Date(),
                null, "system", null);

        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class,
                () -> projectService.addFunction(uuid, functionModel), "");
    }

    @Test
    void testDeleteFunctionForCatch() {
        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenThrow(ApplicationFactoryException.class);
        assertThrows(ApplicationFactoryException.class, () -> projectService.deleteFunction(uuid,
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e")), "");
    }

    @Test
    void testDeleteFunction() {
        List<FunctionModel> functionList = new ArrayList<>();
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

        ProjectModel createdProjectModel = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null, functionList, null);

        FunctionModel functionModel = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e"), 0, "EHS", true, new Date(),
                null, "system", null);

        ProjectModel projectModelWithFunction = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null, Arrays.asList(functionModel),
                null);

        Project alreadySavedProject = mapper.map(createdProjectModel, Project.class);
        Project projectWithFunction = mapper.map(projectModelWithFunction, Project.class);
        Function function = mapper.map(functionModel, Function.class);

        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(projectWithFunction));

        when(functionRepository.findById(UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e")))
                .thenReturn(Optional.of(function));

        when(projectRepository.save(projectWithFunction)).thenReturn(alreadySavedProject);

        assertThat(projectService.deleteFunction(uuid,
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e")))
                        .isEqualTo(createdProjectModel);
    }

    /**
     * testGetAllFunctionsForProject
     */
    @Test
    void testGetAllFunctionsForProject() {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
        FunctionModel functionModel = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e"), 0, "EHS", true, new Date(),
                null, "system", null);
        ProjectModel projectModelWithFunction = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null, Arrays.asList(functionModel),
                null);
        Project projectWithFunction = mapper.map(projectModelWithFunction, Project.class);
        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(projectWithFunction));
        Object obj = projectWithFunction.getProjFunctions();
        assertThat(projectService
                .getAllFunctionsForProject(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                        .isEqualTo(obj);
    }

    /**
     * testGetUnassignedFunctions
     */
    @Test
    void testGetUnassignedFunctions() {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
        FunctionModel functionModel = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e"), 0, "EHS", true, new Date(),
                null, "system", null);
        ProjectModel projectModelWithFunction = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null, Arrays.asList(functionModel),
                null);
        Project projectWithFunction = mapper.map(projectModelWithFunction, Project.class);

        List<Function> functionList = new ArrayList<>();
        FunctionModel functionModel1 = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e"), 0, "EHS", true, new Date(),
                null, "system", null);
        FunctionModel functionModel2 = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479988b0018"), 0, "EHS_Test_1", true,
                new Date(), null, "system", null);

        Function function1 = mapper.map(functionModel1, Function.class);
        Function function2 = mapper.map(functionModel2, Function.class);
        functionList.add(function1);
        functionList.add(function2);

        List<Function> ExistingfunctionList = projectWithFunction.getProjFunctions();
        when(projectRepository.findById(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(Optional.of(projectWithFunction));
        when(functionRepository.findAll(Mockito.any(FilterSpecification.class)))
                .thenReturn(functionList);
        functionList.removeAll(ExistingfunctionList);
        Object obj = functionList;
        assertThat(projectService
                .getUnassignedFunctions(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                        .isEqualTo(obj);
    }

    /**
     * testGetUnassignedProjects
     */
    @Test
    void testGetUnassignedProjects() {

        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull());

        UserModel userObject1 = new UserModel(
                UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
                "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
        FunctionModel functionModel = new FunctionModel(
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e"), 0, "EHS", true, new Date(),
                null, "system", null);
        ProjectModel projectModelWithFunction = new ProjectModel(
                UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project",
                userObject1, true, new Date(), null, "test", null, Arrays.asList(functionModel),
                null);
        ProjectModel projectOject2 = new ProjectModel(
                UUID.fromString("394a6ba2-0988-17b3-560a-bc6e25a5776b"), 0, "Ottawa_MTN_Railsystem",
                userObject1, true, new Date(), null, "415128", "dev", null, null);
        Project projectWithFunction = mapper.map(projectModelWithFunction, Project.class);
        Project project1 = mapper.map(projectOject2, Project.class);
        List<Project> projectList = new ArrayList<>();
        projectList.add(projectWithFunction);
        projectList.add(project1);

        WorkFlowTemplateModel updatedwfTemplate = new WorkFlowTemplateModel(
                UUID.fromString("59441f6c-723b-4462-98aa-b49d912b1150"), 0, "N1-Test", true,
                projectModelWithFunction, new Date(), null, "test", null, null);
        WorkFlowTemplateModel createdwfTemplate1 = new WorkFlowTemplateModel(
                UUID.fromString("0c6ce614-347e-455f-b2b3-7286a5cb0c4c"), 0, "N5", true,
                projectModelWithFunction, new Date(), null, "test", null, null);
        WorkFlowTemplate wfTemplate1 = mapper.map(updatedwfTemplate, WorkFlowTemplate.class);
        WorkFlowTemplate wfTemplate2 = mapper.map(createdwfTemplate1, WorkFlowTemplate.class);
        List<WorkFlowTemplate> wfTemplateList = new ArrayList<>();
        wfTemplateList.add(wfTemplate1);
        wfTemplateList.add(wfTemplate2);

        when(projectRepository.findAll(Mockito.any(FilterSpecification.class)))
                .thenReturn(projectList);
        when(wfTemplateRepository.findAll()).thenReturn(wfTemplateList);

        List<Project> wfTempProjectList = wfTemplateList.stream().map(wftemplate -> {
            Project project = wftemplate.getProject();
            return project;
        }).collect(Collectors.toList());
        projectList.removeAll(wfTempProjectList);

        Object obj = projectList;
        assertThat(projectService.getUnassignedProjects()).isEqualTo(obj);
    }
}
