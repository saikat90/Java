package com.alstom.applicationfactory.dwiservice.masterdata.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;

import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.exception.ApplicationFactoryException;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Template;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.TemplateModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.TemplateRepository;
import com.alstom.applicationfactory.dwiservice.util.FilterSpecification;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class TemplateServiceImplTest {

    @InjectMocks
    TemplateServiceImpl templateService;
    @Mock
    private TemplateRepository templateRepository;
    @Mock
    private ProjectRepository projectRepository;
    ObjectMapper objMapper = new ObjectMapper();

    User user = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A", "LastName",
            "user.ar@alstomgroup.com", "IS&T Project CoE");

    Project project = new Project(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", user,
            true, new Date(), null, "test", null, null, null);

    Template template1 = new Template(null, 0, "Ottawa_Completion", true, "Work Procedure",
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"margin: 12.0pt 0cm 12.0pt 28.8pt;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Completion</span></h2>\\n<div>\\n<ol>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Ensure nothing is left in the site (for e.g. tools, cloth, paper sheets etc.)</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">On completion of the task, inform the Operations desk and ensure the system is operational.</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Complete all the documentation needed to report the task as completed.</span></li>\\n</ol>\\n</div>\\n</div>\\n</div>\\n</body>\\n</html>",
            project);

    Template createdtemplate = new Template(UUID.fromString("06ef2eb2-36c5-a4f4-b1aa-c9a1902a61c3"), 0,
            "Ottawa_Completion", true, "Work Procedure",
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"margin: 12.0pt 0cm 12.0pt 28.8pt;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Completion</span></h2>\\n<div>\\n<ol>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Ensure nothing is left in the site (for e.g. tools, cloth, paper sheets etc.)</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">On completion of the task, inform the Operations desk and ensure the system is operational.</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Complete all the documentation needed to report the task as completed.</span></li>\\n</ol>\\n</div>\\n</div>\\n</div>\\n</body>\\n</html>",
            project);

    Template updatedTemplate = new Template(UUID.fromString("087daf8d-ae19-15e3-b0c9-0765f9a20455"), 0, "Test Title",
            true, "Test Description_1",
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"padding-left: 30px;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Environmental Considerations</span></h2>\\n<table style=\\\"border-color: #000000;\\\" border=\\\"1\\\" width=\\\"100%\\\">\\n<tbody>\\n<tr style=\\\"height: 46px;\\\">\\n<td style=\\\"width: 35.0133%; border-color: #4f81bd; border-style: solid; border-width: 1pt 1pt 2.25pt; border-image: none 100% / 1 / 0 stretch; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"166\\\">\\n<p style=\\\"tab-stops: 60.75pt;\\\"><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Aspect</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 26.8852%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"154\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Impact</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 10.1174%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"97\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Rating</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 26.3926%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"212\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Mitigation Measure</span></strong></span></p>\\n</td>\\n</tr>\\n<tr style=\\\"height: 10px;\\\">\\n<td style=\\\"width: 35.0133%; border-color: currentcolor #4f81bd #4f81bd currentcolor; border-style: none solid solid none; border-width: medium 1pt 1pt medium; padding: 0cm 5.4pt; height: 99px;\\\" width=\\\"186\\\">&nbsp;</td>\\n<td style=\\\"width: 26.8852%; height: 99px;\\\">&nbsp;</td>\\n<td style=\\\"width: 10.1174%; height: 99px;\\\">&nbsp;</td>\\n<td style=\\\"width: 26.3926%; height: 99px;\\\">&nbsp;</td>\\n</tr>\\n</tbody>\\n</table>\\n</div>\\n</div>\\n</body>\\n</html>",
            project);
    Template template2 = new Template(UUID.fromString("0930828c-ebc9-895d-fdbe-c93c022243a5"), 0, "Ottawa_Completion_1",
            true, "Work Procedure_1",
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"margin: 12.0pt 0cm 12.0pt 28.8pt;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Completion</span></h2>\\n<div>\\n<ol>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Ensure nothing is left in the site (for e.g. tools, cloth, paper sheets etc.)</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">On completion of the task, inform the Operations desk and ensure the system is operational.</span></li>\\n<li style=\\\"margin: 12.0pt 0cm 12.0pt 0cm;\\\"><span style=\\\"color: #333399;\\\">Complete all the documentation needed to report the task as completed.</span></li>\\n</ol>\\n</div>\\n</div>\\n</div>\\n</body>\\n</html>",
            project);
    UserModel userModel = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"), "100777182", "User A",
            "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
    ProjectModel projectModel = new ProjectModel(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0,
            "Test Project", userModel, true, new Date(), null, "test", null, null, null);
    TemplateModel updatedTemplateModel = new TemplateModel(UUID.fromString("087daf8d-ae19-15e3-b0c9-0765f9a20455"), 0,
            "Test Title", true, "Test Description_1",
            "<!DOCTYPE html>\\n<html>\\n<head>\\n</head>\\n<body>\\n<div>\\n<div>\\n<h2 style=\\\"padding-left: 30px;\\\"><span style=\\\"color: #333399; font-size: 18px;\\\">Environmental Considerations</span></h2>\\n<table style=\\\"border-color: #000000;\\\" border=\\\"1\\\" width=\\\"100%\\\">\\n<tbody>\\n<tr style=\\\"height: 46px;\\\">\\n<td style=\\\"width: 35.0133%; border-color: #4f81bd; border-style: solid; border-width: 1pt 1pt 2.25pt; border-image: none 100% / 1 / 0 stretch; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"166\\\">\\n<p style=\\\"tab-stops: 60.75pt;\\\"><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Aspect</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 26.8852%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"154\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Impact</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 10.1174%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"97\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Rating</span></strong></span></p>\\n</td>\\n<td style=\\\"width: 26.3926%; border-color: #4f81bd #4f81bd #4f81bd currentcolor; border-style: solid solid solid none; border-width: 1pt 1pt 2.25pt medium; background: #95b3d7 none repeat scroll 0% 0%; padding: 0cm 5.4pt; text-align: center; height: 46px;\\\" width=\\\"212\\\">\\n<p><span style=\\\"color: #333399;\\\"><strong><span style=\\\"font-size: 10.0pt;\\\">Mitigation Measure</span></strong></span></p>\\n</td>\\n</tr>\\n<tr style=\\\"height: 10px;\\\">\\n<td style=\\\"width: 35.0133%; border-color: currentcolor #4f81bd #4f81bd currentcolor; border-style: none solid solid none; border-width: medium 1pt 1pt medium; padding: 0cm 5.4pt; height: 99px;\\\" width=\\\"186\\\">&nbsp;</td>\\n<td style=\\\"width: 26.8852%; height: 99px;\\\">&nbsp;</td>\\n<td style=\\\"width: 10.1174%; height: 99px;\\\">&nbsp;</td>\\n<td style=\\\"width: 26.3926%; height: 99px;\\\">&nbsp;</td>\\n</tr>\\n</tbody>\\n</table>\\n</div>\\n</div>\\n</body>\\n</html>",
            projectModel);

    /**
     * testSearchTemplate
     */
    @Test
    void testSearchTemplate() {

        List<Template> templateList = new ArrayList<>();
        templateList.add(createdtemplate);
        templateList.add(template2);

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", false);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        RequestModel requestModel = RequestMapper.map(request1);

        when(templateRepository.findAll(requestModel.getFilterSpecification())).thenReturn(templateList);
        Object obj1 = templateService.searchTemplate(requestModel);
        assertThat((templateList.size() == '2'));
    }

    /**
     * testSaveTemplate
     */
    @Test
    void testSaveTemplate() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        TemplateModel templateModel = mapper.map(template1, TemplateModel.class);
        TemplateModel createdtemplateModel = mapper.map(createdtemplate, TemplateModel.class);

        List<Template> templateList = new ArrayList<>();
        templateList.add(createdtemplate);
        when(projectRepository.findById(templateModel.getProject().getId())).thenReturn(Optional.of(project));
        when(templateRepository.save(template1)).thenReturn(createdtemplate);
        assertThat(templateService.saveTemplate(templateModel)).isEqualTo(createdtemplateModel);
    }

    @Test
    void testSaveTemplateForProjectNull() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        TemplateModel templateModel = mapper.map(template1, TemplateModel.class);
        templateModel.setProject(null);
        templateModel.setContent(null);
        assertThrows(ApplicationFactoryException.class, () -> templateService.saveTemplate(templateModel), "");
    }

    @Test
    void testSaveTemplateForFindAll() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        List<Template> templateList = new ArrayList<>();
        templateList.add(template2);
        TemplateModel templateModel = mapper.map(template1, TemplateModel.class);
        when(templateRepository.findAll(Mockito.any(FilterSpecification.class))).thenReturn(templateList);
        assertThrows(ApplicationFactoryException.class, () -> templateService.saveTemplate(templateModel), "");
    }

    @Test
    void testUpdateTemplate() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true).setPropertyCondition(Conditions.isNotNull());
        Template updatedNewTemplate = mapper.map(updatedTemplateModel, Template.class);
        TemplateModel updatedNewTemplateModel = mapper.map(updatedNewTemplate, TemplateModel.class);
        when(templateRepository.save(updatedNewTemplate)).thenReturn(updatedNewTemplate);
        assertThat(templateService.updateTemplate(updatedTemplateModel)).isEqualTo(updatedNewTemplateModel);
    }

    @Test
    void testUpdateTemplateForProjectNull() {
        updatedTemplateModel.setProject(null);
        updatedTemplateModel.setContent(null);
        assertThrows(ApplicationFactoryException.class, () -> templateService.updateTemplate(updatedTemplateModel), "");
    }

    @Test
    void testDeleteTemplate() {
        when(templateRepository.findById(UUID.fromString("06ef2eb2-36c5-a4f4-b1aa-c9a1902a61c3")))
                .thenReturn(Optional.of(createdtemplate));
        templateService.deleteTemplate(UUID.fromString("06ef2eb2-36c5-a4f4-b1aa-c9a1902a61c3"));
        verify(templateRepository).delete(createdtemplate);
    }

    @Test
    void testDeleteTemplateForCatch() {
        when(templateRepository.findById(UUID.fromString("06ef2eb2-36c5-a4f4-b1aa-c9a1902a61c3")))
                .thenReturn(Optional.of(createdtemplate));
        doThrow(ApplicationFactoryException.class).when(templateRepository).delete(createdtemplate);
        assertThrows(ApplicationFactoryException.class,
                () -> templateService.deleteTemplate(UUID.fromString("06ef2eb2-36c5-a4f4-b1aa-c9a1902a61c3")), "");
    }

}
