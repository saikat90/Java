package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.instruction.service.InstructionsService;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.Project;
import com.alstom.applicationfactory.dwiservice.masterdata.entity.User;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FunctionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.ProjectRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProjectService;
import com.alstom.applicationfactory.dwiservice.masterdata.service.ProjectUserRoleService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(ProjectController.class)
class ProjectControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProjectRepository projectRepository;

    @MockBean
    private ProjectService projectService;
    @MockBean
    private ProjectUserRoleService projectUserRoleService;
    @MockBean
    private InstructionsService instructionService;

    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;

    @Autowired
    private WebApplicationContext context;

    ObjectMapper mapper = new ObjectMapper();

    UUID uuid = UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91");

    UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(null, 0, "Test Project", userObject1, true,
            new Date(), null, "test", null, null, null);

    ProjectModel createdProjectModel = new ProjectModel(
            UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", userObject1,
            true, new Date(), null, "test", null, null, null);

    ProjectModel updatedProjectModel = new ProjectModel(
            UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", userObject1,
            false, new Date(), null, "test", null, null, null);

    FunctionModel functionModel = new FunctionModel(
            UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e"), 0, "EHS", true, new Date(),
            null, "system", null);

    ProjectModel projectModelWithFunction = new ProjectModel(
            UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", userObject1,
            true, new Date(), null, "test", null, Arrays.asList(functionModel), null);

    Object updatedProjectModel_1 = new ProjectModel(
            UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", userObject1,
            false, new Date(), null, "test", null, null, null);

    /**
     * setup
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testFindAll() throws Exception {

        User userObject1 = new User(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
                "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");
        User userObject2 = new User(UUID.fromString("54c22bf5-dd12-9a00-7f1c-933bb85a5b2d"),
                "100769630", "User B", "LastName", "user.b@alstomgroup.com", "IS&T Project CoE");

        Project projectOject1 = new Project(UUID.fromString("2d9876f4-195b-7c29-a71c-b24ab7647a4d"),
                2, "ATK_KZ8A/KZ4A Alstom Traction 31Y", userObject1, true, new Date(), null,
                "415128", "dev", null, null);

        Project projectOject2 = new Project(UUID.fromString("394a6ba2-0988-17b3-560a-bc6e25a5776b"),
                0, "Ottawa_MTN_Railsystem", userObject2, true, new Date(), null, "415128", "dev",
                null, null);

        List<Project> projectList = new ArrayList<>();

        projectList.add(projectOject1);
        projectList.add(projectOject2);

        when(projectRepository.findAll()).thenReturn(projectList);

        RequestBuilder request = MockMvcRequestBuilders.get("/projects/list")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testCreateProject() throws Exception {

        String json = mapper.writeValueAsString(projectModel);

        when(projectService.createProject(projectModel)).thenReturn(createdProjectModel);

        RequestBuilder request = MockMvcRequestBuilders.post("/projects")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testUpdateProject() throws Exception {

        String json = mapper.writeValueAsString(updatedProjectModel);

        when(projectService.updateProject(updatedProjectModel)).thenReturn(updatedProjectModel);

        RequestBuilder request = MockMvcRequestBuilders.put("/projects")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());

    }

    /**
     * @throws Exception
     */
    @Test
    void testViewProject() throws Exception {

        when(projectService.viewProject(UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91")))
                .thenReturn(createdProjectModel);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/projects/35a0a465-6938-487f-997b-f43c7a6fea91")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteProjectById() throws Exception {

        RequestBuilder request = MockMvcRequestBuilders
                .delete("/projects/35a0a465-6938-487f-997b-f43c7a6fea91")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Disabled
    @Test
    void testDuplicateProject() throws Exception {

        String json = mapper.writeValueAsString(projectModel);

        when(projectService.createProject(projectModel)).thenReturn(createdProjectModel);

        RequestBuilder request = MockMvcRequestBuilders.post("/projects")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result1 = mockMvc.perform(request).andReturn();

        MvcResult result2 = mockMvc.perform(request).andExpect(status().is4xxClientError())
                .andReturn();
        assertEquals(Constants.TWO_HUNDRED, result2.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testAddFunction() throws Exception {
        String json = mapper.writeValueAsString(functionModel);

        when(projectService.addFunction(uuid, functionModel)).thenReturn(projectModelWithFunction);

        RequestBuilder request = MockMvcRequestBuilders
                .post("/projects/35a0a465-6938-487f-997b-f43c7a6fea91/function")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteFunction() throws Exception {

        when(projectService.deleteFunction(uuid,
                UUID.fromString("1716c8c4-4ea6-d0fb-8133-f479868b007e")))
                        .thenReturn(createdProjectModel);

        RequestBuilder request = MockMvcRequestBuilders.delete(
                "/projects/35a0a465-6938-487f-997b-f43c7a6fea91/function/1716c8c4-4ea6-d0fb-8133-f479868b007e")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testSearchProcess() throws Exception {

        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        // mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";

        RequestModel requestModel = RequestMapper.map(request1);
        when(projectService.searchProject(requestModel)).thenReturn(updatedProjectModel_1);
        RequestBuilder request = MockMvcRequestBuilders.post("/projects/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }
}
