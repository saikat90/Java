package com.alstom.applicationfactory.dwiservice.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alstom.applicationfactory.dwiservice.common.constant.Constants;
import com.alstom.applicationfactory.dwiservice.common.model.RequestModel;
import com.alstom.applicationfactory.dwiservice.config.AuthorizationConfig;
import com.alstom.applicationfactory.dwiservice.feign.client.AdminServiceClient;
import com.alstom.applicationfactory.dwiservice.masterdata.model.FleetModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProcessModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.ProjectModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.RevisionModel;
import com.alstom.applicationfactory.dwiservice.masterdata.model.UserModel;
import com.alstom.applicationfactory.dwiservice.masterdata.repository.RevisionRepository;
import com.alstom.applicationfactory.dwiservice.masterdata.service.RevisionService;
import com.alstom.applicationfactory.dwiservice.util.RequestMapper;
import com.alstom.applicationfactory.dwiservice.util.RequestModifier;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@WebMvcTest(RevisionController.class)
class RevisionControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AdminServiceClient adminServiceClient;
    @MockBean
    private AuthorizationConfig authConfig;
    @MockBean
    private JwtDecoder jwtDecoder;
    @Autowired
    private WebApplicationContext context;
    @MockBean
    private RevisionService revisionService;
    @MockBean
    private RevisionRepository revisionRepository;
    @MockBean
    private RequestModel requestModel;

    ObjectMapper mapper = new ObjectMapper();

    UserModel userObject1 = new UserModel(UUID.fromString("001ecd8a-d4aa-d81f-23d0-8b21d783a9df"),
            "100777182", "User A", "LastName", "user.ar@alstomgroup.com", "IS&T Project CoE");

    ProjectModel projectModel = new ProjectModel(
            UUID.fromString("35a0a465-6938-487f-997b-f43c7a6fea91"), 0, "Test Project", userObject1,
            true, new Date(), null, "test", null, null, null);

    FleetModel fleetModel = new FleetModel(UUID.fromString("a59cb76c-2d66-5d28-dd77-d252db143ba3"),
            0, "Test Fleet", projectModel, true, new Date(), null, "test", null);

    ProcessModel processModel = new ProcessModel(null, 0, "Test Process", fleetModel, true,
            new Date(), null, "test", null);

    RevisionModel revisionModel = new RevisionModel(null, 0, "Test Revision", true, new Date(),
            null, "test", null, processModel);
    RevisionModel createdRevisionModel = new RevisionModel(
            UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"), 0, "Test Revision", true,
            new Date(), null, "test", null, processModel);
    RevisionModel updatedRevisionModel = new RevisionModel(
            UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb"), 0, "Test Revision", false,
            new Date(), null, "test", null, processModel);

    /**
     * setup method
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        when(adminServiceClient.getAuthorities(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV", "APP_DWI",
                "test@alstomgroup.com")).thenReturn(Arrays.asList(new String("ROLE_ADM")));

        when(authConfig.getEmailProp()).thenReturn("test@alstomgroup.com");

        when(jwtDecoder.decode("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkN0VHV"))
                .thenReturn(null);

    }

    /**
     * @throws Exception
     */
    @Test
    void testCreateRevision() throws Exception {
        String json = mapper.writeValueAsString(revisionModel);
        when(revisionService.createRevision(revisionModel)).thenReturn(createdRevisionModel);
        RequestBuilder request = MockMvcRequestBuilders.post("/revision")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testUpdateRevision() throws Exception {
        String json = mapper.writeValueAsString(updatedRevisionModel);
        when(revisionService.updateRevision(updatedRevisionModel)).thenReturn(updatedRevisionModel);
        RequestBuilder request = MockMvcRequestBuilders.put("/revision")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testSearchRevision() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        RequestModel requestModel = RequestMapper.map(request1);
        String returnObject = "{\r\n" + "    \"pageNumber\": 0,\r\n" + "    \"pageSize\": 10,\r\n"
                + "    \"totalElements\": 2,\r\n" + "    \"totalPages\": 1,\r\n"
                + "    \"content\": [\r\n" + "        {\r\n"
                + "            \"id\": \"01ce25e8-6a91-b543-c8e9-43999a38fa52\",\r\n"
                + "            \"version\": 0,\r\n"
                + "            \"revisionName\": \"500 000 km\",\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2018-11-07T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2018-11-07T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"240620\",\r\n"
                + "            \"modifiedBy\": null,\r\n" + "            \"process\": {\r\n"
                + "                \"id\": \"bf6575da-d23d-3268-8199-c0dc239b291e\",\r\n"
                + "                \"version\": 0,\r\n"
                + "                \"processName\": \"Preventive-MTN10\",\r\n"
                + "                \"fleet\": {\r\n"
                + "                    \"id\": \"f341a9eb-0afd-e62a-57cf-ee878530c6e3\",\r\n"
                + "                    \"version\": 0,\r\n"
                + "                    \"fleetName\": \"Citadis\",\r\n"
                + "                    \"project\": {\r\n"
                + "                        \"id\": \"cbbb230f-b31d-d380-00ac-3a9488876b65\",\r\n"
                + "                        \"version\": 0,\r\n"
                + "                        \"projName\": \"Ottawa_MTN_Vehicle\",\r\n"
                + "                        \"projectManager\": {\r\n"
                + "                            \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "                            \"employeeId\": \"23139\",\r\n"
                + "                            \"firstName\": \"Alban\",\r\n"
                + "                            \"lastName\": \"HOUSSIN\",\r\n"
                + "                            \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "                            \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "                        },\r\n" + "                        \"active\": true,\r\n"
                + "                        \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                        \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                        \"createdBy\": \"413316\",\r\n"
                + "                        \"modifiedBy\": null,\r\n"
                + "                        \"projFunctions\": [],\r\n"
                + "                        \"projectUserRoles\": []\r\n"
                + "                    },\r\n" + "                    \"active\": true,\r\n"
                + "                    \"createdDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                    \"modifiedDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                    \"createdBy\": \"413316\",\r\n"
                + "                    \"modifiedBy\": null\r\n" + "                },\r\n"
                + "                \"active\": true,\r\n"
                + "                \"createdDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "                \"modifiedDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "                \"createdBy\": \"240620\",\r\n"
                + "                \"modifiedBy\": null\r\n" + "            }\r\n"
                + "        },\r\n" + "        {\r\n"
                + "            \"id\": \"023724d2-3416-02d9-63e1-c19fbf8850a7\",\r\n"
                + "            \"version\": 0,\r\n"
                + "            \"revisionName\": \"Quarterly\",\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2018-11-07T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2018-11-07T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"9827\",\r\n"
                + "            \"modifiedBy\": null,\r\n" + "            \"process\": {\r\n"
                + "                \"id\": \"61d1fd2d-2bd9-e48e-9549-b8d645a76775\",\r\n"
                + "                \"version\": 0,\r\n"
                + "                \"processName\": \"Custodial-MTN30\",\r\n"
                + "                \"fleet\": {\r\n"
                + "                    \"id\": \"424ba1b5-bdcf-e405-1b13-92662b7c12f3\",\r\n"
                + "                    \"version\": 0,\r\n"
                + "                    \"fleetName\": \"COMMS\",\r\n"
                + "                    \"project\": {\r\n"
                + "                        \"id\": \"394a6ba2-0988-17b3-560a-bc6e25a5776b\",\r\n"
                + "                        \"version\": 0,\r\n"
                + "                        \"projName\": \"Ottawa_MTN_Railsystem\",\r\n"
                + "                        \"projectManager\": {\r\n"
                + "                            \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "                            \"employeeId\": \"23139\",\r\n"
                + "                            \"firstName\": \"Alban\",\r\n"
                + "                            \"lastName\": \"HOUSSIN\",\r\n"
                + "                            \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "                            \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "                        },\r\n" + "                        \"active\": true,\r\n"
                + "                        \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                        \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                        \"createdBy\": \"413316\",\r\n"
                + "                        \"modifiedBy\": null,\r\n"
                + "                        \"projFunctions\": [],\r\n"
                + "                        \"projectUserRoles\": []\r\n"
                + "                    },\r\n" + "                    \"active\": true,\r\n"
                + "                    \"createdDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                    \"modifiedDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                    \"createdBy\": \"413316\",\r\n"
                + "                    \"modifiedBy\": null\r\n" + "                },\r\n"
                + "                \"active\": true,\r\n"
                + "                \"createdDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "                \"modifiedDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "                \"createdBy\": \"9827\",\r\n"
                + "                \"modifiedBy\": null\r\n" + "            }\r\n"
                + "        }]\r\n" + "}";

        Object obj = returnObject;

        when(revisionService.searchRevision(requestModel)).thenReturn(returnObject);
        RequestBuilder request = MockMvcRequestBuilders.post("/revision/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testViewRevision() throws Exception {
        when(revisionService.viewRevision(UUID.fromString("01775d61-425d-6629-ecf3-b8ed0a80b6cb")))
                .thenReturn(createdRevisionModel);
        RequestBuilder request = MockMvcRequestBuilders
                .get("/revision/01775d61-425d-6629-ecf3-b8ed0a80b6cb")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testDeleteRevisionById() throws Exception {
        RequestBuilder request = MockMvcRequestBuilders
                .delete("/revision/01775d61-425d-6629-ecf3-b8ed0a80b6cb")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

    /**
     * @throws Exception
     */
    @Test
    void testgetAllRevisionForProcess() throws Exception {
        Map<String, Object> request1 = new HashMap<>();
        request1.put("pageNumber", 0);
        request1.put("pageSize", 10);
        request1.put("isPaged", true);
        request1.put("filterJoins", null);
        request1.put("sort", null);

        UUID ProcessId = UUID.fromString("bf6575da-d23d-3268-8199-c0dc239b291e");
        String returnObject = "{\r\n"
                + "            \"id\": \"01ce25e8-6a91-b543-c8e9-43999a38fa52\",\r\n"
                + "            \"version\": 0,\r\n"
                + "            \"revisionName\": \"500 000 km\",\r\n"
                + "            \"active\": true,\r\n"
                + "            \"createdDate\": \"2018-11-07T00:00:00.000+0000\",\r\n"
                + "            \"modifiedDate\": \"2018-11-07T00:00:00.000+0000\",\r\n"
                + "            \"createdBy\": \"240620\",\r\n"
                + "            \"modifiedBy\": null,\r\n" + "            \"process\": {\r\n"
                + "                \"id\": \"bf6575da-d23d-3268-8199-c0dc239b291e\",\r\n"
                + "                \"version\": 0,\r\n"
                + "                \"processName\": \"Preventive-MTN10\",\r\n"
                + "                \"fleet\": {\r\n"
                + "                    \"id\": \"f341a9eb-0afd-e62a-57cf-ee878530c6e3\",\r\n"
                + "                    \"version\": 0,\r\n"
                + "                    \"fleetName\": \"Citadis\",\r\n"
                + "                    \"project\": {\r\n"
                + "                        \"id\": \"cbbb230f-b31d-d380-00ac-3a9488876b65\",\r\n"
                + "                        \"version\": 0,\r\n"
                + "                        \"projName\": \"Ottawa_MTN_Vehicle\",\r\n"
                + "                        \"projectManager\": {\r\n"
                + "                            \"id\": \"390f980b-89b4-2e1c-27d5-cb4b03c68005\",\r\n"
                + "                            \"employeeId\": \"23139\",\r\n"
                + "                            \"firstName\": \"Alban\",\r\n"
                + "                            \"lastName\": \"HOUSSIN\",\r\n"
                + "                            \"email\": \"alban.houssin@alstomgroup.com\",\r\n"
                + "                            \"department\": \"HQ-Operational Excellence-OPEX\"\r\n"
                + "                        },\r\n" + "                        \"active\": true,\r\n"
                + "                        \"createdDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                        \"modifiedDate\": \"2019-08-12T00:00:00.000+0000\",\r\n"
                + "                        \"createdBy\": \"413316\",\r\n"
                + "                        \"modifiedBy\": null,\r\n"
                + "                        \"projFunctions\": [],\r\n"
                + "                        \"projectUserRoles\": []\r\n"
                + "                    },\r\n" + "                    \"active\": true,\r\n"
                + "                    \"createdDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                    \"modifiedDate\": \"2018-11-06T00:00:00.000+0000\",\r\n"
                + "                    \"createdBy\": \"413316\",\r\n"
                + "                    \"modifiedBy\": null\r\n" + "                },\r\n"
                + "                \"active\": true,\r\n"
                + "                \"createdDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "                \"modifiedDate\": \"2019-01-23T00:00:00.000+0000\",\r\n"
                + "                \"createdBy\": \"240620\",\r\n"
                + "                \"modifiedBy\": null\r\n" + "            }\r\n" + "        }";
        Object obj = returnObject;
        String json = "{\"pageNumber\":0,\"pageSize\":10,\"isPaged\":true,\"filterJoins\":null,\"sort\":null}";
        request1 = RequestModifier.defaultRequestMapIfEmpty(request1);
        List<Map<String, Object>> filterConditions = new ArrayList<>();
        filterConditions.add(RequestModifier.getfilterCondition("UUID", "process.id", ProcessId));
        RequestModel requestModel = RequestMapper
                .map(RequestModifier.updateRequestMapWithAnd(request1, filterConditions));
        when(revisionService.searchRevision(requestModel)).thenReturn(obj);
        RequestBuilder request = MockMvcRequestBuilders
                .post("/revision/bf6575da-d23d-3268-8199-c0dc239b291e/list")
                .accept(MediaType.APPLICATION_JSON).content(json)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request).andExpect(status().isOk()).andReturn();
        assertEquals(Constants.TWO_HUNDRED, result.getResponse().getStatus());
    }

}
